"""그룹 종류의 서버 저장(nexus-server 0.1.29 `GET`/`PATCH /datasets/{id}/group-kinds`, SDK 0.1.25).

한 번 선언하면 그 dataset 을 여는 모든 핸들이 같은 종류로 읽는다.
"""
import warnings

import pytest

from nexus._types import NexusError
from nexus.cas import CasClient
from nexus.client import NexusClient
from nexus.dataset import Dataset
from nexus.group import LabelContainer, RawGroup

BASE = "http://nexus"
KINDS_URL = f"{BASE}/datasets/d1/group-kinds"


@pytest.fixture
def client(requests_mock):
    requests_mock.post(f"{BASE}/api/v1/auth/login",
                       json={"token": "tok", "user_id": 1, "email": "u@x.com"})
    return NexusClient(BASE, "u@x.com", "pass")


@pytest.fixture
def cas():
    return CasClient("http://cas")


def _existing(requests_mock):
    requests_mock.get(f"{BASE}/datasets", json=[{"dataset_id": "d1", "name": "kitti"}])
    requests_mock.get(f"{BASE}/datasets/d1", json={"dataset_id": "d1", "name": "kitti", "tags": []})
    requests_mock.get(f"{BASE}/datasets/d1/versions/v1", json={"version": "v1", "status": "draft"})


def test_open_reads_stored_kinds(client, cas, requests_mock):
    _existing(requests_mock)
    requests_mock.get(KINDS_URL, json={"kinds": {"dets": "container"}})
    ds = Dataset.open("d1", "v1", client=client, cas=cas)
    requests_mock.get(f"{BASE}/datasets/d1/versions/v1/samples/s1", json={
        "sample_id": "s1", "tags": [], "meta": {},
        "dets": [{"id": "a", "label": "car", "bounding_box": {"type": "bounding_box", "rect": [0, 0, 1, 1]}}],
        "raw": [{"id": "b", "label": "x"}],
    })
    s = ds.load_sample("s1")
    assert isinstance(s.get_group("dets"), LabelContainer)
    assert isinstance(s.get_group("raw"), RawGroup)


def test_load_or_create_reads_stored_kinds(client, cas, requests_mock):
    _existing(requests_mock)
    requests_mock.get(KINDS_URL, json={"kinds": {"dets": "group"}})
    ds = Dataset.load_or_create("kitti", "v1", client=client, cas=cas)
    assert ds._group_kinds == {"dets": "group"}


def test_unknown_stored_kind_is_ignored(client, cas, requests_mock):
    # 뒤 판 서버가 새 종류를 더해도 이 SDK 가 열기에서 죽지 않는다 — 모르는 종류는 RawGroup 으로 둔다.
    _existing(requests_mock)
    requests_mock.get(KINDS_URL, json={"kinds": {"dets": "container", "new": "future_kind"}})
    ds = Dataset.open("d1", "v1", client=client, cas=cas)
    assert ds._group_kinds == {"dets": "container"}


def test_old_server_without_route_opens_with_no_kinds(client, cas, requests_mock):
    _existing(requests_mock)
    requests_mock.get(KINDS_URL, status_code=404, text="")
    with warnings.catch_warnings():
        warnings.simplefilter("error")
        ds = Dataset.open("d1", "v1", client=client, cas=cas)
    assert ds._group_kinds == {}


def test_declare_saves_to_server(client, cas, requests_mock):
    _existing(requests_mock)
    requests_mock.get(KINDS_URL, json={"kinds": {}})
    m = requests_mock.patch(KINDS_URL, json={"kinds": {"dets": "container", "other": "group"}})
    ds = Dataset.open("d1", "v1", client=client, cas=cas)
    ds.declare_group_kinds({"dets": "container"})
    assert m.last_request.json() == {"kinds": {"dets": "container"}}
    # 저장 뒤의 전체(다른 곳에서 더한 것 포함)를 핸들에 반영한다.
    assert ds._group_kinds == {"dets": "container", "other": "group"}


def test_load_or_create_group_kinds_saves(client, cas, requests_mock):
    _existing(requests_mock)
    requests_mock.get(KINDS_URL, json={"kinds": {}})
    m = requests_mock.patch(KINDS_URL, json={"kinds": {"dets": "group"}})
    ds = Dataset.load_or_create("kitti", "v1", client=client, cas=cas, group_kinds={"dets": "group"})
    assert m.called and ds._group_kinds == {"dets": "group"}


def test_load_or_create_same_stored_kinds_sends_nothing(client, cas, requests_mock):
    # viewer 가 이미 같은 값인 dataset 을 열어도 요청 0·경고 0.
    _existing(requests_mock)
    requests_mock.get(KINDS_URL, json={"kinds": {"dets": "group", "other": "container"}})
    m = requests_mock.patch(KINDS_URL, status_code=403, json={"error": "forbidden"})
    with warnings.catch_warnings():
        warnings.simplefilter("error")
        ds = Dataset.load_or_create("kitti", "v1", client=client, cas=cas, group_kinds={"dets": "group"})
    assert not m.called
    assert ds._group_kinds == {"dets": "group", "other": "container"}


def test_load_or_create_sends_only_changed_keys(client, cas, requests_mock):
    _existing(requests_mock)
    requests_mock.get(KINDS_URL, json={"kinds": {"dets": "group", "segs": "group"}})
    m = requests_mock.patch(KINDS_URL, json={"kinds": {"dets": "group", "segs": "container", "new": "group"}})
    ds = Dataset.load_or_create("kitti", "v1", client=client, cas=cas,
                                group_kinds={"dets": "group", "segs": "container", "new": "group"})
    assert m.call_count == 1
    assert m.last_request.json() == {"kinds": {"segs": "container", "new": "group"}}
    assert ds._group_kinds == {"dets": "group", "segs": "container", "new": "group"}


def test_load_or_create_sends_all_when_stored_kinds_unreadable(client, cas, requests_mock):
    _existing(requests_mock)
    requests_mock.get(KINDS_URL, status_code=404, text="")
    m = requests_mock.patch(KINDS_URL, json={"kinds": {"dets": "group"}})
    Dataset.load_or_create("kitti", "v1", client=client, cas=cas, group_kinds={"dets": "group"})
    assert m.last_request.json() == {"kinds": {"dets": "group"}}


def test_declare_response_does_not_override_handle_only_keys(client, cas, requests_mock):
    # 롤링 교체: 첫 선언은 옛 파드(404)라 핸들에만 두고, 다음 선언은 새 파드가 저장한다. 그 응답에
    # 다른 스크립트가 저장한 같은 키의 다른 값이 있어도 이 핸들의 선언이 이긴다.
    _existing(requests_mock)
    requests_mock.get(KINDS_URL, json={"kinds": {}})
    ds = Dataset.open("d1", "v1", client=client, cas=cas)
    requests_mock.patch(KINDS_URL, status_code=404, text="")
    with pytest.warns(RuntimeWarning, match="0.1.28 이하"):
        ds.declare_group_kinds({"dets": "container"})
    requests_mock.patch(KINDS_URL, json={"kinds": {"dets": "group", "segs": "group", "other": "container"}})
    ds.declare_group_kinds({"segs": "group"})
    assert ds._group_kinds == {"dets": "container", "segs": "group", "other": "container"}


def test_declare_response_does_not_override_unstorable_handle_keys(client, cas, requests_mock):
    _existing(requests_mock)
    requests_mock.get(KINDS_URL, json={"kinds": {}})
    requests_mock.patch(KINDS_URL, json={"kinds": {"det": "container"}})
    ds = Dataset.open("d1", "v1", client=client, cas=cas)
    with pytest.warns(RuntimeWarning, match="받지 않는 키"):
        ds.declare_group_kinds({"tags": "group", "det": "container"})
    assert ds._group_kinds == {"tags": "group", "det": "container"}


def test_declare_on_old_server_keeps_handle_only_and_warns_once(client, cas, requests_mock):
    _existing(requests_mock)
    requests_mock.get(KINDS_URL, status_code=404, text="")
    requests_mock.patch(KINDS_URL, status_code=404, text="")
    ds = Dataset.open("d1", "v1", client=client, cas=cas)
    with pytest.warns(RuntimeWarning, match="0.1.28 이하") as rec:
        ds.declare_group_kinds({"dets": "container"})
        ds.declare_group_kinds({"more": "group"})
    assert len(rec) == 1
    assert ds._group_kinds == {"dets": "container", "more": "group"}


def test_declare_as_viewer_keeps_handle_only_and_warns(client, cas, requests_mock):
    _existing(requests_mock)
    requests_mock.get(KINDS_URL, json={"kinds": {}})
    requests_mock.patch(KINDS_URL, status_code=403, json={"error": "forbidden"})
    ds = Dataset.open("d1", "v1", client=client, cas=cas)
    with pytest.warns(RuntimeWarning, match="저장하지 못했"):
        ds.declare_group_kinds({"dets": "container"})
    assert ds._group_kinds == {"dets": "container"}


def test_declare_other_server_error_raises_and_keeps_handle_unchanged(client, cas, requests_mock):
    _existing(requests_mock)
    requests_mock.get(KINDS_URL, json={"kinds": {}})
    requests_mock.patch(KINDS_URL, status_code=400, json={"error": "kinds 는 객체여야 합니다"})
    ds = Dataset.open("d1", "v1", client=client, cas=cas)
    with pytest.raises(NexusError) as ei:
        ds.declare_group_kinds({"dets": "group"})
    assert ei.value.status_code == 400
    assert ds._group_kinds == {}


def test_empty_declaration_sends_nothing(client, cas, requests_mock):
    _existing(requests_mock)
    m = requests_mock.patch(KINDS_URL, json={"kinds": {}})
    ds = Dataset.open("d1", "v1", client=client, cas=cas)
    ds.declare_group_kinds({})
    assert not m.called



@pytest.mark.parametrize("key", ["tags", "split", "sample_id", "meta", " pad", "x" * 129, ""])
def test_keys_the_server_rejects_stay_on_the_handle(client, cas, requests_mock, key):
    # 서버는 이 키들을 400 으로 거부한다 — 보내면 요청의 다른 키까지 저장되지 않는다. 그런 이름의 그룹은 annotation 에 있을 수 있다.
    _existing(requests_mock)
    requests_mock.get(KINDS_URL, json={"kinds": {}})
    m = requests_mock.patch(KINDS_URL, json=lambda req, ctx: {"kinds": req.json()["kinds"]})
    ds = Dataset.open("d1", "v1", client=client, cas=cas)
    with pytest.warns(RuntimeWarning, match="받지 않는 키"):
        ds.declare_group_kinds({key: "group", "det": "container"})
    assert m.last_request.json() == {"kinds": {"det": "container"}}
    assert ds._group_kinds == {key: "group", "det": "container"}


def test_load_or_create_with_unstorable_key_does_not_fail_after_creating(client, cas, requests_mock):
    requests_mock.get(f"{BASE}/datasets", json=[])
    requests_mock.post(f"{BASE}/datasets", json={"dataset_id": "d1", "name": "new"}, status_code=201)
    requests_mock.get(f"{BASE}/datasets/d1/versions/v1", status_code=404, json={"error": "no version"})
    requests_mock.post(f"{BASE}/datasets/d1/versions", json={"version": "v1"}, status_code=201)
    requests_mock.get(KINDS_URL, json={"kinds": {}})
    requests_mock.patch(KINDS_URL, json=lambda req, ctx: {"kinds": req.json()["kinds"]})
    with pytest.warns(RuntimeWarning):
        ds = Dataset.load_or_create("new", "v1", client=client, cas=cas,
                                    group_kinds={"tags": "group", "det": "group"})
    assert ds._group_kinds == {"tags": "group", "det": "group"}


def test_more_than_256_keys_are_sent_in_chunks(client, cas, requests_mock):
    _existing(requests_mock)
    requests_mock.get(KINDS_URL, json={"kinds": {}})
    m = requests_mock.patch(KINDS_URL, json=lambda req, ctx: {"kinds": req.json()["kinds"]})
    ds = Dataset.open("d1", "v1", client=client, cas=cas)
    kinds = {f"g{i:03d}": "group" for i in range(300)}
    ds.declare_group_kinds(kinds)
    assert [len(r.json()["kinds"]) for r in m.request_history] == [256, 44]
    assert ds._group_kinds == kinds


def test_open_survives_group_kinds_read_failure(client, cas, requests_mock):
    _existing(requests_mock)
    requests_mock.get(KINDS_URL, status_code=400, json={"error": "boom"})
    with pytest.warns(RuntimeWarning, match="그룹 종류를 읽지 못했"):
        ds = Dataset.open("d1", "v1", client=client, cas=cas)
    assert ds._group_kinds == {}


def test_fork_does_not_save_kinds_again_and_reads_server_kinds(client, cas, requests_mock):
    _existing(requests_mock)
    requests_mock.get(KINDS_URL, json={"kinds": {}})
    patch = requests_mock.patch(KINDS_URL, json=lambda req, ctx: {"kinds": req.json()["kinds"]})
    ds = Dataset.open("d1", "v1", client=client, cas=cas)
    ds.declare_group_kinds({"dets": "container"})
    # 원본 핸들을 연 뒤 다른 스크립트가 더한 선언도 새 핸들이 읽는다.
    requests_mock.get(KINDS_URL, json={"kinds": {"dets": "container", "other": "group"}})
    requests_mock.get(f"{BASE}/datasets/d1/versions/v2", status_code=404, json={"error": "no version"})
    requests_mock.post(f"{BASE}/datasets/d1/versions", json={"version": "v2"}, status_code=201)
    new = ds.fork("v2")
    assert patch.call_count == 1
    assert new._group_kinds == {"dets": "container", "other": "group"}


def test_subset_to_version_reads_server_kinds(client, cas, requests_mock):
    from nexus.dataset import Subset
    _existing(requests_mock)
    requests_mock.get(KINDS_URL, json={"kinds": {}})
    ds = Dataset.open("d1", "v1", client=client, cas=cas)
    requests_mock.get(KINDS_URL, json={"kinds": {"other": "group"}})
    requests_mock.post(f"{BASE}/subsets/s1/version", json={"version": "v3"})
    patch = requests_mock.patch(KINDS_URL, json={"kinds": {}})
    sub = Subset(ds, {"subset_id": "s1", "name": "a", "version": "v1", "filter_json": {}})
    out = sub.to_version("v3")
    assert out._group_kinds == {"other": "group"} and not patch.called
