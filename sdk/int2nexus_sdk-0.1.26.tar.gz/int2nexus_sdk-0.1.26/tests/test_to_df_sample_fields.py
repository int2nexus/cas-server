"""`to_df(sample_fields=True)` — seal 시점 `tags`·`split` 열(SDK 0.1.25, follow-ups 24 절 6번).

sealed 는 seal 이 CAS 에 쓴 메인 manifest(`GET .../manifest` 의 `main_manifest`, nexus-server 0.1.29 부터)를 읽고,
draft 는 explorer 행의 지금 값을 싣는다.
"""
import json

import blake3
import pytest

from nexus._types import NexusError
from tests.test_dataset import (
    _desc_pages, _draft_client, _ds, _register_snapshot, _require_signature, _signed_cas,
)

_MAIN_KEY = "nexus-manifests/manifests/d1/ver-1/abc.json"


def _main_manifest(samples):
    return json.dumps({
        "dataset_id": "d1", "dataset_name": "kitti", "version": "v1",
        "sealed_at": "2026-10-20T00:00:00Z", "manifest_hash": "", "annotation_snapshot": None,
        "samples": samples,
    }, indent=2).encode()


def _sealed(requests_mock, *, body=None, hash_hex=None, with_location=True):
    mock_client, _ = _register_snapshot(requests_mock)
    body = body if body is not None else _main_manifest([
        {"sample_id": "s1", "split": "train", "tags": ["a", "b"], "assets": {}},
        {"sample_id": "s2", "split": None, "tags": [], "assets": {}},
    ])
    requests_mock.get(f"http://cas/{_MAIN_KEY}", content=_require_signature(body))
    if with_location:
        mock_client.get_manifest.return_value["main_manifest"] = {
            "cas_url": f"http://cas/{_MAIN_KEY}",
            "hash_hex": blake3.blake3(body).hexdigest() if hash_hex is None else hash_hex,
        }
    return mock_client


def test_sealed_adds_seal_time_tags_and_split(requests_mock):
    ds = _ds(_sealed(requests_mock), _signed_cas())
    df = ds.to_df(sample_fields=True)
    assert list(df["tags"]) == [["a", "b"], []]
    assert list(df["split"]) == ["train", None]


def test_fingerprint_attr_ignores_sample_fields(requests_mock):
    ds = _ds(_sealed(requests_mock), _signed_cas())
    assert ds.to_df(sample_fields=True).attrs["nexus_fingerprint"] == ds.to_df().attrs["nexus_fingerprint"]


def test_default_does_not_read_main_manifest(requests_mock):
    ds = _ds(_sealed(requests_mock), _signed_cas())
    df = ds.to_df()
    assert "tags" not in df.columns and "split" not in df.columns
    assert not any(r.path.endswith("abc.json") for r in requests_mock.request_history)


def test_sealed_chunksize_also_adds_columns(requests_mock):
    ds = _ds(_sealed(requests_mock), _signed_cas())
    (chunk,) = list(ds.to_df(sample_fields=True, chunksize=10))
    assert list(chunk["split"]) == ["train", None]


def test_hash_mismatch_leaves_columns_empty_and_warns(requests_mock):
    # 0.1.23 이하 seal 의 이름 기반 키는 rename·재생성으로 덮였을 수 있다 — 다른 seal 의 값을 싣지 않는다.
    ds = _ds(_sealed(requests_mock, hash_hex="0" * 64), _signed_cas())
    with pytest.warns(RuntimeWarning, match="해시"):
        df = ds.to_df(sample_fields=True)
    assert list(df["tags"]) == [None, None] and list(df["split"]) == [None, None]


def test_old_server_without_location_raises(requests_mock):
    ds = _ds(_sealed(requests_mock, with_location=False), _signed_cas())
    with pytest.raises(NexusError, match="0.1.29"):
        ds.to_df(sample_fields=True)


def test_group_named_tags_conflicts(requests_mock):
    ds = _ds(_sealed(requests_mock), _signed_cas())
    with pytest.raises(ValueError, match="tags"):
        ds.to_df(groups=["tags"], sample_fields=True)


@pytest.mark.parametrize("sealed", [True, False])
def test_observed_tags_group_conflicts_before_any_download(requests_mock, sealed, recwarn):
    # groups 가 없으면 dataset 에서 관측된 그룹 키로 받기 전에 판정한다 — draft·sealed 가 같은 결과다.
    mock_client = _sealed(requests_mock) if sealed else _draft_client(_desc_pages(2))
    mock_client.version_schema.return_value = {"sample_fields": {"meta": {}, "split": {}, "box": {}}}
    ds = _ds(mock_client, _signed_cas())
    with pytest.raises(ValueError, match="split"):
        ds.to_df(sample_fields=True)
    assert not mock_client.get_manifest.called
    assert not mock_client.explore_samples.called
    assert not [r for r in requests_mock.request_history if "cas" in r.netloc]


def test_groups_without_conflict_skip_schema(requests_mock):
    mock_client = _sealed(requests_mock)
    df = _ds(mock_client, _signed_cas()).to_df(groups=["seatbelt"], sample_fields=True)
    assert list(df["split"]) == ["train", None]
    assert not mock_client.version_schema.called


def test_draft_uses_current_values(recwarn):
    pages = _desc_pages(2)
    for row in pages[0]:  # 행마다 다른 값 — 샘플과 값의 짝이 어긋나면 걸린다
        row["split"], row["tags"] = f"split-{row['sample_id']}", [row["sample_id"]]
    mock_client = _draft_client(pages)
    df = _ds(mock_client, None).to_df(sample_fields=True)
    for sid, split, tags in zip(df["sample_id"], df["split"], df["tags"]):
        assert split == f"split-{sid}" and tags == [sid]
    assert not {"created_at", "image_url", "thumbnail_url"} & set(df.columns)
    mock_client.get_manifest.assert_called_once()


def test_draft_fingerprint_attr_ignores_sample_fields(recwarn):
    a = _ds(_draft_client(_desc_pages(2)), None).to_df(sample_fields=True).attrs["nexus_fingerprint"]
    b = _ds(_draft_client(_desc_pages(2)), None).to_df().attrs["nexus_fingerprint"]
    assert a == b
