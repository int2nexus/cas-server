"""롤링 교체 중 옛 파드 응답의 원인을 경고 문구에 적는다(SDK 0.1.25, follow-ups 24 절 9번).

서버 판은 응답 헤더 `X-Nexus-Version`(nexus-server 0.1.29 부터, 인증된 응답에만)으로 안다.
"""
import warnings

import pytest

from nexus._types import NexusError
from nexus.cas import CasClient
from nexus.client import NexusClient
from nexus.dataset import Dataset

BASE = "http://nexus"
VER = f"{BASE}/datasets/d1/versions/v1"


@pytest.fixture
def ds(requests_mock):
    requests_mock.post(f"{BASE}/api/v1/auth/login",
                       json={"token": "tok", "user_id": 1, "email": "u@x.com"})
    return Dataset(NexusClient(BASE, "u@x.com", "pass"), CasClient("http://cas"), "d1", "kitti", "v1")


def _counts(n, *, computed=True, truncated=False):
    return {"field": "tags", "computed": computed, "truncated": truncated,
            "counts": [{"value": f"t{i}", "count": 1} for i in range(n)]}


def test_truncated_at_500_names_old_pod(ds, requests_mock):
    requests_mock.post(f"{VER}/facets/counts", json=_counts(500, truncated=True))
    with pytest.warns(RuntimeWarning, match="0.1.23 이하") as rec:
        ds.count_values("tags")
    assert "롤링 교체" in str(rec[0].message)


def test_truncated_on_new_pod_names_new_limit_only(ds, requests_mock):
    requests_mock.post(f"{VER}/facets/counts", json=_counts(3, truncated=True),
                       headers={"X-Nexus-Version": "0.1.29"})
    with pytest.warns(RuntimeWarning) as rec:
        ds.count_values("tags")
    msg = str(rec[0].message)
    assert "100,000" in msg and "0.1.23 이하" not in msg


def test_truncated_at_500_with_new_version_header_is_not_old_pod(ds, requests_mock):
    # 새 파드는 100,000 에서 자르므로 500 개로 잘렸다는 사실만으로 옛 파드라고 하지 않는다 — 헤더가 이긴다.
    requests_mock.post(f"{VER}/facets/counts", json=_counts(500, truncated=True),
                       headers={"X-Nexus-Version": "0.1.30"})
    with pytest.warns(RuntimeWarning) as rec:
        ds.count_values("tags")
    assert "0.1.23 이하" not in str(rec[0].message)


def test_not_computed_quickly_without_header_suspects_old_pod(ds, requests_mock):
    requests_mock.post(f"{VER}/facets/counts", json=_counts(0, computed=False))
    with pytest.raises(NexusError, match="3 초") as ei:
        ds.count_values("tags")
    assert "롤링 교체" in str(ei.value)


def test_not_computed_on_new_pod_names_50s(ds, requests_mock):
    requests_mock.post(f"{VER}/facets/counts", json=_counts(0, computed=False),
                       headers={"X-Nexus-Version": "0.1.29"})
    with pytest.raises(NexusError) as ei:
        ds.count_values("tags")
    assert "50 초" in str(ei.value) and "롤링 교체" not in str(ei.value)


def test_untruncated_result_does_not_warn(ds, requests_mock):
    requests_mock.post(f"{VER}/facets/counts", json=_counts(500))
    with warnings.catch_warnings():
        warnings.simplefilter("error")
        assert len(ds.count_values("tags")) == 500


def test_set_values_per_sample_fallback_warns_once_per_call(ds, requests_mock):
    requests_mock.patch(f"{VER}/samples/meta", status_code=405, json={"error": "method not allowed"})
    for sid in ("s1", "s2"):
        requests_mock.patch(f"{VER}/samples/{sid}/annotations", json={"skipped": 0})
    with pytest.warns(RuntimeWarning, match="샘플별") as rec:
        assert ds.set_values("meta.k", {"s1": 1, "s2": 2}) == 2
    assert len([w for w in rec if issubclass(w.category, RuntimeWarning)]) == 1
    assert "전부 또는 없음" in str(rec[0].message)


def test_set_values_fallback_warns_once_across_chunks_at_the_callers_line(ds, requests_mock):
    import re
    requests_mock.patch(f"{VER}/samples/meta", status_code=405, json={"error": "method not allowed"})
    requests_mock.patch(re.compile(r"/samples/s\d+/annotations$"), json={"skipped": 0})
    values = {f"s{i}": i for i in range(10_001)}  # 청크 둘
    with pytest.warns(RuntimeWarning, match="샘플별") as rec:
        ds.set_values("meta.k", values)
    mine = [w for w in rec if "샘플별" in str(w.message)]
    assert len(mine) == 1
    assert mine[0].filename == __file__


def test_set_values_fallback_after_413_split_still_points_at_caller(ds, requests_mock):
    import re
    calls = {"n": 0}

    def bulk(request, context):
        calls["n"] += 1
        context.status_code = 413 if calls["n"] == 1 else 405
        return {"error": "x"}
    requests_mock.patch(f"{VER}/samples/meta", json=bulk)
    requests_mock.patch(re.compile(r"/samples/s\d+/annotations$"), json={"skipped": 0})
    with pytest.warns(RuntimeWarning, match="샘플별") as rec:
        ds.set_values("meta.k", {"s1": 1, "s2": 2})
    assert [w.filename for w in rec if "샘플별" in str(w.message)] == [__file__]


def test_set_values_bulk_path_does_not_warn(ds, requests_mock):
    requests_mock.patch(f"{VER}/samples/meta", json={"updated": 1})
    with warnings.catch_warnings():
        warnings.simplefilter("error")
        assert ds.set_values("meta.k", {"s1": 1}) == 1
