"""seal·fork 의 202(대기 작업) 처리와 `get_version_job`."""

import pytest

import nexus
from nexus._types import NexusError, NexusVersionJobPending
from nexus.client import NexusClient

NEXUS = "http://nexus-test"
DS = "d1"
SEAL = f"{NEXUS}/datasets/{DS}/versions/v1/seal"
VERSIONS = f"{NEXUS}/datasets/{DS}/versions"
VERSION = f"{NEXUS}/datasets/{DS}/versions/v1"
JOB = f"{NEXUS}/api/v1/version-jobs/j1"


def job(state, **kw):
    return {"job_id": "j1", "kind": "seal", "state": state, "queue_position": 1, **kw}


@pytest.fixture
def sleeps(monkeypatch):
    out = []
    monkeypatch.setattr("nexus.client.time.sleep", lambda s: out.append(s))
    return out


@pytest.fixture
def client(requests_mock):
    requests_mock.post(f"{NEXUS}/api/v1/auth/login", json={"token": "tok"})
    return NexusClient(NEXUS, "u@x.com", "pw")


def accepted(requests_mock, url, state="queued"):
    requests_mock.post(
        url,
        status_code=202,
        headers={"Location": "/api/v1/version-jobs/j1"},
        json={"job": job(state), "version": {"version": "v1", "status": "draft"}},
    )


def test_seal_200_is_unchanged(requests_mock, client, sleeps):
    requests_mock.post(SEAL, json={"status": "sealed"})
    assert client.seal(DS, "v1")["status"] == "sealed"
    assert sleeps == []


def test_seal_202_polls_every_2s_then_returns_sealed_version(requests_mock, client, sleeps):
    accepted(requests_mock, SEAL)
    m = requests_mock.get(JOB, [{"json": job("queued")}, {"json": job("running")}, {"json": job("done")}])
    requests_mock.get(VERSION, json={"version": "v1", "status": "sealed"})
    assert client.seal(DS, "v1")["status"] == "sealed"
    assert m.call_count == 3
    assert sleeps == [2.0, 2.0]


def test_seal_202_failed_raises_409_with_job_error(requests_mock, client, sleeps):
    accepted(requests_mock, SEAL)
    requests_mock.get(JOB, json=job("failed", error="cas down"))
    with pytest.raises(NexusError) as e:
        client.seal(DS, "v1")
    assert e.value.status_code == 409
    assert e.value.server_message == "cas down"


def test_seal_202_cancelled_raises_409(requests_mock, client, sleeps):
    accepted(requests_mock, SEAL)
    requests_mock.get(JOB, json=job("cancelled", error="cancelled by u"))
    with pytest.raises(NexusError) as e:
        client.seal(DS, "v1")
    assert e.value.status_code == 409


def test_seal_202_timeout_raises_pending_with_job_id(requests_mock, client, sleeps):
    accepted(requests_mock, SEAL)
    requests_mock.get(JOB, json=job("running"))
    with pytest.raises(NexusVersionJobPending) as e:
        client.seal(DS, "v1", wait=5)
    assert e.value.job_id == "j1"
    assert e.value.job["state"] == "running"
    assert isinstance(e.value, NexusError)
    assert sum(sleeps) <= 5
    assert nexus.NexusVersionJobPending is NexusVersionJobPending


def test_seal_202_block_false_returns_body(requests_mock, client, sleeps):
    accepted(requests_mock, SEAL)
    m = requests_mock.get(JOB, json=job("done"))
    out = client.seal(DS, "v1", block=False)
    assert out["job"]["job_id"] == "j1" and out["version"]["version"] == "v1"
    assert m.call_count == 0


def test_job_404_while_polling_sealed_version_counts_as_done(requests_mock, client, sleeps):
    accepted(requests_mock, SEAL)
    requests_mock.get(JOB, status_code=404, json={"error": "not found"})
    requests_mock.get(VERSION, json={"version": "v1", "status": "sealed"})
    assert client.seal(DS, "v1")["status"] == "sealed"


def test_job_404_while_polling_draft_version_raises(requests_mock, client, sleeps):
    accepted(requests_mock, SEAL)
    requests_mock.get(JOB, status_code=404, json={"error": "not found"})
    requests_mock.get(VERSION, json={"version": "v1", "status": "draft"})
    with pytest.raises(NexusError) as e:
        client.seal(DS, "v1")
    assert e.value.status_code == 409


def test_get_version_job(requests_mock, client):
    requests_mock.get(JOB, json=job("running", stage="shards"))
    assert client.get_version_job("j1")["stage"] == "shards"


def test_old_server_429_seal_busy_still_retries(requests_mock, client, sleeps):
    requests_mock.post(
        SEAL,
        [
            {"status_code": 429, "headers": {"Retry-After": "10"}, "json": {"error": "busy", "code": "seal_busy"}},
            {"json": {"status": "sealed"}},
        ],
    )
    assert client.seal(DS, "v1")["status"] == "sealed"


def test_create_version_201_unchanged(requests_mock, client, sleeps):
    requests_mock.post(VERSIONS, status_code=201, json={"version": "v2", "status": "draft"})
    assert client.create_version(DS, "v2", fork_from="v1")["version"] == "v2"


def test_create_version_202_waits_for_done_and_returns_draft(requests_mock, client, sleeps):
    accepted(requests_mock, VERSIONS)
    requests_mock.get(JOB, [{"json": job("running")}, {"json": job("done")}])
    requests_mock.get(f"{NEXUS}/datasets/{DS}/versions/v2", json={"version": "v2", "status": "draft"})
    out = client.create_version(DS, "v2", fork_from="v1")
    assert out["version"] == "v2" and out["status"] == "draft"


def test_create_version_202_timeout_and_block_false(requests_mock, client, sleeps):
    accepted(requests_mock, VERSIONS)
    requests_mock.get(JOB, json=job("queued"))
    with pytest.raises(NexusVersionJobPending):
        client.create_version(DS, "v2", fork_from="v1", wait=3)
    out = client.create_version(DS, "v2", fork_from="v1", block=False)
    assert out["job"]["job_id"] == "j1"


def test_create_version_202_404_job_draft_version_is_done(requests_mock, client, sleeps):
    accepted(requests_mock, VERSIONS)
    requests_mock.get(JOB, status_code=404, json={"error": "x"})
    requests_mock.get(f"{NEXUS}/datasets/{DS}/versions/v2", json={"version": "v2", "status": "draft"})
    assert client.create_version(DS, "v2", fork_from="v1")["status"] == "draft"


def test_dataset_seal_passes_wait_and_block(requests_mock, client, sleeps):
    from unittest.mock import Mock

    from nexus.dataset import Dataset

    ds = Dataset(client, Mock(), DS, "n", "v1")
    accepted(requests_mock, SEAL)
    out = ds.seal(block=False)
    assert out["job"]["job_id"] == "j1"
    requests_mock.get(JOB, json=job("running"))
    with pytest.raises(NexusVersionJobPending):
        ds.seal(wait=2)


def test_dataset_seal_ignore_after_202_done_returns_sealed(requests_mock, client, sleeps):
    from unittest.mock import Mock

    from nexus.dataset import Dataset

    ds = Dataset(client, Mock(), DS, "n", "v1")
    accepted(requests_mock, SEAL)
    requests_mock.get(JOB, json=job("done"))
    requests_mock.get(VERSION, json={"version": "v1", "status": "sealed", "sample_count": 3})
    assert ds.seal(if_sealed="ignore")["status"] == "sealed"


def test_dataset_fork_passes_wait_and_block(requests_mock, client, sleeps):
    from unittest.mock import Mock

    from nexus.dataset import Dataset

    ds = Dataset(client, Mock(), DS, "n", "v1")
    ds._load_group_kinds = lambda: None
    requests_mock.get(f"{NEXUS}/datasets", json=[{"dataset_id": DS, "name": "n"}])
    requests_mock.get(f"{NEXUS}/datasets/{DS}/versions/v2", [{"status_code": 404, "json": {"error": "x"}}, {"json": {"version": "v2", "status": "draft"}}])
    accepted(requests_mock, VERSIONS)
    requests_mock.get(JOB, json=job("running"))
    with pytest.raises(NexusVersionJobPending):
        ds.fork("v2", wait=2)


def _ds_handle(client):
    from unittest.mock import Mock

    from nexus.dataset import Dataset

    ds = Dataset(client, Mock(), DS, "n", "v1")
    ds._load_group_kinds = lambda: None
    return ds


def _datasets_listing(requests_mock):
    requests_mock.get(f"{NEXUS}/datasets", json=[{"dataset_id": DS, "name": "n"}])


V2 = f"{NEXUS}/datasets/{DS}/versions/v2"


def test_load_or_create_waits_on_existing_preparing_version(requests_mock, client, sleeps):
    _datasets_listing(requests_mock)
    requests_mock.get(V2, [
        {"json": {"version": "v2", "status": "preparing", "job": {"job_id": "j1", "state": "running"}}},
        {"json": {"version": "v2", "status": "draft"}},
    ])
    requests_mock.get(JOB, [{"json": job("running")}, {"json": job("done")}])
    p = requests_mock.post(VERSIONS, status_code=201, json={})
    from nexus.dataset import Dataset

    ds = Dataset.load_or_create("n", "v2", fork_from="v1", client=client, cas=object())
    assert ds._version == "v2"
    assert p.call_count == 0
    assert sleeps == [2.0]


def test_load_or_create_preparing_timeout_and_nonblocking(requests_mock, client, sleeps):
    _datasets_listing(requests_mock)
    requests_mock.get(V2, json={"version": "v2", "status": "preparing", "job": {"job_id": "j1", "state": "queued"}})
    requests_mock.get(JOB, json=job("queued"))
    from nexus.dataset import Dataset

    with pytest.raises(NexusVersionJobPending):
        Dataset.load_or_create("n", "v2", fork_from="v1", client=client, cas=object(), wait=2)
    ds = Dataset.load_or_create("n", "v2", fork_from="v1", client=client, cas=object(), block=False)
    assert ds._version == "v2"


def test_load_or_create_failed_existing_version_raises_409(requests_mock, client, sleeps):
    _datasets_listing(requests_mock)
    requests_mock.get(V2, json={"version": "v2", "status": "failed", "job": {"job_id": "j1", "state": "failed"}})
    from nexus.dataset import Dataset

    with pytest.raises(NexusError) as e:
        Dataset.load_or_create("n", "v2", fork_from="v1", client=client, cas=object())
    assert e.value.status_code == 409


def test_fork_reaching_existing_preparing_version_waits(requests_mock, client, sleeps):
    _datasets_listing(requests_mock)
    requests_mock.get(V2, [
        {"json": {"version": "v2", "status": "preparing", "job": {"job_id": "j1", "state": "running"}}},
        {"json": {"version": "v2", "status": "draft"}},
    ])
    requests_mock.get(JOB, json=job("done"))
    assert _ds_handle(client).fork("v2")._version == "v2"


def test_429_then_202_shares_the_wait_budget(requests_mock, client, sleeps):
    requests_mock.post(SEAL, [
        {"status_code": 429, "headers": {"Retry-After": "4"}, "json": {"error": "busy", "code": "seal_busy"}},
        {"status_code": 202, "json": {"job": job("queued"), "version": {"version": "v1", "status": "draft"}}},
    ])
    requests_mock.get(JOB, json=job("queued"))
    with pytest.raises(NexusVersionJobPending):
        client.seal(DS, "v1", wait=10)
    assert sum(sleeps) <= 10 + 1e-9
    assert sum(sleeps) >= 10 - 1e-9 or sum(sleeps) > 4


def test_load_or_create_nondefault_wait_reaches_create_version(requests_mock, client, sleeps):
    from unittest.mock import MagicMock

    from nexus.dataset import Dataset

    c = MagicMock()
    c.list_datasets.return_value = [{"dataset_id": DS, "name": "n"}]
    c.get_version.return_value = None
    Dataset.load_or_create("n", "v2", fork_from="v1", client=c, cas=object(), wait=30, block=False)
    kw = c.create_version.call_args.kwargs
    assert kw["wait"] == 30 and kw["block"] is False


def test_dataset_fork_block_false_returns_handle_without_polling(requests_mock, client, sleeps):
    _datasets_listing(requests_mock)
    requests_mock.get(V2, [{"status_code": 404, "json": {"error": "x"}}, {"json": {"version": "v2", "status": "preparing", "job": {"job_id": "j1", "state": "queued"}}}])
    accepted(requests_mock, VERSIONS)
    m = requests_mock.get(JOB, json=job("done"))
    ds = _ds_handle(client).fork("v2", block=False)
    assert ds._version == "v2" and m.call_count == 0
