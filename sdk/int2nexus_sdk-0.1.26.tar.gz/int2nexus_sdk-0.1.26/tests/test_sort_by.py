"""`ds.sort_by(field, reverse=False, **filters)` — meta 키 순서로 `AnnotatedSample` 을 낸다(SDK 0.1.25).

서버 정렬이 아니다 — projection 으로 `(id, 값)` 을 모아 클라이언트에서 정렬하고 묶음으로 본문을 받는다(`shuffle()` 구조).
"""
import pytest

from nexus.cas import CasClient
from nexus.client import NexusClient
from nexus.dataset import Dataset

BASE = "http://nexus"
VER = f"{BASE}/datasets/d1/versions/v1"
EXPLORER = f"{VER}/samples/explorer"


@pytest.fixture
def ds(requests_mock):
    requests_mock.post(f"{BASE}/api/v1/auth/login",
                       json={"token": "tok", "user_id": 1, "email": "u@x.com"})
    return Dataset(NexusClient(BASE, "u@x.com", "pass"), CasClient("http://cas"), "d1", "kitti", "v1")


def _router(values):
    """explorer 흉내 — projection(`fields`)이면 `(sample_id, meta.k)` 를, `sample_ids` 면 그 행 전체를 내림차순으로."""
    rows = {sid: {"sample_id": sid, "tags": [], "split": None, "meta": ({} if v is _ABSENT else {"k": v}),
                  "det": [{"id": f"i-{sid}", "label": "car"}]}
            for sid, v in values.items()}

    def cb(request, context):
        body = request.json()
        if body.get("fields"):
            out = [{"sample_id": sid, **({} if values[sid] is _ABSENT else {"meta.k": values[sid]})}
                   for sid in sorted(values, reverse=True)]
            context.headers["X-Nexus-Page-End"] = "1"
            return out
        ids = body.get("sample_ids") or sorted(values, reverse=True)
        return [rows[s] for s in sorted(ids, reverse=True) if s in rows]
    return cb


_ABSENT = object()


def _ids(it):
    return [s.sample_id for s in it]


def test_sorts_ascending_with_ties_by_sample_id(ds, requests_mock):
    requests_mock.post(EXPLORER, json=_router({"s1": 3, "s2": 1, "s3": 3, "s4": 2.5}))
    assert _ids(ds.sort_by("meta.k")) == ["s2", "s4", "s1", "s3"]


def test_reverse_keeps_ties_by_sample_id(ds, requests_mock):
    requests_mock.post(EXPLORER, json=_router({"s1": 3, "s2": 1, "s3": 3}))
    assert _ids(ds.sort_by("meta.k", reverse=True)) == ["s1", "s3", "s2"]


@pytest.mark.parametrize("reverse", [False, True])
def test_missing_values_are_last_regardless_of_reverse(ds, requests_mock, reverse):
    requests_mock.post(EXPLORER, json=_router({"s1": _ABSENT, "s2": "b", "s3": None, "s4": "a"}))
    out = _ids(ds.sort_by("meta.k", reverse=reverse))
    assert out[2:] == ["s1", "s3"]
    assert out[:2] == (["s2", "s4"] if reverse else ["s4", "s2"])


def test_mixed_number_and_string_raises_before_fetching_bodies(ds, requests_mock):
    m = requests_mock.post(EXPLORER, json=_router({"s1": 1, "s2": "a"}))
    with pytest.raises(ValueError, match="섞여"):
        list(ds.sort_by("meta.k"))
    assert not any(r.json().get("sample_ids") for r in m.request_history)


def test_bool_and_number_do_not_mix(ds, requests_mock):
    requests_mock.post(EXPLORER, json=_router({"s1": True, "s2": 0}))
    with pytest.raises(ValueError, match="섞여"):
        list(ds.sort_by("meta.k"))


def test_array_values_raise(ds, requests_mock):
    requests_mock.post(EXPLORER, json=_router({"s1": [1, 2]}))
    with pytest.raises(ValueError, match="배열"):
        list(ds.sort_by("meta.k"))


def test_filters_apply_to_id_collection_and_chunks(ds, requests_mock):
    m = requests_mock.post(EXPLORER, json=_router({"s1": 2, "s2": 1}))
    assert _ids(ds.sort_by("meta.k", split="train")) == ["s2", "s1"]
    assert all(r.json().get("split") == "train" for r in m.request_history)


def test_chunks_follow_page_size(ds, requests_mock):
    m = requests_mock.post(EXPLORER, json=_router({f"s{i}": i for i in range(5)}))
    assert _ids(ds.sort_by("meta.k", page_size=2)) == [f"s{i}" for i in range(5)]
    chunks = [r.json()["sample_ids"] for r in m.request_history if r.json().get("sample_ids")]
    assert chunks == [["s0", "s1"], ["s2", "s3"], ["s4"]]


def test_yields_annotated_samples_with_groups(ds, requests_mock):
    requests_mock.post(EXPLORER, json=_router({"s1": 1}))
    (s,) = list(ds.sort_by("meta.k"))
    assert s.get_group("det") is not None and s.meta["k"] == 1


@pytest.mark.parametrize("field", ["tags", "k", "meta."])
def test_rejects_fields_that_cannot_be_sorted(ds, field):
    with pytest.raises(ValueError):
        list(ds.sort_by(field))


def test_unknown_filter_is_type_error(ds):
    with pytest.raises(TypeError):
        list(ds.sort_by("meta.k", lable="car"))
