"""SDK 0.1.22 — 적재 본문의 dataset_id·재전송 기록 키."""
import copy
from unittest.mock import MagicMock

import requests

from nexus.dataset import Dataset
from nexus.sample import CasRef, Sample


def _sample():
    ref = CasRef("b", "k/a.png", hash_hex="h", size=10, content_type="image/png")
    return Sample(image=ref, annotation={"meta": {"width": 4, "height": 4, "filename": "http://cas/b/k/a.png"}})


def _ok():
    return {"results": [{"index": 0, "sample_id": "s1", "dataset_id": "d1"}]}


def test_ingest_body_carries_dataset_id():
    c = MagicMock()
    c.ingest_batch.return_value = _ok()
    ds = Dataset(c, MagicMock(), "d1", "kitti", "v1")
    ds.add(_sample())
    ds.flush(verbose=False)
    item = c.ingest_batch.call_args[0][0][0]
    assert item["dataset_id"] == "d1" and item["dataset"] == "kitti"


def test_resend_after_rename_keeps_body_and_key():
    c = MagicMock()
    sent = []

    def fake(items):
        sent.append(copy.deepcopy(items[0]))
        if len(sent) == 1:
            raise requests.exceptions.ConnectionError("boom")
        return {"results": [{"index": 0, "sample_id": "s1", "dataset_id": "d1", "replayed": True}]}

    c.ingest_batch.side_effect = fake
    c.get_dataset.return_value = {"dataset_id": "d1", "name": "kitti-renamed", "tags": []}
    ds = Dataset(c, MagicMock(), "d1", "kitti", "v1")
    s = _sample()
    ds.add(s)
    assert not ds.flush(verbose=False)[0].ok
    ds.refresh()
    assert ds._name == "kitti-renamed"
    ds.add(s)
    assert ds.flush(verbose=False)[0].ok
    assert len(sent) == 2
    assert sent[1] == sent[0], "재전송 본문이 바뀌었다(해시가 달라져 409)"
    assert sent[1]["dataset"] == "kitti" and sent[1]["dataset_id"] == "d1"
    assert sent[1]["idempotency_key"]


# --- 오류 code·rejected, 일괄 meta 저수준 메서드 ---
import pytest

from nexus import NexusError
from nexus.client import NexusClient

_NEXUS = "http://nexus.test"
VER = f"{_NEXUS}/datasets/d1/versions/v1"


@pytest.fixture
def client(requests_mock):
    requests_mock.post(f"{_NEXUS}/api/v1/auth/login",
                       json={"token": "t", "user_id": 1, "email": "u@x.com"})
    return NexusClient(_NEXUS, "u@x.com", "pass")


def test_error_carries_code_and_rejected(client, requests_mock):
    requests_mock.patch(f"{VER}/samples/meta", status_code=400, json={
        "error": "1 건이 거절돼 아무것도 쓰지 않았습니다", "code": "meta_write_rejected",
        "rejected": [{"sample_id": "s9", "reason": "not_found"}]})
    with pytest.raises(NexusError) as ei:
        client.patch_meta_items("d1", "v1", [{"sample_id": "s9", "meta": {"k": 1}}])
    assert ei.value.code == "meta_write_rejected"
    assert ei.value.rejected == [{"sample_id": "s9", "reason": "not_found"}]


def test_patch_meta_by_filter_sends_confirm(client, requests_mock):
    m = requests_mock.patch(f"{VER}/samples/meta/by-filter", json={"updated": 3, "skipped_non_object_meta": 0})
    out = client.patch_meta_by_filter("d1", "v1", {"split": "train"}, {"k": 1}, confirm=3)
    assert out["updated"] == 3
    assert m.last_request.qs == {"confirm": ["3"]}
    assert m.last_request.json() == {"filter": {"split": "train"}, "meta": {"k": 1}}


def test_meta_items_path_is_retry_safe():
    from nexus import _retry
    assert _retry.is_safe("PATCH", "/datasets/d1/versions/v1/samples/meta")
    assert not _retry.is_safe("PATCH", "/datasets/d1/versions/v1/samples/meta/by-filter")


# --- Task 9: set_values 일괄화와 update_meta ---
from nexus.cas import CasClient


@pytest.fixture
def ds(requests_mock):
    requests_mock.post(f"{_NEXUS}/api/v1/auth/login",
                       json={"token": "t", "user_id": 1, "email": "u@x.com"})
    c = NexusClient(_NEXUS, "u@x.com", "pass", retry_timeout=0)
    return Dataset(c, CasClient("http://cas"), "d1", "kitti", "v1")


def test_set_values_sends_one_request_per_10000(ds, requests_mock):
    vals = {f"s{i}": i for i in range(10_001)}
    requests_mock.patch(f"{VER}/samples/meta", [{"json": {"updated": 10_000}}, {"json": {"updated": 1}}])
    assert ds.set_values("meta.k", vals) == 10_001
    hist = [r for r in requests_mock.request_history if r.method == "PATCH"]
    assert len(hist) == 2
    assert len(hist[0].json()["items"]) == 10_000
    assert hist[0].json()["items"][0] == {"sample_id": "s0", "meta": {"k": 0}}


def test_set_values_rejection_reports_applied_and_rejected(ds, requests_mock):
    requests_mock.patch(f"{VER}/samples/meta", [
        {"json": {"updated": 10_000}},
        {"status_code": 400, "json": {"error": "x", "code": "meta_write_rejected",
                                      "rejected": [{"sample_id": "s10000", "reason": "not_found"}]}},
    ])
    vals = {f"s{i}": i for i in range(10_001)}
    with pytest.raises(NexusError) as ei:
        ds.set_values("meta.k", vals)
    e = ei.value
    assert e.applied == 10_000
    assert e.rejected == [{"sample_id": "s10000", "reason": "not_found"}]
    assert e.failed_sample_id == "s10000"


def test_set_values_405_falls_back_per_sample(ds, requests_mock):
    requests_mock.patch(f"{VER}/samples/meta", status_code=405, json={"error": "method not allowed"})
    a = requests_mock.patch(f"{VER}/samples/s1/annotations", json={"skipped": 0})
    with pytest.warns(RuntimeWarning, match="샘플별 PATCH"):
        assert ds.set_values("meta.k", {"s1": 1}) == 1
    assert a.last_request.json() == {"annotation_data": {"meta": {"k": 1}}}


def test_set_values_404_is_raised_not_fallen_back(ds, requests_mock):
    requests_mock.patch(f"{VER}/samples/meta", status_code=404, json={"error": "version v1 not found"})
    a = requests_mock.patch(f"{VER}/samples/s1/annotations", json={})
    with pytest.raises(NexusError) as ei:
        ds.set_values("meta.k", {"s1": 1})
    assert ei.value.status_code == 404 and not a.called


def test_update_meta_sends_filter_and_confirm(ds, requests_mock):
    m = requests_mock.patch(f"{VER}/samples/meta/by-filter", json={"updated": 2, "skipped_non_object_meta": 0})
    out = ds.update_meta({"reviewed": True}, confirm=2, split="train", label="car")
    assert out == {"updated": 2, "skipped_non_object_meta": 0}
    body = m.last_request.json()
    assert body["meta"] == {"reviewed": True}
    assert body["filter"]["split"] == "train"
    assert body["filter"]["annotation"] == [{"label": "car"}]


def test_update_meta_empty_split_is_a_filter_like_reads(ds, requests_mock):
    # 읽기(explore_samples)는 split="" 을 보내 split 이 빈 샘플만 고른다 — 쓰기에서 빠지면 버전 전체에 쓴다.
    m = requests_mock.patch(f"{VER}/samples/meta/by-filter", json={"updated": 0, "skipped_non_object_meta": 0})
    ds.update_meta({"k": 1}, split="")
    assert m.last_request.json()["filter"] == {"split": ""}


def test_update_meta_rejects_include_annotations_and_non_dict(ds):
    with pytest.raises(TypeError):
        ds.update_meta({"k": 1}, include_annotations=False)
    with pytest.raises(ValueError):
        ds.update_meta([("k", 1)])


def test_update_meta_positional_meta_does_not_collide_with_meta_filter(ds, requests_mock):
    m = requests_mock.patch(f"{VER}/samples/meta/by-filter", json={"updated": 1, "skipped_non_object_meta": 0})
    ds.update_meta({"reviewed": True}, meta={"split": "a"})
    body = m.last_request.json()
    assert body["meta"] == {"reviewed": True}
    assert body["filter"]["meta"] == {"split": "a"}


def test_update_meta_empty_sample_ids_sends_nothing(ds, requests_mock):
    m = requests_mock.patch(f"{VER}/samples/meta/by-filter", json={"updated": 99})
    assert ds.update_meta({"k": 1}, sample_ids=[]) == {"updated": 0, "skipped_non_object_meta": 0}
    assert not m.called


def test_update_meta_empty_set_and_generator_send_nothing(ds, requests_mock):
    m = requests_mock.patch(f"{VER}/samples/meta/by-filter", json={"updated": 99})
    empty = {"updated": 0, "skipped_non_object_meta": 0}
    assert ds.update_meta({"k": 1}, sample_ids=set()) == empty
    assert ds.update_meta({"k": 1}, sample_ids=(x for x in [])) == empty
    assert ds.update_meta({"k": 1}, sample_ids={}.keys()) == empty
    assert not m.called


def test_update_meta_nonempty_set_is_sent_as_json_list(ds, requests_mock):
    m = requests_mock.patch(f"{VER}/samples/meta/by-filter", json={"updated": 1, "skipped_non_object_meta": 0})
    ds.update_meta({"k": 1}, sample_ids={"s1"})
    assert m.last_request.json()["filter"]["sample_ids"] == ["s1"]


def test_set_values_uuid_keys_are_sent_as_strings(ds, requests_mock):
    import uuid

    sid = uuid.uuid4()
    m = requests_mock.patch(f"{VER}/samples/meta", json={"updated": 1})
    assert ds.set_values("meta.k", {sid: 1}) == 1
    assert m.last_request.json()["items"] == [{"sample_id": str(sid), "meta": {"k": 1}}]


def test_set_values_5xx_says_may_have_been_applied(ds, requests_mock):
    requests_mock.patch(f"{VER}/samples/meta", status_code=503, json={"error": "down"})
    with pytest.raises(NexusError) as ei:
        ds.set_values("meta.k", {"s1": 1})
    assert "적용됐을 수도" in str(ei.value)
    # 503 은 거절이 아니다 — 앞머리도 「거절」이라고 말하지 않는다.
    assert "요청이 실패했습니다" in str(ei.value)
    assert "거절" not in str(ei.value)
    assert ei.value.applied == 0 and ei.value.failed_sample_id == "s1"


def test_set_values_400_rejected_says_not_written(ds, requests_mock):
    requests_mock.patch(f"{VER}/samples/meta", status_code=400, json={
        "error": "x", "code": "meta_write_rejected",
        "rejected": [{"sample_id": "s1", "reason": "not_found"}]})
    with pytest.raises(NexusError) as ei:
        ds.set_values("meta.k", {"s1": 1})
    assert "쓰지 않았습니다" in str(ei.value)
    assert "요청이 거절됐습니다" in str(ei.value)


# --- 검토 2 보강: UUID dataset_id, 본문 바이트 예산, 413 분할, 그 밖의 예외의 진행 정보 ---
def test_dataset_accepts_uuid_dataset_id_and_sends_string():
    import uuid

    did = uuid.uuid4()
    c = MagicMock()
    c.ingest_batch.return_value = {"results": [{"index": 0, "sample_id": "s1", "dataset_id": str(did)}]}
    ds = Dataset(c, MagicMock(), did, "kitti", "v1")
    s = _sample()
    ds.add(s)
    ds.flush(verbose=False)
    body = c.ingest_batch.call_args[0][0][0]
    assert body["dataset_id"] == str(did)
    import json as _json
    _json.dumps(body)  # UUID 객체가 남아 있으면 TypeError
    # 재전송 기록 키도 문자열 id 다 — UUID·문자열 핸들이 같은 기록을 찾는다(실패해 기록이 남은 상태로 본다).
    c.ingest_batch.side_effect = requests.exceptions.ConnectionError("boom")
    s2 = _sample()
    ds.add(s2)
    assert not ds.flush(verbose=False)[0].ok
    assert list(s2._idempotency_keys) == [(str(did), "v1")]


def test_set_values_chunks_respect_body_byte_budget(ds, requests_mock):
    vals = {f"s{i}": "x" * 400 for i in range(3_000)}
    m = requests_mock.patch(f"{VER}/samples/meta", json=lambda req, ctx: {"updated": len(req.json()["items"])})
    assert ds.set_values("meta.k", vals) == 3_000
    hist = [r for r in requests_mock.request_history if r.method == "PATCH"]
    assert len(hist) > 1
    assert all(len(r.body) <= 800_000 for r in hist)
    assert sum(len(r.json()["items"]) for r in hist) == 3_000


def test_set_values_413_splits_in_half_and_keeps_applied(ds, requests_mock):
    def cb(req, ctx):
        n = len(req.json()["items"])
        if n > 2:
            ctx.status_code = 413
            return {"error": "too large"}
        return {"updated": n}

    requests_mock.patch(f"{VER}/samples/meta", json=cb)
    assert ds.set_values("meta.k", {f"s{i}": i for i in range(8)}) == 8
    sizes = [len(r.json()["items"]) for r in requests_mock.request_history if r.method == "PATCH"]
    assert sizes[:3] == [8, 4, 2]


def test_set_values_single_item_413_is_raised_with_progress(ds, requests_mock):
    def cb(req, ctx):
        items = req.json()["items"]
        if any(i["sample_id"] == "s2" for i in items):
            ctx.status_code = 413
            return {"error": "too large"}
        return {"updated": len(items)}

    requests_mock.patch(f"{VER}/samples/meta", json=cb)
    with pytest.raises(NexusError) as ei:
        ds.set_values("meta.k", {"s0": 0, "s1": 1, "s2": 2, "s3": 3})
    e = ei.value
    assert e.status_code == 413
    assert e.applied == 2 and e.failed_sample_id == "s2"


def test_set_values_other_exception_keeps_type_and_progress(ds, requests_mock):
    requests_mock.patch(f"{VER}/samples/meta", json={"updated": 1})
    with pytest.raises(TypeError) as ei:
        ds.set_values("meta.k", {"s1": object()})
    assert ei.value.applied == 0 and ei.value.failed_sample_id == "s1"
