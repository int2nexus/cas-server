from __future__ import annotations
from dataclasses import dataclass
from typing import TYPE_CHECKING

import requests

if TYPE_CHECKING:
    from nexus.sample import Sample


class NexusError(Exception):
    """모든 nexus 예외의 베이스. HTTP 에러로 발생한 경우 `status_code`/`server_message`가
    채워진다(`server_message` = 서버 응답 바디의 `{"error": "..."}` 텍스트, 없으면 None) —
    `str(e)`에도 포함되지만, 프로그램적으로 분기하려면 이 두 속성을 쓴다:
    `except NexusError as e: if e.status_code == 403: ...`."""

    def __init__(
        self,
        message: str = "",
        *,
        status_code: "int | None" = None,
        server_message: "str | None" = None,
        code: "str | None" = None,
        rejected: "list[dict] | None" = None,
    ) -> None:
        self.status_code = status_code
        self.server_message = server_message
        self.code = code
        self.rejected = rejected
        super().__init__(message)


class NexusVersionJobPending(NexusError):
    """seal·fork 가 서버 작업 줄(202)에 올랐는데 `wait` 안에 끝나지 않았다. 작업은 서버에서 계속 돈다.

    `job_id`·`job`(마지막으로 읽은 작업 dict)으로 `NexusClient.get_version_job(job_id)` 를 다시 불러 확인한다."""

    def __init__(self, job: dict, message: "str | None" = None) -> None:
        self.job = job
        self.job_id = job.get("job_id")
        super().__init__(
            message or f"버전 작업 {self.job_id} 이(가) 아직 끝나지 않았습니다 (state={job.get('state')})"
        )


def _raise_for_status(response: "requests.Response") -> None:
    """`response.raise_for_status()` 대체 — 실패 시 서버가 보낸 `{"error": "..."}` 본문을
    담아 `NexusError`를 던진다. `str(requests.HTTPError)`는 상태코드/URL만 담고 응답 바디는
    버리므로, 이 함수 없이 raw HTTPError를 그대로 전파하면 서버가 공들여 만든 에러 메시지
    (예: sealed 버전 안내, 403 사유, 필터링된 fork의 비멤버 sample_id 목록)가 전부 사라진다."""
    if response.ok:
        return
    code = rejected = None
    try:
        body = response.json()
        server_message = body.get("error") if isinstance(body, dict) else None
        if isinstance(body, dict):
            code = body.get("code")
            rejected = body.get("rejected")
    except ValueError:
        server_message = None
    server_message = server_message or (response.text or None)
    message = f"{response.status_code} {response.reason} for {response.request.method} {response.url}"
    if server_message:
        message = f"{message} — {server_message}"
    raise NexusError(
        message, status_code=response.status_code, server_message=server_message,
        code=code, rejected=rejected,
    )


class NexusAuthError(NexusError):
    pass


class NexusCasError(NexusError):
    pass


class NexusIngestError(NexusError):
    pass


class NexusValidationError(NexusError):
    """보낸 데이터의 형식 오류. SDK 가 보내기 전에 거른 것(save() 시점 type check 등, `status_code` 없음)과
    annotation 쓰기(`save_annotation`·`patch_annotations`·`merge_annotation`)에서 서버가 400 으로 거절한 것
    (`status_code=400`, `server_message` 에 서버 사유 — nexus-server 0.1.30 부터)이 이 예외다."""
    pass


class NexusBatchError(NexusError):
    def __init__(self, failures: list[IngestResult]) -> None:
        self.failures = failures
        super().__init__(f"{len(failures)} sample(s) failed to ingest")


@dataclass
class IngestResult:
    ok: bool
    sample: Sample | None
    sample_id: str | None = None
    error: str | None = None
    #: 실패 item의 HTTP 상태코드(배치는 전체가 200이라 본문에서만 알 수 있다).
    #: 401/403은 데이터 문제가 아니라 권한 문제여서 재시도해도 소용없다.
    status_code: int | None = None
    #: 입력에서의 위치(0부터) — `flush` 는 호출 시점 큐, `patch_annotations` 는 넘긴 항목.
    #: 결과 목록도 이 순서로 온다(0.1.18). 병렬 처리라 끝나는 순서는 다르다.
    index: int | None = None
    #: 멱등 키 재전송으로 서버가 기존 결과를 돌려준 것이면 True(서버 0.1.20~). 성공으로 센다.
    replayed: bool = False
