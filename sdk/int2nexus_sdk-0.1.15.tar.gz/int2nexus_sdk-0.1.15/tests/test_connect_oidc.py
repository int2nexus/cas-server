"""`nx.connect(oidc=OidcAuth(...))` — 상호배타 규칙과 접속 시점 토큰 취득.

OIDC 는 nexus 축의 인증이라 CAS STS(`cas_sts`)와는 함께 쓸 수 있다(축이 다르다).
`email`/`password`·`robot_token` 과는 함께 쓸 수 없다 — 셋 다 로그인을 대체한다.
"""

import base64
import json
import time

import pytest

import nexus
from nexus.oidc import OidcAuth


BASE = "http://n"


def _jwt(exp: int) -> str:
    b = lambda d: base64.urlsafe_b64encode(json.dumps(d).encode()).rstrip(b"=").decode()
    return f"{b({'alg': 'RS256'})}.{b({'sub': 'sa', 'exp': exp})}.sig"


@pytest.fixture(autouse=True)
def _reset_globals():
    nexus._client = None
    nexus._cas = None
    yield
    nexus._client = None
    nexus._cas = None


def test_connect_oidc_skips_login_and_sets_bearer(requests_mock):
    tok = _jwt(int(time.time()) + 3600)
    login = requests_mock.post(f"{BASE}/api/v1/auth/login", json={"token": "x"})

    nx = nexus.connect(
        nexus_url=BASE, cas_url="http://cas", cas_key_id="k", cas_secret="s",
        oidc=OidcAuth(token_provider=lambda: tok),
    )

    assert nx._session.headers["Authorization"] == f"Bearer {tok}"
    assert not login.called, "OIDC 인데 로그인을 시도했다"


def test_connect_oidc_needs_no_email_password(requests_mock, tmp_path, monkeypatch):
    # 로그인 경로를 타지 않으므로 email/password 없이 접속 설정이 완결돼야 한다.
    monkeypatch.setenv("NEXUS_SETTINGS", str(tmp_path / "absent.json"))
    tok = _jwt(int(time.time()) + 3600)

    nx = nexus.connect(
        nexus_url=BASE, cas_url="http://cas", cas_key_id="k", cas_secret="s",
        oidc=OidcAuth(token_provider=lambda: tok),
    )
    assert nx is not None


def test_connect_rejects_oidc_with_password():
    tok = _jwt(int(time.time()) + 3600)
    with pytest.raises(ValueError):
        nexus.connect(
            nexus_url=BASE, email="e", password="p",
            cas_url="http://cas", cas_key_id="k", cas_secret="s",
            oidc=OidcAuth(token_provider=lambda: tok),
        )


def test_connect_rejects_oidc_with_robot_token():
    tok = _jwt(int(time.time()) + 3600)
    with pytest.raises(ValueError):
        nexus.connect(
            nexus_url=BASE, cas_url="http://cas", cas_key_id="k", cas_secret="s",
            robot_token="nxr_x", oidc=OidcAuth(token_provider=lambda: tok),
        )


def test_oidc_auth_is_exported():
    # 도입처가 `nexus.OidcAuth` 로 쓸 수 있어야 한다(CasSts 와 대칭).
    assert nexus.OidcAuth is OidcAuth
