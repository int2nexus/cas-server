"""외부 IdP(OIDC) 토큰으로 nexus 에 직접 인증하기 — `nx.connect(oidc=OidcAuth(...))`.

서버는 등록된 발급자의 OIDC 토큰을 요청마다 **직접 Bearer 로** 받는다(교환 없이).
SDK 가 하는 일은 토큰을 어디서 가져오는가(파일 / 콜러블)를 정하고, 만료가 가까우면
다시 가져오는 것뿐이다. `CasSts` 와 대칭이되 훨씬 얇다 — 교환이 없기 때문이다.

이 경로에는 로그인도 `refresh` 도 없다(서버가 OIDC 요청의 `refresh` 를 403 으로 막는다).
회전은 토큰 출처가 진다.
"""

import base64
import json
import time

import pytest

from nexus.client import NexusClient
from nexus.oidc import OidcAuth
from nexus._types import NexusAuthError, NexusError


BASE = "http://nx"


def _jwt(exp: int, sub: str = "sa-1") -> str:
    """서명은 아무거나. SDK 는 exp 만 읽고 검증은 서버가 한다."""
    b = lambda d: base64.urlsafe_b64encode(json.dumps(d).encode()).rstrip(b"=").decode()
    return f"{b({'alg': 'RS256'})}.{b({'sub': sub, 'exp': exp})}.sig"


# ── OidcAuth 검증 ──────────────────────────────────────────────────────────

def test_oidc_auth_requires_exactly_one_source():
    with pytest.raises(ValueError):
        OidcAuth()  # 둘 다 없음
    with pytest.raises(ValueError):
        OidcAuth(token_file="/t", token_provider=lambda: "x")  # 둘 다 있음
    with pytest.raises(ValueError):
        OidcAuth(token_file="   ")  # 빈 경로
    with pytest.raises(ValueError):
        OidcAuth(token_provider="not-callable")  # 콜러블 아님


def test_oidc_auth_repr_hides_token_value():
    # provider 가 클로저로 토큰을 쥐고 있어도 repr 에 노출되면 안 된다.
    secret = _jwt(int(time.time()) + 3600)
    r = repr(OidcAuth(token_provider=lambda: secret))
    assert secret not in r
    assert "token_provider" in r


# ── provider / file 로 Bearer 를 싣는다 ────────────────────────────────────

def test_provider_token_is_sent_as_bearer(requests_mock):
    tok = _jwt(int(time.time()) + 3600)
    requests_mock.get(f"{BASE}/datasets", json=[])

    c = NexusClient(BASE, "", "", oidc=OidcAuth(token_provider=lambda: tok))
    c._get("/datasets")

    sent = requests_mock.request_history[-1]
    assert sent.headers["Authorization"] == f"Bearer {tok}"
    # 로그인도 refresh 도 없어야 한다.
    paths = [h.path for h in requests_mock.request_history]
    assert "/api/v1/auth/login" not in paths
    assert "/api/v1/auth/refresh" not in paths


def test_token_file_is_read_and_sent(requests_mock, tmp_path):
    tok = _jwt(int(time.time()) + 3600)
    f = tmp_path / "token"
    f.write_text(tok, encoding="utf-8")
    requests_mock.get(f"{BASE}/datasets", json=[])

    c = NexusClient(BASE, "", "", oidc=OidcAuth(token_file=str(f)))
    c._get("/datasets")

    assert requests_mock.request_history[-1].headers["Authorization"] == f"Bearer {tok}"


# ── 만료 근처에서 선제 재취득 ──────────────────────────────────────────────

def test_token_near_expiry_is_refetched_from_source(requests_mock):
    soon = _jwt(int(time.time()) + 60)       # 여유(5분) 안쪽
    fresh = _jwt(int(time.time()) + 3600)
    tokens = iter([soon, fresh])
    requests_mock.get(f"{BASE}/datasets", json=[])

    c = NexusClient(BASE, "", "", oidc=OidcAuth(token_provider=lambda: next(tokens)))
    assert c._token == soon
    c._get("/datasets")

    # provider 가 다시 불려 새 토큰이 실린다 — refresh 엔드포인트는 건드리지 않는다.
    assert c._token == fresh
    assert requests_mock.request_history[-1].headers["Authorization"] == f"Bearer {fresh}"
    assert "/api/v1/auth/refresh" not in [h.path for h in requests_mock.request_history]


def test_token_far_from_expiry_is_not_refetched(requests_mock):
    fresh = _jwt(int(time.time()) + 3600)
    calls = {"n": 0}

    def provider():
        calls["n"] += 1
        return fresh

    requests_mock.get(f"{BASE}/datasets", json=[])
    c = NexusClient(BASE, "", "", oidc=OidcAuth(token_provider=provider))
    c._get("/datasets")
    c._get("/datasets")

    # 최초 1회(생성 시)만. 만료가 멀면 매 요청 provider 를 부르지 않는다.
    assert calls["n"] == 1


# ── 401 재취득 (프로세스가 갱신 시점을 놓쳤을 때) ───────────────────────────

def test_401_refetches_from_source_and_retries_once(requests_mock):
    # 프로세스가 절전 등으로 선제 재취득을 놓쳐 만료 토큰으로 요청 → 401.
    # 출처에서 새 토큰을 받아 한 번 재시도한다.
    stale = _jwt(int(time.time()) + 3600)     # exp 는 멀지만 서버가 거부한다고 가정
    fresh = _jwt(int(time.time()) + 3600, sub="sa-2")
    tokens = iter([stale, fresh])

    responses = [
        {"status_code": 401, "json": {"error": "unauthorized"}},
        {"status_code": 200, "json": [{"dataset_id": "d1"}]},
    ]
    requests_mock.get(f"{BASE}/datasets", responses)

    c = NexusClient(BASE, "", "", oidc=OidcAuth(token_provider=lambda: next(tokens)))
    assert c._get("/datasets").json() == [{"dataset_id": "d1"}]
    assert c._token == fresh
    # 두 번째 요청은 새 토큰을 실었다.
    assert requests_mock.request_history[-1].headers["Authorization"] == f"Bearer {fresh}"


def test_401_with_unchanged_token_does_not_waste_a_retry(requests_mock):
    # 만료가 아니라 매핑 삭제·aud/iss 불일치로 401 이면 출처가 같은 토큰을 돌려준다.
    # 그 토큰을 다시 보내면 확실히 또 401 이므로 재시도하지 않고 그대로 올라간다.
    tok = _jwt(int(time.time()) + 3600)
    requests_mock.get(f"{BASE}/datasets", status_code=401, json={"error": "unauthorized"})

    c = NexusClient(BASE, "", "", oidc=OidcAuth(token_provider=lambda: tok))
    with pytest.raises(NexusError) as e:
        c._get("/datasets")
    assert e.value.status_code == 401
    # 재시도 없음 — /datasets 요청은 정확히 한 번.
    assert sum(1 for h in requests_mock.request_history if h.path == "/datasets") == 1


# ── 출처 실패 ──────────────────────────────────────────────────────────────

def test_provider_raising_at_construction_surfaces_auth_error(requests_mock):
    def boom():
        raise RuntimeError("secret-bearing-detail")

    with pytest.raises(NexusAuthError) as e:
        NexusClient(BASE, "", "", oidc=OidcAuth(token_provider=boom))
    # 원 예외 문구(토큰이 섞였을 수 있음)를 사슬로 남기지 않는다.
    assert "secret-bearing-detail" not in str(e.value)


def test_empty_token_file_is_auth_error(tmp_path):
    f = tmp_path / "token"
    f.write_text("   ", encoding="utf-8")
    with pytest.raises(NexusAuthError):
        NexusClient(BASE, "", "", oidc=OidcAuth(token_file=str(f)))


def test_non_utf8_token_file_is_wrapped_as_auth_error(tmp_path):
    # `UnicodeDecodeError` 는 `ValueError` 라 `except OSError` 를 빠져나간다 — 안 감싸면
    # 갱신 경로(`_oidc_maybe_refetch`·`_relogin`)의 `except NexusAuthError` 가 못 받아
    # 사용자 요청이 죽는다. kubelet 중간 쓰기·손상 파일에서 실제로 나는 케이스다.
    f = tmp_path / "token"
    f.write_bytes(b"\xff\xfe not utf-8 \x80")
    with pytest.raises(NexusAuthError) as e:
        NexusClient(BASE, "", "", oidc=OidcAuth(token_file=str(f)))
    # 문제 바이트를 문구에 싣지 않는다(클래스 이름만).
    assert "\\x80" not in str(e.value) and "�" not in str(e.value)
