from pathlib import Path
import pytest
from nexus.cas import CasClient
from nexus._types import NexusCasError

CAS = "http://cas-test"


@pytest.fixture
def client():
    return CasClient(CAS, key_id="kid", secret="sec")


def test_head_returns_metadata(requests_mock, client):
    requests_mock.head(f"{CAS}/bucket/images/img.png",
                       headers={"ETag": '"abc123"', "content-length": "2048",
                                "content-type": "image/png"})
    result = client.head("bucket", "images/img.png")
    assert result["hash_hex"] == "abc123"
    assert result["size"] == 2048
    assert result["content_type"] == "image/png"


def test_head_returns_none_on_404(requests_mock, client):
    requests_mock.head(f"{CAS}/bucket/key", status_code=404)
    assert client.head("bucket", "key") is None


def test_head_raises_on_server_error(requests_mock, client):
    requests_mock.head(f"{CAS}/bucket/key", status_code=500)
    with pytest.raises(NexusCasError):
        client.head("bucket", "key")


def test_put_sends_data(requests_mock, client):
    requests_mock.put(f"{CAS}/bucket/key", status_code=200)
    client.put("bucket", "key", b"hello-data", "image/png")
    assert requests_mock.last_request.body == b"hello-data"
    assert requests_mock.last_request.headers["Content-Type"] == "image/png"


def test_put_raises_on_failure(requests_mock, client):
    requests_mock.put(f"{CAS}/bucket/key", status_code=403)
    with pytest.raises(NexusCasError):
        client.put("bucket", "key", b"data", "image/png")


def test_cas_get_returns_content(requests_mock):
    from nexus.cas import CasClient
    requests_mock.get("http://cas/b/k.png", content=b"hello")
    cas = CasClient("http://cas")
    assert cas.get("b", "k.png") == b"hello"


def test_cas_get_raises_on_error(requests_mock):
    import pytest
    from nexus.cas import CasClient
    from nexus._types import NexusCasError
    requests_mock.get("http://cas/b/missing", status_code=404)
    cas = CasClient("http://cas")
    with pytest.raises(NexusCasError) as ei:
        cas.get("b", "missing")
    # 호출부(to_df)가 404와 403을 다르게 안내하려면 상태 코드가 속성으로 있어야 한다.
    assert ei.value.status_code == 404


def test_cas_get_passes_timeout(requests_mock):
    requests_mock.get("http://cas/b/k", content=b"x")
    cas = CasClient("http://cas")
    cas.get("b", "k", timeout=7)
    assert requests_mock.last_request.timeout == 7


def test_session_has_retry_adapter(client):
    from requests.adapters import HTTPAdapter
    adapter = client._session.get_adapter("http://cas-test/b/k")
    assert isinstance(adapter, HTTPAdapter)
    retry = adapter.max_retries
    assert retry.total == 3
    assert "PUT" in retry.allowed_methods
    assert 503 in retry.status_forcelist


def test_session_reused_across_calls(requests_mock, client):
    # 같은 클라이언트의 모든 요청이 동일 Session을 쓴다(keep-alive 재사용).
    requests_mock.head(f"{CAS}/b/k", headers={"ETag": '"h"', "content-length": "1"})
    s1 = client._session
    client.head("b", "k")
    assert client._session is s1


def test_canonical_request_exact_bytes():
    # 줄바꿈/공백이 서버 cas_client.rs::sigv4_auth와 바이트 동일해야 한다.
    from nexus.cas import _canonical_request
    cr = _canonical_request("PUT", "/data/k.png", "localhost:8080", "abc123", "20260101T000000Z")
    expected = (
        "PUT\n"
        "/data/k.png\n"
        "\n"
        "host:localhost:8080\n"
        "x-amz-content-sha256:abc123\n"
        "x-amz-date:20260101T000000Z\n"
        "\n"
        "host;x-amz-content-sha256;x-amz-date\n"
        "abc123"
    )
    assert cr == expected


def test_uri_encode_path_encodes_special_chars_but_keeps_slashes_and_unreserved():
    from nexus.cas import _uri_encode_path
    # 예약/특수문자는 %XX 로, 경로 구분자 '/' 와 비예약(-_.~ 및 영숫자)은 보존.
    assert _uri_encode_path("/b/p/[2D][C9] x+#%.bmp") == "/b/p/%5B2D%5D%5BC9%5D%20x%2B%23%25.bmp"
    assert _uri_encode_path("/b/a/b/c.png") == "/b/a/b/c.png"           # '/' 보존
    assert _uri_encode_path("/b/-_.~AZ09.png") == "/b/-_.~AZ09.png"     # 비예약 보존
    # 한글 등 비ASCII 는 UTF-8 바이트의 %XX.
    assert _uri_encode_path("/b/사진.png") == "/b/%EC%82%AC%EC%A7%84.png"


def test_head_encodes_bracket_key_on_the_wire(requests_mock, client):
    # 대괄호 등이 있는 키도 CAS HEAD 가 성공해야 한다(전송 경로가 인코딩된다).
    enc = "/bucket/p/%5B2D%5D%5BC9%5D%20x.bmp"
    requests_mock.head(f"{CAS}{enc}", headers={"ETag": '"h"', "content-length": "1"})
    result = client.head("bucket", "p/[2D][C9] x.bmp")
    assert result is not None and result["hash_hex"] == "h"
    assert "%5B" in requests_mock.last_request.path_url


def test_head_signs_the_same_encoded_path_it_sends(requests_mock, client, monkeypatch):
    # 서명 경로 == 전송 경로여야 서버(및 boto3)의 SigV4 검증과 바이트 일치한다.
    import nexus.cas as cas_mod
    captured = {}
    real = cas_mod._canonical_request
    def spy(method, path, *a, **k):
        captured["path"] = path
        return real(method, path, *a, **k)
    monkeypatch.setattr(cas_mod, "_canonical_request", spy)
    enc = "/bucket/d/%5Bx%5D%20y.bmp"
    requests_mock.head(f"{CAS}{enc}", headers={"ETag": '"h"', "content-length": "1"})
    client.head("bucket", "d/[x] y.bmp")
    assert captured["path"] == enc                                  # 서명이 인코딩 경로 기준
    assert captured["path"] == requests_mock.last_request.path_url   # 전송 경로와 동일


def test_get_and_put_encode_special_chars(requests_mock, client):
    enc = "/bucket/k%5Bz%5D.png"
    requests_mock.get(f"{CAS}{enc}", content=b"x")
    assert client.get("bucket", "k[z].png") == b"x"
    assert "%5B" in requests_mock.last_request.path_url
    requests_mock.put(f"{CAS}{enc}", status_code=200)
    client.put("bucket", "k[z].png", b"data", "image/png")
    assert requests_mock.last_request.method == "PUT"
    assert "%5B" in requests_mock.last_request.path_url


def test_signed_headers_structure_and_payload_hash():
    from nexus.cas import CasClient, _sha256_hex
    c = CasClient("http://localhost:8080", key_id="rootkey", secret="rootsecret")
    h = c._signed_headers("PUT", "/data/k.png", b"hello")
    assert h["x-amz-content-sha256"] == _sha256_hex(b"hello")
    assert "T" in h["x-amz-date"] and h["x-amz-date"].endswith("Z")
    assert h["Authorization"].startswith("AWS4-HMAC-SHA256 Credential=rootkey/")
    assert "SignedHeaders=host;x-amz-content-sha256;x-amz-date" in h["Authorization"]
    assert "/s3/aws4_request," in h["Authorization"]


def test_signed_headers_empty_without_creds():
    from nexus.cas import CasClient
    c = CasClient("http://localhost:8080")
    assert c._signed_headers("PUT", "/b/k", b"x") == {}


def test_default_region_is_cas_default():
    # CAS 서버가 region "cas-default"로 고정 검증하므로 SDK 기본값도 이에 맞춘다.
    from nexus.cas import CasClient
    c = CasClient("http://localhost:8080", key_id="k", secret="s")
    assert c._region == "cas-default"
    assert "/cas-default/s3/aws4_request" in c._signed_headers("PUT", "/b/k", b"x")["Authorization"]


def test_host_keeps_port():
    from nexus.cas import CasClient
    assert CasClient("http://localhost:8080")._host() == "localhost:8080"
    assert CasClient("https://cas.example.com")._host() == "cas.example.com"


def test_put_sends_sigv4_headers(requests_mock):
    from nexus.cas import CasClient, _sha256_hex
    requests_mock.put("http://cas-test/data/k.png", status_code=200)
    c = CasClient("http://cas-test", key_id="rootkey", secret="rootsecret")
    c.put("data", "k.png", b"hello", "image/png")
    req = requests_mock.last_request
    assert req.headers["x-amz-content-sha256"] == _sha256_hex(b"hello")
    assert req.headers["Authorization"].startswith("AWS4-HMAC-SHA256 Credential=rootkey/")
    assert req.headers["Content-Type"] == "image/png"


def test_hash_bytes_is_deterministic():
    data = b"test-data-for-hashing"
    assert CasClient.hash_bytes(data) == CasClient.hash_bytes(data)
    assert len(CasClient.hash_bytes(data)) == 64  # blake3: 32 bytes = 64 hex chars


def test_hash_bytes_differs_for_different_data():
    assert CasClient.hash_bytes(b"aaa") != CasClient.hash_bytes(b"bbb")


def test_content_type_image_png():
    assert CasClient.content_type(Path("photo.png")) == "image/png"


def test_content_type_unknown_defaults_to_octet_stream():
    assert CasClient.content_type(Path("file.xyz123")) == "application/octet-stream"


def test_no_auth_header_when_credentials_empty(requests_mock):
    c = CasClient(CAS, key_id="", secret="")
    requests_mock.head(f"{CAS}/b/k",
                       headers={"ETag": '"h"', "content-length": "0"})
    c.head("b", "k")
    assert "Authorization" not in requests_mock.last_request.headers


def test_cas_head_prefers_x_cas_hash_over_etag(requests_mock):
    from nexus.cas import CasClient
    requests_mock.head(
        "http://cas/b/k",
        headers={"ETag": '"md5deadbeef"', "x-cas-hash": "blake3abc", "content-length": "5"},
    )
    cas = CasClient("http://cas")
    assert cas.head("b", "k")["hash_hex"] == "blake3abc"


# ── 403 의 두 얼굴 ────────────────────────────────────────────────────────────
#
# cas 는 정책 거부를 `AccessDenied`, 폐기·만료된 키를 `InvalidAccessKeyId` 로 낸다
# (cas `src/error.rs`). 전에는 둘을 구분하지 못해 "클라이언트당 한 번" 이라는 예산으로
# 눌렀는데, 자격증명에 만료가 붙으면서 오래 도는 프로세스가 두 번째 만료에서 죽는다.

_ACCESS_DENIED = (
    '<?xml version="1.0"?><Error><Code>AccessDenied</Code>'
    "<Message>denied</Message></Error>"
)
_BAD_KEY = (
    '<?xml version="1.0"?><Error><Code>InvalidAccessKeyId</Code>'
    "<Message>The AWS Access Key Id you provided does not exist in our records.</Message>"
    "</Error>"
)


def _static(key_id="kid", secret="sec"):
    """정적 자격증명 클라이언트. **갱신 경로가 없다**(0.1.14~)."""
    return CasClient(CAS, key_id=key_id, secret=secret)


def test_static_credentials_never_retry_on_403(requests_mock):
    """403 은 코드가 무엇이든 한 번만 나가고 그대로 올라간다.

    이전 판은 `InvalidAccessKeyId` 에 nexus 로 새 자격증명을 요청해 한 번 더 시도했다.
    nexus 가 발급을 하지 않게 되면서 그 경로가 없어졌고, 같은 값으로 다시 두드리는 것은
    아무것도 바꾸지 못하므로 재시도 자체를 걷었다.
    """
    for body in (_ACCESS_DENIED, _BAD_KEY):
        m = requests_mock.put(f"{CAS}/b/k", status_code=403, text=body)
        with pytest.raises(NexusCasError):
            _static().put("b", "k", b"d", "image/png")
        assert m.call_count == 1, f"재시도했다({m.call_count} 회): {body[:40]}"


def test_head_403_without_body_also_does_not_retry(requests_mock):
    """HEAD 403 에는 본문이 없어 에러 코드를 못 읽는다 — 그래도 재시도하지 않는다."""
    m = requests_mock.head(f"{CAS}/b/k", status_code=403)
    with pytest.raises(NexusCasError):
        _static().head("b", "k")
    assert m.call_count == 1


# ── NexusCasError 의 status_code (0.1.18) ───────────────────────────────────────
# 문구에만 코드가 있으면 호출자가 403(영구)·404(없음)·5xx(일시)를 가를 수 없고,
# flush 의 권한 판정도 이 값을 본다.

@pytest.mark.parametrize("code", [403, 500, 503])
def test_head_error_carries_status_code(requests_mock, client, code):
    requests_mock.head(f"{CAS}/bucket/key", status_code=code, text="nope")
    with pytest.raises(NexusCasError) as ei:
        client.head("bucket", "key")
    assert ei.value.status_code == code
    assert ei.value.server_message == "nope"


def test_put_error_carries_status_code(requests_mock, client):
    requests_mock.put(f"{CAS}/bucket/key", status_code=403, text="denied")
    with pytest.raises(NexusCasError) as ei:
        client.put("bucket", "key", b"x", "image/png")
    assert ei.value.status_code == 403


def test_read_head_error_carries_status_code(requests_mock, client):
    requests_mock.get(f"{CAS}/bucket/key", status_code=502, text="bad gw")
    with pytest.raises(NexusCasError) as ei:
        client.read_head("bucket", "key", 64)
    assert ei.value.status_code == 502
