from __future__ import annotations
import warnings
from collections.abc import Mapping
from concurrent.futures import ThreadPoolExecutor, as_completed

from tqdm import tqdm

from nexus._types import NexusCasError
from nexus.imageinfo import image_info
from nexus.sample import CasRef, _coerce_cas_ref

DEFAULT_HEADER_BYTES = 64 * 1024


def _first(a, b):
    """이미 알고 있는 값을 우선한다(0·빈 문자열도 유효한 값이므로 `or`를 쓰지 않는다)."""
    return a if a is not None else b


def probe(
    refs,
    *,
    workers: int = 8,
    verbose: bool = True,
    strict: bool = False,
    max_header_bytes: int = DEFAULT_HEADER_BYTES,
    cas=None,
) -> "list[CasRef]":
    """CAS 객체 앞부분만 받아 이미지 크기를 채운 CasRef 리스트를 돌려준다.

    로컬 사본 없이 CAS 좌표만 가진 이미지를 등록할 때 쓴다. 이 단계를 건너뛰면 등록되는
    `meta`에 width/height가 아예 빠지고(0을 적지 않는다), 그러면 크기 facet·histogram
    집계에서 제외되며 CVAT 세션 생성이 거부된다.

    - 입력은 `CasRef` 또는 `s3://`·`http(s)://` URL 문자열의 리스트, **또는 `nx.upload`가
      돌려주는 `{path: CasRef}` 그대로**(`Mapping`이면 `.values()`를 취한다 — dict를 그대로
      반복하면 키인 로컬 경로 문자열이 나와 "CAS 참조가 아니다"로 거부당하므로, 업로드
      결과를 이어붙이는 가장 자연스러운 호출이 막히지 않게 여기서 처리한다).
    - 반환은 **입력 순서를 보존한 리스트**다. 실패한 항목도 자리를 지키며 원본 ref가
      그대로 들어간다(width/height는 None) — 리스트가 짧아져 샘플이 조용히 누락되지 않는다.
    - 이미 width/height가 있는 ref는 네트워크를 타지 않고 통과한다. 재실행이 안전하고
      `nx.upload` 결과를 섞어 넘겨도 된다.
    - 실패는 건당 격리된다. `strict=True`면 하나라도 실패했을 때 `NexusCasError`를 던진다.

    로컬 파일이 있다면 네트워크를 탈 이유가 없다 — `nx.image_info(path.read_bytes())`로
    직접 채우는 쪽이 싸다.
    """
    if max_header_bytes < 1:
        raise ValueError(
            f"max_header_bytes는 1 이상이어야 합니다: {max_header_bytes} "
            "(0 이하면 Range 헤더가 'bytes=0--1'처럼 잘못된 형태가 된다)"
        )
    import nexus as _nx
    _cas = cas
    if _cas is None:
        if _nx._cas is None:
            _nx._auto_connect()
        _cas = _nx._cas

    if isinstance(refs, Mapping):
        refs = refs.values()
    items: list[CasRef] = [_coerce_cas_ref(r, "nx.probe의 인자") for r in refs]
    todo = [i for i, r in enumerate(items) if r.width is None or r.height is None]

    def _one(i: int) -> "tuple[int, CasRef]":
        ref = items[i]
        got = _cas.read_head(ref.bucket, ref.key, max_header_bytes)
        if got is None:
            raise NexusCasError(
                f"CAS object 없음: bucket='{ref.bucket}', key='{ref.key}'"
            )
        info = image_info(got["data"])
        if info is None:
            raise NexusCasError(
                f"이미지 헤더를 읽지 못했습니다 (앞 {max_header_bytes}바이트). "
                "비이미지이거나 헤더가 더 뒤에 있습니다 — max_header_bytes를 올려보세요."
            )
        return i, CasRef(
            bucket=ref.bucket,
            key=ref.key,
            hash_hex=_first(ref.hash_hex, got["hash_hex"]),
            size=_first(ref.size, got["size"]),
            content_type=_first(ref.content_type, got["content_type"]),
            width=info.width,
            height=info.height,
        )

    # index로 키 — bucket/key 문자열로 키를 잡으면 같은 key를 두 번 넘겼을 때(예: probe
    # 실패 후 원본 리스트 그대로 재시도) 서로 다른 실패가 dict에서 겹쳐써져 실패 개수가
    # 실제보다 적게 보고된다.
    errors: dict[int, Exception] = {}
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(_one, i): i for i in todo}
        for f in tqdm(as_completed(futures), total=len(futures),
                      desc="Probing", disable=not verbose):
            try:
                idx, ref = f.result()
                items[idx] = ref
            except Exception as exc:   # 건당 격리: 하나가 실패해도 나머지는 채운다
                errors[futures[f]] = exc

    if errors:
        labels = [f"{items[i].bucket}/{items[i].key}" for i in errors]
        shown = ", ".join(labels[:5])
        more = f" 외 {len(errors) - 5}건" if len(errors) > 5 else ""
        first_err = next(iter(errors.values()))
        msg = (
            f"{len(errors)}개 객체의 이미지 헤더를 읽지 못했습니다: {shown}{more}. "
            f"첫 에러: {first_err}. "
            "해당 샘플은 meta.width/height 없이 등록됩니다."
        )
        if strict:
            raise NexusCasError(msg)
        warnings.warn(msg, RuntimeWarning, stacklevel=2)
    return items
