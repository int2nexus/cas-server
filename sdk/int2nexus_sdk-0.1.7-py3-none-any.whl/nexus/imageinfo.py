from __future__ import annotations
from dataclasses import dataclass


@dataclass
class ImageInfo:
    width: int
    height: int
    mime: str | None = None
    channels: int | None = None


def image_info(data: bytes) -> "ImageInfo | None":
    """이미지 bytes에서 헤더만 파싱해 크기·MIME·채널 수를 읽는다. 실패 시 None.

    Pillow의 `Image.open`은 헤더만 읽고 픽셀 데이터는 건드리지 않으므로, **파일 앞부분만
    있어도** 그리고 풀 디코드 없이도 동작한다. `nx.upload`(로컬 bytes)와 `nx.probe`
    (CAS range GET) 두 경로가 이 함수 하나를 공유한다.

    비이미지·잘린 헤더·Pillow 미설치는 모두 None이다(best-effort). 호출부는 None을
    "모름"으로 다루고, 모르는 값을 0 같은 그럴듯한 값으로 채우지 않는다.
    """
    try:
        from PIL import Image
    except ImportError:
        return None
    import io
    try:
        with Image.open(io.BytesIO(data)) as img:
            return ImageInfo(
                width=img.width,
                height=img.height,
                mime=Image.MIME.get(img.format) if img.format else None,
                channels=len(img.getbands()),
            )
    except Exception:
        return None
