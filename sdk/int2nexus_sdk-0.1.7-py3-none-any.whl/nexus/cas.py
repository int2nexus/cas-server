from __future__ import annotations
import hashlib
import hmac
import mimetypes
from datetime import datetime, timezone
from pathlib import Path
import blake3
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from nexus._types import NexusCasError

# 대량 적재용: 일시적 5xx/네트워크 끊김을 전송 계층에서 백오프 재시도.
# PUT은 key당 내용이 고정(content-addressed)이라 재시도 안전.
_RETRY = Retry(
    total=3,
    backoff_factor=0.5,
    status_forcelist=(429, 500, 502, 503, 504),
    allowed_methods=frozenset(["HEAD", "GET", "PUT"]),
    respect_retry_after_header=True,
    raise_on_status=False,
)

_EMPTY_SHA256 = hashlib.sha256(b"").hexdigest()


def _build_session(
    pool_maxsize: int = 32, verify: "bool | str" = True
) -> requests.Session:
    session = requests.Session()
    adapter = HTTPAdapter(
        max_retries=_RETRY,
        pool_connections=pool_maxsize,
        pool_maxsize=pool_maxsize,
    )
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    # CAS는 nexus와 별개 세션이고 `nx.upload`가 파일 바이트를 여기로 직접 PUT한다 —
    # 사내 TLS 검사 장비가 nexus를 가로챈다면 CAS도 대개 같으므로 같은 설정을 받는다.
    # CAS를 http로 접속하면 이 값은 아무 일도 하지 않는다(무해).
    session.verify = verify
    return session


def _sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _hmac(key: bytes, data: bytes) -> bytes:
    return hmac.new(key, data, hashlib.sha256).digest()


def _signing_key(secret: str, date: str, region: str) -> bytes:
    k_date = _hmac(("AWS4" + secret).encode(), date.encode())
    k_region = _hmac(k_date, region.encode())
    k_service = _hmac(k_region, b"s3")
    return _hmac(k_service, b"aws4_request")


def _canonical_request(
    method: str, path: str, host: str, payload_hash: str, amz_date: str
) -> str:
    """SigV4 canonical request. 서버 cas_client.rs::sigv4_auth와 **바이트 동일**해야 한다.

    SignedHeaders = host;x-amz-content-sha256;x-amz-date (고정), CanonicalQueryString 비어 있음.
    줄바꿈/공백 한 글자라도 다르면 서명 불일치 → 절대 변형 금지.
    """
    return (
        f"{method}\n"
        f"{path}\n"
        f"\n"  # CanonicalQueryString (비어 있음)
        f"host:{host}\n"
        f"x-amz-content-sha256:{payload_hash}\n"
        f"x-amz-date:{amz_date}\n"
        f"\n"  # canonical headers 종료 빈 줄
        f"host;x-amz-content-sha256;x-amz-date\n"
        f"{payload_hash}"
    )


def _total_size(resp) -> "int | None":
    """응답에서 객체의 **전체** 크기를 얻는다. 206이면 Content-Range, 200이면 Content-Length.

    200 분기는 `content-encoding` 헤더가 있으면 None을 돌려준다 — `requests`가 기본으로
    보내는 `Accept-Encoding: gzip, deflate` 때문에 CAS가 압축 응답을 줄 수 있는데, 그러면
    Content-Length는 압축 후 바이트 수라 원본 객체 크기가 아니다. 이 값이 `CasRef.size`를
    거쳐 서버 `sample_assets`에 그대로 박히므로 모르는 채로 두는 편이 낫다(206의
    Content-Range는 항상 실제 전체 크기라 영향 없음).
    """
    cr = resp.headers.get("content-range", "") or ""
    if "/" in cr:
        total = cr.rsplit("/", 1)[1].strip()
        if total.isdigit():
            return int(total)
    if resp.status_code == 200 and not resp.headers.get("content-encoding"):
        cl = resp.headers.get("content-length")
        if cl and str(cl).isdigit():
            return int(cl)
    return None


class CasClient:
    def __init__(
        self,
        cas_url: str,
        key_id: str = "",
        secret: str = "",
        region: str = "cas-default",
        verify: "bool | str" = True,
    ) -> None:
        self._base = cas_url.rstrip("/")
        self._key_id = key_id
        self._secret = secret
        self._region = region
        # 커넥션 재사용(keep-alive) + 재시도를 위해 클라이언트당 Session 하나.
        self._session = _build_session(verify=verify)

    def _host(self) -> str:
        # 스킴만 제거, 포트는 유지 (서버 sigv4_auth와 동일).
        return self._base.removeprefix("http://").removeprefix("https://")

    def _signed_headers(self, method: str, path: str, body: bytes) -> dict:
        """SigV4 Authorization/x-amz-date/x-amz-content-sha256 헤더. 자격증명 없으면 {}.

        서버 cas_client.rs::sigv4_auth 그대로 (host;x-amz-content-sha256;x-amz-date 서명).
        """
        if not (self._key_id and self._secret):
            return {}
        now = datetime.now(timezone.utc)
        date = now.strftime("%Y%m%d")
        amz_date = now.strftime("%Y%m%dT%H%M%SZ")
        payload_hash = _sha256_hex(body)

        canonical_request = _canonical_request(
            method, path, self._host(), payload_hash, amz_date
        )
        credential_scope = f"{date}/{self._region}/s3/aws4_request"
        string_to_sign = (
            f"AWS4-HMAC-SHA256\n"
            f"{amz_date}\n"
            f"{credential_scope}\n"
            f"{_sha256_hex(canonical_request.encode())}"
        )
        signature = _hmac(
            _signing_key(self._secret, date, self._region),
            string_to_sign.encode(),
        ).hex()
        auth = (
            f"AWS4-HMAC-SHA256 Credential={self._key_id}/{credential_scope}, "
            f"SignedHeaders=host;x-amz-content-sha256;x-amz-date, "
            f"Signature={signature}"
        )
        return {
            "Authorization": auth,
            "x-amz-date": amz_date,
            "x-amz-content-sha256": payload_hash,
        }

    def head(self, bucket: str, key: str) -> dict | None:
        path = f"/{bucket}/{key}"
        r = self._session.head(
            f"{self._base}{path}", headers=self._signed_headers("HEAD", path, b"")
        )
        if r.status_code == 404:
            return None
        if not r.ok:
            raise NexusCasError(
                f"CAS HEAD failed ({r.status_code}): {bucket}/{key} — {r.text[:300]}"
            )
        etag = r.headers.get("ETag", r.headers.get("etag", "")).strip('"')
        hash_hex = r.headers.get("x-cas-hash", "") or etag
        size_str = r.headers.get("content-length", "")
        return {
            "hash_hex": hash_hex,
            "size": int(size_str) if size_str else None,
            "content_type": r.headers.get("content-type"),
        }

    def read_head(self, bucket: str, key: str, max_bytes: int) -> "dict | None":
        """객체 앞부분 `max_bytes`만 받아 bytes와 응답 헤더 정보를 돌려준다. 404면 None.

        **Range를 지원하지 않는 CAS에서도 동작한다.** 206이면 요청한 만큼만 오고, 서버가
        Range를 무시하고 200으로 전체를 보내면 예산만큼 읽고 연결을 닫는다 — 전송은 거기서
        끊긴다. 그래서 CAS의 Range 지원 여부를 사전에 알 필요가 없다.

        Range 헤더는 SigV4 SignedHeaders(host;x-amz-content-sha256;x-amz-date)에 없으므로
        서명에 영향을 주지 않는다(`_canonical_request` 참조).

        `iter_content`로 읽는다 — `raw.read`는 Content-Encoding 디코딩을 건너뛰어 압축
        전송이 걸리면 깨진 바이트를 돌려준다. 첫 청크가 예산보다 작게 올 수 있으므로
        예산에 닿거나 스트림이 끝날 때까지 누적한다.

        `hash_hex`는 `head()`와 같은 규칙 — `x-cas-hash`가 없으면 `ETag`로 폴백한다(CAS가
        GET에는 ETag만 주는 배치가 있다). 여기서 빠지면 리치 ref가 안 되어 `flush`가 매
        샘플마다 HEAD를 한 번씩 더 보내고, 이 기능이 노리는 왕복 절감이 조용히 사라진다.
        """
        path = f"/{bucket}/{key}"
        headers = self._signed_headers("GET", path, b"")
        headers["Range"] = f"bytes=0-{max_bytes - 1}"
        r = self._session.get(f"{self._base}{path}", headers=headers, stream=True)
        try:
            if r.status_code == 404:
                return None
            if not r.ok:
                raise NexusCasError(
                    f"CAS GET(range) failed ({r.status_code}): {bucket}/{key} — {r.text[:300]}"
                )
            buf = bytearray()
            for chunk in r.iter_content(8192):
                buf.extend(chunk)
                # `>`이지 `>=`가 아니다: 206 응답의 바디가 정확히 max_bytes였을 때 `>=`면
                # 마지막 청크를 받은 그 반복에서 바로 break해 스트림이 다 온 것처럼 보이지만
                # 실제로는 서버가 아직 EOF를 보내지 않았을 수 있다 — 그 상태에서 close()하면
                # 다 받은 응답을 미완성으로 취급해 재사용 가능한 keep-alive 연결을 끊게 된다.
                # buf[:max_bytes] 슬라이스가 최대 한 청크(8192B)의 초과분은 어차피 잘라내므로
                # 200 응답(전체를 다 보내는 경우)은 여전히 한 청크 여유로 일찍 멈춘다.
                if len(buf) > max_bytes:
                    break
            etag = r.headers.get("ETag", r.headers.get("etag", "")).strip('"')
            hash_hex = r.headers.get("x-cas-hash", "") or etag
            return {
                "data": bytes(buf[:max_bytes]),
                "hash_hex": hash_hex or None,
                "size": _total_size(r),
                "content_type": r.headers.get("content-type"),
            }
        finally:
            r.close()

    def put(
        self,
        bucket: str,
        key: str,
        data: bytes,
        content_type: str = "application/octet-stream",
    ) -> None:
        path = f"/{bucket}/{key}"
        headers = self._signed_headers("PUT", path, data)
        headers["Content-Type"] = content_type  # 서명 대상 아님(SignedHeaders에 미포함)
        r = self._session.put(f"{self._base}{path}", data=data, headers=headers)
        if not r.ok:
            raise NexusCasError(
                f"CAS PUT failed ({r.status_code}): {bucket}/{key} — {r.text[:300]}"
            )

    def get(self, bucket: str, key: str) -> bytes:
        path = f"/{bucket}/{key}"
        r = self._session.get(
            f"{self._base}{path}", headers=self._signed_headers("GET", path, b"")
        )
        if not r.ok:
            raise NexusCasError(
                f"CAS GET failed ({r.status_code}): {bucket}/{key} — {r.text[:300]}"
            )
        return r.content

    @staticmethod
    def hash_bytes(data: bytes) -> str:
        return blake3.blake3(data).hexdigest()

    @staticmethod
    def content_type(path: Path) -> str:
        ct, _ = mimetypes.guess_type(str(path))
        return ct or "application/octet-stream"
