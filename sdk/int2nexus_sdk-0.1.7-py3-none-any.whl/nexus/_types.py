from __future__ import annotations
from dataclasses import dataclass
from typing import TYPE_CHECKING

import requests

if TYPE_CHECKING:
    from nexus.sample import Sample


class NexusError(Exception):
    """모든 nexus 예외의 베이스. HTTP 에러로 발생한 경우 `status_code`/`server_message`가
    채워진다(`server_message` = 서버 응답 바디의 `{"error": "..."}` 텍스트, 없으면 None) —
    `str(e)`에도 포함되지만, 프로그램적으로 분기하려면 이 두 속성을 쓴다:
    `except NexusError as e: if e.status_code == 403: ...`."""

    def __init__(
        self,
        message: str = "",
        *,
        status_code: "int | None" = None,
        server_message: "str | None" = None,
    ) -> None:
        self.status_code = status_code
        self.server_message = server_message
        super().__init__(message)


def _raise_for_status(response: "requests.Response") -> None:
    """`response.raise_for_status()` 대체 — 실패 시 서버가 보낸 `{"error": "..."}` 본문을
    담아 `NexusError`를 던진다. `str(requests.HTTPError)`는 상태코드/URL만 담고 응답 바디는
    버리므로, 이 함수 없이 raw HTTPError를 그대로 전파하면 서버가 공들여 만든 에러 메시지
    (예: sealed 버전 안내, 403 사유, 필터링된 fork의 비멤버 sample_id 목록)가 전부 사라진다."""
    if response.ok:
        return
    try:
        body = response.json()
        server_message = body.get("error") if isinstance(body, dict) else None
    except ValueError:
        server_message = None
    server_message = server_message or (response.text or None)
    message = f"{response.status_code} {response.reason} for {response.request.method} {response.url}"
    if server_message:
        message = f"{message} — {server_message}"
    raise NexusError(message, status_code=response.status_code, server_message=server_message)


class NexusAuthError(NexusError):
    pass


class NexusCasError(NexusError):
    pass


class NexusIngestError(NexusError):
    pass


class NexusBatchError(NexusError):
    def __init__(self, failures: list[IngestResult]) -> None:
        self.failures = failures
        super().__init__(f"{len(failures)} sample(s) failed to ingest")


@dataclass
class IngestResult:
    ok: bool
    sample: Sample | None
    sample_id: str | None = None
    error: str | None = None
    #: 실패 item의 HTTP 상태코드(배치는 전체가 200이라 본문에서만 알 수 있다).
    #: 401/403은 데이터 문제가 아니라 권한 문제여서 재시도해도 소용없다.
    status_code: int | None = None
