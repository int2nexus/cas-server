from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class CasRef:
    bucket: str
    key: str
    hash_hex: str | None = None
    size: int | None = None
    content_type: str | None = None
    width: int | None = None
    height: int | None = None


FileRef = Path | CasRef


def _parse_ref(src: str | Path) -> FileRef:
    from urllib.parse import urlparse
    s = str(src)
    if s.startswith("s3://"):
        without_scheme = s[5:]
        bucket, _, key = without_scheme.partition("/")
        return CasRef(bucket=bucket, key=key)
    if s.startswith("http://") or s.startswith("https://"):
        path = urlparse(s).path.lstrip("/")
        bucket, _, key = path.partition("/")
        return CasRef(bucket=bucket, key=key)
    return Path(s)


def _coerce_cas_ref(v: "CasRef | str | Path", field: str) -> CasRef:
    if isinstance(v, CasRef):
        return v
    ref = _parse_ref(v)  # str → CasRef(url) 또는 Path(로컬)
    if isinstance(ref, CasRef):
        return ref
    raise ValueError(
        f"Sample.{field}는 CAS 참조여야 합니다 (CasRef 또는 s3://·http(s):// URL). "
        f"로컬 경로는 받지 않습니다 — nx.upload(...)로 먼저 CAS에 올린 뒤 반환된 ref를 넘기세요."
    )


@dataclass
class Sample:
    """등록할 학습 단위. 이미지/depth는 **CAS에 이미 있는 ref**만 받는다.

    - `image`/`depth`: `CasRef`(nx.upload 반환) 또는 `s3://`·`http(s)://` URL. 로컬 경로는
      받지 않는다 — `nx.upload(...)`로 먼저 CAS에 올린 뒤 반환된 ref를 넘길 것.
    - `annotation`: GT는 nexus DB에 인라인 저장되므로 로컬 JSON 경로 / dict / URL 모두 허용
      (이미지와 달리 CAS 업로드 대상이 아니라 그대로 읽어 전송한다).
    """
    image: "CasRef | str | None" = None
    annotation: "str | Path | dict | None" = None
    depth: "CasRef | str | None" = None
    split: str | None = None
    tags: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        if self.image is None and self.annotation is None:
            raise ValueError("Sample requires at least image or annotation")
        # 문자열 하나를 넘기면 단일 원소 리스트로 자동 변환 (서버는 배열을 기대).
        if isinstance(self.tags, str):
            self.tags = [self.tags]
        self._image_ref: CasRef | None = (
            _coerce_cas_ref(self.image, "image") if self.image is not None else None
        )
        self._depth_ref: CasRef | None = (
            _coerce_cas_ref(self.depth, "depth") if self.depth else None
        )
        # annotation: dict(인라인 GT)은 그대로, 그 외(경로/URL)는 _parse_ref
        if isinstance(self.annotation, dict):
            self._annotation_ref: "FileRef | dict | None" = self.annotation
        elif self.annotation is not None:
            self._annotation_ref = _parse_ref(self.annotation)
        else:
            self._annotation_ref = None
