from __future__ import annotations
import os

from nexus._types import (
    IngestResult,
    NexusAuthError,
    NexusBatchError,
    NexusCasError,
    NexusError,
    NexusIngestError,
)
from nexus.cas import CasClient
from nexus.client import NexusClient
from nexus.dataset import Dataset
from nexus.sample import CasRef, Sample
from nexus.upload import upload

_client: NexusClient | None = None
_cas: CasClient | None = None


def connect(
    nexus_url: str | None = None,
    email: str | None = None,
    password: str | None = None,
    cas_url: str | None = None,
    cas_key_id: str | None = None,
    cas_secret: str | None = None,
    timeout: "float | tuple[float, float]" = (10.0, 120.0),
) -> NexusClient:
    # bucket은 전역 기본값을 두지 않는다 — nx.upload(paths, bucket=...)에서 호출별로 지정.
    # timeout=(connect, read) — read를 넉넉히(배치 적재가 오래 걸릴 수 있음). 없으면 정체가 무한 hang.
    global _client, _cas

    _nexus_url = nexus_url or os.environ["NEXUS_URL"]
    _email = email or os.environ["NEXUS_EMAIL"]
    _password = password or os.environ["NEXUS_PASSWORD"]
    _cas_url = cas_url or os.environ["CAS_URL"]
    _cas_key_id = cas_key_id or os.environ.get("CAS_KEY_ID", "")
    _cas_secret = cas_secret or os.environ.get("CAS_SECRET", "")

    _client = NexusClient(_nexus_url, _email, _password, timeout=timeout)
    _cas = CasClient(_cas_url, _cas_key_id, _cas_secret)
    return _client


def _auto_connect() -> NexusClient:
    global _client
    if _client is None:
        connect()
    return _client  # type: ignore[return-value]


def list_datasets(
    *,
    name: str | None = None,
    description: str | None = None,
    tags: "str | list[str] | None" = None,
    sort: str | None = None,
    order: str | None = None,
    client: NexusClient | None = None,
) -> list[dict]:
    """등록된 dataset 목록(dict 리스트).

    각 항목: `dataset_id`/`name`/`description`/`tags`/`created_at`와 **`versions`**(버전 문자열
    목록, 예 `['v0','v1']`). 옵션 — `name`/`description`: 부분 검색(ILIKE), `tags`: 하나라도 포함(ANY),
    `sort`: "name" 또는 "created_at"(기본), `order`: "asc"/"desc"(기본 desc).
    """
    c = client or _auto_connect()
    return c.list_datasets(
        name=name, description=description, tags=tags, sort=sort, order=order
    )


__all__ = [
    "connect",
    "list_datasets",
    "Dataset",
    "Sample",
    "CasRef",
    "upload",
    "IngestResult",
    "NexusError",
    "NexusAuthError",
    "NexusCasError",
    "NexusIngestError",
    "NexusBatchError",
]
