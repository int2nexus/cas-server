from __future__ import annotations
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from nexus.sample import Sample


class NexusError(Exception):
    pass


class NexusAuthError(NexusError):
    pass


class NexusCasError(NexusError):
    pass


class NexusIngestError(NexusError):
    pass


class NexusBatchError(NexusError):
    def __init__(self, failures: list[IngestResult]) -> None:
        self.failures = failures
        super().__init__(f"{len(failures)} sample(s) failed to ingest")


@dataclass
class IngestResult:
    ok: bool
    sample: Sample | None
    sample_id: str | None = None
    error: str | None = None
