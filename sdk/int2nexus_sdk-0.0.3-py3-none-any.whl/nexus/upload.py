from __future__ import annotations
import warnings
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from tqdm import tqdm

from nexus._types import NexusCasError
from nexus.cas import CasClient
from nexus.sample import CasRef

THUMBNAIL_MAX_EDGE = 256
THUMBNAIL_QUALITY = 80


def _make_thumbnail(image_bytes: bytes) -> "bytes | None":
    """원본 이미지 bytes → longest-edge 256 WebP bytes. 디코딩 실패 시 None."""
    try:
        from PIL import Image
    except ImportError:
        raise ImportError("pillow is required for thumbnails: pip install pillow")
    import io
    try:
        img = Image.open(io.BytesIO(image_bytes)).convert("RGB")
        img.thumbnail((THUMBNAIL_MAX_EDGE, THUMBNAIL_MAX_EDGE))
        buf = io.BytesIO()
        img.save(buf, format="WEBP", quality=THUMBNAIL_QUALITY)
        return buf.getvalue()
    except Exception as exc:
        warnings.warn(f"thumbnail generation failed: {exc}", RuntimeWarning, stacklevel=2)
        return None


def _image_dims(image_bytes: bytes) -> "tuple[int, int] | None":
    """이미지 bytes에서 (width, height)를 읽는다(헤더만, 풀 디코드 불필요). 실패 시 None.

    업로드 시점에 미리 구해 CasRef에 담아두면, 등록 시 meta 자동 생성에서 CAS 재다운로드를
    건너뛸 수 있다(best-effort — 비이미지/디코딩 실패면 None).
    """
    try:
        from PIL import Image
    except ImportError:
        return None
    import io
    try:
        with Image.open(io.BytesIO(image_bytes)) as img:
            return img.width, img.height
    except Exception:
        return None


def upload(
    paths,
    bucket: str,
    prefix: str = "",
    *,
    workers: int = 8,
    verbose: bool = True,
    strict: bool = False,
    client=None,
    cas=None,
) -> "dict[str, CasRef]":
    """로컬 파일들을 CAS에 직접 업로드하고 {경로: 리치 CasRef} 를 반환한다.

    각 파일: key={prefix}/{filename}, blake3 hash·size·content_type 계산, HEAD-skip(동일 hash)
    /충돌(다른 hash) 검사 후 PUT, WebP 256px 썸네일을 thumb/<key>에 함께 업로드(best-effort).

    일시적 네트워크/5xx 오류는 CAS 클라이언트가 전송 계층에서 재시도한다. 재시도 후에도
    실패한 파일은 **건당 격리**되어 배치 전체를 중단시키지 않는다 — 성공분만 반환한다.
    `strict=True`면 실패가 하나라도 있으면 `NexusCasError`를 던진다(기본 False는 경고만).
    같은 paths로 다시 호출하면 이미 올라간 건 HEAD-skip되어 실패분만 재시도(resume)된다.
    """
    import nexus as _nx
    _client = client
    _cas = cas
    if _client is None or _cas is None:
        if _nx._client is None:
            _nx._auto_connect()
        _client = _client or _nx._client
        _cas = _cas or _nx._cas

    _client.ensure_bucket(bucket)
    prefix = prefix.strip("/") if prefix else ""

    def _one(path) -> "tuple[str, CasRef]":
        p = Path(path)
        data = p.read_bytes()
        hash_hex = CasClient.hash_bytes(data)
        key = f"{prefix}/{p.name}" if prefix else p.name
        content_type = CasClient.content_type(p)

        existing = _cas.head(bucket, key)
        if existing is None:
            _cas.put(bucket, key, data, content_type)
        elif existing.get("hash_hex") and existing["hash_hex"] != hash_hex:
            raise NexusCasError(
                f"CAS key 충돌: '{bucket}/{key}'에 다른 내용이 이미 존재합니다 "
                f"(기존 {existing['hash_hex'][:12]} != 신규 {hash_hex[:12]}). prefix나 파일명을 바꾸세요."
            )

        dims = _image_dims(data)
        thumb = _make_thumbnail(data)
        if thumb is not None:
            try:
                thumb_key = f"thumb/{key}"
                if _cas.head(bucket, thumb_key) is None:
                    _cas.put(bucket, thumb_key, thumb, "image/webp")
            except Exception as exc:
                warnings.warn(f"thumbnail upload failed: {exc}", RuntimeWarning, stacklevel=2)

        return str(path), CasRef(
            bucket=bucket, key=key, hash_hex=hash_hex,
            size=len(data), content_type=content_type,
            width=dims[0] if dims else None,
            height=dims[1] if dims else None,
        )

    refs: dict[str, CasRef] = {}
    errors: dict[str, Exception] = {}
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(_one, p): p for p in paths}
        for f in tqdm(as_completed(futures), total=len(futures),
                      desc="Uploading", disable=not verbose):
            try:
                k, ref = f.result()
                refs[k] = ref
            except Exception as exc:   # 건당 격리: 한 파일 실패가 배치를 죽이지 않음
                errors[str(futures[f])] = exc

    if errors:
        shown = ", ".join(list(errors)[:5])
        more = f" 외 {len(errors) - 5}건" if len(errors) > 5 else ""
        first_err = next(iter(errors.values()))
        msg = (
            f"{len(errors)}개 파일 업로드 실패(재시도 후): {shown}{more}. "
            f"첫 에러: {first_err}. "
            "같은 paths로 nx.upload를 다시 호출하면 성공분은 건너뛰고 실패분만 재시도합니다."
        )
        if strict:
            raise NexusCasError(msg)
        warnings.warn(msg, RuntimeWarning, stacklevel=2)
    return refs
