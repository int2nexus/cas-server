from __future__ import annotations
import hashlib
import hmac
import mimetypes
from datetime import datetime, timezone
from pathlib import Path
import blake3
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from nexus._types import NexusCasError

# 대량 적재용: 일시적 5xx/네트워크 끊김을 전송 계층에서 백오프 재시도.
# PUT은 key당 내용이 고정(content-addressed)이라 재시도 안전.
_RETRY = Retry(
    total=3,
    backoff_factor=0.5,
    status_forcelist=(429, 500, 502, 503, 504),
    allowed_methods=frozenset(["HEAD", "GET", "PUT"]),
    respect_retry_after_header=True,
    raise_on_status=False,
)

_EMPTY_SHA256 = hashlib.sha256(b"").hexdigest()


def _build_session(pool_maxsize: int = 32) -> requests.Session:
    session = requests.Session()
    adapter = HTTPAdapter(
        max_retries=_RETRY,
        pool_connections=pool_maxsize,
        pool_maxsize=pool_maxsize,
    )
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session


def _sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _hmac(key: bytes, data: bytes) -> bytes:
    return hmac.new(key, data, hashlib.sha256).digest()


def _signing_key(secret: str, date: str, region: str) -> bytes:
    k_date = _hmac(("AWS4" + secret).encode(), date.encode())
    k_region = _hmac(k_date, region.encode())
    k_service = _hmac(k_region, b"s3")
    return _hmac(k_service, b"aws4_request")


def _canonical_request(
    method: str, path: str, host: str, payload_hash: str, amz_date: str
) -> str:
    """SigV4 canonical request. 서버 cas_client.rs::sigv4_auth와 **바이트 동일**해야 한다.

    SignedHeaders = host;x-amz-content-sha256;x-amz-date (고정), CanonicalQueryString 비어 있음.
    줄바꿈/공백 한 글자라도 다르면 서명 불일치 → 절대 변형 금지.
    """
    return (
        f"{method}\n"
        f"{path}\n"
        f"\n"  # CanonicalQueryString (비어 있음)
        f"host:{host}\n"
        f"x-amz-content-sha256:{payload_hash}\n"
        f"x-amz-date:{amz_date}\n"
        f"\n"  # canonical headers 종료 빈 줄
        f"host;x-amz-content-sha256;x-amz-date\n"
        f"{payload_hash}"
    )


class CasClient:
    def __init__(
        self,
        cas_url: str,
        key_id: str = "",
        secret: str = "",
        region: str = "cas-default",
    ) -> None:
        self._base = cas_url.rstrip("/")
        self._key_id = key_id
        self._secret = secret
        self._region = region
        # 커넥션 재사용(keep-alive) + 재시도를 위해 클라이언트당 Session 하나.
        self._session = _build_session()

    def _host(self) -> str:
        # 스킴만 제거, 포트는 유지 (서버 sigv4_auth와 동일).
        return self._base.removeprefix("http://").removeprefix("https://")

    def _signed_headers(self, method: str, path: str, body: bytes) -> dict:
        """SigV4 Authorization/x-amz-date/x-amz-content-sha256 헤더. 자격증명 없으면 {}.

        서버 cas_client.rs::sigv4_auth 그대로 (host;x-amz-content-sha256;x-amz-date 서명).
        """
        if not (self._key_id and self._secret):
            return {}
        now = datetime.now(timezone.utc)
        date = now.strftime("%Y%m%d")
        amz_date = now.strftime("%Y%m%dT%H%M%SZ")
        payload_hash = _sha256_hex(body)

        canonical_request = _canonical_request(
            method, path, self._host(), payload_hash, amz_date
        )
        credential_scope = f"{date}/{self._region}/s3/aws4_request"
        string_to_sign = (
            f"AWS4-HMAC-SHA256\n"
            f"{amz_date}\n"
            f"{credential_scope}\n"
            f"{_sha256_hex(canonical_request.encode())}"
        )
        signature = _hmac(
            _signing_key(self._secret, date, self._region),
            string_to_sign.encode(),
        ).hex()
        auth = (
            f"AWS4-HMAC-SHA256 Credential={self._key_id}/{credential_scope}, "
            f"SignedHeaders=host;x-amz-content-sha256;x-amz-date, "
            f"Signature={signature}"
        )
        return {
            "Authorization": auth,
            "x-amz-date": amz_date,
            "x-amz-content-sha256": payload_hash,
        }

    def head(self, bucket: str, key: str) -> dict | None:
        path = f"/{bucket}/{key}"
        r = self._session.head(
            f"{self._base}{path}", headers=self._signed_headers("HEAD", path, b"")
        )
        if r.status_code == 404:
            return None
        if not r.ok:
            raise NexusCasError(
                f"CAS HEAD failed ({r.status_code}): {bucket}/{key} — {r.text[:300]}"
            )
        etag = r.headers.get("ETag", r.headers.get("etag", "")).strip('"')
        hash_hex = r.headers.get("x-cas-hash", "") or etag
        size_str = r.headers.get("content-length", "")
        return {
            "hash_hex": hash_hex,
            "size": int(size_str) if size_str else None,
            "content_type": r.headers.get("content-type"),
        }

    def put(
        self,
        bucket: str,
        key: str,
        data: bytes,
        content_type: str = "application/octet-stream",
    ) -> None:
        path = f"/{bucket}/{key}"
        headers = self._signed_headers("PUT", path, data)
        headers["Content-Type"] = content_type  # 서명 대상 아님(SignedHeaders에 미포함)
        r = self._session.put(f"{self._base}{path}", data=data, headers=headers)
        if not r.ok:
            raise NexusCasError(
                f"CAS PUT failed ({r.status_code}): {bucket}/{key} — {r.text[:300]}"
            )

    def get(self, bucket: str, key: str) -> bytes:
        path = f"/{bucket}/{key}"
        r = self._session.get(
            f"{self._base}{path}", headers=self._signed_headers("GET", path, b"")
        )
        if not r.ok:
            raise NexusCasError(
                f"CAS GET failed ({r.status_code}): {bucket}/{key} — {r.text[:300]}"
            )
        return r.content

    @staticmethod
    def hash_bytes(data: bytes) -> str:
        return blake3.blake3(data).hexdigest()

    @staticmethod
    def content_type(path: Path) -> str:
        ct, _ = mimetypes.guess_type(str(path))
        return ct or "application/octet-stream"
