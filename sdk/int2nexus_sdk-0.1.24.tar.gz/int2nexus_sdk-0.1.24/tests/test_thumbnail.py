import io
from PIL import Image
from nexus.upload import _make_thumbnail


def _png(w, h):
    import struct, zlib
    def chunk(name, d):
        crc = zlib.crc32(name + d) & 0xFFFFFFFF
        return struct.pack(">I", len(d)) + name + d + struct.pack(">I", crc)
    sig = b"\x89PNG\r\n\x1a\n"
    ihdr = chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))  # color type 2 = RGB
    row = b"\x00" + b"\x80\x80\x80" * w
    idat = chunk(b"IDAT", zlib.compress(row * h))
    iend = chunk(b"IEND", b"")
    return sig + ihdr + idat + iend


def test_make_thumbnail_resizes_large_image_to_webp():
    out = _make_thumbnail(_png(800, 600))
    assert out is not None
    img = Image.open(io.BytesIO(out))
    assert img.format == "WEBP"
    assert max(img.size) == 256
    assert img.size == (256, 192)   # 비율 유지


def test_make_thumbnail_does_not_upscale_small_image():
    img = Image.open(io.BytesIO(_make_thumbnail(_png(100, 80))))
    assert img.size == (100, 80)


def _png_gray(w, h):
    import struct, zlib
    def chunk(name, d):
        crc = zlib.crc32(name + d) & 0xFFFFFFFF
        return struct.pack(">I", len(d)) + name + d + struct.pack(">I", crc)
    sig = b"\x89PNG\r\n\x1a\n"
    ihdr = chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 0, 0, 0, 0))  # color type 0 = grayscale
    row = b"\x00" + b"\x80" * w
    idat = chunk(b"IDAT", zlib.compress(row * h))
    iend = chunk(b"IEND", b"")
    return sig + ihdr + idat + iend


def test_make_thumbnail_converts_non_rgb_to_rgb_webp():
    out = _make_thumbnail(_png_gray(300, 300))   # grayscale 입력
    assert out is not None
    img = Image.open(io.BytesIO(out))
    assert img.format == "WEBP"
    assert img.mode == "RGB"        # convert("RGB") 경로 검증
    assert max(img.size) == 256


def test_make_thumbnail_returns_none_on_undecodable_bytes(recwarn):
    assert _make_thumbnail(b"not an image") is None
    assert any("thumbnail generation failed" in str(w.message) for w in recwarn)


def _png_gray16(w, h, values):
    """values(x, y) -> 0..65535. 16 비트 그레이스케일 PNG(빅엔디언)."""
    import struct, zlib
    def chunk(name, d):
        crc = zlib.crc32(name + d) & 0xFFFFFFFF
        return struct.pack(">I", len(d)) + name + d + struct.pack(">I", crc)
    sig = b"\x89PNG\r\n\x1a\n"
    ihdr = chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 16, 0, 0, 0, 0))
    rows = b""
    for y in range(h):
        rows += b"\x00" + b"".join(struct.pack(">H", values(x, y)) for x in range(w))
    return sig + ihdr + chunk(b"IDAT", zlib.compress(rows)) + chunk(b"IEND", b"")


def _thumb_rgb(data):
    out = _make_thumbnail(data)
    assert out is not None
    return Image.open(io.BytesIO(out)).convert("RGB")


def test_gray16_depth_thumbnail_is_not_washed_out():
    # 500~6,000 mm 그라데이션 — 8 비트로 잘라내면 전부 255 로 하얗게 날아간다.
    img = _thumb_rgb(_png_gray16(512, 512, lambda x, y: 500 + (x * 5500) // 511))
    px = list(img.getdata())
    mean = sum(p[0] for p in px) / len(px)
    assert 64 <= mean <= 192, mean


def test_gray16_zero_stays_black():
    img = _thumb_rgb(_png_gray16(512, 512, lambda x, y: 0 if x < 256 else 1000 + x))
    assert img.getpixel((10, 100)) == (0, 0, 0)
    assert img.getpixel((50, 100)) == (0, 0, 0)
    assert img.getpixel((200, 100))[0] > 0


def test_gray16_all_zero_is_black():
    img = _thumb_rgb(_png_gray16(64, 64, lambda x, y: 0))
    assert set(img.getdata()) == {(0, 0, 0)}


def test_gray16_constant_value_is_white():
    img = _thumb_rgb(_png_gray16(64, 64, lambda x, y: 3000))
    assert img.getpixel((10, 10)) == (255, 255, 255)


def test_gray16_gradient_is_mapped_linearly_not_clipped():
    img = _thumb_rgb(_png_gray16(512, 512, lambda x, y: 500 + (x * 5500) // 511))
    w, h = img.size
    left = img.getpixel((2, h // 2))[0]
    mid = img.getpixel((w // 2, h // 2))[0]
    right = img.getpixel((w - 3, h // 2))[0]
    assert left < 40, left
    assert right > 215, right
    assert left < mid < right


def test_gray16_min_nonzero_value_is_not_black_next_to_zero():
    # 왼쪽 0(무효), 오른쪽은 작은 값 1..8 — 8 비트로 자르면 전부 0~8 이라 사실상 검정이다.
    img = _thumb_rgb(_png_gray16(64, 64, lambda x, y: 0 if x < 32 else 1 + (x - 32) // 4))
    assert img.getpixel((5, 10))[0] == 0
    assert img.getpixel((33, 10))[0] >= 1
    assert img.getpixel((62, 10))[0] > 200


def test_gray16_outlier_does_not_crush_the_bulk():
    # 대부분 1000~2000 사이, 한 픽셀만 65535 — 최대값 기준이면 본체가 거의 검정이 된다.
    def v(x, y):
        if (x, y) == (10, 10):
            return 65535
        return 1000 + (x * 1000) // 63
    img = _thumb_rgb(_png_gray16(64, 64, v))
    assert img.getpixel((60, 30))[0] > 200
    assert 90 < img.getpixel((32, 30))[0] < 170
    assert img.getpixel((3, 30))[0] < 60
