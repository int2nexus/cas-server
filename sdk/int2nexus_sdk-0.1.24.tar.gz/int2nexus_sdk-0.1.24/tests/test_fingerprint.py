import builtins
import json
from unittest.mock import MagicMock

import pytest

from nexus._fingerprint import _fp_row, fingerprint_rows
from nexus._types import NexusError
from nexus.dataset import Dataset, _snapshot_shape

from tests.test_dataset import _register_snapshot, _signed_cas, _ndjson_lines


def _snapshot_rows():
    """seal 스냅샷 행 — meta 가 없는 행은 키가 없고 sample_id 오름차순."""
    return [
        {"sample_id": "s1", "box": [{"id": "i1", "label": "car"}]},
        {"sample_id": "s2", "meta": {"width": 640}, "box": [{"id": "i2", "label": "truck"}]},
    ]


def _explorer_rows():
    """같은 두 샘플의 explorer 행 — 다섯 키가 붙고 meta 없음이 `{}`, sample_id 내림차순."""
    extra = {
        "split": "train", "tags": ["a"], "created_at": "2026-10-19T00:00:00Z",
        "image_url": "http://cas/x.png", "thumbnail_url": "http://cas/thumb/x.png",
    }
    return [
        {"sample_id": "s2", "meta": {"width": 640}, "box": [{"id": "i2", "label": "truck"}], **extra},
        {"sample_id": "s1", "meta": {}, "box": [{"id": "i1", "label": "car"}], **extra},
    ]


def test_fingerprint_same_for_snapshot_and_explorer_rows():
    explorer = [_snapshot_shape(r, None) for r in _explorer_rows()]
    assert fingerprint_rows(_snapshot_rows()) == fingerprint_rows(explorer)


def test_fingerprint_same_with_groups_reduction():
    """groups 축약은 스냅샷 행의 없는 meta 를 None 으로 만든다 — explorer 의 `{}` 와 같게 본다."""
    from nexus.dataset import _reduce_groups

    snap = [_reduce_groups(r, ["box"]) for r in _snapshot_rows()]
    exp = [_snapshot_shape(r, ["box"]) for r in _explorer_rows()]
    assert fingerprint_rows(snap) == fingerprint_rows(exp)


def test_fingerprint_changes_when_one_value_changes():
    rows = _snapshot_rows()
    changed = json.loads(json.dumps(rows))
    changed[1]["box"][0]["label"] = "bus"
    assert fingerprint_rows(rows) != fingerprint_rows(changed)


def test_fingerprint_ignores_key_order():
    a = [{"sample_id": "s1", "meta": {"w": 1, "h": 2}, "box": [{"id": "i", "label": "car"}]}]
    b = [{"box": [{"label": "car", "id": "i"}], "meta": {"h": 2, "w": 1}, "sample_id": "s1"}]
    assert fingerprint_rows(a) == fingerprint_rows(b)


def test_fingerprint_format():
    fp = fingerprint_rows(_snapshot_rows())
    assert fp.startswith("nxfp1:")
    assert len(fp) == 6 + 64
    int(fp[6:], 16)


def test_fp_row_drops_empty_meta_without_mutating():
    row = {"sample_id": "s1", "meta": {}}
    assert _fp_row(row) == {"sample_id": "s1"}
    assert row == {"sample_id": "s1", "meta": {}}
    assert _fp_row({"sample_id": "s1", "meta": {"w": 1}}) == {"sample_id": "s1", "meta": {"w": 1}}


def _draft_client(rows):
    mock_client = MagicMock()
    mock_client.get_manifest.return_value = {"annotation_snapshot": None}
    mock_client.explore_samples.side_effect = lambda *a, **kw: list(rows) if kw.get("cursor") is None else []
    return mock_client


def _ds(client, cas=None):
    return Dataset(client, cas or MagicMock(), "d1", "kitti", "v1")


def test_fingerprint_snapshot_source_on_draft_raises(recwarn):
    ds = _ds(_draft_client(_explorer_rows()))
    with pytest.raises(NexusError, match="draft"):
        ds.fingerprint(source="snapshot")


def test_fingerprint_rejects_unknown_source():
    mock_client = MagicMock()
    with pytest.raises(ValueError, match="source"):
        _ds(mock_client).fingerprint(source="cache")
    mock_client.get_manifest.assert_not_called()


def test_fingerprint_draft_equals_rows_fingerprint(recwarn):
    ds = _ds(_draft_client(_explorer_rows()))
    assert ds.fingerprint() == fingerprint_rows(_snapshot_rows())


def test_fingerprint_snapshot_and_explorer_sources_agree_on_sealed(requests_mock, recwarn):
    """sealed 버전에서 explorer 가 스냅샷과 같은 내용을 주면 두 출처의 지문이 같다."""
    mock_client, _ = _register_snapshot(requests_mock)
    snap_rows = [json.loads(l) for l in _ndjson_lines().splitlines() if l.strip()]
    extra = {"split": None, "tags": [], "created_at": "t", "image_url": None, "thumbnail_url": None}
    explorer = [{**r, **extra} for r in reversed(snap_rows)]
    mock_client.explore_samples.side_effect = lambda *a, **kw: explorer if kw.get("cursor") is None else []

    ds = _ds(mock_client, _signed_cas())
    assert ds.fingerprint(source="snapshot") == ds.fingerprint(source="explorer")
    assert ds.fingerprint() == fingerprint_rows(snap_rows)


def test_to_df_attaches_fingerprint_attr(requests_mock, recwarn):
    mock_client, _ = _register_snapshot(requests_mock)
    df = _ds(mock_client, _signed_cas()).to_df()
    snap_rows = [json.loads(l) for l in _ndjson_lines().splitlines() if l.strip()]
    assert df.attrs["nexus_fingerprint"] == fingerprint_rows(snap_rows)

    draft = _ds(_draft_client(_explorer_rows())).to_df()
    assert draft.attrs["nexus_fingerprint"] == fingerprint_rows(_snapshot_rows())


def test_fingerprint_does_not_need_pandas(monkeypatch, recwarn):
    ds = _ds(_draft_client(_explorer_rows()))
    real_import = builtins.__import__

    def no_pandas(name, *args, **kwargs):
        if name == "pandas" or name.startswith("pandas."):
            raise ImportError("No module named 'pandas'")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", no_pandas)
    assert ds.fingerprint().startswith("nxfp1:")


def test_fingerprint_explorer_source_on_sealed_does_not_warn(requests_mock, recwarn):
    """sealed 버전에서 explorer 출처를 고르는 것은 두 경로를 대조하려는 것이다 — draft 경고는 틀린 말이다."""
    mock_client, _ = _register_snapshot(requests_mock)
    mock_client.explore_samples.side_effect = lambda *a, **kw: []

    ds = _ds(mock_client, _signed_cas())
    ds.fingerprint(source="explorer")

    assert not [w for w in recwarn if issubclass(w.category, RuntimeWarning)]


def test_fingerprint_explorer_source_on_draft_still_warns_once(recwarn):
    ds = _ds(_draft_client(_explorer_rows()))
    with pytest.warns(RuntimeWarning, match="draft"):
        ds.fingerprint(source="explorer")
    recwarn.clear()
    ds.fingerprint()
    assert not [w for w in recwarn if issubclass(w.category, RuntimeWarning)]
