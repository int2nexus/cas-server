"""ds.set_assets — 적재한 샘플에 에셋 붙이기 (PATCH .../samples/assets)."""
from unittest.mock import MagicMock

import pytest

from nexus import _retry
from nexus._types import NexusError
from nexus.dataset import Dataset
from nexus.sample import CasRef


def _ds(client=None):
    c = client or MagicMock()
    return Dataset(c, MagicMock(), "d1", "kitti", "v1"), c


def _rich(key="depth/a.png"):
    return CasRef(bucket="b", key=key, hash_hex="ab" * 32, size=10, content_type="image/png")


def test_set_assets_wire_body():
    ds, c = _ds()
    c.patch_asset_items.return_value = {"updated": 1, "unchanged": 0}
    assert ds.set_assets("depth", {"s1": _rich()}) == 1
    args = c.patch_asset_items.call_args
    assert args.args[:2] == ("d1", "v1")
    items = args.args[2]
    assert items[0]["sample_id"] == "s1"
    a = items[0]["assets"]["depth"]
    assert a["bucket"] == "b" and a["key"] == "depth/a.png"
    assert a["hash_hex"] == "ab" * 32 and a["logical_name"] == "a.png"
    assert args.args[3] is False


def test_set_assets_overwrite_flag_is_sent():
    ds, c = _ds()
    c.patch_asset_items.return_value = {"updated": 1, "unchanged": 0}
    ds.set_assets("depth", {"s1": _rich()}, overwrite=True)
    assert c.patch_asset_items.call_args.args[3] is True


def test_set_assets_chunks_by_10000(monkeypatch):
    import nexus.dataset as dsmod

    monkeypatch.setattr(dsmod, "_META_ITEMS_MAX_BYTES", 10**9)  # 건수 상한만 본다
    ds, c = _ds()
    c.patch_asset_items.side_effect = lambda d, v, items, ow: {"updated": len(items), "unchanged": 0}
    vals = {f"s{i}": _rich(f"depth/{i}.png") for i in range(10_001)}
    assert ds.set_assets("depth", vals) == 10_001
    sizes = [len(call.args[2]) for call in c.patch_asset_items.call_args_list]
    assert sizes == [10_000, 1]


def test_set_assets_chunks_by_body_budget():
    ds, c = _ds()
    c.patch_asset_items.side_effect = lambda d, v, items, ow: {"updated": len(items), "unchanged": 0}
    vals = {f"s{i}": _rich(f"depth/{i}.png") for i in range(5_000)}
    assert ds.set_assets("depth", vals) == 5_000
    calls = c.patch_asset_items.call_args_list
    assert len(calls) > 1  # 약 800 KB 예산으로 잘린다(Ingress 1 MB 상한)
    import json
    assert all(len(json.dumps(call.args[2])) <= 800_000 for call in calls)
    sent = [i["sample_id"] for call in calls for i in call.args[2]]
    assert sent == list(vals)


def test_set_assets_rejects_image_role():
    ds, c = _ds()
    with pytest.raises(ValueError, match="image"):
        ds.set_assets("image", {"s1": _rich()})
    c.patch_asset_items.assert_not_called()


def test_set_assets_rejects_local_path():
    ds, c = _ds()
    with pytest.raises(ValueError, match="CAS"):
        ds.set_assets("depth", {"s1": "/tmp/depth.png"})
    c.patch_asset_items.assert_not_called()


def test_set_assets_rejection_raises_with_rejected():
    ds, c = _ds()
    rej = [{"sample_id": "s2", "role": "depth", "reason": "role_exists"}]
    c.patch_asset_items.side_effect = NexusError(
        "거절", status_code=400, server_message="거절", code="asset_write_rejected", rejected=rej,
    )
    with pytest.raises(NexusError) as ei:
        ds.set_assets("depth", {"s1": _rich(), "s2": _rich("depth/b.png")})
    e = ei.value
    assert e.code == "asset_write_rejected" and e.rejected == rej
    assert e.applied == 0 and e.failed_sample_id == "s2"


def test_set_assets_404_explains_server_version():
    ds, c = _ds()
    # 옛 서버의 없는 경로: 서버가 만든 오류 본문이 없다.
    c.patch_asset_items.side_effect = NexusError("404", status_code=404, server_message=None)
    with pytest.raises(NexusError, match="0.1.29"):
        ds.set_assets("depth", {"s1": _rich()})


def test_set_assets_405_explains_server_version():
    ds, c = _ds()
    c.patch_asset_items.side_effect = NexusError("405", status_code=405, server_message=None)
    with pytest.raises(NexusError, match="0.1.29"):
        ds.set_assets("depth", {"s1": _rich()})


def test_set_assets_404_with_server_body_is_not_a_version_problem():
    ds, c = _ds()
    c.patch_asset_items.side_effect = NexusError(
        "version v9 not found", status_code=404, server_message="version v9 not found",
    )
    with pytest.raises(NexusError) as ei:
        ds.set_assets("depth", {"s1": _rich()})
    assert "0.1.29" not in str(ei.value)
    assert ei.value.status_code == 404


def test_patch_asset_items_route_is_retry_safe():
    assert _retry.is_safe("PATCH", "/datasets/d1/versions/v1/samples/assets")


def test_patch_asset_items_client_wire(requests_mock):
    from nexus.client import NexusClient

    requests_mock.post("http://nexus.test/api/v1/auth/login",
                       json={"token": "t", "user_id": 1, "email": "u@x.com"})
    c = NexusClient("http://nexus.test", "u@x.com", "pass")
    m = requests_mock.patch("http://nexus.test/datasets/d1/versions/v1/samples/assets",
                            json={"updated": 1, "unchanged": 0})
    out = c.patch_asset_items("d1", "v1", [{"sample_id": "s1", "assets": {}}], True)
    assert out["updated"] == 1
    assert m.last_request.json() == {"items": [{"sample_id": "s1", "assets": {}}], "overwrite": True}
