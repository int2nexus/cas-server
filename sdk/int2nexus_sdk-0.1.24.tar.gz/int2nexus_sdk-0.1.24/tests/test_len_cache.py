"""SDK 0.1.22 — len(ds) 캐시. sealed 는 서버가 저장한 sample_count, draft 는 한 번 세고 핸들의 쓰기·refresh 뒤에 다시 센다."""
import pytest
import requests

from nexus import NexusError
from nexus.cas import CasClient
from nexus.client import NexusClient
from nexus.dataset import Dataset
from nexus.sample import CasRef, Sample

_NEXUS = "http://nexus.test"
DS = f"{_NEXUS}/datasets/d1"
VER = f"{DS}/versions/v1"
COUNT = f"{VER}/samples/explorer/count"


def _client(requests_mock):
    requests_mock.post(f"{_NEXUS}/api/v1/auth/login", json={"token": "t", "user_id": 1, "email": "u@x.com"})
    return NexusClient(_NEXUS, "u@x.com", "pass", retry_timeout=0)


@pytest.fixture
def ds(requests_mock):
    return Dataset(_client(requests_mock), CasClient("http://cas"), "d1", "kitti", "v1")


def _draft(requests_mock, n=7):
    ver = requests_mock.get(VER, json={"version": "v1", "status": "draft"})
    count = requests_mock.post(COUNT, json={"count": n, "exact": True})
    return ver, count


def test_sealed_len_uses_stored_count_without_counting(ds, requests_mock):
    ver = requests_mock.get(VER, json={"version": "v1", "status": "sealed", "sample_count": 300_000})
    count = requests_mock.post(COUNT, json={"count": 1, "exact": True})
    assert len(ds) == 300_000
    assert len(ds) == 300_000
    assert ver.call_count == 1 and not count.called


def test_draft_len_counts_once_then_caches(ds, requests_mock):
    ver, count = _draft(requests_mock)
    assert len(ds) == 7
    assert len(ds) == 7
    assert ver.call_count == 1 and count.call_count == 1
    assert count.last_request.qs == {"exact": ["true"]}


def test_old_server_sealed_without_field_falls_back_to_counting(ds, requests_mock):
    requests_mock.get(VER, json={"version": "v1", "status": "sealed"})
    count = requests_mock.post(COUNT, json={"count": 5, "exact": True})
    assert len(ds) == 5 and count.call_count == 1


def test_len_of_deleted_version_is_404(ds, requests_mock):
    requests_mock.get(VER, status_code=404, json={"error": "version v1 not found"})
    with pytest.raises(NexusError) as ei:
        len(ds)
    assert ei.value.status_code == 404


def test_refresh_drops_the_cache(ds, requests_mock):
    ver, count = _draft(requests_mock)
    requests_mock.get(DS, json={"dataset_id": "d1", "name": "kitti", "tags": []})
    len(ds)
    ds.refresh()
    len(ds)
    assert count.call_count == 2


@pytest.mark.parametrize("call", [
    lambda ds: ds.link_samples(["s1"]),
    lambda ds: ds.unlink_samples(["s1"]),
    lambda ds: ds.import_samples("d2", "v9", ["s1"]),
])
def test_membership_writes_drop_the_cache(ds, requests_mock, call):
    ver, count = _draft(requests_mock)
    requests_mock.post(f"{VER}/samples", json={})
    requests_mock.delete(f"{VER}/samples", json={"removed": 1})
    requests_mock.post(f"{VER}/samples/import", json={"imported": []})
    len(ds)
    call(ds)
    len(ds)
    assert count.call_count == 2


def test_failed_write_also_drops_the_cache(ds, requests_mock):
    ver, count = _draft(requests_mock)
    requests_mock.delete(f"{VER}/samples", status_code=409, json={"error": "sealed"})
    len(ds)
    with pytest.raises(NexusError):
        ds.unlink_samples(["s1"])
    len(ds)
    assert count.call_count == 2


def test_flush_drops_the_cache_even_when_it_fails(ds, requests_mock):
    ver, count = _draft(requests_mock)
    requests_mock.post(f"{_NEXUS}/ingest/batch", exc=requests.exceptions.ConnectionError("boom"))
    len(ds)
    ref = CasRef("b", "k/a.png", hash_hex="h", size=10, content_type="image/png")
    ds.add(Sample(image=ref, annotation={"meta": {"width": 4, "height": 4, "filename": "http://cas/b/k/a.png"}}))
    ds.flush(verbose=False)
    len(ds)
    assert count.call_count == 2


def test_with_block_exit_flush_drops_the_cache(ds, requests_mock):
    ver, count = _draft(requests_mock)
    len(ds)
    with ds:
        pass
    len(ds)
    assert count.call_count == 2


def test_delete_drops_the_cache(ds, requests_mock):
    ver, count = _draft(requests_mock)
    requests_mock.delete(VER, json={"dataset_id": "d1", "version": "v1", "dataset_deleted": False})
    len(ds)
    ds.delete(confirm=True, delete_cas=False, verbose=False)
    len(ds)
    assert count.call_count == 2


def test_seal_refills_the_cache_from_its_response(ds, requests_mock):
    ver, count = _draft(requests_mock)
    requests_mock.post(f"{VER}/seal", json={"version": "v1", "status": "sealed", "sample_count": 7})
    len(ds)
    ds.seal()
    assert len(ds) == 7
    assert ver.call_count == 1 and count.call_count == 1, "seal 응답의 값으로 채워져 다시 묻지 않는다"


def test_seal_ignore_refills_from_refetched_version(ds, requests_mock):
    ver, count = _draft(requests_mock)
    len(ds)
    requests_mock.post(f"{VER}/seal", status_code=409, json={"error": "already sealed"})
    requests_mock.get(VER, json={"version": "v1", "status": "sealed", "sample_count": 9})
    ds.seal(if_sealed="ignore")
    assert len(ds) == 9
    assert count.call_count == 1


def test_fork_handle_does_not_inherit_the_cache(ds, requests_mock, monkeypatch):
    ver, count = _draft(requests_mock)
    len(ds)
    fresh = Dataset(ds._client, ds._cas, "d1", "kitti", "v2")
    monkeypatch.setattr(Dataset, "load_or_create", classmethod(lambda cls, *a, **k: fresh))
    forked = ds.fork("v2")
    assert forked is fresh and forked._len_cache is None
    assert ds._len_cache == 7


def test_open_prefills_sealed_count(requests_mock):
    c = _client(requests_mock)
    requests_mock.get(DS, json={"dataset_id": "d1", "name": "kitti", "tags": []})
    ver = requests_mock.get(VER, json={"version": "v1", "status": "sealed", "sample_count": 42})
    count = requests_mock.post(COUNT, json={"count": 1, "exact": True})
    ds = Dataset.open("d1", "v1", client=c, cas=CasClient("http://cas"))
    assert len(ds) == 42
    assert ver.call_count == 1 and not count.called


def test_failed_seal_drops_the_cache(ds, requests_mock):
    # seal 이 실패해도 캐시는 버린다 — 응답으로 다시 채울 값이 없으니 다음 len() 이 서버에 묻는다.
    ver, count = _draft(requests_mock)
    requests_mock.post(f"{VER}/seal", status_code=400, json={"error": "bad description"})
    len(ds)
    with pytest.raises(NexusError):
        ds.seal()
    len(ds)
    assert count.call_count == 2


def test_seal_response_without_count_drops_the_cache(ds, requests_mock):
    # 옛 서버의 seal 응답에는 sample_count 가 없다 — 옛 캐시를 들고 있지 않고 다시 묻는다.
    ver, count = _draft(requests_mock)
    requests_mock.post(f"{VER}/seal", json={"version": "v1", "status": "sealed"})
    len(ds)
    ds.seal()
    len(ds)
    assert count.call_count == 2
