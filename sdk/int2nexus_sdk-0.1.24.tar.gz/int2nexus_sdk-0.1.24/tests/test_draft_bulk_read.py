"""SDK 0.1.24 — draft 대량 읽기 표시 헤더와 서버 거절의 문구."""
import warnings

import pytest

from nexus import NexusError
from nexus.cas import CasClient
from nexus.client import NexusClient
from nexus.dataset import Dataset, Subset

_NEXUS = "http://nexus.test"
VER = f"{_NEXUS}/datasets/d1/versions/v1"
EXPLORER = f"{VER}/samples/explorer"
HEADER = "x-nexus-bulk-read"
MESSAGE = "운영자가 draft 대량 읽기를 껐습니다 — sealed 버전을 쓰십시오"


def _client(requests_mock):
    requests_mock.post(f"{_NEXUS}/api/v1/auth/login", json={"token": "t", "user_id": 1, "email": "u@x.com"})
    return NexusClient(_NEXUS, "u@x.com", "pass", retry_timeout=0)


@pytest.fixture
def ds(requests_mock):
    return Dataset(_client(requests_mock), CasClient("http://cas"), "d1", "kitti", "v1")


def _row(sid):
    return {"sample_id": sid, "dataset_id": "d1", "meta": {}, "tags": [], "split": None}


def _draft(requests_mock):
    requests_mock.get(VER, json={"version": "v1", "status": "draft"})
    requests_mock.get(f"{VER}/manifest", json={"annotation_snapshot": None})


def _explorer(requests_mock, rows=None):
    return requests_mock.post(EXPLORER, json=rows if rows is not None else [_row("s1")])


def _marked(m):
    return m.last_request.headers.get(HEADER)


def test_draft_to_df_marks_explorer(ds, requests_mock):
    _draft(requests_mock)
    m = _explorer(requests_mock)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        ds.to_df()
    assert _marked(m) == "1"


def test_fingerprint_explorer_marks(ds, requests_mock):
    requests_mock.get(VER, json={"version": "v1", "status": "sealed"})
    requests_mock.get(
        f"{VER}/manifest", json={"annotation_snapshot": {"cas_url": "http://cas/snap", "hash_hex": None}},
    )
    m = _explorer(requests_mock)
    ds.fingerprint(source="explorer")
    assert _marked(m) == "1"


def test_iter_samples_marks(ds, requests_mock):
    m = _explorer(requests_mock)
    list(ds.iter_samples())
    assert _marked(m) == "1"


def test_samples_with_annotations_marks(ds, requests_mock):
    m = _explorer(requests_mock)
    ds.samples(include_annotations=True)
    assert _marked(m) == "1"


def test_samples_without_annotations_does_not_mark(ds, requests_mock):
    m = _explorer(requests_mock)
    ds.samples(include_annotations=False)
    assert _marked(m) is None


def test_projection_does_not_mark(ds, requests_mock):
    m = _explorer(requests_mock, [{"sample_id": "s1", "meta.k": 1}])
    list(ds.values("meta.k"))
    assert m.called and _marked(m) is None


def test_shuffle_marks_only_the_body_read(ds, requests_mock):
    def reply(request, context):
        body = request.json()
        return [{"sample_id": "s1"}] if body.get("fields") else [_row("s1")]

    m = requests_mock.post(EXPLORER, json=reply)
    list(ds.shuffle(seed=1))
    by_kind = {bool(r.json().get("fields")): r for r in m.request_history}
    assert by_kind[True].headers.get(HEADER) is None  # id 수집(projection)
    assert by_kind[False].headers.get(HEADER) == "1"  # 본 조회


def test_subset_reads_do_not_mark(ds, requests_mock):
    # /subsets/{id}/samples 는 explorer 가 아닌 별도 경로라 서버가 막지 않는다 — 표시를 붙이지 않는다.
    requests_mock.get(VER, json={"version": "v1", "status": "sealed"})
    m = requests_mock.get(f"{_NEXUS}/subsets/sub1/samples", json=[_row("s1")])
    sub = Subset.__new__(Subset)
    sub._client, sub._ds, sub.subset_id, sub.version = ds._client, ds, "sub1", "v1"
    sub.samples(include_annotations=True)
    assert _marked(m) is None
    sub.to_df()
    assert _marked(m) is None


def test_disabled_draft_read_is_one_request_with_the_message(ds, requests_mock):
    _draft(requests_mock)
    m = requests_mock.post(EXPLORER, status_code=403, json={
        "error": "다른 문구", "code": "draft_bulk_read_disabled",
    })
    with pytest.raises(NexusError) as ei, warnings.catch_warnings():
        warnings.simplefilter("ignore")
        ds.to_df()
    assert MESSAGE in str(ei.value)
    assert ei.value.status_code == 403 and ei.value.code == "draft_bulk_read_disabled"
    assert m.call_count == 1


def test_other_403_is_unchanged(ds, requests_mock):
    requests_mock.post(EXPLORER, status_code=403, json={"error": "권한 없음"})
    with pytest.raises(NexusError) as ei:
        ds.samples(include_annotations=True)
    assert MESSAGE not in str(ei.value) and "권한 없음" in str(ei.value)
