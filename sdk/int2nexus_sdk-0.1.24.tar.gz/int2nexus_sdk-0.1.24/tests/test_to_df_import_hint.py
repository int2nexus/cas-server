import builtins

import pytest

from nexus.cas import CasClient
from nexus.client import NexusClient
from nexus.dataset import Dataset

_NEXUS = "http://nexus"


@pytest.fixture
def ds(requests_mock):
    requests_mock.post(f"{_NEXUS}/api/v1/auth/login",
                       json={"token": "t", "user_id": 1, "email": "u@x.com"})
    c = NexusClient(_NEXUS, "u@x.com", "pass", retry_timeout=0)
    return Dataset(c, CasClient("http://cas"), "d1", "kitti", "v1")


def test_to_df_without_pandas_names_an_installable_package(ds, monkeypatch):
    # 배포 패키지 이름은 int2nexus-sdk 이고 pandas extra 가 없다 — 안내대로 설치하면 되어야 한다.
    real_import = builtins.__import__

    def no_pandas(name, *args, **kwargs):
        if name == "pandas" or name.startswith("pandas."):
            raise ImportError("No module named 'pandas'")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", no_pandas)
    with pytest.raises(ImportError) as ei:
        ds.to_df()
    msg = str(ei.value)
    assert "pip install pandas" in msg
    assert "nexus-sdk[" not in msg
