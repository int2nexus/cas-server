from unittest.mock import MagicMock
import pytest


def _png(w, h):
    import struct, zlib
    def chunk(name, d):
        crc = zlib.crc32(name + d) & 0xFFFFFFFF
        return struct.pack(">I", len(d)) + name + d + struct.pack(">I", crc)
    sig = b"\x89PNG\r\n\x1a\n"
    ihdr = chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
    row = b"\x00" + b"\x80\x80\x80" * w
    idat = chunk(b"IDAT", zlib.compress(row * h))
    iend = chunk(b"IEND", b"")
    return sig + ihdr + idat + iend


def test_upload_puts_image_and_thumbnail_returns_rich_ref(tmp_path):
    from nexus.upload import upload
    from nexus.sample import CasRef
    from nexus.cas import CasClient

    img = tmp_path / "img.png"
    data = _png(400, 300)
    img.write_bytes(data)

    cas = MagicMock(); cas.head.return_value = None
    client = MagicMock()

    refs = upload([str(img)], bucket="kitti", prefix="images",
                  workers=1, verbose=False, client=client, cas=cas)

    client.ensure_bucket.assert_called_once_with("kitti")
    ref = refs[str(img)]
    assert isinstance(ref, CasRef)
    assert ref.bucket == "kitti" and ref.key == "images/img.png"
    assert ref.hash_hex == CasClient.hash_bytes(data)
    assert ref.size == len(data)
    assert ref.content_type == "image/png"
    assert ref.width == 400 and ref.height == 300  # 업로드 시 dims 캐시
    assert cas.put.call_count == 2  # image + thumbnail
    thumb = [c for c in cas.put.call_args_list if c[0][1] == "thumb/images/img.png"]
    assert len(thumb) == 1 and thumb[0][0][3] == "image/webp"


def test_upload_skips_put_when_same_hash_exists(tmp_path):
    from nexus.upload import upload
    from nexus.cas import CasClient
    img = tmp_path / "img.png"; data = _png(10, 10); img.write_bytes(data)
    cas = MagicMock()
    cas.head.return_value = {"hash_hex": CasClient.hash_bytes(data), "size": len(data), "content_type": "image/png"}
    refs = upload([str(img)], bucket="b", prefix="p", workers=1, verbose=False,
                  client=MagicMock(), cas=cas)
    cas.put.assert_not_called()
    assert refs[str(img)].key == "p/img.png"


def test_upload_collision_is_reported_as_failure(tmp_path):
    # 충돌은 건당 격리되어 실패로 보고된다 → strict=True면 raise.
    from nexus.upload import upload
    from nexus._types import NexusCasError
    img = tmp_path / "img.png"; img.write_bytes(_png(10, 10))
    cas = MagicMock()
    cas.head.return_value = {"hash_hex": "different", "size": 1, "content_type": "image/png"}
    with pytest.raises(NexusCasError, match="업로드 실패"):
        upload([str(img)], bucket="b", prefix="p", workers=1, verbose=False,
               strict=True, client=MagicMock(), cas=cas)


def test_upload_isolates_per_file_failure(tmp_path):
    # 한 파일이 실패해도 배치를 죽이지 않고 성공분만 반환 (strict=False는 경고).
    from nexus.upload import upload
    from nexus._types import NexusCasError
    a = tmp_path / "a.png"; a.write_bytes(_png(8, 8))
    b = tmp_path / "b.png"; b.write_bytes(_png(8, 8))
    cas = MagicMock(); cas.head.return_value = None

    def put_side(bucket, key, data, ct):
        if key.endswith("b.png"):
            raise NexusCasError("boom")
    cas.put.side_effect = put_side

    with pytest.warns(RuntimeWarning, match="업로드 실패"):
        refs = upload([str(a), str(b)], bucket="bk", prefix="p", workers=1,
                      verbose=False, client=MagicMock(), cas=cas)
    assert str(a) in refs and str(b) not in refs


def test_upload_strict_raises_on_any_failure(tmp_path):
    from nexus.upload import upload
    from nexus._types import NexusCasError
    a = tmp_path / "a.png"; a.write_bytes(_png(8, 8))
    cas = MagicMock(); cas.head.return_value = None
    cas.put.side_effect = NexusCasError("boom")
    with pytest.raises(NexusCasError, match="업로드 실패"):
        upload([str(a)], bucket="bk", prefix="p", workers=1, verbose=False,
               strict=True, client=MagicMock(), cas=cas)


def test_upload_overwrite_false_still_raises_on_collision(tmp_path):
    # 기본값(overwrite=False)은 기존 동작 그대로 충돌을 에러로 낸다.
    from nexus.upload import upload
    from nexus._types import NexusCasError
    img = tmp_path / "img.png"; img.write_bytes(_png(10, 10))
    cas = MagicMock()
    cas.head.return_value = {"hash_hex": "different", "size": 1, "content_type": "image/png"}
    with pytest.raises(NexusCasError, match="업로드 실패"):
        upload([str(img)], bucket="b", prefix="p", workers=1, verbose=False,
               strict=True, client=MagicMock(), cas=cas)
    cas.put.assert_not_called()


def test_upload_overwrite_true_replaces_differing_content(tmp_path):
    # overwrite=True면 다른 내용이 있어도 에러 대신 덮어쓴다 — 이미지 + 썸네일 둘 다.
    from nexus.upload import upload
    from nexus.cas import CasClient
    img = tmp_path / "img.png"; data = _png(10, 10); img.write_bytes(data)
    cas = MagicMock()
    # 이미지 key는 다른 내용, 썸네일 key는 이미 존재(이전 내용의 썸네일) — 둘 다 덮어써야 함.
    cas.head.return_value = {"hash_hex": "different", "size": 1, "content_type": "image/png"}

    refs = upload([str(img)], bucket="b", prefix="p", workers=1, verbose=False,
                  overwrite=True, client=MagicMock(), cas=cas)

    assert refs[str(img)].hash_hex == CasClient.hash_bytes(data)
    assert cas.put.call_count == 2  # image + thumbnail, 썸네일 head 존재 여부와 무관하게 덮어씀
    put_keys = [c[0][1] for c in cas.put.call_args_list]
    assert "p/img.png" in put_keys
    assert "thumb/p/img.png" in put_keys


def test_upload_overwrite_true_skips_put_when_same_hash(tmp_path):
    # overwrite=True라도 내용이 같으면(HEAD-skip) 다시 쓰지 않는다.
    from nexus.upload import upload
    from nexus.cas import CasClient
    img = tmp_path / "img.png"; data = _png(10, 10); img.write_bytes(data)
    cas = MagicMock()
    cas.head.return_value = {"hash_hex": CasClient.hash_bytes(data), "size": len(data), "content_type": "image/png"}

    refs = upload([str(img)], bucket="b", prefix="p", workers=1, verbose=False,
                  overwrite=True, client=MagicMock(), cas=cas)

    cas.put.assert_not_called()
    assert refs[str(img)].key == "p/img.png"


def test_upload_no_prefix_uses_bare_filename(tmp_path):
    from nexus.upload import upload
    img = tmp_path / "img.png"; img.write_bytes(_png(8, 8))
    cas = MagicMock(); cas.head.return_value = None
    refs = upload([str(img)], bucket="b", workers=1, verbose=False,
                  client=MagicMock(), cas=cas)
    assert refs[str(img)].key == "img.png"


def test_rewrite_thumbnails_puts_even_when_thumbnail_exists():
    from nexus.upload import rewrite_thumbnails
    from nexus.sample import CasRef

    cas = MagicMock()
    cas.get.return_value = _png(400, 300)
    cas.head.return_value = {"hash_hex": "x"}   # 썸네일이 이미 있어도

    res = rewrite_thumbnails(
        [CasRef(bucket="b", key="d/a.png"), "s3://b/d/c.png"],
        workers=1, verbose=False, cas=cas,
    )

    assert res == {"written": 2, "skipped": [], "failed": {}}
    puts = {c.args[1]: c.args for c in cas.put.call_args_list}
    assert set(puts) == {"thumb/d/a.png", "thumb/d/c.png"}
    assert all(a[0] == "b" and a[3] == "image/webp" for a in puts.values())
    cas.head.assert_not_called()


def test_rewrite_thumbnails_skips_non_images():
    import warnings
    from nexus.upload import rewrite_thumbnails

    cas = MagicMock()
    cas.get.return_value = b"not an image"
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        res = rewrite_thumbnails(["s3://b/x.bin"], workers=1, verbose=False, cas=cas)
    assert res == {"written": 0, "skipped": ["b/x.bin"], "failed": {}}
    cas.put.assert_not_called()


def test_rewrite_thumbnails_reports_failures():
    from nexus.upload import rewrite_thumbnails

    cas = MagicMock()
    cas.get.side_effect = RuntimeError("boom")
    res = rewrite_thumbnails(["s3://b/x.png"], workers=1, verbose=False, cas=cas)
    assert res["written"] == 0 and res["skipped"] == []
    assert "boom" in res["failed"]["b/x.png"]
    cas.put.assert_not_called()


def test_dataset_rewrite_thumbnails_collects_role_urls(monkeypatch):
    from nexus.dataset import Dataset
    import sys
    up = sys.modules["nexus.upload"]   # nexus.upload 속성은 함수가 가린다

    ds = Dataset.__new__(Dataset)
    ds.list_samples = MagicMock(return_value=[
        {"sample_id": "1", "assets": {"depth": {"cas_url": "s3://b/d1.png"}, "image": {"cas_url": "s3://b/i1.png"}}},
        {"sample_id": "2", "assets": {"image": {"cas_url": "s3://b/i2.png"}}},
        {"sample_id": "3", "assets": {"depth": {"cas_url": "s3://b/d3.png"}}},
    ])
    seen = {}
    def fake(refs, **kw):
        seen["refs"] = list(refs); seen["kw"] = kw
        return {"written": 2, "skipped": [], "failed": {}}
    monkeypatch.setattr(up, "rewrite_thumbnails", fake)

    res = ds.rewrite_thumbnails("depth", workers=2)
    assert seen["refs"] == ["s3://b/d1.png", "s3://b/d3.png"]
    assert seen["kw"] == {"workers": 2}
    assert res["written"] == 2


def test_rewrite_thumbnails_mixed_batch():
    import warnings
    from nexus.upload import rewrite_thumbnails

    def get(bucket, key):
        if key == "bad.png":
            raise RuntimeError("boom")
        return b"junk" if key == "x.bin" else _png(100, 100)
    cas = MagicMock(); cas.get.side_effect = get
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        res = rewrite_thumbnails(
            ["s3://b/ok.png", "s3://b/bad.png", "s3://c/x.bin"],
            workers=1, verbose=False, cas=cas)
    assert res["written"] == 1
    assert res["skipped"] == ["c/x.bin"]
    assert list(res["failed"]) == ["b/bad.png"] and "boom" in res["failed"]["b/bad.png"]
    assert [c.args[1] for c in cas.put.call_args_list] == ["thumb/ok.png"]


def test_rewrite_thumbnails_dedupes_refs():
    from nexus.upload import rewrite_thumbnails
    from nexus.sample import CasRef

    cas = MagicMock(); cas.get.return_value = _png(50, 50)
    res = rewrite_thumbnails(
        ["s3://b/a.png", CasRef(bucket="b", key="a.png"), "s3://c/a.png"],
        workers=1, verbose=False, cas=cas)
    assert res["written"] == 2
    assert cas.get.call_count == 2 and cas.put.call_count == 2


def test_dataset_rewrite_thumbnails_dedupes_urls(monkeypatch):
    import sys
    from nexus.dataset import Dataset
    up = sys.modules["nexus.upload"]
    ds = Dataset.__new__(Dataset)
    ds.list_samples = MagicMock(return_value=[
        {"assets": {"depth": {"cas_url": "s3://b/d.png"}}},
        {"assets": {"depth": {"cas_url": "s3://b/e.png"}}},
        {"assets": {"depth": {"cas_url": "s3://b/d.png"}}},
    ])
    seen = {}
    monkeypatch.setattr(up, "rewrite_thumbnails",
                        lambda refs, **kw: seen.setdefault("refs", list(refs)) and {})
    ds.rewrite_thumbnails("depth")
    assert seen["refs"] == ["s3://b/d.png", "s3://b/e.png"]
