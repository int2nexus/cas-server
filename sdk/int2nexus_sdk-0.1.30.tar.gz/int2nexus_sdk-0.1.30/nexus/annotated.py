from __future__ import annotations

import copy
import json
import warnings

from .meta import Meta
from .group import LabelGroup, LabelContainer, RawGroup
from .instance import Instance
from ._types import NexusError, NexusValidationError

_KIND = {"group": LabelGroup, "container": LabelContainer}
_MISSING = object()
_ZERO_REPORT = {
    "instances": 0,
    "skipped": 0,
    "skipped_reasons": {"missing_label": 0, "not_an_object": 0, "group_not_an_array": 0},
}
# explorer·샘플 단건 응답에서 서버가 annotation 위에 얹는 코어 키. 행에서 이것을 떼면 annotation 이다
# (서버 `flatten_sample_response` — 이름이 겹치면 코어가 그룹을 이긴다).
_CORE_KEYS = ("sample_id", "split", "tags", "created_at", "image_url", "thumbnail_url")


class SampleSummary(dict):
    """`ds.samples(include_annotations=False)` 의 행 — annotation 없는 코어 필드만 담은 **읽기 전용** dict.

    이 행에는 그룹이 없어 저장 경로에 넘기면 그 버전의 그룹이 지워진다(통째 교체는 받은 dict 전체로 바꾼다).
    그래서 고칠 수 없게 두고 저장 메서드(`save_annotation`·`patch_annotations`·`merge_annotation`)와
    `AnnotatedSample.from_row` 가 받지 않는다. 고쳐 쓸 사본이 필요하면 `dict(row)`.

    **읽기 전용은 최상위 키뿐이다** — `row["meta"]["k"] = v`·`row["tags"].append(x)` 처럼 안쪽 dict·list 를 고치는 것은
    막지 않는다. 안쪽 값을 읽기 전용 타입으로 감싸면 `isinstance(row["meta"], dict)`·`json.dumps(row)` 가 깨지고, 이 타입이
    막으려는 것(저장 경로로 넘기기)은 안쪽 값과 무관하게 타입으로 거부된다. `dict(row)` 는 얕은 사본이라 안쪽 값을 원래
    행과 공유하므로, 안쪽까지 고칠 사본은 `copy.deepcopy(dict(row))` 로 만든다."""

    __slots__ = ()

    def _read_only(self, *args, **kwargs):
        raise TypeError(
            "SampleSummary 는 읽기 전용입니다(include_annotations=False 의 행) — 사본은 dict(row) 로 만드십시오"
        )

    __setitem__ = __delitem__ = __ior__ = _read_only
    update = pop = popitem = setdefault = clear = _read_only

    def __reduce__(self):
        # pickle·copy 가 빈 객체에 __setitem__ 으로 채우려다 막히지 않게 생성자로 되살린다.
        return (type(self), (dict(self),))


def _reject_sample_summary(value, where: str) -> None:
    if isinstance(value, SampleSummary):
        raise TypeError(
            f"{where}: samples(include_annotations=False) 의 행은 저장할 수 없습니다 — 그 행에는 그룹이 없어 "
            "통째 교체가 그 버전의 그룹을 지웁니다. load_sample() 이나 get_annotation() 으로 받은 것을 고쳐 저장하십시오"
        )


def _returned_sample(rows, sample_id) -> dict:
    """샘플 태그 일괄 경로의 응답에서 그 샘플 행을 찾는다. 서버는 없거나 삭제된 샘플을 결과에서
    조용히 빼므로, 빠졌으면 저장되지 않은 것이다."""
    for r in rows or []:
        if isinstance(r, dict) and str(r.get("sample_id")) == str(sample_id):
            return r
    raise NexusError(
        f"sample {sample_id} 이(가) 없거나 삭제돼 태그를 저장하지 못했습니다", status_code=404
    )


class AnnotatedSample:
    def __init__(self, sample_id, meta: Meta, groups: dict, dataset=None, had_meta=True,
                 meta_was_null=False, group_kinds: dict | None = None, tags=None, split=None):
        self.sample_id = sample_id
        self.meta = meta
        self.groups = groups
        self._dataset = dataset
        self.had_meta = had_meta
        # 저장 meta 가 null 이었으면 편집 가능한 빈 맵으로 들고, 변경이 없으면 null 로 되돌린다.
        self._meta_was_null = meta_was_null
        # save() 가 비교할 기준. None 이면 기준이 없어 전부 보낸다(from_dict 가 채운다).
        self._baseline = None
        # merge()가 dict 입력을 파싱할 때 쓸 그룹 종류 — from_dict 가 받은 것을 그대로 들고 있는다.
        self._group_kinds: dict = dict(group_kinds) if group_kinds else {}
        # 샘플 태그. 행에서 만든 경우만 리스트이고(`from_row`), 태그를 모르는 경로는 None — 그때
        # save() 는 태그를 다루지 않는다. meta 처럼 샘플에 붙어 버전 간에 공유된다.
        self.tags = list(tags) if tags is not None else None
        self._baseline_tags = list(self.tags) if self.tags is not None else None
        self._split = split

    @property
    def split(self):
        """샘플 split. 읽기 전용이다 — save() 가 쓰지 않는다."""
        return self._split

    @classmethod
    def from_dict(cls, ann: dict, group_kinds: dict, *, sample_id=None, dataset=None,
                  _json_input=False):
        had_meta = "meta" in ann
        meta_raw = ann.get("meta", {})
        meta_was_null = had_meta and meta_raw is None
        if meta_raw is None:
            meta_raw = {}
        meta = Meta.from_dict(meta_raw)
        groups: dict = {}
        for key, val in ann.items():
            if key == "meta":
                continue
            kind = group_kinds.get(key)
            if kind in _KIND and isinstance(val, list):
                groups[key] = _KIND[kind].from_list(val)
            else:
                groups[key] = RawGroup(val)
        obj = cls(sample_id, meta, groups, dataset=dataset, had_meta=had_meta,
                  meta_was_null=meta_was_null, group_kinds=group_kinds)
        # 원본이 아니라 **정규화된** 현재 상태를 기준으로 뜬다(id 없는 행에 uuid4 가 채워지는
        # 등 — 원본과 비교하면 안 바뀐 그룹이 바뀐 것으로 보여 동시 편집을 덮어쓴다).
        # 객체들이 입력 dict 를 그대로 참조하므로 deepcopy 해야 편집이 기준을 바꾸지 않는다.
        # 서버 응답(JSON)에서 온 입력은 JSON 왕복으로 뜬다 — 같은 사본이고 deepcopy 보다 약 3 배
        # 빠르다(샘플당 박스 20 개, 1000 행 280 ms → 98 ms 실측). 순회(`iter_samples`)가 샘플마다
        # 여기를 지나 변환 비용의 대부분이 이 사본이었다. 호출자가 준 dict 는 tuple·numpy 값처럼
        # JSON 이 아닌 것이 섞일 수 있어 종전대로 deepcopy 한다.
        cur = obj.to_dict()
        obj._baseline = json.loads(json.dumps(cur)) if _json_input else copy.deepcopy(cur)
        return obj

    @classmethod
    def from_row(cls, row: dict, group_kinds: dict, *, dataset=None):
        """explorer 응답 한 행(또는 샘플 단건 조회 응답)에서 만든다. 코어 키를 떼고 남은
        `meta`·그룹은 `from_dict` 와 같은 규칙이고, `tags`·`split` 을 더 든다. `SampleSummary`(annotation 없는
        행)는 받지 않는다 — 그룹이 없어 그룹을 더해 저장하면 서버의 그 그룹을 덮는다."""
        _reject_sample_summary(row, "AnnotatedSample.from_row")
        ann ={k: v for k, v in row.items() if k not in _CORE_KEYS}
        obj = cls.from_dict(ann, group_kinds, sample_id=row.get("sample_id"), dataset=dataset,
                            _json_input=True)
        obj.tags = list(row.get("tags") or [])
        obj._baseline_tags = list(obj.tags)
        obj._split = row.get("split")
        return obj

    def to_dict(self) -> dict:
        out = {}
        for key, grp in self.groups.items():
            out[key] = grp.to_raw() if isinstance(grp, RawGroup) else grp.to_list()
        meta_dict = self.meta.to_dict()
        if self._meta_was_null and isinstance(meta_dict, dict) and not meta_dict:
            out["meta"] = None
        elif self.had_meta or (isinstance(meta_dict, dict) and meta_dict):
            out["meta"] = meta_dict
        return out

    def get_group(self, name):
        return self.groups.get(name)

    def _field_names(self) -> list:
        """존재하는 필드 이름(그룹 + "meta") — 오타 에러 메시지에 쓴다."""
        return sorted(set(self.groups) | {"meta"})

    def _missing_field_error(self, name) -> AttributeError:
        return AttributeError(
            f"no such field '{name}' (existing fields: {', '.join(self._field_names())})")

    def _kind_for(self, name):
        """새로 만드는 그룹의 클래스 — 선언된 종류가 없으면 LabelGroup."""
        return _KIND.get(self._group_kinds.get(name), LabelGroup)

    def _coerce_field_value(self, name, value):
        """FiftyOne 호환 setter 들이 공유하는 값 검증. "meta" 는 Meta/dict 만, 그 외
        필드는 LabelGroup/LabelContainer/RawGroup 객체나 row 의 list(암묵적으로
        LabelGroup 으로 감싼다)만 받는다. 그 외 타입은 조용히 저장하지 않고 TypeError."""
        if name == "meta":
            if isinstance(value, Meta):
                return value
            if isinstance(value, dict):
                # 호출부 dict 를 그대로 감싸면 나중에 그 dict 를 고친 것이 샘플에 번진다.
                return Meta.from_dict(copy.deepcopy(value))
            raise TypeError(
                f"'meta' must be a Meta or dict, got {type(value).__name__}")
        if isinstance(value, (LabelGroup, RawGroup)):
            return value
        if isinstance(value, list):
            if not all(isinstance(row, dict) for row in value):
                raise TypeError(f"field '{name}' rows must be dicts")
            # 선언된 종류를 따른다 — 무조건 LabelGroup 이면 container 로 선언한 필드가
            # 컨테이너 규칙(컴포넌트 하나·같은 타입) 검증을 건너뛴 채 저장된다.
            return self._kind_for(name).from_list(value)
        raise TypeError(
            f"field '{name}' must be a LabelGroup/LabelContainer/RawGroup or a list of rows, "
            f"got {type(value).__name__}")

    def __getitem__(self, name):
        if name == "meta":
            return self.meta
        return self.groups[name]

    def __setitem__(self, name, value):
        coerced = self._coerce_field_value(name, value)
        if name == "meta":
            self.meta = coerced
            # 방금 값이 들어왔으니 이제 present 필드다 — null 이었던 상태도 해제한다.
            self.had_meta = True
            self._meta_was_null = False
        else:
            self.groups[name] = coerced

    def get_field(self, name):
        """FiftyOne `get_field` 호환. 없는 필드는 존재하는 필드 목록을 담은
        `AttributeError`로 실패한다(오타를 그 자리에서 드러낸다)."""
        if name == "meta":
            return self.meta
        if name in self.groups:
            return self.groups[name]
        raise self._missing_field_error(name)

    def set_field(self, name, value, create=True) -> None:
        """FiftyOne `set_field` 호환. `create=False`면 이미 있는 필드만 고칠 수 있다
        (오타로 새 필드가 조용히 생기는 것을 막는다). "meta"는 항상 존재하는
        필드로 친다 — 샘플마다 있는 내장 필드라 새로 "만드는" 대상이 아니다."""
        if not create and name != "meta" and name not in self.groups:
            raise self._missing_field_error(name)
        self[name] = value

    def clear_field(self, name) -> None:
        """FiftyOne `clear_field`와 이름·의도(값을 비운다)는 같지만, 이 SDK 의
        wire spec 은 명시적 null 을 금지하므로 `None`이 아니라 **빈 컬렉션**으로
        되돌린다(고객 제안 §3.2). meta 는 빈 `Meta({})`로 되돌리는데, save() 시점에
        기준(baseline)과 비교해 예전에 있던 키가 전부 삭제(null)로 나간다."""
        if name == "meta":
            self.meta = Meta({})
            self.had_meta = True
            self._meta_was_null = False
            return
        if name not in self.groups:
            raise self._missing_field_error(name)
        grp = self.groups[name]
        if isinstance(grp, LabelContainer):
            self.groups[name] = LabelContainer([])
        elif isinstance(grp, LabelGroup):
            self.groups[name] = LabelGroup([])
        else:
            self.groups[name] = RawGroup([])

    def validate(self) -> None:
        self.meta.validate()
        for grp in self.groups.values():
            grp.validate()

    def _diff(self) -> dict:
        """기준과 비교한 부분 저장 본문. 그룹은 통째로, meta 는 키 단위."""
        cur = self.to_dict()
        base = self._baseline if self._baseline is not None else {}
        patch: dict = {}
        for key, val in cur.items():
            if key == "meta":
                continue
            if base.get(key, _MISSING) != val:
                patch[key] = copy.deepcopy(val)
        for key in base:
            if key != "meta" and key not in cur:
                patch[key] = []

        cur_meta = cur.get("meta")
        base_meta = base.get("meta")
        if cur_meta is None and base_meta is None:
            return patch
        bm = {} if base_meta is None else base_meta
        cm = {} if cur_meta is None else cur_meta
        if not isinstance(cm, dict) or not isinstance(bm, dict):
            if cm != bm:
                # 서버도 비객체 meta 에는 병합하지 않는다(409) — 요청 전에 막는다.
                raise NexusValidationError("meta must be a JSON object")
            return patch
        meta_patch = {}
        for k, v in cm.items():
            if v is None:
                if bm.get(k) is not None:
                    meta_patch[k] = None
            elif bm.get(k, _MISSING) != v:
                meta_patch[k] = copy.deepcopy(v)
        for k in bm:
            if k not in cm:
                meta_patch[k] = None
        if meta_patch:
            patch["meta"] = meta_patch
        return patch

    def _tag_diff(self):
        """기준과 비교한 (더해진, 빠진) 태그. 순서만 바뀐 것은 변경이 아니다 — 서버 태그는
        합집합·순서 보존이라 순서를 SDK 가 정할 수 없다."""
        if self.tags is None:
            if self._baseline_tags is not None:
                raise NexusValidationError(
                    "tags 를 None 으로 바꿀 수 없습니다 — 태그를 모두 떼려면 s.tags = [] 로 두십시오"
                )
            return [], []
        if not isinstance(self.tags, (list, tuple)) or not all(
            isinstance(t, str) and t for t in self.tags
        ):
            raise NexusValidationError("tags must be a list of non-empty strings")
        base = self._baseline_tags or []
        added = list(dict.fromkeys(t for t in self.tags if t not in base))
        removed = [t for t in base if t not in self.tags]
        return added, removed

    def _full_for_put(self) -> dict:
        """옛 서버 폴백용 통째 교체 본문. meta 의 삭제 표식(None)은 키를 뺀다 —
        PUT 에서 `k: null` 은 null 저장이지 삭제가 아니다."""
        full = self.to_dict()
        m = full.get("meta")
        if isinstance(m, dict):
            full["meta"] = {k: v for k, v in m.items() if v is not None}
        return full

    def save(self) -> dict:
        """바뀐 그룹·meta 키·태그만 저장한다. 순서:

        1. 태그가 바뀌었으면 버전을 확인한다 — sealed 면 아무것도 보내지 않고 `NexusError(409)`.
           버전 경로가 없는 서버의 태그 경로(`/samples/tags`)에는 버전이 없어 sealed 핸들로도 통하므로, meta 가
           sealed 버전 경로에서 409 인 것과 맞춘다.
        2. 그룹·meta 변경분을 PATCH(옛 서버는 PUT 폴백).
        3. 더해진 태그를 붙이고 빠진 태그를 뗀다.

        2 와 3 은 한 트랜잭션이 아니다 — 3 이 실패하면 2 는 이미 저장됐고, 다시 save() 하면 태그만
        다시 보낸다. 서버가 버전 경로를 가진 판(nexus-server 0.1.37 이상)이면 meta·태그는 이 핸들의 버전에만 반영된다.
        그보다 낮은 판은 meta·태그가 샘플에 붙어 있어 같은 샘플을 공유하는 다른 버전의 조회에도 바뀐 값이 보이고, meta 는
        seal 스냅샷(`to_df()`)에 seal 때 값이 남지만 태그는 스냅샷 결과에 없어 언제나 현재 값이다."""
        ds = self._dataset
        if ds is None:
            raise NexusValidationError("AnnotatedSample has no dataset to save to")
        added, removed = self._tag_diff()
        patch = self._diff()   # meta 는 바뀐 경우에만 여기서 검사된다
        if not patch and not added and not removed:
            return copy.deepcopy(_ZERO_REPORT)
        if added or removed:
            ds._ensure_tags_writable()
        report = copy.deepcopy(_ZERO_REPORT)
        if patch:
            report = self._save_patch(ds, patch)
            self._baseline = copy.deepcopy(self.to_dict())
        # 기준은 응답에 실린 그 샘플의 tags 로 갱신한다 — 서버는 새 태그를 DISTINCT 로 골라 붙여서
        # 여러 개면 순서가 입력과 달라진다(m-pg 실측: z,a,m,q,c → c,z,q,a,m). 응답에 tags 가 없으면
        # 기존 순서 + 새 태그로 어림한다.
        if added:
            row = _returned_sample(
                ds._client.add_tags_bulk(
                    [self.sample_id], added, dataset_id=ds._dataset_id, version=ds._version
                ),
                self.sample_id,
            )
            self._baseline_tags = list(row["tags"]) if isinstance(row.get("tags"), list) \
                else list(self._baseline_tags or []) + added
        if removed:
            row = _returned_sample(
                ds._client.remove_tags_bulk(
                    [self.sample_id], removed, dataset_id=ds._dataset_id, version=ds._version
                ),
                self.sample_id,
            )
            self._baseline_tags = list(row["tags"]) if isinstance(row.get("tags"), list) \
                else [t for t in self._baseline_tags if t not in removed]
        if added or removed:
            # 서버에 저장된 모양(중복 없음, 서버 순서)으로 맞춘다.
            self.tags = list(self._baseline_tags)
        return report

    def _save_patch(self, ds, patch: dict) -> dict:
        # 보낼 그룹만 검증한다 — 안 건드린 그룹의 깨진 데이터가 이 저장을 막으면 안 된다
        # (서버는 그 그룹을 그대로 보존할 뿐, 이번 요청이 그 내용을 책임지지 않는다).
        # 삭제되는 그룹(`patch[key] == []`인데 `self.groups`에 더는 없음)은 검증할 객체가 없다.
        # 405 폴백(통째 PUT)도 같은 patch 로 판단한 것을 그대로 쓴다 — 안 바뀐 그룹은
        # 서버가 이미 들고 있는 데이터이므로 여기서 다시 검증할 이유가 없다.
        for key in patch:
            if key == "meta":
                continue
            grp = self.groups.get(key)
            if grp is not None:
                grp.validate()

        unsupported = getattr(ds, "_partial_annotations_unsupported", lambda: False)()
        report = None
        if not unsupported:
            try:
                report = ds.merge_annotation(self.sample_id, patch)
            except NexusError as e:
                if getattr(e, "status_code", None) != 405:
                    raise
                mark = getattr(ds, "_mark_partial_annotations_unsupported", None)
                if mark is not None:
                    mark()
                warnings.warn(
                    "서버가 annotation 부분 저장(PATCH)을 지원하지 않아 통째 교체로 저장했습니다 "
                    "— 그 사이 다른 곳에서 고친 그룹을 덮어쓸 수 있습니다"
                    "(부분 저장은 nexus-server 0.1.18 부터).",
                    RuntimeWarning,
                    stacklevel=3,
                )
                unsupported = True
        if report is None:
            full = self._full_for_put()
            if self._baseline_tags is not None:
                # 행(explorer·샘플 단건 응답)에서 만든 샘플은 코어 키와 이름이 같은 그룹을 못 봤다 —
                # 서버가 코어 키를 그룹보다 우선한다. 통째 PUT 이 그 그룹을 빼고 나가면 이 버전의 그
                # 그룹이 지워지므로, annotation 전용 조회로 저장된 값을 읽어 그대로 실어 보낸다.
                stored = ds.get_annotation(self.sample_id)
                for key in _CORE_KEYS:
                    if key in stored:
                        full[key] = stored[key]
            # meta 는 고쳤을 때만 싣는다 — 안 고친 meta 를 다시 쓰면 그 사이 다른 곳에서 바꾼 값을 되돌린다
            # (meta 키가 없는 PUT 은 0.1.16 서버도 meta 를 건드리지 않는다).
            replace_meta = "meta" in patch
            if not replace_meta:
                full.pop("meta", None)
            m = full.get("meta")
            if m is not None and not isinstance(m, dict):
                raise NexusValidationError("meta must be a JSON object")
            report = ds.save_annotation(self.sample_id, full, replace_meta=replace_meta)
        return report

    @staticmethod
    def _select_fields(available: set, fields, omit_fields) -> set:
        selected = set(available)
        if fields is not None:
            selected &= set(fields)
        if omit_fields is not None:
            selected -= set(omit_fields)
        return selected

    def merge(self, other, fields=None, omit_fields=None, merge_lists=True, overwrite=True) -> None:
        """FiftyOne `Sample.merge` 호환. `other`의 필드를 이 샘플에 합친다(제자리 수정,
        반환값 없음). `other`가 dict면 이 샘플이 이미 알고 있는 그룹 종류(`_group_kinds`,
        `from_dict`에서 받아 들고 있던 것)로 해석해 파싱한다 — 별도 그룹 종류 인자를
        요구하면 호출부가 또 한 번 그것을 외워야 한다.

        그룹은 `merge_lists=True`이고 양쪽이 `RawGroup`이 아닐 때만 `Instance.id` 단위로
        병합한다(같은 id는 `overwrite`일 때만 교체, 새 id는 추가) — 그 외에는(`merge_lists=False`
        이거나 어느 한쪽이라도 `RawGroup`) 그룹 전체를 통째로 교체하며 `overwrite=False`면
        이미 있는 필드는 건드리지 않는다. self 에 없는 필드는 `overwrite`와 무관하게 추가된다.
        meta 는 키 단위로 합친다(`overwrite=True`면 other 의 값으로 덮고, 아니면 self 에
        없는 키만 채운다). `other`에서 가져오는 값은 전부 deep copy 한다 — 안 하면 두 샘플이
        같은 Instance 객체를 공유해 한쪽 편집이 다른 쪽에도 번진다."""
        if isinstance(other, dict):
            other = AnnotatedSample.from_dict(other, self._group_kinds)
        elif not isinstance(other, AnnotatedSample):
            raise TypeError(
                f"merge() expects an AnnotatedSample or dict, got {type(other).__name__}")

        available = set(other.groups) | {"meta"}
        selected = self._select_fields(available, fields, omit_fields)

        # 실패할 수 있는 검사는 무엇이든 바꾸기 전에 한다 — 그룹을 절반만 합친 채
        # 예외가 나면 안 된다(add_labels 와 같은 기준).
        other_meta = other.meta.to_dict()
        if "meta" in selected:
            if not isinstance(other_meta, dict):
                raise NexusValidationError("meta to merge must be a JSON object")
            if other_meta and not isinstance(self.meta._data, dict):
                raise NexusValidationError("meta must be a JSON object")

        for field in sorted(selected):   # 새 그룹이 붙는 순서를 결정적으로
            if field == "meta":
                self._merge_meta(other_meta, overwrite)
            else:
                self._merge_group(field, other.groups[field], merge_lists, overwrite)

    def _merge_meta(self, other_data: dict, overwrite: bool) -> None:
        base = self.meta._data
        written = False
        for k, v in other_data.items():
            if overwrite or k not in base:
                base[k] = copy.deepcopy(v)
                written = True
        # 실제로 키를 쓴 경우에만 present 로 바꾼다 — 빈 meta 를 합쳤다고 저장된 null 이
        # {} 로 바뀌면 통째 PUT 폴백에서 null 이 {} 로 덮인다.
        if written:
            self.had_meta = True
            self._meta_was_null = False

    def _merge_group(self, field, other_grp, merge_lists: bool, overwrite: bool) -> None:
        if field not in self.groups:
            self.groups[field] = copy.deepcopy(other_grp)
            return
        self_grp = self.groups[field]
        if not merge_lists or isinstance(self_grp, RawGroup) or isinstance(other_grp, RawGroup):
            if overwrite:
                self.groups[field] = copy.deepcopy(other_grp)
            return
        # 양쪽 다 LabelGroup/LabelContainer — id 단위 병합
        other_copy = copy.deepcopy(other_grp)
        index = {inst.id: idx for idx, inst in enumerate(self_grp.instances)}
        for inst in other_copy.instances:
            existing_idx = index.get(inst.id)
            if existing_idx is None:
                self_grp.instances.append(inst)
                index[inst.id] = len(self_grp.instances) - 1
            elif overwrite:
                self_grp.instances[existing_idx] = inst

    def add_labels(self, labels, label_field=None) -> None:
        """FiftyOne `Sample.add_labels` 호환. `labels`는 `Instance` 하나, `Instance`
        리스트, 또는 `{field: Instance | list[Instance]}` dict다. dict가 아니면
        `label_field`가 필수다(어느 필드에 넣을지 알 수 없다).

        같은 id 가 대상 필드에 이미 있으면(자기 자신끼리든 배치 안에서든) 어느 것도
        추가하지 않고 `ValueError` — 그래서 검증을 전부 마친 뒤에만 실제로 붙인다
        (나쁜 배치가 샘플을 절반만 바꿔 놓고 실패하면 안 된다). "meta"나 `RawGroup`에는
        붙일 수 없다(둘 다 `Instance` 목록이 아니다) — `TypeError`."""
        if isinstance(labels, dict):
            if label_field is not None:
                # FiftyOne 은 여기서 label_field 를 접두어로 쓴다 — 조용히 무시하면 다른 필드에 들어간다.
                raise ValueError("labels가 dict이면 label_field를 줄 수 없다(필드는 dict 키로 정한다)")
            batch = labels
        else:
            if label_field is None:
                raise ValueError("labels가 dict가 아니면 label_field가 필요하다")
            if isinstance(labels, Instance):
                batch = {label_field: [labels]}
            elif isinstance(labels, list):
                batch = {label_field: labels}
            else:
                raise TypeError(
                    f"labels must be an Instance, list of Instance, or dict, "
                    f"got {type(labels).__name__}")

        normalized: dict = {}
        for field, items in batch.items():
            if field == "meta":
                raise TypeError("cannot add_labels to 'meta'")
            if isinstance(items, Instance):
                items = [items]
            elif not isinstance(items, list):
                raise TypeError(
                    f"labels for field '{field}' must be an Instance or list of Instance, "
                    f"got {type(items).__name__}")
            for item in items:
                if not isinstance(item, Instance):
                    raise TypeError(
                        f"labels for field '{field}' must be Instance objects, "
                        f"got {type(item).__name__}")
            existing = self.groups.get(field)
            if isinstance(existing, RawGroup):
                raise TypeError(f"field '{field}' is a RawGroup; cannot add_labels to it")
            normalized[field] = items

        # 아무것도 바꾸기 전에 id 충돌을 전부 검사한다.
        for field, items in normalized.items():
            existing = self.groups.get(field)
            existing_ids = {inst.id for inst in existing.instances} if existing is not None else set()
            seen: set = set()
            for item in items:
                if item.id in existing_ids or item.id in seen:
                    raise ValueError(f"instance id '{item.id}' already exists in field '{field}'")
                seen.add(item.id)

        for field, items in normalized.items():
            if field not in self.groups:
                self.groups[field] = self._kind_for(field)([])
            # 호출부 객체를 그대로 넣으면 같은 Instance 를 두 샘플(또는 두 필드)이 공유한다.
            self.groups[field].instances.extend(copy.deepcopy(items))

    def copy(self, fields=None, omit_fields=None) -> "AnnotatedSample":
        """FiftyOne `Sample.copy` 호환. 저장되지 않은 deep copy를 만든다 — 새
        객체는 `sample_id=None`·`dataset=None`이라 `save()`가 `NexusValidationError`로
        실패한다(기준(baseline)도 없다). 원본 편집이 복사본에, 복사본 편집이 원본에
        번지지 않도록 선택된 그룹·meta를 전부 deep copy한다."""
        selected_groups = self._select_fields(set(self.groups), fields, omit_fields)
        include_meta = True
        if fields is not None:
            include_meta = "meta" in fields
        if omit_fields is not None:
            include_meta = include_meta and "meta" not in omit_fields

        new_groups = {k: copy.deepcopy(v) for k, v in self.groups.items() if k in selected_groups}
        if include_meta:
            new_meta = copy.deepcopy(self.meta)
            had_meta = self.had_meta
            meta_was_null = self._meta_was_null
        else:
            new_meta = Meta({})
            had_meta = False
            meta_was_null = False

        new = AnnotatedSample(
            None, new_meta, new_groups, dataset=None, had_meta=had_meta,
            meta_was_null=meta_was_null, group_kinds=self._group_kinds,
        )
        return new
