from __future__ import annotations
import base64
import json
import threading
import time

import requests
from nexus._types import NexusAuthError, NexusError, NexusIngestError, _raise_for_status

# 만료 이 시간 전부터 미리 갱신한다. 토큰 수명(24시간)에 비하면 짧지만, 요청 하나가
# 이 창을 넘겨 만료되는 일이 없을 만큼은 길다.
_REFRESH_MARGIN_SECS = 300


def _jwt_exp(token: str) -> "int | None":
    """JWT payload의 `exp`를 **검증 없이** 읽는다. 못 읽으면 None.

    서명을 확인하지 않는 것이 맞다 — 검증은 서버가 한다. 여기서 필요한 건 "언제쯤
    갱신해야 하나"라는 힌트뿐이고, 값이 틀려도 최악의 경우 갱신 시점이 어긋날 뿐
    (그러면 401 재로그인이 받아준다). 이 값으로 권한 판단을 하지 않는다.
    """
    try:
        payload = token.split(".")[1]
        payload += "=" * (-len(payload) % 4)  # base64url은 패딩이 없다
        exp = json.loads(base64.urlsafe_b64decode(payload))["exp"]
        return int(exp)
    except Exception:
        return None


class NexusClient:
    def __init__(
        self,
        nexus_url: str,
        email: str,
        password: str,
        timeout: "float | tuple[float, float]" = (10.0, 120.0),
        verify: "bool | str" = True,
    ) -> None:
        self._base = nexus_url.rstrip("/")
        self._session = requests.Session()
        # TLS 검증 설정을 **세션에 한 번** 건다 — `_login`과 `_get`/`_post`/... 전부는 물론
        # 세션을 직접 쓰는 get_dataset/get_version까지 한 번에 덮인다. 메서드마다 인자를
        # 흘리면 나중에 메서드를 추가할 때 빠뜨리기 쉽고, 그 누락은 "어떤 호출만 SSL 에러"라는
        # 재현하기 어려운 증상으로 나타난다.
        # `verify`는 bool 또는 **CA 번들 경로**(사내 루트 CA). 검증을 끄는 것보다 경로 쪽이 안전하다.
        self._session.verify = verify
        # flush가 배치를 병렬 POST하므로 커넥션 풀을 넉넉히 — 기본 pool_maxsize(10)면
        # 동시성 초과 시 커넥션을 버리고 재생성해 오버헤드가 난다.
        adapter = requests.adapters.HTTPAdapter(pool_connections=32, pool_maxsize=32)
        self._session.mount("http://", adapter)
        self._session.mount("https://", adapter)
        # (connect, read) 타임아웃. read는 서버가 응답 바이트를 보내기까지 허용 시간 —
        # 없으면(requests 기본) 일시적 커넥션 정체가 **무한 hang**으로 굳는다. 배치 처리가
        # 오래 걸릴 수 있어 read는 넉넉히. 호출부가 kwargs로 개별 override 가능.
        self._timeout = timeout
        self._token: str | None = None
        self._token_exp: int | None = None
        # 갱신 API가 없는 구버전 서버(< 0.1.1)를 만나면 켜진다 — 매 요청마다 404를
        # 두드리지 않기 위해. SDK가 구서버에서도 그대로 동작해야 한다.
        self._refresh_unsupported = False
        # 토큰이 만료되면(수명 24시간) 다시 로그인하기 위해 자격증명을 들고 있는다.
        # 없으면 오래 도는 프로세스·노트북이 하루 뒤부터 전부 401로 죽고, 사용자는
        # 스크립트를 재시작하는 것 말고 방법이 없다. 비밀번호가 프로세스 메모리에
        # 남지만, 애초에 설정 파일(~/.int2nexus/settings.json)에 평문으로 있다.
        self._email = email
        self._password = password
        # flush가 배치를 병렬 POST하므로 여러 스레드가 동시에 401을 받을 수 있다.
        # 락이 없으면 그 수만큼 로그인 요청이 몰린다.
        self._auth_lock = threading.Lock()
        self._login(email, password)

    def _login(self, email: str, password: str) -> None:
        r = self._session.post(
            f"{self._base}/api/v1/auth/login",
            json={"email": email, "password": password},
            timeout=self._timeout,
        )
        if not r.ok:
            raise NexusAuthError(
                f"Login failed ({r.status_code}): {r.text}",
                status_code=r.status_code,
                server_message=r.text or None,
            )
        self._set_token(r.json()["token"])

    def _set_token(self, token: str) -> None:
        self._token = token
        self._token_exp = _jwt_exp(token)
        self._session.headers["Authorization"] = f"Bearer {token}"

    def _maybe_refresh(self) -> None:
        """만료가 가까우면 **미리** 토큰을 갱신한다.

        만료된 **뒤에는** 갱신할 수 없다(서버가 401). 그래서 이건 401 재로그인을 대체하는
        게 아니라 그 앞을 막는 것이고, 재로그인은 폴백으로 남는다 — 프로세스가 절전되거나
        오래 멈춰 있어 갱신 시점을 놓치는 경우가 있다.

        갱신이 재로그인보다 나은 이유는 비용이다. 로그인은 bcrypt(cost 12) 검증을 하므로
        수백 ms가 걸리는데, 갱신은 DB 조회 한 번이다. 비밀번호를 네트워크로 다시 보내지
        않는 것도 이점이다.

        **실패해도 조용히 넘어간다.** 여기서 예외를 올리면 갱신이라는 부수적인 일 때문에
        정작 사용자의 요청이 죽는다. 실패하면 원래 토큰으로 진행하고, 만료됐으면 401
        재로그인이 받아준다.
        """
        if self._refresh_unsupported or self._token_exp is None:
            return
        if self._token_exp - time.time() > _REFRESH_MARGIN_SECS:
            return
        with self._auth_lock:
            # 병렬 flush에서 여러 스레드가 동시에 도달한다. 락 안에서 다시 확인해
            # 갱신이 한 번만 일어나게 한다.
            if self._token_exp is None or self._token_exp - time.time() > _REFRESH_MARGIN_SECS:
                return
            try:
                r = self._session.post(
                    f"{self._base}/api/v1/auth/refresh", timeout=self._timeout
                )
            except requests.RequestException:
                return
            if r.status_code == 404:
                # 갱신 API가 없는 구버전 서버(< 0.1.1). 매 요청마다 두드리지 않도록 꺼둔다.
                self._refresh_unsupported = True
                return
            if not r.ok:
                return
            try:
                self._set_token(r.json()["token"])
            except (ValueError, KeyError):
                return

    # _get/_post/_put/_delete raise NexusError(status_code=, server_message=) on non-2xx —
    # server_message는 서버 응답 바디의 {"error": "..."} 텍스트(str(requests.HTTPError)와 달리
    # 안 사라짐). 대부분의 호출부(list_datasets, create_dataset, create_version, delete_version 등)는
    # 이 NexusError를 그대로 전파한다; ingest()/get_manifest()/get_sample() 등 일부만 잡아서
    # 더 구체적인 타입(NexusIngestError)이나 상태코드별 메시지로 재포장한다.
    # 모든 호출에 기본 timeout을 건다(호출부가 timeout= 로 덮어쓸 수 있음).
    def _send(self, method: str, path: str, **kwargs) -> requests.Response:
        """모든 API 호출이 지나는 곳. **401이면 한 번 다시 로그인하고 재시도한다.**

        재시도가 안전한 이유: 서버가 401을 내는 지점은 요청 본문을 보기도 전인 인증
        추출기라, 거부된 요청은 아무 부작용도 남기지 않는다. 같은 요청을 그대로 다시
        보내도 중복 생성 같은 문제가 없다. (본문은 전부 `json=`이라 재직렬화된다 —
        스트림·파일 업로드가 있었다면 재시도가 성립하지 않는다.)

        재시도는 **한 번뿐**이다. 자격증명 자체가 틀렸다면(예: 다른 곳에서 비밀번호가
        바뀜) 재로그인이 실패하고 원래의 401이 그대로 올라간다.
        """
        self._maybe_refresh()
        kwargs.setdefault("timeout", self._timeout)
        url = f"{self._base}{path}"
        token_used = self._token
        r = self._session.request(method, url, **kwargs)
        if r.status_code == 401 and self._relogin(token_used):
            r = self._session.request(method, url, **kwargs)
        return r

    def _relogin(self, token_used: "str | None") -> bool:
        """만료된 토큰을 갱신한다. 갱신됐으면 True(= 재시도할 가치가 있다)."""
        with self._auth_lock:
            # 다른 스레드가 이미 갱신했으면 그대로 쓴다 — flush가 병렬로 POST하기 때문에
            # 이 검사가 없으면 401을 받은 수만큼 로그인이 몰린다.
            if self._token != token_used:
                return True
            try:
                self._login(self._email, self._password)
                return True
            except NexusAuthError:
                # 재로그인이 안 되면 원래의 401을 그대로 올린다. 여기서 예외를 바꿔치기하면
                # 호출부가 기대하는 status_code가 달라진다.
                return False

    def _get(self, path: str, **kwargs) -> requests.Response:
        r = self._send("GET", path, **kwargs)
        _raise_for_status(r)
        return r

    def _post(self, path: str, **kwargs) -> requests.Response:
        r = self._send("POST", path, **kwargs)
        _raise_for_status(r)
        return r

    def _put(self, path: str, **kwargs) -> requests.Response:
        r = self._send("PUT", path, **kwargs)
        _raise_for_status(r)
        return r

    def _delete(self, path: str, **kwargs) -> requests.Response:
        r = self._send("DELETE", path, **kwargs)
        _raise_for_status(r)
        return r

    def _patch(self, path: str, **kwargs) -> requests.Response:
        r = self._send("PATCH", path, **kwargs)
        _raise_for_status(r)
        return r

    # ── 계정 관리 ────────────────────────────────────────────────────────────
    def change_password(self, current_password: str, new_password: str) -> None:
        """로그인한 계정의 비밀번호를 바꾼다. 현재 비밀번호를 재확인한다.

        **이미 발급된 토큰은 무효화되지 않는다**(만료까지 최대 24시간). 변경은 새 로그인부터
        적용되므로, 이 클라이언트 인스턴스는 계속 그대로 쓸 수 있다.

        `~/.int2nexus/settings.json`에 비밀번호를 적어두었다면 **그 파일도 함께 고쳐야 한다** —
        안 그러면 다음 `nx.connect()`가 실패한다.

        현재 비밀번호가 틀리면 `NexusError(status_code=403)`. 403은 세션 만료가 아니라
        확인 실패라는 뜻이므로 재로그인해도 해결되지 않는다.
        """
        self._post(
            "/api/v1/auth/password",
            json={"current_password": current_password, "new_password": new_password},
        )
        # 보관 중인 자격증명도 갱신한다. 안 하면 토큰이 만료되는 시점(최대 24시간 뒤)에
        # 재로그인이 **옛 비밀번호**로 시도돼 실패한다 — 바꾼 지 한참 뒤에야 터지는
        # 종류의 버그라 원인을 찾기 어렵다.
        with self._auth_lock:
            self._password = new_password

    def delete_account(self, password: str) -> dict:
        """로그인한 계정을 **완전히 삭제**한다(비활성화가 아니다). 되돌릴 수 없다.

        반환: `{"deleted_user_id", "released_datasets", "warning"}`.
        `released_datasets`는 소유권이 풀린 dataset 수다 — nexus는 주인 없는 dataset을
        **누구나 수정·삭제 가능**으로 취급하므로 0이 아니면 확인이 필요하다.

        삭제 후 이 클라이언트의 토큰은 만료까지 인증은 통과하지만 쓰기는 실패한다.
        새 클라이언트를 만들지 말고 그냥 버리는 것이 맞다.
        """
        return self._delete(
            "/api/v1/auth/account", json={"password": password}
        ).json()

    def delete_version(
        self, dataset_id: str, version: str, confirm: str, delete_cas: bool = False
    ) -> dict:
        """version hard-delete(dataset 유지). confirm=<버전 문자열> 필요.
        기본은 CAS 보존이고, True 를 명시해야 미참조 파일이 삭제된다.
        **sealed 버전은 삭제 불가**(영구 보존 대상, 예외 없음 — dataset에 남은 버전이 그거 하나뿐이라
        dataset까지 같이 지워지는 경우도 포함) — `NexusError(status_code=409)`."""
        try:
            return self._delete(
                f"/datasets/{dataset_id}/versions/{version}",
                params={"confirm": confirm, "delete_cas": str(bool(delete_cas)).lower()},
            ).json()
        except NexusError as e:
            if e.status_code == 403:
                raise NexusError(
                    f"you are not the owner of dataset '{dataset_id}' — only the dataset "
                    f"owner can delete a version ({e.server_message or str(e)})",
                    status_code=e.status_code,
                    server_message=e.server_message,
                ) from e
            raise

    def list_datasets(
        self,
        *,
        q: str | None = None,
        name: str | None = None,
        description: str | None = None,
        tags: "str | list[str] | None" = None,
        sort: str | None = None,
        order: str | None = None,
        favorite: bool = False,
    ) -> list[dict]:
        """dataset 목록. 옵션: q(통합 검색 — name/description/tags 중 하나라도 부분일치, UI 단일 검색창용),
        name/description(개별 ILIKE), tags(ANY), sort(name|created_at), order(asc|desc),
        favorite(True면 내 즐겨찾기만). 각 항목에 is_favorite 포함."""
        params: dict = {}
        if q:
            params["q"] = q
        if name:
            params["name"] = name
        if description:
            params["description"] = description
        if tags:
            params["tags"] = tags if isinstance(tags, str) else ",".join(tags)
        if sort:
            params["sort"] = sort
        if order:
            params["order"] = order
        if favorite:
            params["favorite"] = "true"
        return self._get("/datasets", params=params).json()

    def sample_history(self, dataset_id: str, sample_id: str) -> dict:
        """한 샘플의 버전별 annotation 이력(든 버전만, created_at 오름차순)."""
        return self._get(f"/datasets/{dataset_id}/samples/{sample_id}/history").json()

    def version_diff(
        self, dataset_id: str, version: str, *, against: str | None = None
    ) -> dict:
        """버전 diff — target(version) vs base(against, 없으면 parent_version)."""
        params = {"against": against} if against else {}
        return self._get(
            f"/datasets/{dataset_id}/versions/{version}/diff", params=params
        ).json()

    # ── Annotation sessions (CVAT) ─────────────────────────────────────────
    def create_annotation_session(
        self,
        dataset_id: str,
        version: str,
        sample_ids: list[str],
        *,
        groups: "list[str] | None" = None,
        extra_labels: "list[dict] | None" = None,
    ) -> dict:
        """CVAT 편집 세션 생성. **201을 즉시 받고 준비는 서버가 백그라운드로 한다** —
        반환된 세션의 status는 `creating`이고 `cvat_url`은 아직 없다.
        `AnnotationSession.wait_open()`으로 기다릴 것.

        sealed 버전이거나 다른 활성 세션과 샘플이 겹치면 `NexusError(status_code=409)`,
        서버에 `[cvat]` 설정이 없으면 503."""
        body: dict = {"sample_ids": list(sample_ids)}
        if groups is not None:
            body["groups"] = groups
        if extra_labels is not None:
            body["extra_labels"] = extra_labels
        return self._post(
            f"/datasets/{dataset_id}/versions/{version}/annotation-sessions", json=body
        ).json()

    def list_annotation_sessions(
        self,
        *,
        dataset_id: "str | None" = None,
        version: "str | None" = None,
        status: "str | None" = None,
        mine: bool = False,
        limit: "int | None" = None,
        cursor: "str | None" = None,
    ) -> list[dict]:
        """세션 목록. `dataset_id`+`version`을 주면 그 버전만, 아니면 **전역**이다.

        `status` 기본은 서버 쪽 `active`(creating+open) — 이력까지 보려면 `"all"`.
        `mine=True`는 로그인 계정이 만든 것만(SDK는 항상 토큰을 싣는다)."""
        params: dict = {}
        if status is not None:
            params["status"] = status
        if mine:
            params["mine"] = "true"
        if limit is not None:
            params["limit"] = limit
        if cursor is not None:
            params["cursor"] = cursor
        if dataset_id and version:
            path = f"/datasets/{dataset_id}/versions/{version}/annotation-sessions"
        else:
            path = "/annotation-sessions"
            if dataset_id:
                params["dataset_id"] = dataset_id
        return self._get(path, params=params).json()

    def get_annotation_session(self, session_id: str) -> dict:
        """세션 단건. 목록과 달리 `sample_ids`와 `has_unimported_changes`가 채워진다
        (후자는 CVAT을 한 번 호출하므로 폴링에는 목록을 쓸 것)."""
        return self._get(f"/annotation-sessions/{session_id}").json()

    def import_annotation_session(self, session_id: str) -> dict:
        """CVAT 결과를 draft에 반영하고 요약을 반환. **반복 호출이 멱등**이다."""
        return self._post(f"/annotation-sessions/{session_id}/import").json()

    def close_annotation_session(self, session_id: str, *, force: bool = False) -> dict:
        """작업 종료 — 샘플 잠금만 풀고 CVAT project는 남긴다.
        미반영 변경이 있으면 `NexusError(status_code=409)`이며 `force=True`로 넘긴다."""
        params = {"force": "true"} if force else {}
        return self._post(
            f"/annotation-sessions/{session_id}/close", params=params
        ).json()

    def delete_annotation_session(self, session_id: str) -> None:
        """세션과 **CVAT project를 완전히 삭제**한다 — 이미지 사본과 미반영 편집도 사라진다.
        dataset 소유자만 가능(owner가 없으면 누구나) — 아니면 `NexusError(status_code=403)`."""
        self._delete(f"/annotation-sessions/{session_id}")

    # ── Subsets (저장된 explorer 필터) ──────────────────────────────────────
    def create_subset(self, dataset_id: str, version: str, name: str, filter: dict) -> dict:
        """서브셋 생성. filter = SampleExplorerRequest 형태.

        **dataset 소유자만** 가능하다 — 아니면 `NexusError(status_code=403)`.
        (owner가 지정되지 않은 dataset은 인증된 누구나.)"""
        return self._post(
            f"/datasets/{dataset_id}/versions/{version}/subsets",
            json={"name": name, "filter": filter},
        ).json()

    def list_subsets(self, dataset_id: str, version: str) -> list[dict]:
        return self._get(f"/datasets/{dataset_id}/versions/{version}/subsets").json()

    def get_subset(self, subset_id: str) -> dict:
        return self._get(f"/subsets/{subset_id}").json()

    def update_subset(
        self, subset_id: str, *, name: str | None = None, filter: dict | None = None
    ) -> dict:
        body: dict = {}
        if name is not None:
            body["name"] = name
        if filter is not None:
            body["filter"] = filter
        return self._put(f"/subsets/{subset_id}", json=body).json()

    def delete_subset(self, subset_id: str) -> None:
        self._delete(f"/subsets/{subset_id}")

    def subset_samples(
        self, subset_id: str, *, cursor: str | None = None,
        limit: int | None = None, include_annotations: bool | None = None,
    ) -> list[dict]:
        """서브셋 필터 resolve → 샘플 한 페이지(explorer와 동일 형식)."""
        params: dict = {}
        if cursor is not None:
            params["cursor"] = cursor
        if limit is not None:
            params["limit"] = limit
        if include_annotations is not None:
            params["include_annotations"] = str(include_annotations).lower()
        return self._get(f"/subsets/{subset_id}/samples", params=params).json()

    def materialize_subset(self, subset_id: str, version: str) -> dict:
        """서브셋을 **새 버전**으로 물질화(필터링된 fork). 필터를 resolve한 샘플만 담고
        라벨은 서브셋의 version에서 복제. 0개 resolve면 400. 생성된 DatasetVersion 반환.

        **dataset 소유자만** 가능하다 — 아니면 `NexusError(status_code=403)`."""
        return self._post(
            f"/subsets/{subset_id}/version", json={"version": version}
        ).json()

    def add_favorite(self, dataset_id: str) -> None:
        """dataset을 내 즐겨찾기에 추가(멱등). PUT /datasets/{id}/favorite."""
        self._put(f"/datasets/{dataset_id}/favorite")

    def remove_favorite(self, dataset_id: str) -> None:
        """dataset을 내 즐겨찾기에서 해제(멱등). DELETE /datasets/{id}/favorite."""
        self._delete(f"/datasets/{dataset_id}/favorite")

    def create_dataset(
        self,
        name: str,
        tags: list[str] | None = None,
        description: str | None = None,
    ) -> dict:
        body: dict = {"name": name}
        if tags:
            # 문자열 하나를 넘기면 단일 원소 리스트로 자동 변환 (서버는 배열을 기대).
            body["tags"] = [tags] if isinstance(tags, str) else list(tags)
        if description:
            body["description"] = description
        return self._post("/datasets", json=body).json()

    def update_dataset(
        self, dataset_id: str, *, name: str | None = None, description: str | None = None,
    ) -> dict:
        """dataset의 name/description을 제공된 것만 갱신(둘 다 None이면 no-op). name이 이미
        다른 dataset에 쓰이고 있으면 서버가 409. 소유자 게이트: owner가 있으면 그 유저만
        가능(`NexusError(status_code=403)`), 없으면 누구나."""
        body: dict = {}
        if name is not None:
            body["name"] = name
        if description is not None:
            body["description"] = description
        return self._patch(f"/datasets/{dataset_id}", json=body).json()

    def get_dataset(self, dataset_id: str) -> dict | None:
        """dataset 단건 조회(name/tags/description/owner_user_id 등). 없으면 None."""
        r = self._send("GET", f"/datasets/{dataset_id}")
        if r.status_code == 404:
            return None
        _raise_for_status(r)
        return r.json()

    def list_versions(self, dataset_id: str) -> list[dict]:
        """dataset의 version 목록."""
        return self._get(f"/datasets/{dataset_id}/versions").json()

    def get_version(self, dataset_id: str, version: str) -> dict | None:
        r = self._send("GET", f"/datasets/{dataset_id}/versions/{version}")
        if r.status_code == 404:
            return None
        _raise_for_status(r)
        return r.json()

    def create_version(
        self,
        dataset_id: str,
        version: str,
        fork_from: str | None = None,
        sample_ids: list[str] | None = None,
    ) -> dict:
        """새 버전 생성. `fork_from`만 주면 그 버전 전량 fork(멤버 승계).
        `fork_from`+`sample_ids`면 **필터링된 fork** — 그 버전 멤버 중 지정 샘플만 담음
        (서버가 비멤버 sample_id는 400). `sample_ids`만 주면(무 fork_from) 400.
        둘 다 없으면 빈 draft 버전. 스키마(관측된 label/component)는 버전이 아니라 dataset
        전체가 공유하므로, fork 여부와 무관하게 dataset에 지금까지 관측된 것을 항상 그대로 본다."""
        body: dict = {"version": version}
        if fork_from is not None:
            body["fork_from"] = fork_from
        if sample_ids is not None:
            body["sample_ids"] = sample_ids
        return self._post(f"/datasets/{dataset_id}/versions", json=body).json()

    def add_sample_ids(self, dataset_id: str, version: str, sample_ids: list[str]) -> None:
        self._post(
            f"/datasets/{dataset_id}/versions/{version}/samples",
            json={"sample_ids": sample_ids},
        )

    def remove_sample_ids(self, dataset_id: str, version: str, sample_ids: list[str]) -> dict:
        """여러 sample을 version에서 링크 해제(sample·데이터는 유지). `{"removed": n}` 반환."""
        return self._delete(
            f"/datasets/{dataset_id}/versions/{version}/samples",
            json={"sample_ids": sample_ids},
        ).json()

    def import_samples(
        self,
        dataset_id: str,
        version: str,
        source_dataset_id: str,
        source_version: str,
        sample_ids: list[str],
    ) -> dict:
        """다른 dataset(source_dataset_id/source_version)의 sample들을 이 dataset(target) 버전으로
        복사(크로스 데이터셋 재사용). asset은 재사용(재업로드 없음)하지만 sample/annotation은
        독립 복제되어 이후 target 쪽 수정이 source에 영향 없음. 반환:
        `{"imported": [{"source_sample_id", "sample_id"}, ...]}`."""
        return self._post(
            f"/datasets/{dataset_id}/versions/{version}/samples/import",
            json={
                "source_dataset_id": source_dataset_id,
                "source_version": source_version,
                "sample_ids": sample_ids,
            },
        ).json()

    def add_tags_bulk(self, sample_ids: list[str], tags: list[str]) -> list[dict]:
        """여러 sample에 동일한 tag들을 추가(합집합, 순서 보존). dataset/version 무관 —
        sample_id만으로 동작. 없거나 삭제된 sample_id는 결과에서 조용히 빠진다.
        샘플이 속한 **dataset의 소유자만** 가능하다(여러 dataset에 걸치면 전부 소유해야 한다).
        실제로 갱신된 Sample 목록을 반환."""
        return self._post(
            "/samples/tags", json={"sample_ids": sample_ids, "tags": tags}
        ).json()

    def remove_tags_bulk(self, sample_ids: list[str], tags: list[str]) -> list[dict]:
        """여러 sample에서 동일한 tag들을 제거. 없거나 삭제된 sample_id는 결과에서 조용히 빠진다."""
        return self._delete(
            "/samples/tags", json={"sample_ids": sample_ids, "tags": tags}
        ).json()

    def seal(self, dataset_id: str, version: str) -> dict:
        """버전을 seal(불변 스냅샷)한다. 성공 시 sealed DatasetVersion을 반환한다.
        이미 sealed면 서버가 409를 반환하며 NexusError(status_code=409)로 전파된다."""
        return self._post(
            f"/datasets/{dataset_id}/versions/{version}/seal"
        ).json()

    def ensure_bucket(self, bucket: str) -> None:
        self._post("/api/v1/buckets/ensure", json={"bucket": bucket})

    def ingest(self, payload: dict) -> dict:
        try:
            return self._post("/ingest", json=payload).json()
        except NexusError as e:
            raise NexusIngestError(
                str(e), status_code=e.status_code, server_message=e.server_message
            ) from e

    def ingest_batch(self, items: list[dict]) -> dict:
        try:
            return self._post("/ingest/batch", json={"items": items}).json()
        except NexusError as e:
            raise NexusIngestError(
                str(e), status_code=e.status_code, server_message=e.server_message
            ) from e

    def get_manifest(self, dataset_id: str, version: str) -> dict:
        try:
            return self._get(f"/datasets/{dataset_id}/versions/{version}/manifest").json()
        except NexusError as e:
            if e.status_code == 409:
                raise NexusError(
                    f"version '{version}' is not sealed — to_df() requires a sealed version",
                    status_code=e.status_code,
                    server_message=e.server_message,
                ) from e
            raise

    def get_manifest_samples(
        self, dataset_id: str, version: str,
        cursor: str | None = None, limit: int = 1000,
    ) -> dict:
        params = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return self._get(
            f"/datasets/{dataset_id}/versions/{version}/manifest/samples",
            params=params,
        ).json()

    def patch_annotations(
        self,
        dataset_id: str,
        version: str,
        sample_id: str,
        annotation_data: dict,
    ) -> dict:
        """그 버전의 샘플 annotation을 통째로 교체하고 **서버 보고서**를 반환한다.

        보고서는 `{"instances": n, "skipped": n,
        "skipped_reasons": {"missing_label", "not_an_object", "group_not_an_array"}}` 형태다.
        교체는 병합이 아니므로 스킵된 원소는 원래 있던 인스턴스가 지워진 것과 같다 —
        `skipped`가 0이 아니면 유실이 일어났다는 뜻이다.

        호환성(중요): 구버전 서버(0.1.3 이하)는 이 경로에서 204 + 빈 본문을 준다.
        본문이 비었거나 JSON이 아니면 예외를 던지지 않고 `{}`를 반환한다 — 신버전 SDK가
        구버전 서버에 붙는 조합에서 저장 자체는 성공했기 때문이다.
        """
        r = self._put(
            f"/datasets/{dataset_id}/versions/{version}/samples/{sample_id}/annotations",
            json={"annotation_data": annotation_data},
        )
        if not r.content:
            return {}
        try:
            body = r.json()
        except ValueError:
            return {}
        return body if isinstance(body, dict) else {}

    def get_sample_annotations(self, dataset_id: str, version: str, sample_id: str) -> dict:
        """샘플의 annotation만 조회한다(코어 필드 없음).

        반환은 같은 경로 PUT 의 `annotation_data`와 **같은 형태**라, 고쳐서 그대로
        되돌려 보낼 수 있다. 코어 필드까지 필요하면 `get_sample()`을 쓴다.
        """
        return self._get(
            f"/datasets/{dataset_id}/versions/{version}/samples/{sample_id}/annotations"
        ).json()

    def set_sample_dimensions(self, items: "list[dict]") -> "list[dict]":
        """여러 샘플의 meta.width/height를 채운다. `items`는 `{sample_id, width, height}` 리스트.

        **빈칸을 채우는 것만 가능하다** — 이미 크기가 기록된 샘플은 거부되어 결과에 사유와 함께
        담긴다. 거부는 에러가 아니므로 서버는 배치 전체를 200으로 답한다. 건별 결과
        (`{sample_id, ok, error?}`) 리스트를 그대로 반환한다.
        """
        return self._patch("/samples/dimensions", json={"items": items}).json()["results"]

    def get_sample(self, dataset_id: str, version: str, sample_id: str) -> dict:
        """단건 GT 조회. 코어 필드 + group_key 배열이 평탄화된 dict를 반환한다."""
        try:
            return self._get(
                f"/datasets/{dataset_id}/versions/{version}/samples/{sample_id}"
            ).json()
        except NexusError as e:
            if e.status_code == 404:
                raise NexusError(
                    f"sample {sample_id} not found in {dataset_id}/{version}",
                    status_code=e.status_code,
                    server_message=e.server_message,
                ) from e
            raise

    def explore_samples(
        self, dataset_id: str, version: str, *,
        cursor: str | None = None, limit: int = 1000,
        split: str | None = None, tags: "list[str] | None" = None,
        meta: dict | None = None, annotation: "list[dict] | None" = None,
        include_annotations: bool | None = None,
        sample_ids: "list[str] | None" = None,
    ) -> list[dict]:
        """버전-스코프 explorer 조회 **한 페이지**(커서 기반, 페이지네이션은 호출부 책임).
        `annotation`은 `[{"group_key":, "label":, "confidence":{"min":,"max":}, "track_id":,
        "id":, "component":{...}}, ...]` 형태 — 리스트 원소끼리는 AND(sample_id 교집합),
        한 원소 안의 조건은 **같은 instance**가 전부 만족해야 함(correlated).
        `sample_ids`는 다른 필터와 AND(교집합) — 명시한 샘플들로만 범위를 좁힌다."""
        body: dict = {"limit": limit}
        if cursor is not None:
            body["cursor"] = cursor
        if split is not None:
            body["split"] = split
        if tags:
            body["tags"] = tags
        if meta is not None:
            body["meta"] = meta
        if annotation:
            body["annotation"] = annotation
        if include_annotations is not None:
            body["include_annotations"] = include_annotations
        if sample_ids:
            body["sample_ids"] = sample_ids
        return self._post(
            f"/datasets/{dataset_id}/versions/{version}/samples/explorer", json=body,
        ).json()

    def list_sample_ids_by_label(
        self, dataset_id: str, version: str, label: str
    ) -> set[str]:
        # 버전-스코프 explorer의 annotation 필터로 조회. 라벨만 필요하므로
        # include_annotations=False(경량)로 sample_id만 페이징한다.
        ids: set[str] = set()
        cursor = None
        limit = 1000
        while True:
            page = self.explore_samples(
                dataset_id, version, cursor=cursor, limit=limit,
                annotation=[{"label": label}], include_annotations=False,
            )
            for s in page:
                ids.add(s["sample_id"])
            if len(page) < limit:
                break
            cursor = page[-1]["sample_id"]  # DESC order → last row is the smallest sample_id
        return ids
