from __future__ import annotations
import warnings

from nexus._types import (
    IngestResult,
    NexusAuthError,
    NexusBatchError,
    NexusCasError,
    NexusError,
    NexusIngestError,
)
from nexus import settings as _settings
from nexus.cas import CasClient
from nexus.client import NexusClient
from nexus.dataset import AnnotationSession, Dataset
from nexus.sample import CasRef, Sample
from nexus.upload import upload

_client: NexusClient | None = None
_cas: CasClient | None = None


def _apply_insecure_tls(verify: "bool | str") -> None:
    """`verify=False`일 때 urllib3의 요청마다 나오는 경고를 억제하고 **한 번만** 우리 경고를 낸다.

    요청마다 나오는 경고는 대량 적재 로그를 뒤덮어 실제 문제를 가린다. 그렇다고 조용히
    넘기면 "이 연결은 중간자 공격을 탐지하지 못한다"는 사실이 어디에도 남지 않으므로,
    접속 시점에 한 번은 반드시 알린다.
    """
    if verify is not False:
        return
    warnings.warn(
        "TLS 인증서 검증이 꺼져 있습니다(verify=False) — 이 연결은 중간자 공격을 탐지하지 "
        "못합니다. 사내 프록시가 원인이라면 검증을 끄는 대신 루트 CA 번들 경로를 주는 쪽을 "
        "권합니다: nx.connect(verify='/path/to/corp-ca.pem') 또는 설정 파일의 \"verify\" 키.",
        stacklevel=3,
    )
    try:  # urllib3 2.x / 1.x 모두 대응
        from urllib3.exceptions import InsecureRequestWarning

        warnings.simplefilter("ignore", InsecureRequestWarning)
    except Exception:  # pragma: no cover - urllib3 내부 구조가 바뀐 경우
        pass


def connect(
    nexus_url: str | None = None,
    email: str | None = None,
    password: str | None = None,
    cas_url: str | None = None,
    cas_key_id: str | None = None,
    cas_secret: str | None = None,
    timeout: "float | tuple[float, float]" = (10.0, 120.0),
    verify: "bool | str | None" = None,
    settings_path: "str | None" = None,
) -> NexusClient:
    """nexus/CAS에 접속한다. 인자를 하나도 안 주면 환경변수와 설정 파일에서 해소한다.

    값의 우선순위는 **인자 > 환경변수 > 설정 파일**(`~/.int2nexus/settings.json`,
    `NEXUS_SETTINGS`로 경로 변경 가능). 설정 파일에 다 적어두면 `nx.connect()` 한 줄이면 된다.

    `verify`는 TLS 인증서 검증 — `True`(기본), `False`(검증 끔), 또는 **CA 번들 경로**.
    사내 TLS 검사 장비 때문에 SSL 에러가 난다면 검증을 끄는 대신 사내 루트 CA 경로를 주는
    쪽을 권한다. nexus와 CAS 양쪽 세션에 같은 값이 적용된다.
    """
    # bucket은 전역 기본값을 두지 않는다 — nx.upload(paths, bucket=...)에서 호출별로 지정.
    # timeout=(connect, read) — read를 넉넉히(배치 적재가 오래 걸릴 수 있음). 없으면 정체가 무한 hang.
    global _client, _cas

    cfg = _settings.resolve(
        path=settings_path,
        nexus_url=nexus_url,
        email=email,
        password=password,
        cas_url=cas_url,
        cas_key_id=cas_key_id,
        cas_secret=cas_secret,
        verify=verify,
    )
    _apply_insecure_tls(cfg["verify"])

    _client = NexusClient(
        cfg["nexus_url"], cfg["email"], cfg["password"],
        timeout=timeout, verify=cfg["verify"],
    )
    _cas = CasClient(
        cfg["cas_url"], cfg["cas_key_id"], cfg["cas_secret"], verify=cfg["verify"]
    )
    return _client


def _auto_connect() -> NexusClient:
    global _client
    if _client is None:
        connect()
    return _client  # type: ignore[return-value]


def list_datasets(
    *,
    q: str | None = None,
    name: str | None = None,
    description: str | None = None,
    tags: "str | list[str] | None" = None,
    sort: str | None = None,
    order: str | None = None,
    favorite: bool = False,
    client: NexusClient | None = None,
) -> list[dict]:
    """등록된 dataset 목록(dict 리스트).

    각 항목: `dataset_id`/`name`/`description`/`tags`/`created_at`와 **`versions`**(버전 문자열
    목록, 예 `['v0','v1']`), **`is_favorite`**(내 즐겨찾기 여부). 옵션 — `name`/`description`: 부분
    검색(ILIKE), `tags`: 하나라도 포함(ANY), `sort`: "name"|"created_at"(기본), `order`: "asc"/"desc"(기본
    desc), `favorite`: True면 내 즐겨찾기만.
    """
    c = client or _auto_connect()
    return c.list_datasets(
        q=q, name=name, description=description, tags=tags, sort=sort, order=order, favorite=favorite
    )


def annotation_session(
    session_id: str, *, client: NexusClient | None = None
) -> "AnnotationSession":
    """`session_id`로 기존 세션을 다시 잡는다.

    세션은 파이썬 프로세스와 무관하게 서버에 남아 있다 — 스크립트를 껐다 켜도, 다른
    사람이 만든 세션이어도 id만 있으면 이어받을 수 있다. 목록에서 고르려면
    :func:`annotation_sessions` 를 쓴다.
    """
    c = client or _auto_connect()
    return AnnotationSession(c, c.get_annotation_session(session_id))


def annotation_sessions(
    *,
    status: "str | None" = None,
    dataset_id: str | None = None,
    mine: bool = False,
    limit: int | None = None,
    client: NexusClient | None = None,
) -> "list[AnnotationSession]":
    """**전역** CVAT 편집 세션 목록 — dataset·버전을 가로질러 "지금 진행 중인 것"을 모은다.

    기본은 진행 중인 것만(`status="active"` = creating+open)이다. 이력까지 보려면 `"all"`,
    특정 상태만 보려면 `"open"`/`"closed"`/`"failed"`. `mine=True`면 내가 만든 것만.

    각 항목은 `dataset_name`/`version`/`sample_count`를 이미 담고 있어 추가 조회 없이
    목록을 그릴 수 있다. 다만 `has_unimported_changes`는 목록에서 항상 `None`이다
    (세션마다 CVAT 호출이 필요해서) — 필요하면 `.refresh()` 후 읽을 것.
    """
    c = client or _auto_connect()
    rows = c.list_annotation_sessions(
        dataset_id=dataset_id, status=status, mine=mine, limit=limit
    )
    return [AnnotationSession(c, r) for r in rows]


__all__ = [
    "connect",
    "list_datasets",
    "annotation_sessions",
    "annotation_session",
    "Dataset",
    "AnnotationSession",
    "Sample",
    "CasRef",
    "upload",
    "IngestResult",
    "NexusError",
    "NexusAuthError",
    "NexusCasError",
    "NexusIngestError",
    "NexusBatchError",
]
