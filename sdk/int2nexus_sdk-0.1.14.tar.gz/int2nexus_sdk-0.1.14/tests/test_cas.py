from pathlib import Path
import pytest
from nexus.cas import CasClient
from nexus._types import NexusCasError

CAS = "http://cas-test"


@pytest.fixture
def client():
    return CasClient(CAS, key_id="kid", secret="sec")


def test_head_returns_metadata(requests_mock, client):
    requests_mock.head(f"{CAS}/bucket/images/img.png",
                       headers={"ETag": '"abc123"', "content-length": "2048",
                                "content-type": "image/png"})
    result = client.head("bucket", "images/img.png")
    assert result["hash_hex"] == "abc123"
    assert result["size"] == 2048
    assert result["content_type"] == "image/png"


def test_head_returns_none_on_404(requests_mock, client):
    requests_mock.head(f"{CAS}/bucket/key", status_code=404)
    assert client.head("bucket", "key") is None


def test_head_raises_on_server_error(requests_mock, client):
    requests_mock.head(f"{CAS}/bucket/key", status_code=500)
    with pytest.raises(NexusCasError):
        client.head("bucket", "key")


def test_put_sends_data(requests_mock, client):
    requests_mock.put(f"{CAS}/bucket/key", status_code=200)
    client.put("bucket", "key", b"hello-data", "image/png")
    assert requests_mock.last_request.body == b"hello-data"
    assert requests_mock.last_request.headers["Content-Type"] == "image/png"


def test_put_raises_on_failure(requests_mock, client):
    requests_mock.put(f"{CAS}/bucket/key", status_code=403)
    with pytest.raises(NexusCasError):
        client.put("bucket", "key", b"data", "image/png")


def test_cas_get_returns_content(requests_mock):
    from nexus.cas import CasClient
    requests_mock.get("http://cas/b/k.png", content=b"hello")
    cas = CasClient("http://cas")
    assert cas.get("b", "k.png") == b"hello"


def test_cas_get_raises_on_error(requests_mock):
    import pytest
    from nexus.cas import CasClient
    from nexus._types import NexusCasError
    requests_mock.get("http://cas/b/missing", status_code=404)
    cas = CasClient("http://cas")
    with pytest.raises(NexusCasError) as ei:
        cas.get("b", "missing")
    # 호출부(to_df)가 404와 403을 다르게 안내하려면 상태 코드가 속성으로 있어야 한다.
    assert ei.value.status_code == 404


def test_cas_get_passes_timeout(requests_mock):
    requests_mock.get("http://cas/b/k", content=b"x")
    cas = CasClient("http://cas")
    cas.get("b", "k", timeout=7)
    assert requests_mock.last_request.timeout == 7


def test_session_has_retry_adapter(client):
    from requests.adapters import HTTPAdapter
    adapter = client._session.get_adapter("http://cas-test/b/k")
    assert isinstance(adapter, HTTPAdapter)
    retry = adapter.max_retries
    assert retry.total == 3
    assert "PUT" in retry.allowed_methods
    assert 503 in retry.status_forcelist


def test_session_reused_across_calls(requests_mock, client):
    # 같은 클라이언트의 모든 요청이 동일 Session을 쓴다(keep-alive 재사용).
    requests_mock.head(f"{CAS}/b/k", headers={"ETag": '"h"', "content-length": "1"})
    s1 = client._session
    client.head("b", "k")
    assert client._session is s1


def test_canonical_request_exact_bytes():
    # 줄바꿈/공백이 서버 cas_client.rs::sigv4_auth와 바이트 동일해야 한다.
    from nexus.cas import _canonical_request
    cr = _canonical_request("PUT", "/data/k.png", "localhost:8080", "abc123", "20260101T000000Z")
    expected = (
        "PUT\n"
        "/data/k.png\n"
        "\n"
        "host:localhost:8080\n"
        "x-amz-content-sha256:abc123\n"
        "x-amz-date:20260101T000000Z\n"
        "\n"
        "host;x-amz-content-sha256;x-amz-date\n"
        "abc123"
    )
    assert cr == expected


def test_signed_headers_structure_and_payload_hash():
    from nexus.cas import CasClient, _sha256_hex
    c = CasClient("http://localhost:8080", key_id="rootkey", secret="rootsecret")
    h = c._signed_headers("PUT", "/data/k.png", b"hello")
    assert h["x-amz-content-sha256"] == _sha256_hex(b"hello")
    assert "T" in h["x-amz-date"] and h["x-amz-date"].endswith("Z")
    assert h["Authorization"].startswith("AWS4-HMAC-SHA256 Credential=rootkey/")
    assert "SignedHeaders=host;x-amz-content-sha256;x-amz-date" in h["Authorization"]
    assert "/s3/aws4_request," in h["Authorization"]


def test_signed_headers_empty_without_creds():
    from nexus.cas import CasClient
    c = CasClient("http://localhost:8080")
    assert c._signed_headers("PUT", "/b/k", b"x") == {}


def test_default_region_is_cas_default():
    # CAS 서버가 region "cas-default"로 고정 검증하므로 SDK 기본값도 이에 맞춘다.
    from nexus.cas import CasClient
    c = CasClient("http://localhost:8080", key_id="k", secret="s")
    assert c._region == "cas-default"
    assert "/cas-default/s3/aws4_request" in c._signed_headers("PUT", "/b/k", b"x")["Authorization"]


def test_host_keeps_port():
    from nexus.cas import CasClient
    assert CasClient("http://localhost:8080")._host() == "localhost:8080"
    assert CasClient("https://cas.example.com")._host() == "cas.example.com"


def test_put_sends_sigv4_headers(requests_mock):
    from nexus.cas import CasClient, _sha256_hex
    requests_mock.put("http://cas-test/data/k.png", status_code=200)
    c = CasClient("http://cas-test", key_id="rootkey", secret="rootsecret")
    c.put("data", "k.png", b"hello", "image/png")
    req = requests_mock.last_request
    assert req.headers["x-amz-content-sha256"] == _sha256_hex(b"hello")
    assert req.headers["Authorization"].startswith("AWS4-HMAC-SHA256 Credential=rootkey/")
    assert req.headers["Content-Type"] == "image/png"


def test_hash_bytes_is_deterministic():
    data = b"test-data-for-hashing"
    assert CasClient.hash_bytes(data) == CasClient.hash_bytes(data)
    assert len(CasClient.hash_bytes(data)) == 64  # blake3: 32 bytes = 64 hex chars


def test_hash_bytes_differs_for_different_data():
    assert CasClient.hash_bytes(b"aaa") != CasClient.hash_bytes(b"bbb")


def test_content_type_image_png():
    assert CasClient.content_type(Path("photo.png")) == "image/png"


def test_content_type_unknown_defaults_to_octet_stream():
    assert CasClient.content_type(Path("file.xyz123")) == "application/octet-stream"


def test_no_auth_header_when_credentials_empty(requests_mock):
    c = CasClient(CAS, key_id="", secret="")
    requests_mock.head(f"{CAS}/b/k",
                       headers={"ETag": '"h"', "content-length": "0"})
    c.head("b", "k")
    assert "Authorization" not in requests_mock.last_request.headers


def test_cas_head_prefers_x_cas_hash_over_etag(requests_mock):
    from nexus.cas import CasClient
    requests_mock.head(
        "http://cas/b/k",
        headers={"ETag": '"md5deadbeef"', "x-cas-hash": "blake3abc", "content-length": "5"},
    )
    cas = CasClient("http://cas")
    assert cas.head("b", "k")["hash_hex"] == "blake3abc"


# ── 403 의 두 얼굴 ────────────────────────────────────────────────────────────
#
# cas 는 정책 거부를 `AccessDenied`, 폐기·만료된 키를 `InvalidAccessKeyId` 로 낸다
# (cas `src/error.rs`). 전에는 둘을 구분하지 못해 "클라이언트당 한 번" 이라는 예산으로
# 눌렀는데, 자격증명에 만료가 붙으면서 오래 도는 프로세스가 두 번째 만료에서 죽는다.

_ACCESS_DENIED = (
    '<?xml version="1.0"?><Error><Code>AccessDenied</Code>'
    "<Message>denied</Message></Error>"
)
_BAD_KEY = (
    '<?xml version="1.0"?><Error><Code>InvalidAccessKeyId</Code>'
    "<Message>The AWS Access Key Id you provided does not exist in our records.</Message>"
    "</Error>"
)


def _static(key_id="kid", secret="sec"):
    """정적 자격증명 클라이언트. **갱신 경로가 없다**(0.1.14~)."""
    return CasClient(CAS, key_id=key_id, secret=secret)


def test_static_credentials_never_retry_on_403(requests_mock):
    """403 은 코드가 무엇이든 한 번만 나가고 그대로 올라간다.

    이전 판은 `InvalidAccessKeyId` 에 nexus 로 새 자격증명을 요청해 한 번 더 시도했다.
    nexus 가 발급을 하지 않게 되면서 그 경로가 없어졌고, 같은 값으로 다시 두드리는 것은
    아무것도 바꾸지 못하므로 재시도 자체를 걷었다.
    """
    for body in (_ACCESS_DENIED, _BAD_KEY):
        m = requests_mock.put(f"{CAS}/b/k", status_code=403, text=body)
        with pytest.raises(NexusCasError):
            _static().put("b", "k", b"d", "image/png")
        assert m.call_count == 1, f"재시도했다({m.call_count} 회): {body[:40]}"


def test_head_403_without_body_also_does_not_retry(requests_mock):
    """HEAD 403 에는 본문이 없어 에러 코드를 못 읽는다 — 그래도 재시도하지 않는다."""
    m = requests_mock.head(f"{CAS}/b/k", status_code=403)
    with pytest.raises(NexusCasError):
        _static().head("b", "k")
    assert m.call_count == 1
