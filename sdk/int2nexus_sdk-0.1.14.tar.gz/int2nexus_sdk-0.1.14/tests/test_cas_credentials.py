import json
import os
import stat
import pytest
from nexus import settings
from nexus._types import NexusCasError


def test_env_credentials_win_and_no_issue_call(monkeypatch, tmp_path):
    """환경변수가 있으면 nexus에 요청하지 않는다 — CI·자동화의 탈출구다."""
    monkeypatch.setenv("CAS_KEY_ID", "CASK-env")
    monkeypatch.setenv("CAS_SECRET", "sk-env")
    monkeypatch.setenv("NEXUS_SETTINGS", str(tmp_path / "s.json"))
    resolved = settings.resolve(nexus_url="http://x", email="e", password="p", cas_url="http://c")
    assert resolved["cas_key_id"] == "CASK-env"
    assert resolved["cas_secret"] == "sk-env"


def test_save_cas_credentials_creates_file_and_tightens_mode(tmp_path):
    p = tmp_path / "settings.json"
    settings.save_cas_credentials(p, "CASK-1", "sk-1")
    data = json.loads(p.read_text(encoding="utf-8"))
    assert data["cas_key_id"] == "CASK-1"
    assert data["cas_secret"] == "sk-1"
    if os.name == "posix":
        assert stat.S_IMODE(p.stat().st_mode) == 0o600


def test_save_cas_credentials_preserves_other_keys(tmp_path):
    """기존 설정을 날리지 않는다 — 같은 파일에 nexus_url·email·password가 들어 있다."""
    p = tmp_path / "settings.json"
    p.write_text(json.dumps({"nexus_url": "http://n", "email": "e"}), encoding="utf-8")
    settings.save_cas_credentials(p, "CASK-2", "sk-2")
    data = json.loads(p.read_text(encoding="utf-8"))
    assert data["nexus_url"] == "http://n"
    assert data["email"] == "e"
    assert data["cas_key_id"] == "CASK-2"


def test_cas_region_is_a_known_key_and_does_not_warn(tmp_path, recwarn):
    p = tmp_path / "settings.json"
    p.write_text(json.dumps({"nexus_url": "http://n", "cas_region": "eu-1"}), encoding="utf-8")
    settings.load_file(p)
    assert not any("모르는 키" in str(w.message) for w in recwarn.list)


def test_save_cas_credentials_persists_region(tmp_path):
    p = tmp_path / "settings.json"
    settings.save_cas_credentials(p, "CASK-3", "sk-3", region="eu-1")
    data = json.loads(p.read_text(encoding="utf-8"))
    assert data["cas_region"] == "eu-1"


def test_save_cas_credentials_no_temp_file_left_behind(tmp_path):
    """원자적 쓰기(mkstemp + os.replace)가 임시 파일을 지우지 않고 남기지 않는다."""
    p = tmp_path / "settings.json"
    settings.save_cas_credentials(p, "CASK-4", "sk-4")
    assert [f.name for f in tmp_path.iterdir()] == ["settings.json"]


def test_save_cas_credentials_leaves_original_intact_on_replace_failure(tmp_path, monkeypatch):
    """쓰다가 죽으면(여기서는 os.replace 실패로 흉내) 원본이 절반짜리로 남으면 안 된다 —
    이 파일에는 CAS 자격증명 말고도 nexus_url/email/password가 들어 있다."""
    p = tmp_path / "settings.json"
    p.write_text(json.dumps({"nexus_url": "http://n", "email": "e"}), encoding="utf-8")

    def boom(*a, **k):
        raise OSError("disk full")

    monkeypatch.setattr(settings.os, "replace", boom)

    with pytest.raises(OSError):
        settings.save_cas_credentials(p, "CASK-x", "sk-x")

    data = json.loads(p.read_text(encoding="utf-8"))
    assert data == {"nexus_url": "http://n", "email": "e"}
    # 임시 파일도 안 남는다 — 실패 시 정리한다.
    assert [f.name for f in tmp_path.iterdir()] == ["settings.json"]


# ── nexus 는 CAS 자격증명을 발급하지 않는다 (0.1.14~) ────────────────────────
#
# 이전 판은 자격증명이 비어 있으면 `POST /api/v1/auth/cas-credentials` 로 자동 발급을
# 받았고, 403 을 받으면 같은 경로로 갈아 끼웠다. 서버가 그 경로를 걷으면서 둘 다 없앴다.
#
# **여기서 지키는 것은 「부르지 않는다」와 「조용히 넘어가지 않는다」 둘이다.** 앞은 2 단계의
# 조건 자체이고(그 경로를 지운 서버에서 접속이 실패하면 안 된다), 뒤는 그 결과로 서명 없이
# 나가게 된 사용자가 그 사실을 알아야 하기 때문이다.


def _connect(monkeypatch, tmp_path, requests_mock, **kwargs):
    """발급 엔드포인트를 등록해 두고 connect 한다. (mock, 설정 파일) 을 돌려준다.

    **엔드포인트를 등록하는 것이 요점이다** — 등록해 두고도 `called` 가 거짓이어야
    "부르지 않는다" 가 단언된다. 등록하지 않으면 못 불러서 통과한 것과 구분되지 않는다.
    """
    import nexus

    nexus._client = None
    nexus._cas = None
    settings_file = tmp_path / "s.json"
    monkeypatch.setenv("NEXUS_SETTINGS", str(settings_file))
    requests_mock.post("http://n/api/v1/auth/login", json={"token": "t"})
    issue = requests_mock.post(
        "http://n/api/v1/auth/cas-credentials",
        status_code=201,
        json={"cas_key_id": "k", "secret_key": "s", "cas_url": "http://c", "region": "cas-default"},
    )
    nexus.connect(nexus_url="http://n", email="e", password="p", cas_url="http://c", **kwargs)
    return issue, settings_file


def test_connect_never_asks_nexus_to_issue(monkeypatch, tmp_path, requests_mock):
    """자격증명이 하나도 없어도 발급을 요청하지 않는다. **2 단계의 조건 자체다.**"""
    issue, _ = _connect(monkeypatch, tmp_path, requests_mock)
    assert not issue.called, "발급 엔드포인트를 불렀다"


def test_connect_never_asks_when_credentials_supplied(monkeypatch, tmp_path, requests_mock):
    """자격증명이 있을 때도 마찬가지다 — 이쪽은 이전 판에서도 부르지 않았다."""
    issue, _ = _connect(
        monkeypatch, tmp_path, requests_mock, cas_key_id="kid", cas_secret="sec"
    )
    assert not issue.called


def test_connect_without_credentials_warns_and_points_at_sts(monkeypatch, tmp_path, requests_mock):
    """조용히 넘어가지 않는다. CAS 가 익명 읽기를 막은 배포에서는 첫 호출이 403 이 되는데,
    그때 원인을 접속 시점으로 되짚는 것은 사용자 몫이 된다."""
    with pytest.warns(UserWarning) as rec:
        _connect(monkeypatch, tmp_path, requests_mock)
    msg = "\n".join(str(w.message) for w in rec)
    assert "서명 없이" in msg
    assert "CAS_KEY_ID" in msg
    assert "cas_sts" in msg, "갱신이 필요한 사용자에게 STS 를 가리켜야 한다"


def test_connect_with_half_credentials_warns_about_the_half(monkeypatch, tmp_path, requests_mock):
    """한쪽만 있으면 서명이 만들어지지 않는다(`_signed_headers` 가 둘 다 본다) —
    '없음' 과 다른 상태이므로 문구도 달라야 한다."""
    with pytest.warns(UserWarning) as rec:
        _connect(monkeypatch, tmp_path, requests_mock, cas_key_id="kid")
    msg = "\n".join(str(w.message) for w in rec)
    assert "한쪽만" in msg


def test_save_cas_credentials_true_warns_and_writes_nothing(monkeypatch, tmp_path, requests_mock):
    """인자는 시그니처 호환으로 남아 있지만 아무 일도 하지 않는다.

    **조용히 무시하지 않는다** — 이 값을 켜 둔 코드는 "자격증명이 파일에 남는다" 를
    전제하고 있으므로, 그 전제가 깨진 것을 그 자리에서 알려야 한다.
    """
    with pytest.warns(UserWarning) as rec:
        _, settings_file = _connect(
            monkeypatch, tmp_path, requests_mock, save_cas_credentials=True
        )
    msg = "\n".join(str(w.message) for w in rec)
    assert "save_cas_credentials" in msg
    assert not settings_file.exists(), "쓸 값이 없는데 설정 파일을 만들었다"


def test_client_has_no_issue_method(monkeypatch, tmp_path, requests_mock):
    """공개 메서드도 걷었다 — 남겨 두면 지금은 503, 서버가 경로를 지운 뒤에는 404 만
    내는 메서드가 된다."""
    from nexus.client import NexusClient

    assert not hasattr(NexusClient, "issue_cas_credentials")


# ── 403 은 갈아 끼우지 않고 그대로 올라간다 ──────────────────────────────────


def _cas(key_id="CASK1", secret="sk1"):
    from nexus.cas import CasClient

    return CasClient("http://cas", key_id, secret)


def test_static_credentials_do_not_retry_on_403(requests_mock):
    """갱신할 곳이 없으므로 재시도하지 않는다. **요청이 한 번만 나가야 한다** —
    두 번 나가면 같은 값으로 다시 두드린 것이고 아무것도 달라지지 않는다."""
    m = requests_mock.get(
        "http://cas/b/k",
        status_code=403,
        text="<Error><Code>InvalidAccessKeyId</Code></Error>",
    )
    with pytest.raises(NexusCasError):
        _cas().get("b", "k")
    assert m.call_count == 1, f"403 에 재시도했다(호출 {m.call_count} 회)"


def test_dead_static_key_hint_says_sdk_does_not_renew(requests_mock):
    """`InvalidAccessKeyId` 는 정책이 아니라 키가 죽은 것이다. 이전 문구는 "`cas_key_id`
    없이 `nx.connect()` 를 불러 SDK 가 발급·갱신하게 하라" 였는데 그 경로가 없어졌다 —
    그대로 두면 되지 않는 일을 시키는 안내가 된다."""
    requests_mock.get(
        "http://cas/b/k",
        status_code=403,
        text="<Error><Code>InvalidAccessKeyId</Code></Error>",
    )
    with pytest.raises(NexusCasError) as e:
        _cas().get("b", "k")
    msg = str(e.value)
    assert "갱신하지 않습니다" in msg
    assert "cas_sts" in msg or "STS" in msg
    assert "발급" not in msg.split("갱신하지 않습니다")[0], "발급을 권하는 옛 문구가 남았다"


def test_policy_denied_403_still_reads_as_policy(requests_mock):
    """`AccessDenied` 는 자격증명 문제가 아니다 — 이 구분은 그대로 살아 있어야 한다."""
    requests_mock.get(
        "http://cas/b/k",
        status_code=403,
        text="<Error><Code>AccessDenied</Code></Error>",
    )
    with pytest.raises(NexusCasError) as e:
        _cas().get("b", "k")
    assert "정책" in str(e.value)


def test_non_403_has_no_forbidden_hint(requests_mock):
    requests_mock.get("http://cas/b/k", status_code=500, text="boom")
    with pytest.raises(NexusCasError) as e:
        _cas().get("b", "k")
    assert "정책" not in str(e.value)
