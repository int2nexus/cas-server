"""`StsCredentials` — 갱신 창, 토큰 재읽기, 재시도, 캐시 유지, 동시성."""

import threading
import time
import urllib.parse

import pytest
import requests

from nexus._types import NexusCasError
from nexus._version import USER_AGENT
from nexus.sts import REFRESH_WINDOW_SECS, CasSts, StsCredentials

from .sts_helpers import CAS, STS_URL, FakeClock, SleepRecorder, sts_error, sts_ok


def make(tmp_path, clock, sleep=None, token="tok-web-1", duration_seconds=3600, forced_min_interval=60.0):
    f = tmp_path / "token"
    f.write_text(token, encoding="utf-8")
    p = StsCredentials(
        CAS,
        CasSts(token_file=str(f), duration_seconds=duration_seconds),
        clock=clock,
        sleep=sleep or SleepRecorder(),
        forced_min_interval=forced_min_interval,
    )
    return f, p


def form(req):
    return {k: v[0] for k, v in urllib.parse.parse_qs(req.text).items()}


def test_first_call_posts_form_and_caches(tmp_path, requests_mock):
    clock = FakeClock()
    m = requests_mock.post(STS_URL, text=sts_ok(clock.t + 3600))
    _, p = make(tmp_path, clock, duration_seconds=1800)
    c1 = p.current()
    c2 = p.current()
    assert c1 is c2
    assert m.call_count == 1
    assert form(m.last_request) == {
        "Action": "AssumeRoleWithWebIdentity",
        "Version": "2011-06-15",
        "WebIdentityToken": "tok-web-1",
        "DurationSeconds": "1800",
    }
    assert USER_AGENT in m.last_request.headers["User-Agent"]


def test_refresh_window_boundary(tmp_path, requests_mock):
    clock = FakeClock()
    m = requests_mock.post(
        STS_URL,
        [
            {"text": sts_ok(clock.t + 3600, key="CASS-1")},
            {"text": sts_ok(clock.t + 7200, key="CASS-2")},
        ],
    )
    _, p = make(tmp_path, clock)
    p.current()
    clock.t += 3600 - REFRESH_WINDOW_SECS - 1  # 남은 601초
    assert p.current().key_id == "CASS-1"
    assert m.call_count == 1
    clock.t += 1  # 남은 600초
    assert p.current().key_id == "CASS-2"
    assert m.call_count == 2


def test_token_file_is_reread_on_every_refresh(tmp_path, requests_mock):
    clock = FakeClock()
    m = requests_mock.post(
        STS_URL, [{"text": sts_ok(clock.t + 1000)}, {"text": sts_ok(clock.t + 5000)}]
    )
    f, p = make(tmp_path, clock, token="old-token")
    p.current()
    f.write_text("new-token", encoding="utf-8")
    clock.t += 500  # 남은 500초 — 창
    p.current()
    assert [form(r)["WebIdentityToken"] for r in m.request_history] == ["old-token", "new-token"]


def test_token_provider_is_called_on_every_refresh(requests_mock):
    clock = FakeClock()
    calls = []

    def provider():
        calls.append(1)
        return f"t{len(calls)}"

    requests_mock.post(STS_URL, [{"text": sts_ok(clock.t + 1000)}, {"text": sts_ok(clock.t + 5000)}])
    p = StsCredentials(CAS, CasSts(token_provider=provider), clock=clock, sleep=SleepRecorder())
    p.current()
    clock.t += 500
    p.current()
    assert len(calls) == 2


def test_concurrent_callers_trigger_a_single_sts_call(tmp_path, requests_mock):
    clock = FakeClock()

    def slow(request, context):
        time.sleep(0.05)
        return sts_ok(clock.t + 3600)

    m = requests_mock.post(STS_URL, text=slow)
    _, p = make(tmp_path, clock)
    barrier = threading.Barrier(8)
    out = []

    def worker():
        barrier.wait()
        out.append(p.current().key_id)

    threads = [threading.Thread(target=worker) for _ in range(8)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert m.call_count == 1
    assert len(out) == 8


def _slow_second_refresh(clock, entered, release):
    calls = []

    def respond(request, context):
        calls.append(1)
        if len(calls) == 1:
            return sts_ok(clock.t + 1000, key="CASS-cached")
        entered.set()
        release.wait(5)
        return sts_ok(clock.t + 9000, key="CASS-new")

    return calls, respond


def test_usable_cache_is_returned_without_waiting_for_a_slow_refresh(tmp_path, requests_mock):
    clock = FakeClock()
    entered, release = threading.Event(), threading.Event()
    calls, respond = _slow_second_refresh(clock, entered, release)
    requests_mock.post(STS_URL, text=respond)
    _, p = make(tmp_path, clock)
    p.current()
    clock.t += 500  # 남은 500초 — 창에 들었지만 캐시는 쓸 만하다
    out = []
    t = threading.Thread(target=lambda: out.append(p.current().key_id))
    t.start()
    try:
        assert entered.wait(5)
        started = time.monotonic()
        assert p.current().key_id == "CASS-cached"
        assert time.monotonic() - started < 1.0
    finally:
        release.set()
        t.join(5)
    assert out == ["CASS-new"]
    assert len(calls) == 2


def test_nearly_expired_cache_waits_for_the_refresh_in_progress(tmp_path, requests_mock):
    clock = FakeClock()
    entered, release = threading.Event(), threading.Event()
    calls, respond = _slow_second_refresh(clock, entered, release)
    requests_mock.post(STS_URL, text=respond)
    _, p = make(tmp_path, clock)
    p.current()
    clock.t += 950  # 남은 50초 — 캐시를 쓸 수 없다
    t = threading.Thread(target=p.current)
    t.start()
    assert entered.wait(5)
    timer = threading.Timer(0.2, release.set)
    timer.start()
    try:
        assert p.current().key_id == "CASS-new"
    finally:
        release.set()
        t.join(5)
    assert len(calls) == 2


def test_refresh_failure_keeps_usable_cache_with_warning(tmp_path, requests_mock):
    clock = FakeClock()
    sleep = SleepRecorder()
    requests_mock.post(
        STS_URL,
        [{"text": sts_ok(clock.t + 1000, key="CASS-cached", secret="sk-x", token="tok-x")}]
        + [{"status_code": 500, "text": sts_error("IDPCommunicationError")}] * 4,
    )
    _, p = make(tmp_path, clock, sleep)
    p.current()
    clock.t += 500  # 남은 500초 — 창
    with pytest.warns(UserWarning, match="기존 임시 자격증명") as w:
        assert p.current().key_id == "CASS-cached"
    assert all("sk-x" not in str(x.message) and "tok-x" not in str(x.message) for x in w)
    assert sleep.calls == [0.5, 1.0, 2.0]


def test_refresh_failure_without_margin_raises(tmp_path, requests_mock):
    clock = FakeClock()
    requests_mock.post(
        STS_URL,
        [{"text": sts_ok(clock.t + 1000)}, {"status_code": 400, "text": sts_error("ExpiredToken")}],
    )
    _, p = make(tmp_path, clock)
    p.current()
    clock.t += 950  # 남은 50초
    with pytest.raises(NexusCasError, match="ExpiredToken"):
        p.current()


def test_min_interval_between_attempts_while_cache_is_usable(tmp_path, requests_mock):
    clock = FakeClock()
    m = requests_mock.post(
        STS_URL,
        [
            {"text": sts_ok(clock.t + 1000)},
            {"status_code": 400, "text": sts_error("ExpiredToken")},
            {"text": sts_ok(clock.t + 9000, key="CASS-new")},
        ],
    )
    _, p = make(tmp_path, clock)
    p.current()
    clock.t += 500
    with pytest.warns(UserWarning):
        p.current()  # 시도 1회 — 실패, 캐시 사용
    clock.t += 10
    p.current()  # 직전 시도 30초 이내 — STS 를 부르지 않는다
    assert m.call_count == 2
    clock.t += 21
    assert p.current().key_id == "CASS-new"
    assert m.call_count == 3


def test_does_not_follow_redirect_on_sts_post(tmp_path, requests_mock):
    clock = FakeClock()
    m = requests_mock.post(STS_URL, status_code=307, headers={"Location": "http://evil/"})
    evil = requests_mock.post("http://evil/", text=sts_ok(clock.t + 3600))
    _, p = make(tmp_path, clock)
    with pytest.raises(NexusCasError):
        p.current()
    assert m.call_count == 1
    assert evil.call_count == 0


def test_connection_error_message_carries_reason(tmp_path, requests_mock):
    clock = FakeClock()
    sleep = SleepRecorder()
    m = requests_mock.post(
        STS_URL, [{"exc": requests.exceptions.ConnectionError("boom-reason")}] * 4
    )
    _, p = make(tmp_path, clock, sleep)
    with pytest.raises(NexusCasError, match="boom-reason"):
        p.current()
    assert m.call_count == 4


def test_retries_transient_statuses_and_connection_errors(tmp_path, requests_mock):
    clock = FakeClock()
    sleep = SleepRecorder()
    m = requests_mock.post(
        STS_URL,
        [
            {"exc": requests.exceptions.ConnectionError},
            {"status_code": 503, "text": "busy"},
            {"text": sts_ok(clock.t + 3600)},
        ],
    )
    _, p = make(tmp_path, clock, sleep)
    p.current()
    assert m.call_count == 3
    assert sleep.calls == [0.5, 1.0]


@pytest.mark.parametrize("status,code", [(400, "InvalidIdentityToken"), (403, "AccessDenied")])
def test_client_errors_are_not_retried(tmp_path, requests_mock, status, code):
    clock = FakeClock()
    m = requests_mock.post(STS_URL, status_code=status, text=sts_error(code))
    _, p = make(tmp_path, clock)
    with pytest.raises(NexusCasError, match=code):
        p.current()
    assert m.call_count == 1


def test_force_refresh_skips_sts_when_another_thread_already_refreshed(tmp_path, requests_mock):
    clock = FakeClock()
    m = requests_mock.post(
        STS_URL,
        [
            {"text": sts_ok(clock.t + 3600, key="CASS-old")},
            {"text": sts_ok(clock.t + 3600, key="CASS-new")},
        ],
    )
    _, p = make(tmp_path, clock)
    old = p.current()
    assert p.force_refresh(old) is True  # 스레드 A — 실제 갱신
    assert m.call_count == 2
    clock.t += 1
    # 스레드 B — 옛 값으로 403 을 받았다. 60초 간격에 걸리면 새 자격증명을 두고 실패한다.
    assert p.force_refresh(old) is True
    assert m.call_count == 2
    assert p.current().key_id == "CASS-new"


def test_force_refresh_is_rate_limited_for_the_same_credentials(tmp_path, requests_mock):
    clock = FakeClock()
    m = requests_mock.post(
        STS_URL,
        [
            {"text": sts_ok(clock.t + 3600, key="CASS-1")},
            {"text": sts_ok(clock.t + 3600, key="CASS-2")},
            {"text": sts_ok(clock.t + 7200, key="CASS-3")},
        ],
    )
    _, p = make(tmp_path, clock, forced_min_interval=60.0)
    first = p.current()
    assert p.force_refresh(first) is True
    assert m.call_count == 2
    second = p.current()
    clock.t += 30
    assert p.force_refresh(second) is False
    assert m.call_count == 2
    clock.t += 31
    assert p.force_refresh(second) is True
    assert m.call_count == 3


def test_proactive_refresh_does_not_consume_forced_interval(tmp_path, requests_mock):
    clock = FakeClock()
    m = requests_mock.post(
        STS_URL,
        [
            {"text": sts_ok(clock.t + 1000, key="CASS-1")},
            {"text": sts_ok(clock.t + 5000, key="CASS-2")},
            {"text": sts_ok(clock.t + 9000, key="CASS-3")},
        ],
    )
    _, p = make(tmp_path, clock)
    p.current()
    clock.t += 500
    c2 = p.current()  # 선제 갱신
    assert c2.key_id == "CASS-2"
    assert p.force_refresh(c2) is True
    assert m.call_count == 3
