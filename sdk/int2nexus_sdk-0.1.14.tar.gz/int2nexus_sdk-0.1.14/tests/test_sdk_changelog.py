import sys
from pathlib import Path

import pytest

# repo-root/scripts 를 import 경로에 추가 (이 파일: sdk/tests/test_*.py)
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "scripts"))
from sdk_changelog import (
    changelog_versions,
    pyproject_version,
    render_changelog,
    require_section,
    write_changelog,
)

REPO_ROOT = Path(__file__).resolve().parents[2]

_SAMPLE = """# int2nexus-sdk 변경 이력

```
## 9.9.9
```

## 0.1.13

- 고친 것

```
pip install int2nexus-sdk==0.1.13
```

## 0.1.12 이하

옛 노트는 차트 CHANGELOG.
"""


def test_changelog_versions_reads_version_headings_only():
    # 코드 블록 안의 `## 9.9.9` 와 `## 0.1.12 이하` 는 버전 절이 아니다.
    assert changelog_versions(_SAMPLE) == ["0.1.13"]


def test_require_section_passes_when_present():
    require_section(_SAMPLE, "0.1.13")


def test_require_section_stops_when_missing():
    with pytest.raises(SystemExit) as ei:
        require_section(_SAMPLE, "0.1.14")
    assert "0.1.14" in str(ei.value)


def test_require_section_ignores_heading_inside_code_block():
    with pytest.raises(SystemExit):
        require_section(_SAMPLE, "9.9.9")


def test_pyproject_version():
    text = '[project]\nname = "int2nexus-sdk"\nversion = "0.1.13"\n'
    assert pyproject_version(text) == "0.1.13"


def test_pyproject_version_missing_stops():
    with pytest.raises(SystemExit):
        pyproject_version('[project]\nname = "x"\n')


def test_render_changelog_is_a_page():
    html = render_changelog(_SAMPLE)
    assert html.startswith("<!DOCTYPE html>")
    assert '<meta charset="utf-8">' in html
    assert "<h2" in html and "0.1.13" in html
    # 펜스 코드 블록이 코드로 렌더링된다(확장이 빠지면 문단으로 뭉개진다)
    assert "<pre><code>pip install int2nexus-sdk==0.1.13" in html


def test_write_changelog_writes_html_and_markdown(tmp_path):
    src = tmp_path / "CHANGELOG.md"
    src.write_text(_SAMPLE, encoding="utf-8")
    out = tmp_path / "sdk"
    out.mkdir()

    write_changelog(out, src)

    assert (out / "CHANGELOG.md").read_text(encoding="utf-8") == _SAMPLE
    assert "0.1.13" in (out / "changelog.html").read_text(encoding="utf-8")


def test_repo_changelog_has_version_sections():
    # 실제 sdk/CHANGELOG.md 가 이 판정기로 읽힌다(형식이 어긋나면 발행 날에야 알게 된다).
    text = (REPO_ROOT / "sdk" / "CHANGELOG.md").read_text(encoding="utf-8")
    assert changelog_versions(text), "sdk/CHANGELOG.md 에서 버전 절을 찾지 못했다"
