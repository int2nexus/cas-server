"""`CasClient(sts=...)` — 세션 토큰 서명, 403 재시도, 안내 문구, 충돌 규칙."""

import time

import pytest

from nexus._types import NexusCasError
from nexus.cas import CasClient
from nexus.sts import CasSts

from .sts_helpers import CAS, S3_ACCESS_DENIED, S3_BAD_KEY, STS_URL, sts_ok

# CasClient 는 실제 시계를 쓴다 — 만료를 충분히 먼 미래로 둔다.
FAR = time.time() + 5 * 3600


def client(tmp_path, token="tok-web"):
    f = tmp_path / "token"
    f.write_text(token, encoding="utf-8")
    return CasClient(CAS, sts=CasSts(token_file=str(f)))


def test_put_carries_session_token_and_keeps_signed_headers(tmp_path, requests_mock):
    sts = requests_mock.post(STS_URL, text=sts_ok(FAR, key="CASS-1", token="tok-session-1"))
    put = requests_mock.put(f"{CAS}/b/k", status_code=200)
    c = client(tmp_path)
    c.put("b", "k", b"x")
    c.put("b", "k", b"y")
    assert sts.call_count == 1
    h = put.last_request.headers
    assert h["x-amz-security-token"] == "tok-session-1"
    assert "Credential=CASS-1/" in h["Authorization"]
    assert "SignedHeaders=host;x-amz-content-sha256;x-amz-date," in h["Authorization"]


@pytest.mark.parametrize("method", ["get", "head", "read_head"])
def test_read_paths_carry_session_token(tmp_path, requests_mock, method):
    requests_mock.post(STS_URL, text=sts_ok(FAR, token="tok-r"))
    if method == "head":
        m = requests_mock.head(f"{CAS}/b/k", status_code=200, headers={"content-length": "1"})
    else:
        m = requests_mock.get(f"{CAS}/b/k", status_code=200, content=b"abcd")
    c = client(tmp_path)
    if method == "read_head":
        c.read_head("b", "k", 2)
    else:
        getattr(c, method)("b", "k")
    assert m.last_request.headers["x-amz-security-token"] == "tok-r"


@pytest.mark.parametrize("method", ["get", "put", "head", "read_head"])
def test_sts_mode_does_not_follow_redirects(tmp_path, requests_mock, method):
    # requests 는 다른 호스트로 넘어갈 때 Authorization 만 떼고 x-amz-security-token 은 그대로 보낸다.
    requests_mock.post(STS_URL, text=sts_ok(FAR, token="tok-r"))
    verb = {"put": "put", "head": "head"}.get(method, "get")
    other = "http://other-host/b/k"
    getattr(requests_mock, verb)(f"{CAS}/b/k", status_code=307, headers={"Location": other})
    target = getattr(requests_mock, verb)(other, status_code=200, content=b"abcd")
    c = client(tmp_path)
    with pytest.raises(NexusCasError, match="리다이렉트") as e:
        if method == "put":
            c.put("b", "k", b"x")
        elif method == "read_head":
            c.read_head("b", "k", 2)
        else:
            getattr(c, method)("b", "k")
    assert target.call_count == 0
    assert "tok-r" not in str(e.value)


def test_static_mode_still_follows_redirects(requests_mock):
    requests_mock.get(f"{CAS}/b/k", status_code=307, headers={"Location": "http://other-host/b/k"})
    requests_mock.get("http://other-host/b/k", status_code=200, content=b"abcd")
    assert CasClient(CAS, key_id="k", secret="s").get("b", "k") == b"abcd"


def test_403_invalid_key_forces_refresh_and_resigns_retry(tmp_path, requests_mock):
    requests_mock.post(
        STS_URL,
        [
            {"text": sts_ok(FAR, key="CASS-old", token="tok-old")},
            {"text": sts_ok(FAR, key="CASS-new", token="tok-new")},
        ],
    )
    put = requests_mock.put(f"{CAS}/b/k", [{"status_code": 403, "text": S3_BAD_KEY}, {"status_code": 200}])
    client(tmp_path).put("b", "k", b"x")
    retry = put.request_history[1].headers
    assert "Credential=CASS-new/" in retry["Authorization"]
    assert retry["x-amz-security-token"] == "tok-new"


def test_403_access_denied_does_not_refresh(tmp_path, requests_mock):
    sts = requests_mock.post(STS_URL, text=sts_ok(FAR))
    requests_mock.put(f"{CAS}/b/k", status_code=403, text=S3_ACCESS_DENIED)
    with pytest.raises(NexusCasError) as e:
        client(tmp_path).put("b", "k", b"x")
    assert sts.call_count == 1
    assert "정책" in str(e.value)
    assert "x-amz-security-token" in str(e.value)


def test_same_session_after_refresh_gets_its_own_hint(tmp_path, requests_mock):
    requests_mock.post(STS_URL, text=sts_ok(FAR, key="CASS-same"))
    requests_mock.put(f"{CAS}/b/k", status_code=403, text=S3_BAD_KEY)
    with pytest.raises(NexusCasError, match="같은 세션"):
        client(tmp_path).put("b", "k", b"x")


def test_retry_after_another_thread_refreshed_uses_new_credentials(tmp_path, requests_mock):
    sts = requests_mock.post(STS_URL, [{"text": sts_ok(FAR, key="CASS-old")}, {"text": sts_ok(FAR, key="CASS-new")}])
    c = client(tmp_path)
    old = c._sts.current()
    assert c._retry_with_fresh_credentials(old, "InvalidAccessKeyId") is True  # A
    assert c._retry_with_fresh_credentials(old, "InvalidAccessKeyId") is True  # B
    assert sts.call_count == 2


def test_ensure_credentials_calls_sts_once_and_is_noop_for_static(tmp_path, requests_mock):
    sts = requests_mock.post(STS_URL, text=sts_ok(FAR))
    client(tmp_path).ensure_credentials()
    assert sts.call_count == 1
    CasClient(CAS, key_id="k", secret="s").ensure_credentials()
    assert sts.call_count == 1


def test_sts_conflicts_with_static_credentials(tmp_path):
    cfg = CasSts(token_file=str(tmp_path / "t"))
    with pytest.raises(ValueError):
        CasClient(CAS, key_id="k", sts=cfg)
    with pytest.raises(ValueError):
        CasClient(CAS, secret="s", sts=cfg)
