"""SDK 가 자기 이름과 버전을 `User-Agent` 에 싣는가.

서버 요청 로그의 `ua` 는 **앞 48 자**만 남긴다. 그래서 "붙어 있다" 로는 부족하고
"48 자 안에 온전히 들어간다" 까지가 이 기능이다 — 잘린 버전 문자열은 없는 것과 같다.
"""

import requests

from nexus._version import USER_AGENT, __version__

# 서버가 요청 로그에 남기는 길이(`ua` 필드). 늘리려면 서버부터 고쳐야 한다.
_UA_LOG_LIMIT = 48


def test_user_agent_carries_dist_name_and_version():
    assert USER_AGENT == f"int2nexus-sdk/{__version__}"


def test_user_agent_survives_the_48_char_log_truncation():
    """requests 기본값까지 붙인 실제 헤더가 잘려도 우리 토큰은 온전해야 한다."""
    session = requests.Session()
    from nexus._version import apply_user_agent

    apply_user_agent(session)
    ua = session.headers["User-Agent"]

    assert USER_AGENT in ua[:_UA_LOG_LIMIT], f"48자 절단에 우리 토큰이 걸린다: {ua!r}"
    # requests 기본값을 지우지 않는다 — TLS·프록시 문제를 볼 때 쓰인다.
    assert "python-requests/" in ua


def test_cas_requests_send_the_user_agent(requests_mock):
    from nexus.cas import CasClient

    requests_mock.put("http://cas-ua/b/k", status_code=200)
    CasClient("http://cas-ua", key_id="kid", secret="sec").put(
        "b", "k", b"data", "image/png"
    )

    sent = requests_mock.request_history[-1].headers["User-Agent"]
    assert USER_AGENT in sent[:_UA_LOG_LIMIT]


def test_nexus_requests_send_the_user_agent(requests_mock):
    from nexus.client import NexusClient

    requests_mock.post("http://nx-ua/api/v1/auth/login", json={"token": "t"})
    NexusClient("http://nx-ua", "e@x.com", "pw")

    sent = requests_mock.request_history[-1].headers["User-Agent"]
    assert USER_AGENT in sent[:_UA_LOG_LIMIT]
