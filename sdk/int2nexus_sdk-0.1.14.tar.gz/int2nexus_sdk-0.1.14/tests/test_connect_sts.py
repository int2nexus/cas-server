"""`nx.connect(cas_sts=...)` — 충돌 규칙, 접속 시점 발급, 정적 키 분기 우회."""

import json
import time

import pytest

import nexus
from nexus._types import NexusCasError
from nexus.sts import CasSts

from .sts_helpers import CAS, STS_URL, sts_error, sts_ok

FAR = time.time() + 5 * 3600


@pytest.fixture(autouse=True)
def _reset_globals():
    nexus._client = None
    nexus._cas = None
    yield
    nexus._client = None
    nexus._cas = None


@pytest.fixture
def token_file(tmp_path):
    f = tmp_path / "token"
    f.write_text("tok-web", encoding="utf-8")
    return str(f)


def mock_nexus(requests_mock):
    requests_mock.post("http://n/api/v1/auth/login", json={"token": "t"})
    return requests_mock.post(
        "http://n/api/v1/auth/cas-credentials",
        status_code=201,
        json={"cas_key_id": "CASK-auto", "secret_key": "sk", "cas_url": CAS, "region": "cas-default"},
    )


def test_connect_rejects_sts_with_explicit_static_args(token_file):
    with pytest.raises(ValueError):
        nexus.connect(
            nexus_url="http://n", email="e", password="p", cas_url=CAS,
            cas_key_id="k", cas_secret="s", cas_sts=CasSts(token_file=token_file),
        )


def test_connect_sts_fetches_at_connect_and_skips_auto_issue(token_file, requests_mock):
    issue = mock_nexus(requests_mock)
    sts = requests_mock.post(STS_URL, text=sts_ok(FAR, key="CASS-c"))
    nexus.connect(
        nexus_url="http://n", email="e", password="p", cas_url=CAS,
        cas_sts=CasSts(token_file=token_file),
    )
    assert sts.call_count == 1
    assert not issue.called
    assert nexus._cas._sts.current().key_id == "CASS-c"


def test_connect_sts_ignores_env_static_keys_with_warning(token_file, requests_mock, monkeypatch):
    monkeypatch.setenv("CAS_KEY_ID", "CASK-env")
    monkeypatch.setenv("CAS_SECRET", "sk-env")
    mock_nexus(requests_mock)
    requests_mock.post(STS_URL, text=sts_ok(FAR))
    with pytest.warns(UserWarning, match="무시"):
        nexus.connect(
            nexus_url="http://n", email="e", password="p", cas_url=CAS,
            cas_sts=CasSts(token_file=token_file),
        )
    assert nexus._cas._key_id == ""


def test_connect_sts_does_not_touch_settings_file(token_file, requests_mock, monkeypatch, tmp_path):
    p = tmp_path / "s.json"
    original = {
        "nexus_url": "http://n", "email": "e", "password": "p", "cas_url": CAS,
        "cas_key_id": "CASK-file", "cas_secret": "sk-file",
    }
    p.write_text(json.dumps(original), encoding="utf-8")
    monkeypatch.setenv("NEXUS_SETTINGS", str(p))
    mock_nexus(requests_mock)
    requests_mock.post(STS_URL, text=sts_ok(FAR))
    with pytest.warns(UserWarning, match="무시"):
        nexus.connect(cas_sts=CasSts(token_file=token_file))
    assert json.loads(p.read_text(encoding="utf-8")) == original


def test_connect_sts_surfaces_sts_errors_at_connect(token_file, requests_mock):
    mock_nexus(requests_mock)
    requests_mock.post(STS_URL, status_code=403, text=sts_error("AccessDenied", "no mapping"))
    # 이전에 성공한 정적 접속이 남긴 값을 흉내 낸다 — 실패한 STS 접속이 이 둘을 지우지
    # 않으면 upload/probe 가 죽은 이전 클라이언트를 계속 쓴다.
    nexus._cas = object()
    nexus._client = object()
    with pytest.raises(NexusCasError, match="AccessDenied"):
        nexus.connect(
            nexus_url="http://n", email="e", password="p", cas_url=CAS,
            cas_sts=CasSts(token_file=token_file),
        )
    assert nexus._cas is None
    assert nexus._client is None


def test_cas_sts_is_exported():
    assert nexus.CasSts is CasSts
    assert "CasSts" in nexus.__all__
