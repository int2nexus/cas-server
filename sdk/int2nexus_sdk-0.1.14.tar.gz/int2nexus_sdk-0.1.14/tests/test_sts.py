"""`nexus.sts` 의 순수 부분 — 설정값 검사, 응답 파싱, 에러 문구, 토큰 읽기."""

import traceback
from datetime import datetime, timezone

import pytest

from nexus._types import NexusCasError
from nexus.sts import (
    CasSts,
    Credentials,
    error_message,
    parse_expiration,
    parse_success,
    read_token,
)

from .sts_helpers import S3_ACCESS_DENIED, sts_error, sts_ok


def test_cas_sts_requires_exactly_one_token_source():
    with pytest.raises(ValueError):
        CasSts()
    with pytest.raises(ValueError):
        CasSts(token_file="f", token_provider=lambda: "t")
    CasSts(token_file="f")
    CasSts(token_provider=lambda: "t")


def test_cas_sts_rejects_non_callable_token_provider():
    with pytest.raises(ValueError):
        CasSts(token_provider="abc")


def test_cas_sts_rejects_blank_file_and_out_of_range_duration():
    with pytest.raises(ValueError):
        CasSts(token_file="  ")
    for bad in (899, 43201, True, 3600.0):
        with pytest.raises(ValueError):
            CasSts(token_file="f", duration_seconds=bad)
    CasSts(token_file="f", duration_seconds=900)
    CasSts(token_file="f", duration_seconds=43200)


def test_cas_sts_repr_hides_provider():
    r = repr(CasSts(token_provider=lambda: "secret-token-value"))
    assert "<callable>" in r
    assert "secret-token-value" not in r
    assert "lambda" not in r


def test_credentials_repr_hides_secret_and_session_token():
    r = repr(Credentials("CASS-1", "sk-hidden", "tok-hidden", 1.0))
    assert "CASS-1" in r
    assert "sk-hidden" not in r
    assert "tok-hidden" not in r


def test_parse_expiration_accepts_z_suffix():
    # Python 3.10 의 fromisoformat 은 `Z` 를 받지 않는다 — cas 는 `…ffffffZ` 를 낸다.
    expected = datetime(2026, 9, 14, 1, 2, 3, 123456, tzinfo=timezone.utc).timestamp()
    assert parse_expiration("2026-09-14T01:02:03.123456Z") == pytest.approx(expected)


def test_parse_expiration_rejects_naive_and_garbage():
    for s in ("2026-09-14T01:02:03", "not-a-date"):
        with pytest.raises(ValueError):
            parse_expiration(s)


def test_parse_success_reads_four_fields_and_unescapes():
    c = parse_success(sts_ok(2_000_000_000.0, key="CASS-a", secret="sk-a&amp;b", token="tok-a"))
    assert c.key_id == "CASS-a"
    assert c.secret == "sk-a&b"
    assert c.session_token == "tok-a"
    assert c.expires_at == pytest.approx(2_000_000_000.0)


def test_parse_success_missing_expiration_does_not_leak_secrets():
    body = (
        sts_ok(2e9, secret="sk-leak", token="tok-leak")
        .replace("<Expiration>", "<X>")
        .replace("</Expiration>", "</X>")
    )
    with pytest.raises(NexusCasError) as e:
        parse_success(body)
    assert "sk-leak" not in str(e.value)
    assert "tok-leak" not in str(e.value)


@pytest.mark.parametrize(
    "code,needle",
    [
        ("ExpiredToken", "900"),
        ("InvalidIdentityToken", "aud"),
        ("AccessDenied", "매핑"),
        ("IDPCommunicationError", "JWKS"),
        ("ValidationError", "형식"),
    ],
)
def test_error_message_per_code_carries_cas_message(code, needle):
    msg = error_message(400, sts_error(code, "cas said this"))
    assert code in msg
    assert "cas said this" in msg
    assert needle in msg


def test_s3_style_403_means_sts_not_enabled_not_missing_mapping():
    msg = error_message(403, S3_ACCESS_DENIED)
    assert "auth.oidc.issuers" in msg
    assert "매핑" not in msg


def test_unknown_error_body_is_truncated():
    msg = error_message(502, "x" * 1000)
    assert "502" in msg
    assert len(msg) < 400


def test_read_token_file_strips_and_rereads(tmp_path):
    f = tmp_path / "token"
    f.write_text(" t1\n", encoding="utf-8")
    cfg = CasSts(token_file=str(f))
    assert read_token(cfg) == "t1"
    f.write_text("t2", encoding="utf-8")
    assert read_token(cfg) == "t2"


def test_read_token_missing_or_empty_file_names_path(tmp_path):
    missing = tmp_path / "nope"
    with pytest.raises(NexusCasError) as e:
        read_token(CasSts(token_file=str(missing)))
    assert str(missing) in str(e.value)
    empty = tmp_path / "empty"
    empty.write_text("\n", encoding="utf-8")
    with pytest.raises(NexusCasError):
        read_token(CasSts(token_file=str(empty)))


def test_read_token_provider_errors_are_wrapped_without_their_message():
    def boom():
        raise RuntimeError("contains-token-abc")

    with pytest.raises(NexusCasError) as e:
        read_token(CasSts(token_provider=boom))
    assert "contains-token-abc" not in str(e.value)
    assert "RuntimeError" in str(e.value)
    # 노트북 traceback 은 __cause__·__context__ 의 문구를 함께 찍는다 — 둘 다 끊는다.
    assert e.value.__cause__ is None and e.value.__suppress_context__
    shown = "".join(traceback.format_exception(type(e.value), e.value, e.value.__traceback__))
    assert "contains-token-abc" not in shown
    for bad in (lambda: "", lambda: None, lambda: 123):
        with pytest.raises(NexusCasError):
            read_token(CasSts(token_provider=bad))
