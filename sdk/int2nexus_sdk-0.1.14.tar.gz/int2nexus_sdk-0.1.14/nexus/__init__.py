from __future__ import annotations
import os
import warnings

from nexus._types import (
    IngestResult,
    NexusAuthError,
    NexusBatchError,
    NexusCasError,
    NexusError,
    NexusIngestError,
)
from nexus import settings as _settings
from nexus._version import __version__
from nexus.cas import CasClient
from nexus.client import NexusClient
from nexus.dataset import AnnotationSession, Dataset
from nexus.imageinfo import ImageInfo, image_info
from nexus.probe import probe
from nexus.sample import CasRef, Sample
from nexus.sts import CasSts
from nexus.upload import upload

_client: NexusClient | None = None
_cas: CasClient | None = None


def _apply_insecure_tls(verify: "bool | str") -> None:
    """`verify=False`일 때 urllib3의 요청마다 나오는 경고를 억제하고 **한 번만** 우리 경고를 낸다.

    요청마다 나오는 경고는 대량 적재 로그를 뒤덮어 실제 문제를 가린다. 그렇다고 조용히
    넘기면 "이 연결은 중간자 공격을 탐지하지 못한다"는 사실이 어디에도 남지 않으므로,
    접속 시점에 한 번은 반드시 알린다.
    """
    if verify is not False:
        return
    warnings.warn(
        "TLS 인증서 검증이 꺼져 있습니다(verify=False) — 이 연결은 중간자 공격을 탐지하지 "
        "못합니다. 사내 프록시가 원인이라면 검증을 끄는 대신 루트 CA 번들 경로를 주는 쪽을 "
        "권합니다: nx.connect(verify='/path/to/corp-ca.pem') 또는 설정 파일의 \"verify\" 키.",
        stacklevel=3,
    )
    try:  # urllib3 2.x / 1.x 모두 대응
        from urllib3.exceptions import InsecureRequestWarning

        warnings.simplefilter("ignore", InsecureRequestWarning)
    except Exception:  # pragma: no cover - urllib3 내부 구조가 바뀐 경우
        pass


def connect(
    nexus_url: str | None = None,
    email: str | None = None,
    password: str | None = None,
    cas_url: str | None = None,
    cas_key_id: str | None = None,
    cas_secret: str | None = None,
    timeout: "float | tuple[float, float]" = (10.0, 120.0),
    verify: "bool | str | None" = None,
    settings_path: "str | None" = None,
    save_cas_credentials: bool = False,
    robot_token: "str | None" = None,
    cas_sts: "CasSts | None" = None,
) -> NexusClient:
    """nexus/CAS에 접속한다. 인자를 하나도 안 주면 환경변수와 설정 파일에서 해소한다.

    값의 우선순위는 **인자 > 환경변수 > 설정 파일**(`~/.int2nexus/settings.json`,
    `NEXUS_SETTINGS`로 경로 변경 가능). 설정 파일에 다 적어두면 `nx.connect()` 한 줄이면 된다.

    `verify`는 TLS 인증서 검증 — `True`(기본), `False`(검증 끔), 또는 **CA 번들 경로**.
    사내 TLS 검사 장비 때문에 SSL 에러가 난다면 검증을 끄는 대신 사내 루트 CA 경로를 주는
    쪽을 권한다. nexus와 CAS 양쪽 세션에 같은 값이 적용된다.

    **CAS 자격증명은 nexus 가 발급하지 않는다**(0.1.14~). 이전 판은 자격증명이 비어 있으면
    `POST /api/v1/auth/cas-credentials` 로 자동 발급을 받았는데, 그 경로가 걷히면서 없어졌다.
    정적 키는 인자·환경변수(`CAS_KEY_ID`/`CAS_SECRET`)·설정 파일 중 하나로 직접 주고, 스스로
    갱신이 필요하면 아래 STS 모드를 쓴다.

    **자격증명이 없어도 접속 자체는 된다** — 서명 없는 요청은 `CasClient._signed_headers` 가
    그대로 통과시킨다. CAS 가 익명 읽기를 허용하는 배포에서는 그대로 읽히고, 아니면 첫 CAS
    호출이 403 이다. 어느 쪽인지 접속 시점에는 알 수 없으므로 `warnings.warn` 으로 알린다.

    **403 에 자격증명을 갈아 끼우지 않는다.** 갱신할 곳이 없기 때문이다 — 만료·폐기된 정적
    키는 새 값을 주어야 풀리고, 에러 메시지가 그것을 짚는다(`cas.py` 의
    `_MANUAL_CREDENTIAL_DEAD_HINT`). 스스로 갱신하는 것은 STS 모드뿐이다.

    `save_cas_credentials` 인자는 시그니처 호환을 위해 남아 있지만 아무 일도 하지 않는다 —
    켜 두면 경고한다.

    **로봇 토큰**(`robot_token=` 또는 `NEXUS_ROBOT_TOKEN`)을 주면 로그인 경로를 타지 않고
    그 값이 그대로 Bearer 로 실린다. `email`/`password` 는 필요 없다. 관리자가
    `POST /api/v1/admin/robots/{user_id}/tokens` 로 발급한 `nxr_` 로 시작하는 값이고,
    워크로드는 보통 sealed-secret 에서 환경변수로 받는다.

    **로봇 토큰은 설정 파일에 저장하지 않는다.** 그 값은 배포가 주입하는 것이지 이 라이브러리가
    관리할 것이 아니고, 파일에 남기면 sealed-secret 으로 관리하는 의미가 사라진다.

    로봇 토큰에는 갱신도 재로그인도 없다. `401` 은 그대로 올라간다 — 폐기·만료·계정 정지
    중 무엇이든 관리자가 조작해야 풀리고, 재시도해 봐야 같은 값을 다시 보내는 것뿐이다.

    **CAS 임시 자격증명(STS)** 은 `cas_sts=CasSts(token_file=...)` 또는
    `CasSts(token_provider=...)` 로 켠다(0.1.12+). 그러면 cas 의 `AssumeRoleWithWebIdentity` 로
    임시 자격증명을 받아 쓰고 만료 전에 스스로 갱신한다. **정적 키 경로 전체를 건너뛴다** —
    `cas_key_id`/`cas_secret` 인자와 함께 주면 `ValueError`, 환경변수·설정 파일의 정적 키는 경고를
    내고 무시한다. 접속 시점에 한 번 받아
    토큰 파일·매핑이 틀렸으면 여기서 `NexusCasError` 로 실패한다(cas 에 닿지 않으면 재시도 뒤).
    """
    # bucket은 전역 기본값을 두지 않는다 — nx.upload(paths, bucket=...)에서 호출별로 지정.
    # timeout=(connect, read) — read를 넉넉히(배치 적재가 오래 걸릴 수 있음). 없으면 정체가 무한 hang.
    global _client, _cas

    if cas_sts is not None and (cas_key_id or cas_secret):
        raise ValueError(
            "cas_sts 와 cas_key_id/cas_secret 인자는 함께 줄 수 없습니다 — STS 모드는 CAS 자격증명을 "
            "스스로 받습니다"
        )

    # 인자 > 환경변수. 설정 파일은 보지 않는다 — 로봇 토큰은 배포가 주입하는 값이고,
    # 파일에 남기면 sealed-secret 으로 관리하는 의미가 사라진다.
    resolved_robot_token = robot_token or os.environ.get("NEXUS_ROBOT_TOKEN") or None

    cfg = _settings.resolve(
        path=settings_path,
        require_login=resolved_robot_token is None,
        nexus_url=nexus_url,
        email=email,
        password=password,
        cas_url=cas_url,
        cas_key_id=cas_key_id,
        cas_secret=cas_secret,
        verify=verify,
    )
    _apply_insecure_tls(cfg["verify"])

    client = NexusClient(
        cfg["nexus_url"], cfg["email"] or "", cfg["password"] or "",
        timeout=timeout, verify=cfg["verify"],
        robot_token=resolved_robot_token,
    )
    _client = client

    # settings.resolve()가 인자·환경변수·설정 파일에서 읽어 채워둔 값(셋 다 없으면
    # CasClient 기본값과 같은 "cas-default"). **0.1.14 부터 이 값을 갈아 끼우는 경로가
    # 없다** — 자동 발급 응답의 region 이 채워 주던 자리였다. 기본 region 이 아닌 배포는
    # 반드시 직접 준다. 틀리면 서명이 맞지 않아 계속 403 이다.
    region = cfg["cas_region"]

    # **STS 분기보다 먼저 본다.** 이 인자는 두 모드 모두에서 아무 일도 하지 않으므로
    # STS 뒤에 두면 STS 사용자만 경고를 못 받는다.
    if save_cas_credentials:
        # 발급이 없어졌으므로 저장할 것도 없다. 인자는 시그니처 호환을 위해 남겨 두되
        # 조용히 무시하지 않는다 — 이 값을 켜 둔 코드는 "자격증명이 파일에 남는다"를
        # 전제하고 있으므로, 그 전제가 깨진 것을 그 자리에서 알려야 한다.
        warnings.warn(
            "save_cas_credentials 는 더 이상 아무 일도 하지 않습니다(0.1.14~) — nexus 가 "
            "CAS 자격증명을 발급하지 않으므로 저장할 값이 생기지 않습니다. 정적 키는 "
            "CAS_KEY_ID/CAS_SECRET 이나 설정 파일로 직접 주십시오.",
            stacklevel=2,
        )

    if cas_sts is not None:
        # **정적 키 분기 전체를 건너뛴다**(지금은 한쪽 키 경고뿐이다). 환경변수나
        # 설정 파일에 키가 있으면 조용히 버리지 않고 알린다 — 0.1.9 이하 설치본은 설정 파일에 자동
        # 발급 키가 깔려 있을 수 있어 매 접속 보일 수 있고, 그것은 의도다.
        if cfg["cas_key_id"] or cfg["cas_secret"]:
            warnings.warn(
                "CAS_KEY_ID/CAS_SECRET(환경변수 또는 설정 파일)을 무시하고 cas_sts 로 받은 임시 "
                "자격증명을 씁니다",
                stacklevel=2,
            )
        cas = CasClient(cfg["cas_url"], region=region, verify=cfg["verify"], sts=cas_sts)
        try:
            cas.ensure_credentials()
        except Exception:
            # 실패한 접속이 _client/_cas 중 하나라도 남기면 upload/probe 가 재접속하지 않고
            # 옛 클라이언트로 죽는다(probe는 _cas를 직접 본다) — 둘 다 지운다.
            _client = None
            _cas = None
            raise
        _cas = cas
        return client

    if not cfg["cas_key_id"] or not cfg["cas_secret"]:
        # **nexus 에 발급을 요청하지 않는다**(0.1.14~). 이전 판은 자격증명이 비어 있으면
        # `POST /api/v1/auth/cas-credentials` 로 자동 발급을 받았는데, nexus 가 그 경로를
        # 걷으면서 부를 곳이 없어졌다. 자격증명 없이도 접속 자체는 되고(서명 없는 요청은
        # `CasClient._signed_headers` 가 그대로 통과시킨다), CAS 가 익명 읽기를 허용하지
        # 않는 배포에서는 첫 CAS 호출이 403 이다. 그래서 여기서 조용히 넘어가지 않고
        # 무엇을 해야 하는지 적어 경고한다.
        if cfg["cas_key_id"] or cfg["cas_secret"]:
            # 한쪽만 있으면 어차피 서명에 못 쓴다 — 둘 다 있어야 `_signed_headers` 가
            # 서명한다. 반쪽이 있다는 것은 설정이 끊긴 것이므로 따로 짚는다.
            warnings.warn(
                "CAS_KEY_ID/CAS_SECRET 중 한쪽만 설정되어 있어 그것만으로는 서명할 수 "
                "없습니다 — CAS 요청이 서명 없이 나갑니다.",
                stacklevel=2,
            )
        else:
            warnings.warn(
                "CAS 자격증명이 없어 CAS 요청이 서명 없이 나갑니다. nexus 는 CAS 자격증명을 "
                "발급하지 않습니다(0.1.14~) — CAS 운영자에게 받은 키를 CAS_KEY_ID/CAS_SECRET "
                "으로 주거나, 스스로 갱신하는 STS 모드를 쓰십시오"
                "(`nx.connect(cas_sts=CasSts(token_file=...))`).",
                stacklevel=2,
            )

    _cas = CasClient(
        cfg["cas_url"], cfg["cas_key_id"], cfg["cas_secret"],
        region=region, verify=cfg["verify"],
    )
    return client


def _auto_connect() -> NexusClient:
    global _client
    if _client is None:
        connect()
    return _client  # type: ignore[return-value]


def list_datasets(
    *,
    q: str | None = None,
    name: str | None = None,
    description: str | None = None,
    tags: "str | list[str] | None" = None,
    sort: str | None = None,
    order: str | None = None,
    favorite: bool = False,
    mine: bool = False,
    unowned: bool = False,
    limit: int | None = None,
    cursor: str | None = None,
    client: NexusClient | None = None,
) -> list[dict]:
    """등록된 dataset 목록(dict 리스트).

    각 항목: `dataset_id`/`name`/`description`/`tags`/`created_at`와 **`versions`**(버전 문자열
    목록, 예 `['v0','v1']`), **`is_favorite`**(내 즐겨찾기 여부). 옵션 — `name`/`description`: 부분
    검색(ILIKE), `tags`: 하나라도 포함(ANY), `sort`: "name"|"created_at"(기본), `order`: "asc"/"desc"(기본
    desc), `favorite`: True면 내 즐겨찾기만, `mine`: 내가 담당인 것만, `unowned`: 담당자가 없는 것만.

    **`limit`을 안 주면 커서를 자동으로 순회해 전체를 모은다**(서버 0.1.7부터 한 응답에
    기본 100개까지만 실린다). `limit`에 숫자를 주면 그 개수만큼 한 페이지만 반환한다.
    """
    c = client or _auto_connect()
    return c.list_datasets(
        q=q, name=name, description=description, tags=tags, sort=sort, order=order,
        favorite=favorite, mine=mine, unowned=unowned, limit=limit, cursor=cursor,
    )


def annotation_session(
    session_id: str, *, client: NexusClient | None = None
) -> "AnnotationSession":
    """`session_id`로 기존 세션을 다시 잡는다.

    세션은 파이썬 프로세스와 무관하게 서버에 남아 있다 — 스크립트를 껐다 켜도, 다른
    사람이 만든 세션이어도 id만 있으면 이어받을 수 있다. 목록에서 고르려면
    :func:`annotation_sessions` 를 쓴다.
    """
    c = client or _auto_connect()
    return AnnotationSession(c, c.get_annotation_session(session_id))


def annotation_sessions(
    *,
    status: "str | None" = None,
    dataset_id: str | None = None,
    mine: bool = False,
    limit: int | None = None,
    client: NexusClient | None = None,
) -> "list[AnnotationSession]":
    """**전역** CVAT 편집 세션 목록 — dataset·버전을 가로질러 "지금 진행 중인 것"을 모은다.

    기본은 진행 중인 것만(`status="active"` = creating+open)이다. 이력까지 보려면 `"all"`,
    특정 상태만 보려면 `"open"`/`"closed"`/`"failed"`. `mine=True`면 내가 만든 것만.

    각 항목은 `dataset_name`/`version`/`sample_count`를 이미 담고 있어 추가 조회 없이
    목록을 그릴 수 있다. 다만 `has_unimported_changes`는 목록에서 항상 `None`이다
    (세션마다 CVAT 호출이 필요해서) — 필요하면 `.refresh()` 후 읽을 것.
    """
    c = client or _auto_connect()
    rows = c.list_annotation_sessions(
        dataset_id=dataset_id, status=status, mine=mine, limit=limit
    )
    return [AnnotationSession(c, r) for r in rows]


__all__ = [
    "__version__",
    "connect",
    "list_datasets",
    "annotation_sessions",
    "annotation_session",
    "Dataset",
    "AnnotationSession",
    "Sample",
    "CasRef",
    "CasSts",
    "upload",
    "probe",
    "image_info",
    "ImageInfo",
    "IngestResult",
    "NexusError",
    "NexusAuthError",
    "NexusCasError",
    "NexusIngestError",
    "NexusBatchError",
]
