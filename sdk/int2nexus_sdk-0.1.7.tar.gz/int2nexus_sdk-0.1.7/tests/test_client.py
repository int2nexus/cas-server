import pytest
from nexus.client import NexusClient
from nexus._types import NexusAuthError, NexusIngestError, NexusError

NEXUS = "http://nexus-test"


@pytest.fixture
def logged_in(requests_mock):
    requests_mock.post(f"{NEXUS}/api/v1/auth/login",
                       json={"token": "tok123", "user_id": 1, "email": "u@x.com"})
    return NexusClient(NEXUS, "u@x.com", "pass")


def test_login_stores_token(requests_mock):
    requests_mock.post(f"{NEXUS}/api/v1/auth/login",
                       json={"token": "mytoken", "user_id": 1, "email": "u@x.com"})
    client = NexusClient(NEXUS, "u@x.com", "pass")
    assert client._token == "mytoken"
    assert client._session.headers["Authorization"] == "Bearer mytoken"


def test_login_failure_raises_auth_error(requests_mock):
    requests_mock.post(f"{NEXUS}/api/v1/auth/login", status_code=401,
                       json={"error": "invalid credentials"})
    with pytest.raises(NexusAuthError):
        NexusClient(NEXUS, "u@x.com", "wrong")


def test_list_datasets(logged_in, requests_mock):
    requests_mock.get(f"{NEXUS}/datasets",
                      json=[{"dataset_id": "d1", "name": "kitti"}])
    result = logged_in.list_datasets()
    assert result[0]["name"] == "kitti"


def test_create_dataset(logged_in, requests_mock):
    requests_mock.post(f"{NEXUS}/datasets",
                       json={"dataset_id": "d2", "name": "new-ds"}, status_code=201)
    result = logged_in.create_dataset("new-ds", tags=["detection"])
    assert result["dataset_id"] == "d2"


def test_create_dataset_coerces_str_tag_to_list(logged_in, requests_mock):
    # tags="x" 문자열을 넘기면 ["x"] 배열로 변환해 보낸다 (서버는 배열을 기대).
    requests_mock.post(f"{NEXUS}/datasets",
                       json={"dataset_id": "d3", "name": "ds"}, status_code=201)
    logged_in.create_dataset("ds", tags="tutorial")
    assert requests_mock.last_request.json()["tags"] == ["tutorial"]


def test_update_dataset_sends_only_provided_fields(logged_in, requests_mock):
    requests_mock.patch(f"{NEXUS}/datasets/d1", json={"dataset_id": "d1", "name": "renamed"})
    result = logged_in.update_dataset("d1", name="renamed")
    assert result["name"] == "renamed"
    assert requests_mock.last_request.json() == {"name": "renamed"}


def test_update_dataset_both_fields(logged_in, requests_mock):
    requests_mock.patch(f"{NEXUS}/datasets/d1", json={"dataset_id": "d1", "name": "renamed", "description": "d"})
    logged_in.update_dataset("d1", name="renamed", description="d")
    assert requests_mock.last_request.json() == {"name": "renamed", "description": "d"}


def test_update_dataset_no_fields_sends_empty_body(logged_in, requests_mock):
    requests_mock.patch(f"{NEXUS}/datasets/d1", json={"dataset_id": "d1", "name": "unchanged"})
    logged_in.update_dataset("d1")
    assert requests_mock.last_request.json() == {}


def test_get_dataset_returns_none_on_404(logged_in, requests_mock):
    requests_mock.get(f"{NEXUS}/datasets/d1", status_code=404)
    assert logged_in.get_dataset("d1") is None


def test_get_dataset_returns_dict_when_found(logged_in, requests_mock):
    requests_mock.get(f"{NEXUS}/datasets/d1",
                      json={"dataset_id": "d1", "name": "kitti", "tags": ["a"], "description": "d"})
    result = logged_in.get_dataset("d1")
    assert result["name"] == "kitti"
    assert result["tags"] == ["a"]


def test_get_version_returns_none_on_404(logged_in, requests_mock):
    requests_mock.get(f"{NEXUS}/datasets/d1/versions/v1", status_code=404)
    assert logged_in.get_version("d1", "v1") is None


def test_get_version_returns_dict_when_found(logged_in, requests_mock):
    requests_mock.get(f"{NEXUS}/datasets/d1/versions/v1",
                      json={"dataset_version_id": "dv1", "version": "v1"})
    result = logged_in.get_version("d1", "v1")
    assert result["version"] == "v1"


def test_ingest_raises_on_http_error(logged_in, requests_mock):
    requests_mock.post(f"{NEXUS}/ingest", status_code=400,
                       json={"error": "bad request"})
    with pytest.raises(NexusIngestError) as exc_info:
        logged_in.ingest({"dataset": "x", "version": "v1", "image": {}, "annotation": {}})
    e = exc_info.value
    assert e.status_code == 400
    assert e.server_message == "bad request"
    assert "bad request" in str(e)


def test_ingest_returns_response(logged_in, requests_mock):
    requests_mock.post(f"{NEXUS}/ingest", status_code=201,
                       json={"sample_id": "s1", "dataset_id": "d1", "version": "v1"})
    result = logged_in.ingest({"dataset": "kitti", "version": "v1"})
    assert result["sample_id"] == "s1"


def test_explore_samples_sends_only_provided_filters(logged_in, requests_mock):
    requests_mock.post(f"{NEXUS}/datasets/d1/versions/v1/samples/explorer", json=[])
    logged_in.explore_samples("d1", "v1", limit=50)
    assert requests_mock.last_request.json() == {"limit": 50}


def test_explore_samples_sends_all_filters(logged_in, requests_mock):
    requests_mock.post(f"{NEXUS}/datasets/d1/versions/v1/samples/explorer", json=[])
    logged_in.explore_samples(
        "d1", "v1", cursor="s5", limit=100, split="train", tags=["night"],
        meta={"width": {"type": "range", "min": 100}},
        annotation=[{"group_key": "det", "label": "car"}],
        include_annotations=False, sample_ids=["s1", "s2"],
    )
    assert requests_mock.last_request.json() == {
        "limit": 100, "cursor": "s5", "split": "train", "tags": ["night"],
        "meta": {"width": {"type": "range", "min": 100}},
        "annotation": [{"group_key": "det", "label": "car"}],
        "include_annotations": False, "sample_ids": ["s1", "s2"],
    }


def test_list_sample_ids_by_label_keyset_pages(logged_in, requests_mock):
    # limit는 client 내부에서 1000으로 고정. 첫 페이지는 1000개(가득) → 계속,
    # 둘째 페이지는 1000개 미만 → 종료. sample_id는 DESC 총순서이므로 페이지의
    # 마지막 row가 다음 cursor가 된다.
    limit = 1000
    # DESC 순서를 모사: 첫 페이지 id는 큰 값, 둘째 페이지 id는 작은 값.
    page1 = [{"sample_id": f"s{9000 - i}"} for i in range(limit)]
    page2 = [{"sample_id": f"s{500 - i}"} for i in range(3)]
    seen_cursors: list[str | None] = []
    bodies: list[dict] = []

    def responder(request, context):
        body = request.json()  # POST explorer body
        bodies.append(body)
        cursor = body.get("cursor")
        seen_cursors.append(cursor)
        context.status_code = 200
        return page1 if cursor is None else page2

    requests_mock.post(
        f"{NEXUS}/datasets/d1/versions/v1/samples/explorer", json=responder
    )

    ids = logged_in.list_sample_ids_by_label("d1", "v1", "car")

    # 두 번 요청: 첫 요청은 cursor 없음, 둘째 요청은 page1의 마지막 sample_id를 cursor로.
    assert seen_cursors == [None, page1[-1]["sample_id"]]
    # label은 annotation 매처로 전달, 경량 조회(include_annotations=False).
    assert bodies[0]["annotation"] == [{"label": "car"}]
    assert bodies[0]["include_annotations"] is False
    # 결과는 두 페이지 id의 합집합.
    expected = {s["sample_id"] for s in page1} | {s["sample_id"] for s in page2}
    assert ids == expected


def test_get_sample(logged_in, requests_mock):
    requests_mock.get(
        f"{NEXUS}/datasets/d1/versions/v1/samples/s1",
        json={
            "sample_id": "s1", "split": "train", "tags": [],
            "meta": {"filename": "img"},
            "road_obj_ma": [{"id": "b", "label": "sedan"}],
        },
    )
    out = logged_in.get_sample("d1", "v1", "s1")
    assert out["sample_id"] == "s1"
    assert out["road_obj_ma"][0]["label"] == "sedan"


def test_get_sample_404_raises(logged_in, requests_mock):
    requests_mock.get(f"{NEXUS}/datasets/d1/versions/v1/samples/nope",
                      status_code=404, json={"error": "not found"})
    with pytest.raises(NexusError) as exc_info:
        logged_in.get_sample("d1", "v1", "nope")
    assert exc_info.value.status_code == 404


def test_get_manifest_not_sealed_raises_with_hint(logged_in, requests_mock):
    requests_mock.get(f"{NEXUS}/datasets/d1/versions/v1/manifest",
                      status_code=409, json={"error": "version not sealed"})
    with pytest.raises(NexusError, match="requires a sealed version") as exc_info:
        logged_in.get_manifest("d1", "v1")
    assert exc_info.value.status_code == 409


def test_delete_version_403_raises_friendly_owner_message(logged_in, requests_mock):
    requests_mock.delete(f"{NEXUS}/datasets/d1/versions/v1",
                         status_code=403, json={"error": "not the dataset owner"})
    with pytest.raises(NexusError, match="not the owner") as exc_info:
        logged_in.delete_version("d1", "v1", confirm="v1")
    assert exc_info.value.status_code == 403
    assert exc_info.value.server_message == "not the dataset owner"


def test_delete_version_non_403_error_propagates_unchanged(logged_in, requests_mock):
    requests_mock.delete(f"{NEXUS}/datasets/d1/versions/v1",
                         status_code=400, json={"error": "bad confirm value"})
    with pytest.raises(NexusError, match="bad confirm value") as exc_info:
        logged_in.delete_version("d1", "v1", confirm="wrong")
    assert exc_info.value.status_code == 400


def test_list_datasets_with_filters(logged_in, requests_mock):
    requests_mock.get(f"{NEXUS}/datasets", json=[])
    logged_in.list_datasets(name="kit", tags=["a", "b"], sort="name", order="asc")
    q = requests_mock.last_request.qs
    assert q["name"] == ["kit"]
    assert q["tags"] == ["a,b"]
    assert q["sort"] == ["name"]
    assert q["order"] == ["asc"]


def test_list_datasets_walks_the_cursor(logged_in, requests_mock):
    """서버가 한 응답에 100개까지만 싣는다(0.1.7+). 순회하지 않으면 조용히 잘린다."""
    page_size = 1000
    first = [{"dataset_id": f"d{i}", "name": f"ds{i}"} for i in range(page_size)]
    second = [{"dataset_id": "last", "name": "ds-last"}]
    requests_mock.get(f"{NEXUS}/datasets", [{"json": first}, {"json": second}])

    result = logged_in.list_datasets()

    assert len(result) == page_size + 1
    assert result[-1]["dataset_id"] == "last"
    # 두 번째 요청이 첫 페이지 마지막 id를 커서로 넘겨야 한다.
    assert requests_mock.last_request.qs["cursor"] == [f"d{page_size - 1}"]


def test_list_datasets_limit_returns_one_page(logged_in, requests_mock):
    """limit을 주면 한 페이지만 — 자동 순회하지 않는다(ds.samples()와 같은 규칙)."""
    requests_mock.get(f"{NEXUS}/datasets",
                      json=[{"dataset_id": f"d{i}"} for i in range(5)])
    result = logged_in.list_datasets(limit=5)
    assert len(result) == 5
    assert requests_mock.last_request.qs["limit"] == ["5"]
    assert requests_mock.call_count == 2   # 로그인 1 + 목록 1


def test_list_datasets_owner_filters(logged_in, requests_mock):
    requests_mock.get(f"{NEXUS}/datasets", json=[])
    logged_in.list_datasets(mine=True, limit=10)
    assert requests_mock.last_request.qs["mine"] == ["true"]

    logged_in.list_datasets(unowned=True, limit=10)
    assert requests_mock.last_request.qs["unowned"] == ["true"]


def test_list_versions_walks_the_cursor(logged_in, requests_mock):
    """버전 목록도 0.1.7부터 잘린다 — 같은 헬퍼를 쓴다."""
    page_size = 1000
    first = [{"dataset_version_id": f"v{i}", "version": f"v{i}"} for i in range(page_size)]
    second = [{"dataset_version_id": "vlast", "version": "vlast"}]
    requests_mock.get(f"{NEXUS}/datasets/d1/versions", [{"json": first}, {"json": second}])

    result = logged_in.list_versions("d1")

    assert len(result) == page_size + 1
    assert requests_mock.last_request.qs["cursor"] == [f"v{page_size - 1}"]


def test_list_subsets_walks_the_cursor(logged_in, requests_mock):
    page_size = 1000
    first = [{"subset_id": f"s{i}"} for i in range(page_size)]
    second = [{"subset_id": "slast"}]
    requests_mock.get(f"{NEXUS}/datasets/d1/versions/v0/subsets",
                      [{"json": first}, {"json": second}])

    result = logged_in.list_subsets("d1", "v0")

    assert len(result) == page_size + 1
    assert requests_mock.last_request.qs["cursor"] == [f"s{page_size - 1}"]


def test_list_versions(logged_in, requests_mock):
    requests_mock.get(f"{NEXUS}/datasets/d1/versions",
                      json=[{"version": "v1"}, {"version": "v2"}])
    vers = logged_in.list_versions("d1")
    assert [v["version"] for v in vers] == ["v1", "v2"]


def test_remove_sample_ids(logged_in, requests_mock):
    requests_mock.delete(f"{NEXUS}/datasets/d1/versions/v1/samples", json={"removed": 2})
    out = logged_in.remove_sample_ids("d1", "v1", ["s1", "s2"])
    assert out["removed"] == 2
    assert requests_mock.last_request.json() == {"sample_ids": ["s1", "s2"]}


def test_import_samples(logged_in, requests_mock):
    requests_mock.post(
        f"{NEXUS}/datasets/d2/versions/v1/samples/import",
        json={"imported": [{"source_sample_id": "s1", "sample_id": "s1-copy"}]},
    )
    out = logged_in.import_samples("d2", "v1", "d1", "v0", ["s1"])
    assert out["imported"][0]["sample_id"] == "s1-copy"
    assert requests_mock.last_request.json() == {
        "source_dataset_id": "d1", "source_version": "v0", "sample_ids": ["s1"],
    }


def test_add_tags_bulk(logged_in, requests_mock):
    requests_mock.post(
        f"{NEXUS}/samples/tags",
        json=[{"sample_id": "s1", "tags": ["night", "rain"]}, {"sample_id": "s2", "tags": ["night"]}],
    )
    out = logged_in.add_tags_bulk(["s1", "s2"], ["night"])
    assert [s["sample_id"] for s in out] == ["s1", "s2"]
    assert requests_mock.last_request.json() == {"sample_ids": ["s1", "s2"], "tags": ["night"]}


def test_remove_tags_bulk(logged_in, requests_mock):
    requests_mock.delete(f"{NEXUS}/samples/tags", json=[{"sample_id": "s1", "tags": []}])
    out = logged_in.remove_tags_bulk(["s1", "s2"], ["night"])
    assert out == [{"sample_id": "s1", "tags": []}]
    assert requests_mock.last_request.json() == {"sample_ids": ["s1", "s2"], "tags": ["night"]}


def test_default_timeout_set_and_sent(requests_mock):
    requests_mock.post(f"{NEXUS}/api/v1/auth/login", json={"token": "t"})
    c = NexusClient(NEXUS, "u@x.com", "pass")
    assert c._timeout == (10.0, 120.0)              # 기본 (connect, read)
    requests_mock.get(f"{NEXUS}/datasets", json=[])
    c.list_datasets()
    assert requests_mock.last_request.timeout == (10.0, 120.0)


def test_custom_timeout(requests_mock):
    requests_mock.post(f"{NEXUS}/api/v1/auth/login", json={"token": "t"})
    c = NexusClient(NEXUS, "u@x.com", "pass", timeout=5)
    assert c._timeout == 5


def test_favorite_add_remove(logged_in, requests_mock):
    requests_mock.put(f"{NEXUS}/datasets/d1/favorite", status_code=204)
    requests_mock.delete(f"{NEXUS}/datasets/d1/favorite", status_code=204)
    logged_in.add_favorite("d1")
    assert requests_mock.request_history[-1].method == "PUT"
    logged_in.remove_favorite("d1")
    assert requests_mock.request_history[-1].method == "DELETE"


def test_list_datasets_favorite_param(logged_in, requests_mock):
    requests_mock.get(f"{NEXUS}/datasets", json=[])
    logged_in.list_datasets(favorite=True)
    assert requests_mock.last_request.qs.get("favorite") == ["true"]


def test_subset_crud(logged_in, requests_mock):
    requests_mock.post(f"{NEXUS}/datasets/d1/versions/v0/subsets",
                       json={"subset_id": "s1", "name": "a"})
    out = logged_in.create_subset("d1", "v0", "a", {"meta": {}})
    assert out["subset_id"] == "s1"
    assert requests_mock.last_request.json() == {"name": "a", "filter": {"meta": {}}}
    requests_mock.get(f"{NEXUS}/subsets/s1/samples", json=[])
    logged_in.subset_samples("s1", limit=5, include_annotations=False)
    assert requests_mock.last_request.qs.get("include_annotations") == ["false"]


def test_version_diff(logged_in, requests_mock):
    requests_mock.get(f"{NEXUS}/datasets/d1/versions/v1/diff",
                      json={"base": "v0", "target": "v1"})
    out = logged_in.version_diff("d1", "v1", against="v0")
    assert out["base"] == "v0"
    assert requests_mock.last_request.qs.get("against") == ["v0"]


def test_sample_history(logged_in, requests_mock):
    requests_mock.get(f"{NEXUS}/datasets/d1/samples/s1/history",
                      json={"sample_id": "s1", "dataset_id": "d1", "versions": []})
    out = logged_in.sample_history("d1", "s1")
    assert out["sample_id"] == "s1"


def test_list_datasets_q_param(logged_in, requests_mock):
    requests_mock.get(f"{NEXUS}/datasets", json=[])
    logged_in.list_datasets(q="road")
    assert requests_mock.last_request.qs.get("q") == ["road"]


# ── 계정 관리 ────────────────────────────────────────────────────────────────

def test_change_password_sends_both_passwords(logged_in, requests_mock):
    m = requests_mock.post(f"{NEXUS}/api/v1/auth/password", status_code=204)
    logged_in.change_password("old-pass", "new-pass-123")
    assert m.last_request.json() == {
        "current_password": "old-pass",
        "new_password": "new-pass-123",
    }


def test_change_password_wrong_current_raises(logged_in, requests_mock):
    """403은 '토큰은 멀쩡한데 확인용 비밀번호가 틀렸다'는 뜻이다 — 세션 만료가 아니다."""
    requests_mock.post(f"{NEXUS}/api/v1/auth/password", status_code=403,
                       json={"error": "forbidden"})
    with pytest.raises(NexusError) as exc:
        logged_in.change_password("wrong", "new-pass-123")
    assert exc.value.status_code == 403


def test_delete_account_returns_summary(logged_in, requests_mock):
    m = requests_mock.delete(
        f"{NEXUS}/api/v1/auth/account",
        json={"deleted_user_id": 7, "released_datasets": 2, "warning": "…"},
    )
    out = logged_in.delete_account("my-pass")
    assert m.last_request.json() == {"password": "my-pass"}
    assert out["deleted_user_id"] == 7
    assert out["released_datasets"] == 2


def test_delete_account_with_owned_datasets_raises_conflict(logged_in, requests_mock):
    # 서버 0.1.6부터 소유가 남은 계정의 삭제는 409다 — 이관 뒤 다시 부르라는 뜻이라
    # 재로그인으로 풀리는 401과 구분돼야 한다.
    requests_mock.delete(
        f"{NEXUS}/api/v1/auth/account",
        status_code=409,
        json={"error": "3개의 dataset을 소유하고 있어 계정을 삭제할 수 없습니다."},
    )
    with pytest.raises(NexusError) as exc:
        logged_in.delete_account("my-pass")
    assert exc.value.status_code == 409


# ── dataset 소유권 이관 ───────────────────────────────────────────────────────

def test_transfer_dataset_owner_puts_email_to_v1_path(logged_in, requests_mock):
    m = requests_mock.put(
        f"{NEXUS}/api/v1/datasets/d1/owner",
        json={"dataset_id": "d1", "name": "kitti", "owner_user_id": 9},
    )
    out = logged_in.transfer_dataset_owner("d1", "new-owner@int2.us")
    assert m.last_request.json() == {"email": "new-owner@int2.us"}
    assert out["owner_user_id"] == 9


def test_transfer_dataset_owner_to_self_raises_400(logged_in, requests_mock):
    # 자기 자신에게 넘기면 서버가 400이다. 200으로 돌려주면 "넘겼다"로 읽힌다.
    requests_mock.put(
        f"{NEXUS}/api/v1/datasets/d1/owner",
        status_code=400,
        json={"error": "이미 이 계정이 소유하고 있습니다"},
    )
    with pytest.raises(NexusError) as exc:
        logged_in.transfer_dataset_owner("d1", "me@int2.us")
    assert exc.value.status_code == 400


def test_transfer_dataset_owner_ownerless_raises_403(logged_in, requests_mock):
    # 주인 없는 dataset은 이 경로로 인수할 수 없다 — superuser의 admin 경로가 맡는다.
    requests_mock.put(
        f"{NEXUS}/api/v1/datasets/d1/owner", status_code=403, json={"error": "forbidden"}
    )
    with pytest.raises(NexusError) as exc:
        logged_in.transfer_dataset_owner("d1", "new-owner@int2.us")
    assert exc.value.status_code == 403


# ── CVAT annotation 세션 ─────────────────────────────────────────────────────

def test_create_annotation_session_sends_only_given_options(logged_in, requests_mock):
    """groups/extra_labels를 안 주면 바디에 넣지 않는다 — None을 보내면 서버가 '빈 필터'로
    오해할 수 있다."""
    m = requests_mock.post(
        f"{NEXUS}/datasets/d1/versions/v0/annotation-sessions",
        status_code=201,
        json={"session_id": "s1", "status": "creating", "dataset_id": "d1"},
    )
    logged_in.create_annotation_session("d1", "v0", ["a", "b"])
    assert m.last_request.json() == {"sample_ids": ["a", "b"]}

    logged_in.create_annotation_session(
        "d1", "v0", ["a"], groups=["det"],
        extra_labels=[{"group": "det", "label": "Face"}],
    )
    body = m.last_request.json()
    assert body["groups"] == ["det"]
    assert body["extra_labels"] == [{"group": "det", "label": "Face"}]


def test_list_annotation_sessions_global_vs_version_scoped(logged_in, requests_mock):
    """dataset_id+version이 다 있으면 버전 스코프 경로, 아니면 전역 경로."""
    g = requests_mock.get(f"{NEXUS}/annotation-sessions", json=[])
    v = requests_mock.get(f"{NEXUS}/datasets/d1/versions/v0/annotation-sessions", json=[])

    logged_in.list_annotation_sessions(status="all", mine=True)
    assert g.called
    assert g.last_request.qs["status"] == ["all"]
    assert g.last_request.qs["mine"] == ["true"]

    logged_in.list_annotation_sessions(dataset_id="d1", version="v0")
    assert v.called


def test_close_annotation_session_force_is_a_query_param(logged_in, requests_mock):
    m = requests_mock.post(f"{NEXUS}/annotation-sessions/s1/close", json={"status": "closed"})
    logged_in.close_annotation_session("s1")
    assert "force" not in m.last_request.qs
    logged_in.close_annotation_session("s1", force=True)
    assert m.last_request.qs["force"] == ["true"]


def test_session_wrapper_waits_until_open(logged_in, requests_mock):
    """생성은 비동기다 — creating 동안 폴링하다 open이 되면 돌려준다."""
    from nexus.dataset import AnnotationSession

    requests_mock.get(
        f"{NEXUS}/annotation-sessions/s1",
        [
            {"json": {"session_id": "s1", "status": "creating", "dataset_id": "d1"}},
            {"json": {"session_id": "s1", "status": "open", "dataset_id": "d1",
                      "cvat_url": "http://cvat/tasks/5"}},
        ],
    )
    ses = AnnotationSession(logged_in, {"session_id": "s1", "status": "creating", "dataset_id": "d1"})
    assert ses.url is None
    ses.wait_open(interval=0, verbose=False)
    assert ses.status == "open"
    assert ses.url == "http://cvat/tasks/5"


def test_session_wrapper_raises_with_reason_when_preparation_fails(logged_in, requests_mock):
    """failed는 조용히 넘어가면 안 된다 — 사유를 예외 메시지에 담는다."""
    from nexus.dataset import AnnotationSession

    requests_mock.get(
        f"{NEXUS}/annotation-sessions/s1",
        json={"session_id": "s1", "status": "failed", "dataset_id": "d1",
              "error": "편집 가능한 라벨이 없습니다"},
    )
    ses = AnnotationSession(logged_in, {"session_id": "s1", "status": "creating", "dataset_id": "d1"})
    with pytest.raises(NexusError) as exc:
        ses.wait_open(interval=0, verbose=False)
    assert "편집 가능한 라벨이 없습니다" in str(exc.value)


def test_session_wrapper_times_out_with_actionable_message(logged_in, requests_mock):
    from nexus.dataset import AnnotationSession

    requests_mock.get(
        f"{NEXUS}/annotation-sessions/s1",
        json={"session_id": "s1", "status": "creating", "dataset_id": "d1"},
    )
    ses = AnnotationSession(logged_in, {"session_id": "s1", "status": "creating", "dataset_id": "d1"})
    with pytest.raises(NexusError) as exc:
        ses.wait_open(timeout=0, interval=0, verbose=False)
    # 서버는 계속 준비 중일 수 있으므로 다시 조회할 방법을 알려줘야 한다.
    assert "s1" in str(exc.value)


def test_session_pull_returns_summary_and_refreshes(logged_in, requests_mock):
    from nexus.dataset import AnnotationSession

    requests_mock.post(
        f"{NEXUS}/annotation-sessions/s1/import",
        json={"updated_samples": 1, "created_instances": 0, "removed_instances": 0,
              "updated_components": 2, "deleted_components": 0, "warnings": []},
    )
    requests_mock.get(
        f"{NEXUS}/annotation-sessions/s1",
        json={"session_id": "s1", "status": "open", "dataset_id": "d1",
              "has_unimported_changes": False},
    )
    ses = AnnotationSession(logged_in, {"session_id": "s1", "status": "open", "dataset_id": "d1"})
    out = ses.pull()
    assert out["updated_samples"] == 1
    # pull 후 상태가 갱신돼야 "아직 안 가져온 게 있나"를 바로 볼 수 있다.
    assert ses.has_unimported_changes is False


def test_has_unimported_changes_is_none_when_unknown(logged_in, requests_mock):
    """None은 '없음'이 아니라 '모름'이다 — 목록으로 만든 객체는 항상 None."""
    from nexus.dataset import AnnotationSession

    ses = AnnotationSession(logged_in, {"session_id": "s1", "status": "open", "dataset_id": "d1"})
    assert ses.has_unimported_changes is None


def test_annotation_session_can_be_resumed_by_id(logged_in, requests_mock):
    """세션은 프로세스와 무관하게 서버에 남는다 — id만으로 다시 잡을 수 있어야 한다."""
    import nexus as nx

    requests_mock.get(
        f"{NEXUS}/annotation-sessions/s9",
        json={"session_id": "s9", "status": "open", "dataset_id": "d1",
              "cvat_url": "http://cvat/tasks/9"},
    )
    ses = nx.annotation_session("s9", client=logged_in)
    assert ses.session_id == "s9"
    assert ses.url == "http://cvat/tasks/9"


# ── 토큰 만료 시 자동 재로그인 ──────────────────────────────────────────────
# 토큰 수명이 24시간이라, 재로그인이 없으면 오래 도는 프로세스·노트북은 하루 뒤부터
# 모든 호출이 401로 죽고 스크립트를 재시작하는 것 말고 방법이 없다.

def test_expired_token_triggers_relogin_and_retry(requests_mock):
    requests_mock.post(
        f"{NEXUS}/api/v1/auth/login",
        [{"json": {"token": "old", "user_id": 1, "email": "u@x.com"}},
         {"json": {"token": "new", "user_id": 1, "email": "u@x.com"}}],
    )
    # 첫 호출은 만료로 401, 재로그인 뒤 두 번째는 성공.
    requests_mock.get(
        f"{NEXUS}/datasets",
        [{"status_code": 401, "json": {"error": "unauthorized"}},
         {"json": [{"dataset_id": "d1"}]}],
    )

    client = NexusClient(NEXUS, "u@x.com", "pass")
    assert client.list_datasets() == [{"dataset_id": "d1"}]
    assert client._token == "new"
    assert client._session.headers["Authorization"] == "Bearer new"


def test_relogin_is_attempted_only_once(requests_mock):
    # 서버가 계속 401을 주면(예: jwt.secret 불일치) 무한 재시도에 빠지면 안 된다.
    requests_mock.post(f"{NEXUS}/api/v1/auth/login",
                       json={"token": "tok", "user_id": 1, "email": "u@x.com"})
    requests_mock.get(f"{NEXUS}/datasets", status_code=401,
                      json={"error": "unauthorized"})

    client = NexusClient(NEXUS, "u@x.com", "pass")
    with pytest.raises(NexusError) as exc:
        client.list_datasets()
    assert exc.value.status_code == 401
    # 최초 로그인 1 + 재로그인 1 = 2. GET은 최초 1 + 재시도 1 = 2.
    calls = [h.path for h in requests_mock.request_history]
    assert calls.count("/api/v1/auth/login") == 2
    assert calls.count("/datasets") == 2


def test_relogin_failure_surfaces_the_original_401(requests_mock):
    # 비밀번호가 다른 곳에서 바뀌었다면 재로그인도 실패한다. 그때 사용자에게 보여야 할
    # 것은 재로그인 실패가 아니라 원래 요청의 401이다.
    requests_mock.post(
        f"{NEXUS}/api/v1/auth/login",
        [{"json": {"token": "tok", "user_id": 1, "email": "u@x.com"}},
         {"status_code": 401, "json": {"error": "invalid credentials"}}],
    )
    requests_mock.get(f"{NEXUS}/datasets", status_code=401,
                      json={"error": "unauthorized"})

    client = NexusClient(NEXUS, "u@x.com", "pass")
    with pytest.raises(NexusError) as exc:
        client.list_datasets()
    assert exc.value.status_code == 401
    assert not isinstance(exc.value, NexusAuthError)


def test_non_401_errors_do_not_trigger_relogin(requests_mock):
    # 403은 세션 문제가 아니라 소유권 문제다 — 재로그인해도 풀리지 않는다.
    requests_mock.post(f"{NEXUS}/api/v1/auth/login",
                       json={"token": "tok", "user_id": 1, "email": "u@x.com"})
    requests_mock.get(f"{NEXUS}/datasets", status_code=403,
                      json={"error": "forbidden"})

    client = NexusClient(NEXUS, "u@x.com", "pass")
    with pytest.raises(NexusError) as exc:
        client.list_datasets()
    assert exc.value.status_code == 403
    calls = [h.path for h in requests_mock.request_history]
    assert calls.count("/api/v1/auth/login") == 1


def test_change_password_updates_stored_credential(requests_mock):
    # 갱신하지 않으면 토큰 만료 시점(최대 24시간 뒤)에 옛 비밀번호로 재로그인해 실패한다.
    requests_mock.post(f"{NEXUS}/api/v1/auth/login",
                       json={"token": "tok", "user_id": 1, "email": "u@x.com"})
    requests_mock.post(f"{NEXUS}/api/v1/auth/password", status_code=204)

    client = NexusClient(NEXUS, "u@x.com", "old-pass")
    client.change_password("old-pass", "new-pass")
    assert client._password == "new-pass"


# ── 만료 전 선제 갱신 (POST /api/v1/auth/refresh) ──────────────────────────
# 만료된 뒤에는 갱신할 수 없으므로(서버가 401), 재로그인을 대체하는 게 아니라 그 앞을 막는다.

def _jwt(exp: int) -> str:
    """서명은 아무거나. SDK는 exp만 읽고 검증은 서버가 한다."""
    import base64, json as _json
    b = lambda d: base64.urlsafe_b64encode(_json.dumps(d).encode()).rstrip(b"=").decode()
    return f"{b({'alg':'HS256'})}.{b({'sub':1,'email':'u@x.com','exp':exp})}.sig"


def test_token_near_expiry_is_refreshed_before_the_request(requests_mock):
    import time
    soon = _jwt(int(time.time()) + 60)      # 1분 뒤 만료 → 여유(5분) 안쪽
    fresh = _jwt(int(time.time()) + 86400)
    requests_mock.post(f"{NEXUS}/api/v1/auth/login", json={"token": soon, "user_id": 1, "email": "u@x.com"})
    requests_mock.post(f"{NEXUS}/api/v1/auth/refresh", json={"token": fresh, "user_id": 1, "email": "u@x.com"})
    requests_mock.get(f"{NEXUS}/datasets", json=[])

    client = NexusClient(NEXUS, "u@x.com", "pass")
    client.list_datasets()

    assert client._token == fresh
    calls = [h.path for h in requests_mock.request_history]
    assert calls.count("/api/v1/auth/refresh") == 1
    # 갱신했으니 재로그인은 없어야 한다 — 로그인은 최초 1회뿐.
    assert calls.count("/api/v1/auth/login") == 1


def test_token_far_from_expiry_is_left_alone(requests_mock):
    import time
    requests_mock.post(f"{NEXUS}/api/v1/auth/login",
                       json={"token": _jwt(int(time.time()) + 86400), "user_id": 1, "email": "u@x.com"})
    requests_mock.get(f"{NEXUS}/datasets", json=[])

    client = NexusClient(NEXUS, "u@x.com", "pass")
    client.list_datasets()
    assert "/api/v1/auth/refresh" not in [h.path for h in requests_mock.request_history]


def test_old_server_without_refresh_is_probed_only_once(requests_mock):
    # SDK 0.1.2가 구서버(< 0.1.1)에서도 그대로 동작해야 한다. 404를 매 요청마다
    # 두드리면 호출 수가 두 배가 된다.
    import time
    soon = _jwt(int(time.time()) + 60)
    requests_mock.post(f"{NEXUS}/api/v1/auth/login", json={"token": soon, "user_id": 1, "email": "u@x.com"})
    requests_mock.post(f"{NEXUS}/api/v1/auth/refresh", status_code=404, text="not found")
    requests_mock.get(f"{NEXUS}/datasets", json=[])

    client = NexusClient(NEXUS, "u@x.com", "pass")
    client.list_datasets()
    client.list_datasets()
    client.list_datasets()

    calls = [h.path for h in requests_mock.request_history]
    assert calls.count("/api/v1/auth/refresh") == 1, "구서버를 반복해서 두드린다"
    assert calls.count("/datasets") == 3


def test_refresh_failure_does_not_break_the_request(requests_mock):
    # 갱신은 부수적인 일이다. 실패했다고 사용자의 요청을 죽이면 안 된다.
    import time
    soon = _jwt(int(time.time()) + 60)
    requests_mock.post(f"{NEXUS}/api/v1/auth/login", json={"token": soon, "user_id": 1, "email": "u@x.com"})
    requests_mock.post(f"{NEXUS}/api/v1/auth/refresh", status_code=500, text="boom")
    requests_mock.get(f"{NEXUS}/datasets", json=[{"dataset_id": "d1"}])

    client = NexusClient(NEXUS, "u@x.com", "pass")
    assert client.list_datasets() == [{"dataset_id": "d1"}]
    assert client._token == soon      # 갱신 실패 → 원래 토큰 유지


def test_unparseable_token_disables_proactive_refresh(requests_mock):
    # exp를 못 읽으면 언제 갱신할지 알 수 없다. 매 요청 갱신하지 말고 그냥 두고,
    # 만료되면 401 재로그인이 받게 한다.
    requests_mock.post(f"{NEXUS}/api/v1/auth/login",
                       json={"token": "not-a-jwt", "user_id": 1, "email": "u@x.com"})
    requests_mock.get(f"{NEXUS}/datasets", json=[])

    client = NexusClient(NEXUS, "u@x.com", "pass")
    assert client._token_exp is None
    client.list_datasets()
    assert "/api/v1/auth/refresh" not in [h.path for h in requests_mock.request_history]


# ── annotation round-trip (get_sample_annotations / delete_version 기본값) ──

def test_get_sample_annotations_gets_correct_path_and_returns_body(logged_in, requests_mock):
    body = {"meta": {"scene": "night"}, "objects": [{"id": "o1", "label": "car"}]}
    m = requests_mock.get(
        f"{NEXUS}/datasets/d1/versions/v1/samples/s1/annotations", json=body
    )
    out = logged_in.get_sample_annotations("d1", "v1", "s1")
    assert m.last_request.method == "GET"
    assert out == body


def test_delete_version_default_sends_delete_cas_false(logged_in, requests_mock):
    # 서버 기본값이 false로 바뀐 이유가 무력화되지 않으려면, SDK가 명시 안 해도
    # 실제로 보내는 값이 "false"여야 한다.
    m = requests_mock.delete(f"{NEXUS}/datasets/d1/versions/v1", json={"deleted": True})
    logged_in.delete_version("d1", "v1", confirm="v1")
    assert m.last_request.qs["delete_cas"] == ["false"]
