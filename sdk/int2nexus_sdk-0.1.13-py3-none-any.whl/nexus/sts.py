"""CAS STS(`AssumeRoleWithWebIdentity`) 임시 자격증명.

설계: `docs/superpowers/specs/2026-09-14-sdk-cas-sts-design.md`.

**명시 인자로만 켜진다.** 환경변수·설정 파일로는 켜지지 않는다 — 도입처가 요청한 것이 「기본
체인에 맡기지 않는 모드」이고, 환경변수를 더하면 `CAS_KEY_ID`/`CAS_SECRET` 과의 우선순위 규칙이
하나 더 생긴다.

**토큰·세션 토큰·secret 은 예외·경고·repr 어디에도 싣지 않는다.** 노트북 출력은 공유되기 쉽다.
"""

from __future__ import annotations

import html
import re
import threading
import time
import warnings
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable

import requests
from requests.adapters import HTTPAdapter

from nexus._types import NexusCasError
from nexus._version import apply_user_agent

# cas `api/sts/mod.rs` 의 MIN/MAX_SESSION_SECS 와 같은 값.
MIN_DURATION_SECS = 900
MAX_DURATION_SECS = 43200

# 남은 수명이 이 값 이하면 새로 받는다. cas 는 남은 수명 900 초 **초과** 세션을 재사용하므로
# 900 초보다 일찍 갱신하면 같은 세션이 돌아온다 — 600 은 그 아래이면서 요청 지연과 300 초
# 이내의 시계 오차를 흡수한다.
REFRESH_WINDOW_SECS = 600.0

# 캐시가 쓸 만할 때 STS 시도 사이의 최소 간격. 클라이언트 시계가 서버보다 300 초 넘게 앞서면
# 창에 들었다고 보는데 서버는 같은 세션을 돌려준다 — 그 반복을 30 초에 한 번으로 묶는다.
MIN_REFRESH_INTERVAL_SECS = 30.0

# 갱신이 실패해도 캐시의 남은 수명이 이보다 크면 캐시를 쓴다. kubelet 교체 직전(토큰 잔여 900 초
# 미만 → `ExpiredToken`)과 cas 의 JWKS 실패 백오프는 잠시 뒤 풀리는 실패다.
FAIL_OPEN_MARGIN_SECS = 60.0

STS_TIMEOUT = (5, 10)
RETRY_BACKOFF_SECS = (0.5, 1.0, 2.0)
RETRY_STATUSES = frozenset({408, 429, 500, 502, 503, 504})

_FIELDS = ("AccessKeyId", "SecretAccessKey", "SessionToken", "Expiration")
_FIELD_RE = {name: re.compile(rf"<{name}>([^<]*)</{name}>") for name in _FIELDS}
_CODE_RE = re.compile(r"<Code>([^<]{1,64})</Code>")
_MESSAGE_RE = re.compile(r"<Message>([^<]{0,500})</Message>")

_STS_CODE_HINTS = {
    "ExpiredToken": (
        "토큰이 만료됐거나 남은 수명이 900초 미만입니다. projected 토큰의 expirationSeconds"
        "(7200 이상 권장)나 IdP 토큰 수명을 확인하십시오"
    ),
    "InvalidIdentityToken": "토큰의 서명·iss·aud 가 cas 의 auth.oidc.issuers 설정과 맞지 않습니다",
    "AccessDenied": "토큰은 유효하지만 (issuer, subject) 매핑이 없거나 템플릿 키가 폐기·만료됐습니다",
    "IDPCommunicationError": "cas 가 IdP 의 JWKS 를 가져오지 못했습니다(재시도 후에도 실패)",
    "ValidationError": "STS 요청 형식이 맞지 않습니다",
}


@dataclass(frozen=True)
class CasSts:
    """STS 모드 설정. `token_file` 과 `token_provider` 중 정확히 하나를 준다.

    `token_file` 은 STS 를 부를 때마다 다시 읽는다(kubelet 이 projected 토큰을 갈아 끼운다).
    `token_provider` 는 STS 를 부를 때마다 호출한다(Keycloak 등 코드가 토큰을 가져오는 경우).
    **토큰의 남은 수명은 900 초 이상이어야 한다** — cas 발급 하한이다.
    """

    token_file: "str | None" = None
    token_provider: "Callable[[], str] | None" = None
    duration_seconds: int = 3600

    def __post_init__(self) -> None:
        if (self.token_file is None) == (self.token_provider is None):
            raise ValueError("CasSts 는 token_file 과 token_provider 중 정확히 하나를 받습니다")
        if self.token_file is not None and not str(self.token_file).strip():
            raise ValueError("CasSts.token_file 이 비어 있습니다")
        if self.token_provider is not None and not callable(self.token_provider):
            raise ValueError("CasSts.token_provider 는 호출할 수 있는 값이어야 합니다")
        d = self.duration_seconds
        if isinstance(d, bool) or not isinstance(d, int) or not MIN_DURATION_SECS <= d <= MAX_DURATION_SECS:
            raise ValueError(
                f"CasSts.duration_seconds 는 {MIN_DURATION_SECS}~{MAX_DURATION_SECS} 정수여야 "
                f"합니다 (받은 값: {d!r})"
            )

    def __repr__(self) -> str:
        source = (
            f"token_file={self.token_file!r}"
            if self.token_file is not None
            else "token_provider=<callable>"
        )
        return f"CasSts({source}, duration_seconds={self.duration_seconds})"


@dataclass(frozen=True)
class Credentials:
    """임시 자격증명 한 벌. 불변이라 스레드가 섞인 조합을 볼 수 없다."""

    key_id: str
    secret: str = field(repr=False)
    session_token: str = field(repr=False)
    expires_at: float


def parse_expiration(s: str) -> float:
    """RFC 3339 → epoch 초. `Z` 를 `+00:00` 으로 바꾼다(3.10 의 `fromisoformat` 은 `Z` 를 모른다)."""
    v = s.strip()
    if v[-1:] in ("Z", "z"):
        v = v[:-1] + "+00:00"
    dt = datetime.fromisoformat(v)
    if dt.tzinfo is None:
        raise ValueError("시간대가 없는 Expiration")
    return dt.timestamp()


def parse_success(body: str) -> Credentials:
    """2xx 본문에서 자격증명을 뽑는다. **실패해도 본문은 에러에 싣지 않는다** — secret 이 들어 있다.

    정규식으로 네 요소만 집는다 — `cas.py::_s3_error_code` 와 같은 이유로 외부 XML 파서 경로를
    늘리지 않는다. cas `xml_escape` 가 쓰는 엔티티는 `html.unescape` 로 되돌린다.
    """
    values: dict[str, str] = {}
    for name, rx in _FIELD_RE.items():
        m = rx.search(body)
        if m is None or not m.group(1).strip():
            raise NexusCasError(
                "STS 응답에서 자격증명을 읽지 못했습니다 — AssumeRoleWithWebIdentity 응답 형식이 아닙니다"
            )
        values[name] = html.unescape(m.group(1).strip())
    try:
        expires_at = parse_expiration(values["Expiration"])
    except ValueError:
        raise NexusCasError("STS 응답의 Expiration 을 읽지 못했습니다") from None
    return Credentials(
        key_id=values["AccessKeyId"],
        secret=values["SecretAccessKey"],
        session_token=values["SessionToken"],
        expires_at=expires_at,
    )


def error_message(status: int, body: str) -> str:
    """비 2xx STS 응답을 사용자가 할 일로 바꾼다.

    **루트가 `<ErrorResponse>` 일 때만 STS 코드로 읽는다.** STS 가 마운트되지 않은 cas 는 같은
    `POST /` 에 S3 형식 `<Error><Code>AccessDenied` 403 을 주는데, 그것을 STS 의 `AccessDenied`
    로 읽으면 "매핑이 없다" 로 엉뚱한 곳을 가리킨다.
    """
    code_m = _CODE_RE.search(body)
    code = code_m.group(1) if code_m else ""
    msg_m = _MESSAGE_RE.search(body)
    message = html.unescape(msg_m.group(1)) if msg_m else ""
    if "<ErrorResponse" in body and code:
        hint = _STS_CODE_HINTS.get(code, "")
        text = f"CAS STS 가 자격증명 발급을 거부했습니다 ({status} {code}: {message})"
        return f"{text} — {hint}" if hint else text
    if status == 403 and "<Error>" in body:
        return (
            f"CAS STS 가 켜져 있지 않습니다 ({status} {code}) — cas 의 auth.oidc.issuers 가 "
            "비어 있으면 POST / 가 STS 로 라우팅되지 않습니다"
        )
    return f"CAS STS 호출 실패 ({status}): {body[:300]}"


def read_token(cfg: CasSts) -> str:
    """STS 에 보낼 토큰을 **지금** 읽는다. 에러 문구에 토큰 값을 싣지 않는다."""
    if cfg.token_file is not None:
        try:
            raw = Path(cfg.token_file).read_text(encoding="utf-8")
        except OSError as e:
            raise NexusCasError(
                f"STS 토큰 파일을 읽지 못했습니다: {cfg.token_file} ({e.__class__.__name__}) — "
                "projected 볼륨의 마운트 경로와 audience 를 확인하십시오"
            ) from None
        token = raw.strip()
        if not token:
            raise NexusCasError(f"STS 토큰 파일이 비어 있습니다: {cfg.token_file}")
        return token
    try:
        token = cfg.token_provider()  # type: ignore[misc]
    except Exception as e:
        # 원 예외는 종류만 싣고 사슬을 끊는다(`from None`) — 문구에 토큰이 들어 있을 수 있고,
        # `__cause__` 로 남기면 노트북 traceback 이 그 문구를 그대로 찍는다.
        raise NexusCasError(
            f"CasSts.token_provider 가 예외를 던졌습니다 ({e.__class__.__name__})"
        ) from None
    if not isinstance(token, str) or not token.strip():
        raise NexusCasError("CasSts.token_provider 가 빈 값이나 문자열이 아닌 값을 돌려줬습니다")
    return token.strip()


class StsCredentials:
    """`CasClient` 가 하나를 소유하는 임시 자격증명 공급자.

    **락은 하나이고 STS 호출을 그 안에서 한다** — 동시에 창에 든 워커 N 개가 STS 를 한 번만
    부르게 하려는 것이다. **기다리는 것은 캐시를 쓸 수 없는 워커뿐이다**(남은 수명 60 초 이하·
    캐시 없음). 그때 최악 소요는 타임아웃 15 초 × 4회 + 백오프 3.5 초 ≈ 64 초다. 캐시가 쓸 만한
    워커는 락이 잡혀 있으면 캐시를 들고 바로 돌아간다.

    STS 전용 세션을 따로 만든다 — 데이터 평면 세션의 어댑터 재시도(연결 오류 재시도)가 여기의
    수동 재시도와 곱해지지 않게 재시도 없는 어댑터를 쓴다.
    """

    def __init__(
        self,
        endpoint: str,
        cfg: CasSts,
        verify: "bool | str" = True,
        *,
        clock: Callable[[], float] = time.time,
        sleep: Callable[[float], None] = time.sleep,
        forced_min_interval: float = 60.0,
    ) -> None:
        self._url = endpoint.rstrip("/") + "/"
        self._cfg = cfg
        self._clock = clock
        self._sleep = sleep
        self._forced_min_interval = forced_min_interval
        session = requests.Session()
        adapter = HTTPAdapter(max_retries=0)
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        apply_user_agent(session)
        session.verify = verify
        self._session = session
        self._lock = threading.Lock()
        self._creds: "Credentials | None" = None
        # 선제 갱신 시도(성공·실패 무관)와 강제 갱신은 **다른 시각**을 기록한다 — 선제 갱신이 강제
        # 갱신 간격을 소모하면 만료 직후의 403 이 복구되지 않는다.
        self._last_attempt_at: "float | None" = None
        self._last_forced_at: "float | None" = None

    def _fresh(self, creds: "Credentials | None", now: float) -> bool:
        return creds is not None and creds.expires_at - now > REFRESH_WINDOW_SECS

    def current(self) -> Credentials:
        """서명에 쓸 자격증명. 스펙 5 절 규칙."""
        creds = self._creds
        now = self._clock()
        if self._fresh(creds, now):
            return creds  # type: ignore[return-value]
        # 캐시가 쓸 만하면 진행 중인 갱신을 기다리지 않는다 — STS 가 응답하지 않으면 한 사이클이
        # 최대 64 초이고, 그동안 쓸 수 있는 자격증명을 두고 워커 전부가 멈춘다.
        if creds is not None and creds.expires_at - now > FAIL_OPEN_MARGIN_SECS:
            if not self._lock.acquire(blocking=False):
                return creds
        else:
            self._lock.acquire()
        try:
            now = self._clock()
            creds = self._creds
            if self._fresh(creds, now):
                return creds  # type: ignore[return-value]
            usable = creds is not None and creds.expires_at - now > FAIL_OPEN_MARGIN_SECS
            if (
                usable
                and self._last_attempt_at is not None
                and now - self._last_attempt_at < MIN_REFRESH_INTERVAL_SECS
            ):
                return creds  # type: ignore[return-value]
            self._last_attempt_at = now
            try:
                fresh = self._assume_role()
            except NexusCasError as e:
                remaining = creds.expires_at - self._clock() if creds is not None else 0.0
                if creds is not None and remaining > FAIL_OPEN_MARGIN_SECS:
                    warnings.warn(
                        f"STS 갱신에 실패해 기존 임시 자격증명을 계속 씁니다"
                        f"(남은 수명 {int(remaining)}초): {e}",
                        stacklevel=2,
                    )
                    return creds
                raise
            self._creds = fresh
            return fresh
        finally:
            self._lock.release()

    def force_refresh(self, failed: Credentials) -> bool:
        """데이터 요청이 403(정책 거부 아님)을 받은 뒤 부른다. 재시도할지 돌려준다.

        **판정 순서가 요점이다**(`cas.py::_retry_with_fresh_credentials` 와 같다):
        ① 다른 스레드가 이미 갈아 끼웠으면 STS 없이 `True` ② 강제 갱신 간격 안이면 `False`
        ③ STS 를 부른다. ② 가 ① 보다 먼저면 워커 여럿이 동시에 403 을 맞았을 때 첫 워커만
        복구되고 나머지는 새 자격증명을 두고 실패한다.

        실패하면 예외를 올린다 — 데이터 403 이 이미 났으므로 캐시 유지 규칙을 적용하지 않는다.
        """
        with self._lock:
            if self._creds is not None and self._creds != failed:
                return True
            now = self._clock()
            if (
                self._last_forced_at is not None
                and now - self._last_forced_at < self._forced_min_interval
            ):
                return False
            self._last_forced_at = now
            self._last_attempt_at = now
            self._creds = self._assume_role()
            return True

    def _assume_role(self) -> Credentials:
        token = read_token(self._cfg)
        data = {
            "Action": "AssumeRoleWithWebIdentity",
            "Version": "2011-06-15",
            "WebIdentityToken": token,
            "DurationSeconds": str(self._cfg.duration_seconds),
        }
        attempts = len(RETRY_BACKOFF_SECS) + 1
        for i in range(attempts):
            last = i == attempts - 1
            try:
                # allow_redirects=False — 3xx 를 따라가면 WebIdentityToken 을 실은 폼을
                # 우리가 모르는 위치로 다시 보내게 된다.
                r = self._session.post(
                    self._url, data=data, timeout=STS_TIMEOUT, allow_redirects=False
                )
            except requests.RequestException as e:
                if last:
                    # str(e)를 함께 싣는다 — requests/urllib3 예외 문구는 URL과 원인만
                    # 담고 폼 바디(토큰)는 절대 담지 않으므로 노출 위험이 없다.
                    raise NexusCasError(
                        f"CAS STS 에 연결하지 못했습니다 ({self._url}, {e.__class__.__name__}: {e})"
                    ) from None
                self._sleep(RETRY_BACKOFF_SECS[i])
                continue
            if r.status_code in RETRY_STATUSES and not last:
                self._sleep(RETRY_BACKOFF_SECS[i])
                continue
            if 200 <= r.status_code < 300:
                return parse_success(r.text)
            raise NexusCasError(error_message(r.status_code, r.text))
        raise AssertionError("unreachable")
