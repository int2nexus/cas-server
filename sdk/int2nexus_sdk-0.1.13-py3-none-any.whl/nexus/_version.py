"""배포 버전과 그것으로 만든 `User-Agent`.

**서버 요청 로그의 `ua` 필드로 SDK 버전을 밖에서 읽기 위한 것이다.** nexus 는 요청 로그
한 줄에 `ua`(User-Agent 앞 48 자)를 남기는데, 지금까지 SDK 는 자기 이름을 적지 않아
그 자리에 `python-requests/<그 버전>` 만 들어갔다. 즉 우리가 이미 찍고 있는 값이 정작
우리 클라이언트만 식별하지 못했다 — 고객이 빌드하지 않는 이미지 안의 SDK 버전을
이미지를 열지 않고 확인할 방법이 그래서 없었다.

`int2nexus-sdk/0.1.12 python-requests/2.32.3` 는 43 자라 48 자 절단에 걸리지 않는다.
**우리 토큰이 앞에 온다** — 뒤에 붙이면 requests 가 버전을 올리는 것만으로 우리 이름이
잘려 나갈 수 있다.

버전은 설치 메타데이터에서 읽는다. `pyproject.toml` 의 값을 여기에 다시 적으면 판을
낼 때마다 두 곳을 고쳐야 하고, 한 곳이 낡으면 로그가 거짓을 말한다.
"""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version as _dist_version

DIST_NAME = "int2nexus-sdk"

try:
    __version__ = _dist_version(DIST_NAME)
except PackageNotFoundError:  # 설치하지 않고 소스 트리에서 import 한 경우
    __version__ = "0+unknown"

USER_AGENT = f"{DIST_NAME}/{__version__}"


def apply_user_agent(session) -> None:
    """세션의 `User-Agent` 앞에 우리 토큰을 붙인다. requests 기본값은 뒤에 남긴다.

    기본값을 지우지 않는 이유는 그 값(`python-requests/<version>`)이 TLS·프록시 문제를
    가릴 때 실제로 쓰이기 때문이다. 붙이는 자리가 둘(nexus 세션·CAS 세션)이라 함수로
    둔다 — 한쪽만 붙는 상태가 되면 "SDK 가 낸 요청인가"를 로그에서 묻는 데 답이 갈린다.

    CAS 쪽 서명은 `host;x-amz-content-sha256;x-amz-date` 만 서명하므로 이 헤더는 SigV4 에
    영향을 주지 않는다.
    """
    default = session.headers.get("User-Agent", "") or ""
    session.headers["User-Agent"] = f"{USER_AGENT} {default}".strip()
