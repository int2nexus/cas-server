from __future__ import annotations
import json
import threading
import warnings
from concurrent.futures import ThreadPoolExecutor, as_completed
from contextlib import contextmanager
from pathlib import Path, PurePosixPath

from tqdm import tqdm


def _warn_if_skipped(sample_id: str, report: dict | None) -> None:
    """annotation 교체 보고서에 스킵이 있으면 사용자에게 보이는 경고를 낸다.

    반환값만 주면 부족하다 — 호출부가 반환값을 보지 않기 때문이다. 교체는 병합이 아니라
    통째 교체라, 스킵된 원소는 **원래 있던 인스턴스가 지워진** 것이다.
    (구버전 서버는 빈 보고서를 주므로 그때는 아무 경고도 내지 않는다 — 저장은 성공했고
    유실을 주장할 근거가 없다.)
    """
    if not isinstance(report, dict) or not report:
        return
    skipped = report.get("skipped") or 0
    if not skipped:
        return
    reasons = report.get("skipped_reasons") or {}
    detail = ", ".join(f"{k}={reasons[k]}" for k in sorted(reasons))
    warnings.warn(
        f"sample {sample_id}: annotation {skipped}건이 저장되지 않았습니다"
        f"({detail}) — 교체이므로 그만큼 기존 인스턴스가 지워졌습니다.",
        RuntimeWarning,
        stacklevel=3,
    )


@contextmanager
def _spinner(desc: str, *, disable: bool = False):
    """블로킹 호출(예: delete) 동안 경과시간 스피너를 별도 스레드로 돌린다."""
    if disable:
        yield
        return
    bar = tqdm(total=0, desc=desc, bar_format="{desc} {elapsed}", leave=False)
    stop = threading.Event()

    def _tick() -> None:
        while not stop.wait(0.25):
            bar.refresh()

    th = threading.Thread(target=_tick, daemon=True)
    th.start()
    try:
        yield
    finally:
        stop.set()
        th.join(timeout=1)
        bar.close()

def _prompt(question: str) -> "str | None":
    """대화형이면 `input()`으로 답을 받고, 입력이 불가능하면 None.

    Jupyter/IPython은 `sys.stdin.isatty()`가 False라도 `input()`이 입력 박스로 동작하므로
    isatty로 판단하지 않는다. 진짜 비대화형(파이프/CI: EOFError, pytest 캡처: OSError)에서만
    None을 돌려준다."""
    try:
        return input(question)
    except (EOFError, OSError):
        return None


def _resolve_delete_cas(delete_cas: "bool | None", what: str) -> bool:
    """delete_cas가 명시되면 그대로, None이면 대화형으로 한 번 묻는다.
    입력이 불가능한 비대화형(스크립트/CI)이면 안전하게 False(CAS 파일 보존)로 둔다."""
    if delete_cas is not None:
        return bool(delete_cas)
    ans = _prompt(
        f"{what} 삭제: 미참조 CAS 파일(이미지/썸네일)도 함께 삭제할까요? "
        f"삭제=y / 보존=N [y/N]: "
    )
    if ans is None:
        return False
    return ans.strip().lower() in ("y", "yes")


from nexus._types import IngestResult, NexusBatchError, NexusCasError, NexusError
from nexus.cas import CasClient
from nexus.client import NexusClient
from nexus.sample import CasRef, FileRef, Sample, _parse_ref


def _sample_label(s: "Sample | None") -> str:
    """진행 로그용 짧은 식별 문자열 — 이미지 키 파일명 > annotation 파일명 순."""
    if s is None:
        return "<sample>"
    key = getattr(getattr(s, "_image_ref", None), "key", None)
    if key:
        return PurePosixPath(key).name
    ann = getattr(s, "annotation", None)
    if isinstance(ann, (str, Path)):
        return Path(str(ann)).name
    return "<sample>"

_DF_EXT_FORMAT = {
    "csv": "csv", "json": "json",
    "jsonl": "jsonl", "ndjson": "jsonl",
    "parquet": "parquet", "pq": "parquet",
}


def _snapshot_coords(url: str, cas_base: str) -> "tuple[str, str]":
    """서버가 준 스냅샷 URL에서 CAS 좌표(bucket, key)만 뽑는다.

    **URL의 호스트는 버린다.** 서버는 이 URL을 자기 `cas.base_url`로 만드는데, 서버가
    클러스터 내부 주소로 CAS에 붙어 있으면 노트북에서는 그 호스트에 닿지 못한다. 요청은
    SDK가 접속한 `cas_url`로 보낸다 — 업로드가 가는 곳과 같은 곳이다.

    URL이 SDK의 base로 시작하면 그 base를 떼고(경로 접두사가 있는 배치), 아니면 URL 경로의
    첫 세그먼트를 bucket으로 본다(서버 `object_url`이 `{base}/{bucket}/{key}`다).
    """
    from urllib.parse import urlparse

    base = cas_base.rstrip("/") + "/"
    rest = url[len(base):] if url.startswith(base) else urlparse(url).path.lstrip("/")
    bucket, _, key = rest.partition("/")
    if not bucket or not key:
        raise NexusError(f"스냅샷 URL에서 CAS bucket/key를 읽을 수 없습니다: {url}")
    return bucket, key


def _write_dataframe(df, path: "str | Path", fmt: "str | None" = None):
    """DataFrame을 파일로 저장. fmt 생략 시 확장자로 추론.
    지원: csv / json / jsonl(ndjson) / parquet. 중첩(dict·list) 셀은 csv에서 JSON 문자열로 직렬화."""
    p = Path(path)
    fmt = (fmt or _DF_EXT_FORMAT.get(p.suffix.lower().lstrip(".")))
    if fmt is None:
        raise ValueError(
            f"format을 지정하거나 확장자(.csv/.json/.jsonl/.parquet)를 사용하세요: {path}"
        )
    fmt = fmt.lower()
    if fmt == "csv":
        out = df.copy()
        for col in out.columns:
            out[col] = out[col].apply(
                lambda v: json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else v
            )
        out.to_csv(p, index=False)
    elif fmt == "json":
        df.to_json(p, orient="records", force_ascii=False, indent=2)
    elif fmt == "jsonl":
        df.to_json(p, orient="records", lines=True, force_ascii=False)
    elif fmt == "parquet":
        try:
            df.to_parquet(p)
        except ImportError as e:
            raise ImportError("parquet 저장은 pyarrow가 필요합니다: pip install pyarrow") from e
    else:
        raise ValueError(f"지원하지 않는 format '{fmt}' (csv/json/jsonl/parquet)")
    return p


def _is_dimension_recorded(value) -> bool:
    """크기 값이 "기록된 것"인지 판단한다 (타입 기반 분류).

    서버의 `src/catalog/sample.rs:is_dimension_recorded`와 동일:
    JSON을 Python 값으로 직렬화한 후 타입에 따라 판정한다.

    - None → blank (False)
    - bool (True/False 모두) → recorded (True, fail-closed)
    - int/float → recorded only if > 0
    - str/list/dict/… → recorded (True, fail-closed: 타입을 모르니까 안 건드린다)

    주의: 이전과 달리 문자열 강제 변환을 하지 않는다.
    JSON `false`는 Python bool False이고, 절대 numeric check를 통과하지 않는다.
    "1920"은 문자열이므로 coerce하지 않고 recorded로 취급한다.
    """
    if value is None:
        return False
    # bool은 int의 서브클래스라 반드시 먼저 체크한다
    if isinstance(value, bool):
        return True  # bool(True/False 모두)은 recorded (fail-closed)
    # 숫자 타입: > 0이면 recorded
    if isinstance(value, (int, float)):
        return value > 0
    # 그 외 모든 타입(str, list, dict, …): recorded (fail-closed)
    return True


def _dims_already_match(before, width: int, height: int) -> bool:
    """기록되어 있던 값이 실측값과 같은가 — 같으면 write를 만들지 않는다.

    `before`가 `None`(기록 없음)이면 당연히 다르다. 기록이 있어도 **양쪽 축이 모두 진짜
    숫자이고 실측값과 같을 때만** 같다고 본다. `bool`을 숫자에서 제외하는 이유는 Python에서
    `True == 1`이기 때문이다 — 그대로 두면 `meta.width`가 `true`인 샘플이 폭 1px 이미지와
    같은 값으로 판정되어 영영 보정 대상에서 빠진다.

    `1920.0 == 1920`은 같다고 본다. 이건 표현 차이지 잘못된 값이 아니라, 고쳐 봐야 같은 값을
    다시 쓰는 write만 늘어난다.
    """
    if before is None:
        return False
    for current, measured in zip(before, (width, height)):
        if isinstance(current, bool) or not isinstance(current, (int, float)):
            return False
        if current != measured:
            return False
    return True


def _print_dim_changes(changes: "list[dict]", limit: int = 20) -> None:
    """dry-run 변경 목록을 보여준다.

    개수만 찍지 않는 이유가 이 기능의 안전장치 전부다. overwrite 모드에는 sealed 게이트가
    없으므로, 쓰기 전에 사람이 보는 이 목록이 "probe가 엉뚱한 객체를 재고 있다"를 잡는
    유일한 자리다.
    """
    if not changes:
        return
    for c in changes[:limit]:
        before = "(없음)" if c["from"] is None else f"{c['from'][0]}x{c['from'][1]}"
        print(f"  {c['sample_id']}: {before} -> {c['to'][0]}x{c['to'][1]}")
    if len(changes) > limit:
        print(f"  ... 외 {len(changes) - limit}건")


class Dataset:
    def __init__(
        self,
        client: NexusClient,
        cas: CasClient,
        dataset_id: str,
        name: str,
        version: str,
    ) -> None:
        self._client = client
        self._cas = cas
        self._dataset_id = dataset_id
        self._name = name
        self._version = version
        self._queue: list[Sample] = []

    @property
    def dataset_id(self) -> str:
        return self._dataset_id

    @property
    def version(self) -> str:
        return self._version

    @classmethod
    def load_or_create(
        cls,
        name: str,
        version: str,
        tags: list[str] | None = None,
        description: str | None = None,
        *,
        fork_from: str | None = None,
        sample_ids: list[str] | None = None,
        client: NexusClient | None = None,
        cas: CasClient | None = None,
    ) -> "Dataset":
        """dataset을 이름으로 찾거나 만들고, 없으면 version을 생성해 Dataset 핸들 반환.
        `fork_from`: 그 버전 전량 fork. `fork_from`+`sample_ids`: **필터링된 fork**
        (그 버전 멤버 중 지정 샘플만, 라벨째로) — "이 샘플들만 담은 새 버전" 용도.
        (순수 카탈로그 — bucket/prefix 인자 없음.)"""
        import nexus as _nx

        _client = client
        _cas = cas

        if _client is None or _cas is None:
            if _nx._client is None:
                _nx._auto_connect()
            _client = _client or _nx._client
            _cas = _cas or _nx._cas

        datasets = _client.list_datasets()
        matched = next((d for d in datasets if d["name"] == name), None)
        if matched:
            dataset_id = matched["dataset_id"]
        else:
            dataset_id = _client.create_dataset(
                name, tags=tags, description=description
            )["dataset_id"]

        if not _client.get_version(dataset_id, version):
            # fork_from+sample_ids → 필터링된 fork(그 버전 샘플 중 일부만 라벨째로).
            _client.create_version(
                dataset_id, version, fork_from=fork_from, sample_ids=sample_ids
            )

        return cls(_client, _cas, dataset_id, name, version)

    def link_samples(self, sample_ids: list[str]) -> None:
        """이미 존재하는 sample_id들을 이 버전에 연결. ingest 없이 참조만 추가."""
        self._client.add_sample_ids(self._dataset_id, self._version, sample_ids)

    def update(self, *, name: "str | None" = None, description: "str | None" = None) -> dict:
        """dataset의 name/description을 제공된 것만 수정한다(둘 다 생략하면 no-op). dataset은
        생성 시 이름이 고정되고 rename 전용 API가 따로 없었는데, 이 메서드가 그 유일한 경로다
        (참고: 통째로 새 dataset을 원하면 `clone()`).

        name을 바꾸면 이 `Dataset` 핸들의 내부 이름도 함께 갱신한다 — 안 하면 이후 `add`+`flush`가
        **예전 이름으로 ingest**해서 그 이름의 dataset이 새로 생겨버린다(치명적인 함정이라 자동 처리).

        - name이 이미 다른 dataset에 쓰이고 있으면 `NexusError(status_code=409)`.
        - **역할 게이트**: `editor` 이상이면 담당자가 아니어도 가능하다 — `viewer` 는
          `NexusError(status_code=403)`(`Dataset.delete()`와 동일 정책).
        """
        out = self._client.update_dataset(self._dataset_id, name=name, description=description)
        if name is not None:
            self._name = out["name"]
        return out

    def favorite(self) -> None:
        """이 dataset을 내 즐겨찾기에 추가(멱등). `GET /datasets`의 `is_favorite`·`favorite=` 필터에 반영."""
        self._client.add_favorite(self._dataset_id)

    def unfavorite(self) -> None:
        """이 dataset을 내 즐겨찾기에서 해제(멱등)."""
        self._client.remove_favorite(self._dataset_id)

    def sample_history(self, sample_id: str) -> dict:
        """이 dataset에서 한 샘플의 **버전별 annotation 이력**(그 샘플이 든 버전만, 오래된→최신).
        반환: `{sample_id, dataset_id, versions:[{version, status, parent_version, created_at, annotation}]}`."""
        return self._client.sample_history(self._dataset_id, sample_id)

    def diff(self, against: "str | None" = None) -> dict:
        """이 버전 vs base(`against`, 없으면 `parent_version`)의 annotation/멤버십 diff.
        반환: `{base, target, summary{samples, instances, labels[]}, changed_samples{count, sample_ids},
        base_audit{created_by, updated_by, updated_at}, target_audit{...}}`.
        `against` 없고 parent_version도 없으면 400."""
        return self._client.version_diff(self._dataset_id, self._version, against=against)

    # ── CVAT annotation 세션 ────────────────────────────────────────────────
    def create_annotation_session(
        self,
        sample_ids: list[str],
        *,
        groups: "list[str] | None" = None,
        extra_labels: "list[dict] | None" = None,
        wait: bool = True,
        timeout: float = 600.0,
    ) -> "AnnotationSession":
        """이 버전의 샘플들을 CVAT으로 보내 편집 세션을 연다(draft 전용, sealed면 409).

        ``sample_ids``는 필터가 아니라 **목록**이다 — ``ds.samples()``나 explorer로 고른
        결과를 그대로 넘기면 된다.

        ``extra_labels``는 데이터에 아직 없는 라벨을 CVAT에 만들어 준다. 없으면 작업자가
        기존에 관측된 라벨로만 그릴 수 있다:
        ``[{"group": "det", "label": "Face", "components": ["bounding_box"]}]``

        ``wait=True``(기본)면 ``open``이 될 때까지 기다린 뒤 돌려준다 — 반환 즉시
        ``session.url``을 작업자에게 넘길 수 있다. ``wait=False``면 ``creating`` 상태로
        바로 받고 나중에 :meth:`AnnotationSession.wait_open` 을 부른다.
        """
        d = self._client.create_annotation_session(
            self._dataset_id, self._version, sample_ids,
            groups=groups, extra_labels=extra_labels,
        )
        ses = AnnotationSession(self._client, d)
        return ses.wait_open(timeout=timeout) if wait else ses

    def annotation_sessions(self, *, status: "str | None" = None) -> "list[AnnotationSession]":
        """이 (dataset, version)의 세션 목록. 기본은 진행 중인 것만(``active``) —
        이력까지 보려면 ``status="all"``."""
        rows = self._client.list_annotation_sessions(
            dataset_id=self._dataset_id, version=self._version, status=status
        )
        return [AnnotationSession(self._client, r) for r in rows]

    def create_subset(self, name: str, filter: dict) -> "Subset":
        """이 버전에 **서브셋**(저장된 explorer 필터) 생성. `filter`는 explorer 바디 형태
        (`meta`/`annotation`/`tags`/`split`). 인증 필요, 이름 중복 시 409."""
        d = self._client.create_subset(self._dataset_id, self._version, name, filter)
        return Subset(self, d)

    def list_subsets(self) -> "list[Subset]":
        """이 버전의 서브셋 목록."""
        return [
            Subset(self, d)
            for d in self._client.list_subsets(self._dataset_id, self._version)
        ]

    def unlink_samples(self, sample_ids: list[str]) -> dict:
        """여러 sample을 이 버전에서 **링크 해제**(sample·데이터는 유지 — 다른 버전엔 그대로).
        반환: `{"removed": n}`(실제 해제된 링크 수). sealed 버전이면 409."""
        return self._client.remove_sample_ids(self._dataset_id, self._version, sample_ids)

    def import_samples(
        self, source_dataset_id: str, source_version: str, sample_ids: list[str]
    ) -> dict:
        """다른 dataset(`source_dataset_id`/`source_version`)의 sample들을 **이 버전으로 복사**해온다
        (크로스 데이터셋 재사용 — sample은 이제 dataset 범위 객체라 직접 링크는 불가, 이 방식이 유일한 경로).
        asset은 재사용(재업로드 없음)하지만 sample/annotation은 독립 복제 — 이후 이 버전에서 수정해도
        source에 영향 없음. 반환: `{"imported": [{"source_sample_id", "sample_id"}, ...]}`."""
        return self._client.import_samples(
            self._dataset_id, self._version, source_dataset_id, source_version, sample_ids
        )

    def fork(
        self,
        new_version: str,
        *,
        sample_ids: "list[str] | None" = None,
        group_key: str | None = None,
        label: str | None = None,
        confidence_min: float | None = None,
        confidence_max: float | None = None,
        track_id: int | None = None,
        split: str | None = None,
        tags: "list[str] | None" = None,
        exclude_tags: "list[str] | None" = None,
        meta: dict | None = None,
    ) -> "Dataset":
        """이 버전을 조건에 맞는 샘플만 담아 **같은 dataset의 새 버전**으로 만든다(필터링된 fork).
        필터를 하나도 안 주면 이 버전 전체를 그대로 fork한다(`load_or_create(fork_from=)`와 동일).

        필터는 `samples()`와 같은 의미 — `sample_ids`는 다른 필터와 AND, `group_key`/`label`/
        `confidence_min`/`confidence_max`/`track_id`는 **같은 instance**가 모두 만족해야 하는
        단일 annotation 조건. 내부적으로 `samples()`(필터가 있으면 전체 자동 수집)로 매칭되는
        sample_id를 모은 뒤 `fork_from=`+`sample_ids=`로 새 버전을 만든다. 매칭이 0개면 `ValueError`.

        **다른 dataset**으로 옮기고 싶으면, 먼저 이 메서드로 필터링된 버전을 만들고 그 결과에
        `clone(new_name, new_version)`을 이어서 부르면 된다(필터링된 버전 전체를 복제하는 방식).
        """
        has_filter = any([
            sample_ids, group_key, label,
            confidence_min is not None, confidence_max is not None,
            track_id is not None, split, tags, exclude_tags, meta,
        ])
        ids: "list[str] | None" = None
        if has_filter:
            ids = [
                s["sample_id"]
                for s in self.samples(
                    sample_ids=sample_ids, group_key=group_key, label=label,
                    confidence_min=confidence_min, confidence_max=confidence_max,
                    track_id=track_id, split=split, tags=tags,
                    exclude_tags=exclude_tags, meta=meta,
                    include_annotations=False,
                )
            ]
            if not ids:
                raise ValueError("필터에 매칭되는 샘플이 없습니다.")
        return Dataset.load_or_create(
            self._name, new_version,
            fork_from=self._version, sample_ids=ids,
            client=self._client, cas=self._cas,
        )

    def clone(
        self, new_name: str, new_version: str, *,
        batch_size: int = 256, verbose: bool = True,
    ) -> "Dataset":
        """이 (dataset, version)을 새 dataset의 새 버전으로 **완전히 복제**한다(독립 복제 —
        이후 어느 쪽을 수정해도 서로 영향 없음). dataset 이름을 바꾸는 API가 따로 없어서,
        새 이름으로 다시 만들고 싶을 때의 우회로로도 쓸 수 있다.

        - 원본 dataset의 `tags`/`description`을 그대로 복사해 새 dataset을 만든다(없으면 생성 —
          `load_or_create`와 동일하게 멱등, 이미 있으면 재사용).
        - 새 버전은 **항상 draft**로 시작한다(원본이 sealed여도 복제본은 draft — 바로 이어서
          patch/추가 가능).
        - 내부적으로 `import_samples`를 `batch_size`만큼 청크로 나눠 호출한다(대량 데이터셋
          대비, `flush()`와 동일한 관례).
        - **멱등하지 않다** — 같은 대상에 두 번 부르면 `flush()`를 두 번 부르는 것처럼 샘플이
          중복 복사된다.
        """
        src = self._client.get_dataset(self._dataset_id) or {}
        new_ds = Dataset.load_or_create(
            new_name, new_version,
            tags=src.get("tags"), description=src.get("description"),
            client=self._client, cas=self._cas,
        )
        sample_ids = [s["sample_id"] for s in self.list_samples()]
        for i in tqdm(
            range(0, len(sample_ids), batch_size),
            desc="Cloning", disable=not verbose,
        ):
            chunk = sample_ids[i : i + batch_size]
            new_ds.import_samples(self._dataset_id, self._version, chunk)
        return new_ds

    def list_samples(
        self,
        *,
        split: str | None = None,
        page_size: int = 1000,
        max_samples: int | None = None,
    ) -> list[dict]:
        """이 dataset/version에 포함된 샘플 목록을 모두 가져온다 (cursor 페이지네이션 자동).

        각 항목은 dict로 `sample_id`/`split`/`tags`와 `assets`(`{image: {cas_url, hash_hex,
        size, content_type}, depth: {...}}`)를 담는다. 프론트 전용 `image_url`/`thumbnail_url`은 포함하지 않는다.
        sealed 여부와 무관하게 동작한다(`to_df`와 달리 draft에서도 조회 가능).

        - `split`: 지정 시 해당 split만 (클라이언트 측 필터).
        - `page_size`: 요청당 페이지 크기. `max_samples`: 최대 수집 개수(상한).
        """
        out: list[dict] = []
        cursor = None
        seen: set = set()
        while True:
            page = self._client.get_manifest_samples(
                self._dataset_id, self._version, cursor=cursor, limit=page_size,
            )
            for s in page.get("samples", []):
                if split is not None and s.get("split") != split:
                    continue
                out.append(s)
                if max_samples is not None and len(out) >= max_samples:
                    return out
            cursor = page.get("next_cursor")
            # 끝(falsy)이거나 서버가 전진하지 않는 cursor를 주면 중단 (무한 루프 방지).
            if not cursor or cursor in seen:
                break
            seen.add(cursor)
        return out

    def samples(
        self,
        *,
        sample_ids: "list[str] | None" = None,
        group_key: str | None = None,
        label: str | None = None,
        confidence_min: float | None = None,
        confidence_max: float | None = None,
        track_id: int | None = None,
        split: str | None = None,
        tags: "list[str] | None" = None,
        exclude_tags: "list[str] | None" = None,
        meta: dict | None = None,
        include_annotations: bool = True,
        limit: int | None = None,
        after: str | None = None,
    ) -> list[dict]:
        """이 버전의 샘플을 조회한다(explorer를 감싼 범용 조회). 필터를 하나도 안 주면 버전의
        전체 샘플을 반환. 반환은 `get_sample()`과 같은 평탄 GT dict 리스트
        (`include_annotations=False`면 annotation 없는 경량 코어만).

        - `sample_ids`: 이 sample_id들로만 좁힌다(다른 필터와 AND).
        - `tags`/`exclude_tags`: 각각 "하나라도 가진 것"과 "하나라도 가지면 뺀다"이다. 둘을
          함께 주면 AND(예: `tags=["train"], exclude_tags=["blurry"]`). 태그가 하나도 없는
          샘플은 `exclude_tags`로 빠지지 않는다.
        - `group_key`/`label`/`confidence_min`/`confidence_max`/`track_id` 중 하나라도 주면,
          그 조건을 **모두 만족하는 같은 instance**를 찾는 단일 필터가 된다(예:
          `samples(group_key="det", label="car")` = "det 그룹에 label이 car인 instance가
          있는 샘플"). `split`/`tags`/`meta`는 샘플 자체의 속성으로 별도 필터링된다.
        - `limit`을 **안 주면**(기본) 커서를 자동으로 순회해 매칭되는 전체를 모아서 반환한다.
          `limit`에 숫자를 주면 그 개수만큼 **한 페이지만** 반환하고(자동 페이지네이션 없음),
          `after`(이전 결과의 마지막 `sample_id`)로 호출부가 직접 다음 페이지를 요청해야 한다.

        더 복잡한 조건(component 필터, 여러 instance에 대한 AND 조건 등)이 필요하면
        `self._client.explore_samples(...)`를 직접 쓸 것 — 이 메서드는 흔한 단일 조건 검색용이다.
        """
        annotation_filter: dict = {}
        if group_key is not None:
            annotation_filter["group_key"] = group_key
        if label is not None:
            annotation_filter["label"] = label
        if confidence_min is not None or confidence_max is not None:
            annotation_filter["confidence"] = {"min": confidence_min, "max": confidence_max}
        if track_id is not None:
            annotation_filter["track_id"] = track_id
        annotation = [annotation_filter] if annotation_filter else None

        if limit is not None:
            return self._client.explore_samples(
                self._dataset_id, self._version,
                cursor=after, limit=limit,
                split=split, tags=tags, exclude_tags=exclude_tags,
                meta=meta, annotation=annotation,
                include_annotations=include_annotations, sample_ids=sample_ids,
            )

        page_size = 1000
        out: list[dict] = []
        cursor = after
        while True:
            page = self._client.explore_samples(
                self._dataset_id, self._version,
                cursor=cursor, limit=page_size,
                split=split, tags=tags, exclude_tags=exclude_tags,
                meta=meta, annotation=annotation,
                include_annotations=include_annotations, sample_ids=sample_ids,
            )
            out.extend(page)
            if len(page) < page_size:
                break
            cursor = page[-1]["sample_id"]
        return out

    def patch_annotations(
        self,
        sample_id: "str | dict[str, dict]",
        annotation_data: dict | None = None,
        *,
        workers: int = 8,
        strict: bool = False,
        verbose: bool = True,
    ) -> "None | list[IngestResult]":
        """샘플 annotation을 이 버전 전용으로 교체한다 (CoW — 공유 원본·다른 버전 보존).

        단일/배치를 하나로 처리한다:
        - **단일**: `patch_annotations(sample_id, annotation_data)` → 반환 `None`.
        - **배치**: `patch_annotations({sample_id: annotation_data, ...})` → PUT을 워커로
          **병렬** 처리하고 건당 `IngestResult` 리스트를 반환(`sample_id`/`ok`/`error`).
          (`[(sample_id, annotation_data), ...]` 형태의 시퀀스도 받는다.)

        `strict=True`면 배치 중 실패가 있으면 `NexusBatchError`를 던진다.

        어느 경로든 서버가 **형식이 어긋난 인스턴스를 버렸으면 경고**(`RuntimeWarning`)를
        낸다. 교체는 병합이 아니므로 버려진 만큼 기존 인스턴스가 지워진다. 건별 보고서가
        필요하면 `save_annotation()`을 쓴다(반환값으로 준다).
        """
        if annotation_data is not None:
            # 단일
            report = self._client.patch_annotations(
                self._dataset_id, self._version, sample_id, annotation_data
            )
            _warn_if_skipped(sample_id, report)
            return None

        # 배치: dict 또는 (sample_id, annotation_data) 시퀀스
        items = list(sample_id.items()) if isinstance(sample_id, dict) else [tuple(x) for x in sample_id]

        def _one(sid: str, ann: dict) -> str:
            report = self._client.patch_annotations(self._dataset_id, self._version, sid, ann)
            _warn_if_skipped(sid, report)
            return sid

        results: list[IngestResult] = []
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {pool.submit(_one, sid, ann): sid for sid, ann in items}
            for future in tqdm(
                as_completed(futures), total=len(futures),
                desc="Patching", disable=not verbose,
            ):
                sid = futures[future]
                try:
                    future.result()
                    results.append(IngestResult(ok=True, sample=None, sample_id=sid))
                except Exception as e:
                    results.append(IngestResult(
                        ok=False, sample=None, sample_id=sid, error=str(e),
                        # status_code를 빼면 아래 권한 판정이 성립하지 않는다.
                        status_code=getattr(e, "status_code", None),
                    ))

        # flush와 같은 이유로 **권한 실패는 strict와 무관하게 예외로 올린다.**
        # 401/403은 개별 샘플이 잘못된 게 아니라 이 계정이 이 dataset을 못 고친다는 뜻이라
        # 전건이 같은 이유로 실패한다. 기본값(strict=False)에서 조용히 넘어가면 "N건 실패"만
        # 남기고 정상 종료해, 배치 스크립트가 아무것도 못 고치고 성공한 것처럼 보인다.
        denied = [r for r in results if not r.ok and r.status_code in (401, 403)]
        if denied:
            code = denied[0].status_code
            reason = ("토큰이 없거나 만료되었습니다 — 다시 connect() 하세요"
                      if code == 401 else
                      f"이 계정은 dataset '{self._name}'을 수정할 수 없습니다 — "
                      f"수정에는 역할 'editor' 이상이 필요합니다(담당자일 필요는 없습니다). "
                      f"승인 대기 중인 계정도 'viewer' 로 취급됩니다")
            raise NexusError(
                f"수정 권한이 없어 {len(denied)}건이 거부되었습니다({code}): {reason}",
                status_code=code,
                server_message=denied[0].error,
            )

        if strict:
            failures = [r for r in results if not r.ok]
            if failures:
                raise NexusBatchError(failures)
        return results

    def set_keypoint_info(
        self,
        keypoint_info: dict,
        *,
        filter: "dict | None" = None,
        confirm: "int | bool | None" = None,
    ) -> dict:
        """이 버전의 샘플들에 정적 골격 정의(`meta.keypoint_info`)를 심는다.

        `keypoint_info`는 컴포넌트 키로 색인한다(그룹 키가 아니다):

            ds.set_keypoint_info({
                "BKP_Landmark_Whole_Keypoints": {
                    "labels": ["hip", "right_hip", "right_knee", ...],
                    "edges": [[3, 2, 1, 0, 4, 5, 6], [0, 7, 8, 9, 10], ...],
                },
            })

        `labels`/`edges`는 FiftyOne `fo.KeypointSkeleton`과 같은 모양이라 그대로 옮기면 된다.
        **`edges`의 원소는 쌍이 아니라 경로다** — `[3, 2, 1, 0]`은 3-2, 2-1, 1-0을 잇는
        사슬 하나다. nexus가 이것으로 CVAT skeleton의 연결선을 그린다. 생략하면 연결선 없이
        점만 그려진다(종전 동작).

        **instances를 건드리지 않는다.** 같은 결과를 `get_annotation()` → 고침 →
        `save_annotation()` 왕복으로도 낼 수 있고 그쪽도 정상 경로지만, 그것은 샘플마다 그
        버전의 인스턴스를 통째로 다시 쓴다 — 골격 정의 하나를 바꾸자고 GT 전체를 재작성하는
        것이라 규모가 맞지 않는다.

        **병합이지 교체가 아니다.** 적어 보낸 컴포넌트 키만 덮고, 나머지 키와 `meta`의 다른
        필드(`width`/`height` 등)는 보존한다. 골격을 하나씩 옮기는 중에 앞서 옮긴 것이
        지워지지 않는다. 반대로 **키를 지우는 방법은 없다.**

        **버전은 대상을 고르는 데만 쓰인다.** `samples.meta`는 버전 격리가 없어서 쓴 값은 그
        샘플을 담은 **모든 버전**이 함께 본다. 골격 정의는 버전마다 다를 것이 아니라 이것이
        맞는 동작이다. 같은 이유로 **sealed 버전에서도 된다**(`backfill_dims`와 같은 규율 —
        seal이 박제하는 것은 instances이고 `samples.meta`는 얼리지 않는다).

        모양이 어긋나면 **쓰기 전에** 거부된다(400): 옛 배열 모양(`{"<키>": ["hip", ...]}`),
        빈 `labels`, 문자열이 아닌 이름, 그리고 **관절 수 밖을 가리키는 `edges` 인덱스**.
        마지막이 특히 여기서 걸려야 한다 — CVAT 세션을 만들 때 잡으면 경고 한 줄로
        흘러가고, 그때는 고칠 사람이 화면 앞에 없다.

        - `filter`: explorer 필터. 비우면 이 버전의 전부(정적 정의라 그것이 보통이다).
        - `confirm`: 대상이 10,000건을 넘으면 서버가 요구한다(409). `True`면 **개수를 먼저
          세어 그 값을 넣는다** — 대량 dataset 에 한 번에 심을 때 쓴다. 세는 사이 적재가
          들어와 수가 달라지면 서버가 409 로 막으므로 안전망은 그대로다. 정확한 수를 이미
          아는 자동화는 그 정수를 그대로 넘기면 된다.

        반환: `{"updated": n, "skipped_non_object_meta": n}`. 뒤의 값이 0이 아니면 그
        샘플들의 `meta`가 JSON 객체가 아니라는 뜻이다(덮으면 나머지 meta를 지우게 되므로
        서버가 뺀다).
        """
        n = confirm
        if confirm is True:
            # **개수를 세어서 채운다.** 서버 409 메시지에서 숫자를 뽑아내는 방법도 있지만
            # 그것은 문구가 바뀌는 날 조용히 멈춘다. 여기서 센 값과 실제가 어긋나면
            # (그 사이 적재가 들어오면) 서버가 409 로 막으므로 안전망은 그대로다.
            n, _exact = self._client.count_samples(
                self._dataset_id, self._version, filter, exact=True
            )
        elif isinstance(confirm, bool):
            n = None  # confirm=False 는 "확인 없이" 라는 뜻이다
        return self._client.set_keypoint_info(
            self._dataset_id, self._version, keypoint_info, filter=filter, confirm=n,
        )

    def backfill_dims(
        self,
        *,
        workers: int = 8,
        chunk_size: int = 500,
        overwrite: bool = False,
        dry_run: bool = False,
        verbose: bool = True,
    ) -> dict:
        """이 버전의 샘플에서 `meta.width/height`를 실측값으로 채우거나(기본) 고친다.

        네 단계다: ① 버전의 샘플을 훑어 대상을 고르고, ② image asset의 CAS 좌표를 뽑고,
        ③ `nx.probe`로 객체 앞부분만 받아 크기를 재고, ④ 서버에 청크로 적용한다.

        대상 추림을 서버 필터로 하지 않는 이유는, typed meta 필터가
        `jsonb_typeof(meta->'width') = 'number'` 가드에 걸려 **키가 없는 행을 잡지 못하기**
        때문이다. 그리고 그 "키 없음"이 최근 등록된 샘플들의 상태다. 일회성 보정이라
        전량 스캔을 감수한다.

        `overwrite=False` (기본)
            `meta.width/height`가 비었거나 `null`이거나 0 이하인 샘플만 고른다. 기록된 값은
            서버가 거부하므로 애초에 보내지 않는다.

        `overwrite=True`
            **기록된 값도 실측값으로 교체한다.** ingest 당시 `ann.json`이 들고 있던 선언값이
            애초에 틀렸을 때 쓴다 — 채우기 모드로는 그런 값에 닿을 수 없다.

            대상 추림에서 "이미 기록됨" 스킵이 빠지므로 `image_url`이 있는 **전량을 probe**한다.
            채우기 모드보다 훨씬 오래 걸린다. 그렇게 잰 뒤 **실측값이 기록값과 다른 건만**
            전송한다 — 같은 값을 다시 쓰는 write는 만들지 않는다.

            안전장치는 sealed 검사가 아니라 `dry_run`이다. 잘못된 값의 형태가 정해져 있지
            않으므로 좁은 규칙을 세울 수 없고, 대신 무엇이 어떻게 바뀌는지를 쓰기 전에 보는
            것으로 대신한다. 변경 목록이 전부 같은 비율로 어긋나 있으면 `ann.json` 쪽의
            일관된 실수이고, 제각각이면 probe가 엉뚱한 객체를 재고 있다는 신호다.

        `dry_run=True`면 ③까지 실제로 돌고 ④만 건너뛴다 — "몇 건이 대상이고 그중 몇 건을
        **실제로 잴 수 있는가**"가 실행 전에 알고 싶은 전부라, 재보지 않는 dry-run은 쓸모가 없다.

        한 건의 나쁜 측정값(0 이하)이 배치 전체를 막지 않는다 — 서버는 `width`/`height` 중
        하나라도 1 미만이면 그 청크를 통째로 400으로 거부하므로, 애초에 그런 값을 보내지
        않는다(측정 못한 건으로 집계). 이미 서버에 보낸 앞선 청크의 적용 결과는 그대로 남는다.

        반환: `{scanned, targeted, measured, unchanged, applied, corrected, rejected, changes}`.

        - `unchanged`: 쟀더니 기록값과 같아 보내지 않은 건수(`overwrite=True`에서만 0이 아니다).
        - `corrected`: 적용된 것 중 **기존 값을 덮어쓴** 건수. `overwrite=False`에서는 항상 0이다
          (그 모드는 기록된 축을 구조적으로 못 바꾼다). 나머지(`applied - corrected`)는 빈칸을
          채운 것이다.
        - `changes`: 실제로 보낸 항목의 `{sample_id, from, to}` 목록. `from`은 기록되어 있던
          원래 값(`[width, height]`, 어느 축도 기록되어 있지 않았으면 `None`)이다.
        - `rejected`: 서버가 거부한 항목의 `{sample_id, error}` 리스트.
        """
        from nexus.probe import probe as _probe

        rows = self.samples(include_annotations=False)
        scanned = len(rows)

        # (sample_id, CasRef, 기록되어 있던 원래 값) — 원래 값은 변경 목록과 corrected 집계에 쓴다.
        targets: list[tuple[str, CasRef, "list | None"]] = []
        for r in rows:
            meta = r.get("meta") or {}
            w_recorded = _is_dimension_recorded(meta.get("width"))
            h_recorded = _is_dimension_recorded(meta.get("height"))
            # overwrite 모드는 이 스킵을 하지 않는다 — 고쳐야 할 값이 바로 "기록된 값"이라,
            # 여기서 걸러내면 대상이 하나도 남지 않는다.
            if w_recorded and h_recorded and not overwrite:
                continue  # 이미 기록된 값이 있다 — 서버도 거부할 대상이다
            url = r.get("image_url")
            if not url:
                continue  # image asset이 없으면 잴 수가 없다
            ref = _parse_ref(url)
            if isinstance(ref, CasRef):
                # 한쪽 축만 기록되어 있어도 원래 값을 담는다 — 변경 목록에서 그 축이
                # "(없음)"으로 보이면 무엇이 덮이는지가 정확히 가려진다.
                before = (
                    [meta.get("width"), meta.get("height")]
                    if (w_recorded or h_recorded) else None
                )
                targets.append((r["sample_id"], ref, before))

        empty = {"scanned": scanned, "targeted": 0, "measured": 0, "unchanged": 0,
                 "applied": 0, "corrected": 0, "rejected": [], "changes": []}
        if not targets:
            if verbose:
                print(f"보정 대상 없음 (샘플 {scanned}건 확인)")
            return empty

        probed = _probe([ref for _, ref, _ in targets], cas=self._cas, workers=workers, verbose=verbose)

        items: list[dict] = []
        changes: list[dict] = []
        measured = 0
        unchanged = 0
        for (sid, _, before), ref in zip(targets, probed):
            # width/height가 1 미만이면(측정 실패로 0/음수가 나온 경우 포함) 보내지 않는다 —
            # 서버는 이런 값이 하나라도 섞이면 그 청크 전체를 400으로 거부하므로, 여기서
            # 걸러야 한 건의 나쁜 측정이 나머지 정상 건까지 막지 못한다(측정 못한 건으로 집계).
            if ref.width is None or ref.height is None or ref.width < 1 or ref.height < 1:
                continue
            measured += 1
            # 이미 맞는 값이면 보내지 않는다. overwrite 모드는 전량을 재므로 대부분이 여기 걸린다 —
            # 거르지 않으면 멀쩡한 샘플 수만 건에 의미 없는 UPDATE를 날리게 된다.
            if _dims_already_match(before, ref.width, ref.height):
                unchanged += 1
                continue
            items.append({"sample_id": sid, "width": ref.width, "height": ref.height})
            changes.append({"sample_id": sid, "from": before, "to": [ref.width, ref.height]})

        report = {
            "scanned": scanned,
            "targeted": len(targets),
            "measured": measured,
            "unchanged": unchanged,
            "applied": 0,
            "corrected": 0,
            "rejected": [],
            "changes": changes,
        }
        if dry_run:
            if verbose:
                print(f"[dry-run] 대상 {len(targets)}건 중 {measured}건을 쟀고, "
                      f"{unchanged}건은 이미 맞는 값이라 제외했습니다. "
                      f"바뀔 항목 {len(items)}건 — 쓰기는 하지 않았습니다.")
                _print_dim_changes(changes)
            return report

        # 무엇이 correction이고 무엇이 채우기인지는 보내기 전에만 알 수 있다(서버 응답은
        # sample_id와 ok만 준다). 미리 집합으로 잡아두고 적용된 것만 세어 리포트에 담는다.
        # 채우기 모드에는 correction이 없다 — 그 모드는 기록된 축을 구조적으로 못 바꾼다.
        corrections = (
            {c["sample_id"] for c in changes if c["from"] is not None} if overwrite else set()
        )

        for i in range(0, len(items), chunk_size):
            chunk = items[i:i + chunk_size]
            # 위치(index)로 zip하지 않고 sample_id로 매칭한다 — 응답이 부분적으로 짧아지면
            # (프록시가 body를 자르는 등) zip은 조용히 꼬리를 버려 report가 실제보다
            # 적게 실패한 것처럼(=성공한 것처럼) 보이게 만든다. 보낸 항목 수만큼 반드시
            # 결과를 채워야 rejected가 exit code 판단 근거로 신뢰할 수 있다.
            by_id = {
                r.get("sample_id"): r
                for r in self._client.set_sample_dimensions(chunk, overwrite=overwrite)
            }
            for sent_item in chunk:
                res = by_id.get(sent_item["sample_id"])
                if res is None:
                    report["rejected"].append(
                        {"sample_id": sent_item["sample_id"],
                         "error": "batch 응답에 해당 item 결과 없음"}
                    )
                elif res.get("ok"):
                    report["applied"] += 1
                    if sent_item["sample_id"] in corrections:
                        report["corrected"] += 1
                else:
                    report["rejected"].append(
                        {"sample_id": res.get("sample_id"), "error": res.get("error")}
                    )
        if verbose:
            print(f"보정 완료: {report['applied']}건 적용"
                  f"(기존 값 교체 {report['corrected']}건, 빈칸 채움 "
                  f"{report['applied'] - report['corrected']}건), "
                  f"{len(report['rejected'])}건 거부, 대상 {report['targeted']}건 중 "
                  f"{report['measured']}건 측정, {report['unchanged']}건은 이미 맞는 값")
        return report

    def get_sample(self, sample_id: str) -> dict:
        """이 dataset+version에 속한 샘플의 코어 필드와 annotation을 평탄한 GT dict로 조회한다.

        반환 dict는 코어 필드와 annotation의 group_key 배열을 **같은 root**에 담는다:
          {"sample_id", "split", "tags", "created_at", "meta",
           "image_url", "thumbnail_url",
           "<group_key>": [ {"id", "label", "track_id"?, "confidence"?, ...components} ], ...}

        - annotation은 항상 포함되며, 버전-해소(CoW) instances로 재구성된다.
        - "meta"는 top-level 단일 키(공유 samples.meta, 버전 격리되지 않음).
        - group_key가 코어 키와 충돌하면 코어 필드가 우선한다.
        - asset 원시 참조는 이 응답에 없다 — ds.list_samples() 또는 GET /samples/{id}/assets로 조회.
        버전에 없는 sample → NexusError.
        """
        return self._client.get_sample(self._dataset_id, self._version, sample_id)

    def get_annotation(self, sample_id: str) -> dict:
        """이 버전에서 그 샘플의 annotation만 가져온다(코어 필드 없음).

        반환 형태는 `{"meta": {...}, "<group_key>": [ {...}, ... ], ...}` 이고
        `save_annotation()`의 입력과 **그대로 호환**된다.

        `get_sample()`과 달리 코어 필드(`sample_id`/`split`/`tags`/…)를 섞지 않는다.
        섞으면 코어와 이름이 겹치는 group_key 가 응답에서 사라지고, 그것을 그대로
        저장하면 그 그룹의 인스턴스가 전부 지워진다.
        """
        return self._client.get_sample_annotations(self._dataset_id, self._version, sample_id)

    def save_annotation(self, sample_id: str, annotation: dict) -> dict:
        """`get_annotation()`으로 받은 dict 를 고쳐서 그대로 저장한다.

        **이 버전의 그 샘플 annotation 을 통째로 교체한다.** 일부만 병합하지 않는다 —
        받은 dict 에서 어떤 그룹을 빼고 저장하면 그 그룹은 삭제된다. 그래서 반드시
        `get_annotation()`으로 받은 것을 고쳐 쓰고, 직접 조립한 dict 를 넣지 말 것.

        주의 두 가지:

        - **덮어쓰기 경합.** 받은 뒤 저장하기까지 사이에 다른 곳에서 같은 샘플을 고치면
          그 변경이 사라진다(낙관적 잠금이 없다). 같은 샘플을 여러 곳에서 동시에 고치는
          작업에는 쓰지 말 것.
        - **`meta` 는 버전 격리가 없다.** 이 dict 에 `meta` 가 들어 있으면 그 값이
          `samples.meta` 를 덮어쓰고, 그것은 **모든 버전이 함께 보는 값**이다.
          `get_annotation()` 출력에는 `meta` 가 포함되므로, 왕복만 해도 같은 값이 다시
          써진다. meta 를 건드리고 싶지 않으면 저장 전에 그 키를 빼면 된다.

        sealed 버전에서는 409.

        반환은 서버 보고서다:
        `{"instances": n, "skipped": n,
          "skipped_reasons": {"missing_label", "not_an_object", "group_not_an_array"}}`.
        `skipped`는 **형식이 어긋나 저장되지 않은 원소 수**이고, 교체는 병합이 아니므로
        그만큼 기존 인스턴스가 지워졌다는 뜻이다. 0이 아니면 `RuntimeWarning`도 함께 낸다
        — 반환값을 보지 않는 호출부에서도 유실이 드러나야 하기 때문이다.
        (구버전 서버는 빈 본문을 주므로 그때는 `{}`가 반환되고 경고도 없다.)
        """
        report = self._client.patch_annotations(
            self._dataset_id, self._version, sample_id, annotation
        )
        _warn_if_skipped(sample_id, report)
        return report

    def transfer_owner(self, email: str) -> dict:
        """이 dataset 의 소유권을 다른 계정으로 넘긴다(현재 소유자 전용).

        **넘겨도 이 핸들의 권한은 그대로다**(서버 `0.1.9` 부터). 수정·삭제는 역할이 가르므로
        `editor` 이상이면 계속 된다 — 옮겨 가는 것은 「다시 넘길 자격」 하나다. 계정 삭제도
        소유한 dataset 이 남은 채로 되고, 그 dataset 은 담당자만 풀린다.

        주인이 없는 dataset 에는 쓸 수 없고(403 — superuser 의 관리 조작이다),
        자기 자신에게 넘기는 것도 거부된다(400). `email` 로 가입된 계정이 없으면 404.

        서버 `0.1.6` 부터.
        """
        return self._client.transfer_dataset_owner(self._dataset_id, email)

    def add(self, sample: "Sample | list[Sample]") -> None:
        """샘플을 등록 큐에 추가한다. 단일 `Sample` 또는 `Sample` 리스트 모두 받는다."""
        if isinstance(sample, Sample):
            self._queue.append(sample)
            return
        samples = list(sample)  # 리스트/튜플/제너레이터 허용
        for s in samples:
            if not isinstance(s, Sample):
                raise TypeError(
                    f"add()는 Sample 또는 Sample 리스트를 받습니다 — {type(s).__name__}를 받았습니다."
                )
        self._queue.extend(samples)

    def flush(
        self, workers: int = 4, strict: bool = False, verbose: bool = True,
        batch_size: int = 256, item_log: bool = False,
    ) -> list[IngestResult]:
        """큐를 서버에 적재한다. 2단계 — ① payload 준비(병렬), ② batch ingest(청크).

        진행 표시(`verbose=True`):
        - **Preparing** 바 — payload 준비 진행.
        - **Ingesting** 바 — 실제 적재 진행. postfix로 `ok`/`fail` 누계 + 현재 항목(id/파일명).
        - `item_log=True`면 항목마다 한 줄씩(`✓ <sample_id>  <파일명>` / `✗ <파일명>: <error>`)
          바를 깨지 않고 출력한다(대량 적재 시엔 로그가 많아지니 필요할 때만).
        """
        queue = self._queue[:]
        self._queue.clear()

        results: list[IngestResult] = []
        prepared: list[tuple] = []  # (sample, payload)

        # Phase 1: build payloads in parallel.
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {pool.submit(self._prepare_payload, s): s for s in queue}
            for future in tqdm(
                as_completed(futures), total=len(futures),
                desc="Preparing", disable=not verbose,
            ):
                s = futures[future]
                try:
                    prepared.append((s, future.result()))
                except Exception as e:
                    results.append(IngestResult(
                        ok=False, sample=s, error=str(e),
                        # prepare 단계도 CAS HEAD로 401을 만날 수 있다 — 아래 권한 판정이
                        # 이 필드를 보므로 여기서 빠뜨리면 그 실패만 조용히 넘어간다.
                        status_code=getattr(e, "status_code", None),
                    ))
                    if item_log:
                        tqdm.write(f"  FAIL {_sample_label(s)}: prepare 실패: {e}")

        # Phase 2: batch-ingest prepared payloads in chunks — **청크를 병렬 POST**.
        # 서버 get_or_create_dataset/version이 ON CONFLICT DO NOTHING이라 동시 ingest가 안전.
        # (직렬 POST는 건당 tx의 DB 왕복 지연이 그대로 곱해져 대량 적재의 병목이었다.)
        ok_n = fail_n = 0
        bar = tqdm(total=len(prepared), desc="Ingesting", disable=not verbose)

        def _record(r: IngestResult) -> None:  # 메인 스레드에서만 호출 → 락 불필요
            nonlocal ok_n, fail_n
            results.append(r)
            if r.ok:
                ok_n += 1
                if item_log:
                    tqdm.write(f"  OK {r.sample_id}  {_sample_label(r.sample)}")
            else:
                fail_n += 1
                if item_log:
                    tqdm.write(f"  FAIL {_sample_label(r.sample)}: {r.error}")
            bar.set_postfix(ok=ok_n, fail=fail_n, cur=_sample_label(r.sample), refresh=False)
            bar.update(1)

        def _ingest_chunk(chunk: list) -> list[IngestResult]:  # 워커 스레드: 네트워크만
            payloads = [p for (_, p) in chunk]
            try:
                resp = self._client.ingest_batch(payloads)
                by_index = {r["index"]: r for r in resp.get("results", [])}
            except Exception as e:
                # whole-request failure → every item in this chunk failed
                code = getattr(e, "status_code", None)
                return [IngestResult(ok=False, sample=s, error=str(e), status_code=code)
                        for (s, _) in chunk]
            out: list[IngestResult] = []
            # chunk의 각 항목을 반드시 1개 결과로 매핑 (len(results) == len(prepared) 보장).
            for pos, (s, _) in enumerate(chunk):
                item = by_index.get(pos)
                if item is None:
                    out.append(IngestResult(ok=False, sample=s, error="batch 응답에 해당 item 결과 없음"))
                elif item.get("error"):
                    out.append(IngestResult(ok=False, sample=s, error=item["error"],
                                            status_code=item.get("status")))
                else:
                    out.append(IngestResult(ok=True, sample=s, sample_id=item.get("sample_id")))
            return out

        chunks = [prepared[i:i + batch_size] for i in range(0, len(prepared), batch_size)]
        if chunks:
            with ThreadPoolExecutor(max_workers=workers) as pool:
                for future in as_completed([pool.submit(_ingest_chunk, c) for c in chunks]):
                    for r in future.result():  # 메인 스레드에서 집계 → thread-safe
                        _record(r)

        bar.close()
        if verbose:
            tqdm.write(f"[flush] {ok_n} ok, {fail_n} fail (총 {len(results)})")

        # **권한 실패는 strict와 무관하게 예외로 올린다.**
        # 401/403은 개별 데이터가 잘못된 게 아니라 이 계정이 이 dataset에 쓸 수 없다는 뜻이라,
        # 모든 item이 같은 이유로 실패한다. 기본값(strict=False)에서 조용히 넘어가면
        # "0 ok, N fail"만 찍고 정상 종료해 CI/크론이 아무것도 적재하지 않고 성공한 것처럼 보인다.
        denied = [r for r in results if not r.ok and r.status_code in (401, 403)]
        if denied:
            code = denied[0].status_code
            reason = ("토큰이 없거나 만료되었습니다 — 다시 connect() 하세요"
                      if code == 401 else
                      f"이 계정은 dataset '{self._name}'에 쓸 수 없습니다 — "
                      f"적재에는 역할 'editor' 이상이 필요합니다(담당자일 필요는 없습니다). "
                      f"역할 부여는 관리자가 합니다")
            raise NexusError(
                f"적재 권한이 없어 {len(denied)}건이 거부되었습니다({code}): {reason}",
                status_code=code,
                server_message=denied[0].error,
            )

        if strict:
            failures = [r for r in results if not r.ok]
            if failures:
                raise NexusBatchError(failures)
        return results

    def delete(
        self, *, confirm: "str | bool | None" = None,
        delete_cas: "bool | None" = None, verbose: bool = True,
    ) -> dict:
        """이 **version 하나**를 hard-delete한다. **삭제 후 남은 버전이 0개면 dataset도 함께 삭제.**

        이 version의 override instances·sample 링크·**이 version에만 있던 sample**(+instances/
        assets)을 제거한다. **미참조 CAS object는 `delete_cas`가 참일 때만 함께 제거**한다(아래
        참고 — 기본은 대화형 확인, 비대화형이면 보존). 다른 version/dataset과 공유된 sample은
        보존, sealed 스냅샷 샤드는 GC 안 함.

        **sealed 버전은 삭제할 수 없다**(영구 보존 대상 — 예외 없음, 이 버전이 dataset의 마지막
        버전이라 dataset까지 같이 지워지는 경우도 포함). `NexusError(status_code=409)`.

        - `confirm`: `"<버전 문자열>"` 또는 `True`(=`self._version`). **`None`(기본)이면 대화형으로
          확인**(비대화형이면 에러 — 실수로 삭제 방지).
        - `delete_cas`: `True`/`False`, 또는 `None`이면 대화형 확인(비대화형이면 False=CAS 보존).
        반환: `{dataset_id, version, samples_deleted, cas_objects_deleted, dataset_deleted}`.
        """
        if confirm is True:
            ver = self._version
        elif isinstance(confirm, str) and confirm:
            ver = confirm
        elif confirm is None:
            ans = _prompt(
                f"version '{self._version}' 을 삭제합니다"
                f"(마지막 버전이면 dataset도 함께 삭제). 진행할까요? [y/N]: "
            )
            if ans is None:  # 진짜 비대화형(입력 불가) — 실수 삭제 방지
                raise ValueError(
                    "delete()는 confirm=<버전 문자열> 또는 confirm=True 가 필요합니다(비대화형)"
                )
            if ans.strip().lower() not in ("y", "yes"):
                if verbose:
                    tqdm.write("[delete] 취소됨")
                return {"cancelled": True}
            ver = self._version
        else:
            raise ValueError("confirm은 <버전 문자열> / True / None 이어야 합니다")

        dc = _resolve_delete_cas(delete_cas, f"version '{self._version}'")
        with _spinner(f"[delete] version '{self._version}' 삭제 중", disable=not verbose):
            out = self._client.delete_version(self._dataset_id, self._version, ver, delete_cas=dc)
        if verbose:
            extra = " (+dataset 삭제)" if out.get("dataset_deleted") else ""
            tqdm.write(
                f"[delete] version '{self._version}' 삭제 완료{extra} - "
                f"samples={out.get('samples_deleted')}, "
                f"cas={out.get('cas_objects_deleted')}"
            )
        return out

    def seal(self, *, if_sealed: str = "error") -> dict:
        """이 버전을 **seal**(불변 스냅샷)한다 — 단방향.

        seal 시 서버가 annotation을 NDJSON 샤드로 CAS에 박제하고 manifest hash를 기록한다.
        이후 이 버전엔 ingest/patch/add가 막히고(409), `to_df()`가 읽을 수 있게 된다.

        - `if_sealed="error"`(기본): 이미 sealed면 서버 409를 그대로 전파.
        - `if_sealed="ignore"`: 이미 sealed면 현재 버전 상태를 반환(멱등, 노트북 재실행에 편리).

        반환: sealed DatasetVersion dict.
        """
        import requests

        try:
            return self._client.seal(self._dataset_id, self._version)
        except NexusError as e:
            if if_sealed == "ignore" and e.status_code == 409:
                return self._client.get_version(self._dataset_id, self._version)
            raise

    def to_df(
        self,
        groups: "list[str] | None" = None,
        *,
        path: "str | Path | None" = None,
        format: "str | None" = None,
        chunksize: "int | None" = None,
    ) -> "pd.DataFrame":
        """sealed 버전의 GT annotation 스냅샷(NDJSON)을 그대로 DataFrame으로 로드한다.

        각 행 = NDJSON 한 줄 = ``{sample_id, meta, <group_key>: [instances...], ...}``.
        이미지 경로 등 부가정보는 ``meta``(특히 ``meta.filename`` = 이미지 URL)에 담겨 있다.

        - ``groups=None``: 모든 group_key를 그대로 싣는다(NDJSON 원형).
        - ``groups=[...]``: 지정한 group_key만 싣는다(+ ``sample_id``, ``meta``).
        - ``path=``: 주면 결과를 파일로도 저장한다. ``format`` 생략 시 확장자로 추론
          (``csv`` / ``json`` / ``jsonl``·``ndjson`` / ``parquet``). DataFrame은 그대로 반환.
        - ``chunksize=N``: DataFrame **하나** 대신 ``≤N`` 행 DataFrame들의 **이터레이터**를 반환한다
          (샤드 단위로 지연 다운로드 → 메모리 ≈ 한 청크). 대규모 데이터셋용.
          (``pandas.read_csv(chunksize=)`` 와 동일한 관용구. ``path``와 함께 쓸 수 없다.)
        - **sealed 버전 필요** — annotation 스냅샷은 seal 시 생성된다(없으면 ``NexusError``).
        """
        try:
            import pandas as pd
        except ImportError:
            raise ImportError(
                "pandas is required for to_df(). "
                "Install with: pip install 'nexus-sdk[pandas]'"
            )

        manifest = self._client.get_manifest(self._dataset_id, self._version)
        snapshot = manifest.get("annotation_snapshot")
        if not snapshot or not snapshot.get("cas_url"):
            raise NexusError(
                "to_df()는 sealed 버전이 필요합니다 — annotation 스냅샷이 없습니다. "
                "ds.seal() 후 다시 시도하세요."
            )
        raw = self._fetch_snapshot(
            snapshot["cas_url"], snapshot.get("hash_hex"), "annotation 스냅샷 manifest", timeout=30
        )
        try:
            shard_manifest = json.loads(raw)
        except ValueError as e:
            raise NexusError(
                "annotation 스냅샷 manifest가 JSON이 아닙니다 — CAS가 다른 것을 돌려주고 "
                f"있습니다.\n  URL: {snapshot['cas_url']}\n  받은 내용: {raw[:200]!r}"
            ) from e

        if chunksize is not None:
            if chunksize <= 0:
                raise ValueError("chunksize는 양의 정수여야 합니다.")
            if path is not None:
                raise ValueError(
                    "chunksize와 path는 함께 쓸 수 없습니다 — 청크를 순회하며 직접 저장하세요."
                )
            return self._iter_df_chunks(shard_manifest, groups, chunksize)

        df = pd.DataFrame(list(self._stream_gt(shard_manifest, groups)))
        if path is not None:
            _write_dataframe(df, path, format)
        return df

    def _require_cas(self, what: str) -> None:
        """CAS 클라이언트 없이 만든 핸들(`Dataset(client, None, ...)`)이면 안내로 멈춘다.

        `0.1.12` 까지 `to_df` 는 CAS 클라이언트를 쓰지 않아 이런 핸들로도 동작했다. 가드가
        없으면 `'NoneType' object has no attribute '_base'` 로 죽어 원인을 가리키지 않는다.
        `nx.connect`·`load_or_create` 가 만든 핸들은 자격증명이 없어도 `CasClient` 를 갖는다.
        """
        if self._cas is None:
            raise NexusError(
                f"CAS 클라이언트가 없어 {what}을(를) 받을 수 없습니다 — nx.connect()로 접속하거나 "
                "Dataset.load_or_create(cas=...)에 CasClient를 넘기세요."
            )

    def _fetch_snapshot(
        self, url: str, hash_hex: "str | None", what: str, timeout: float
    ) -> bytes:
        """seal 스냅샷 객체를 CAS에서 받아 seal 때 기록된 해시와 대조한다.

        **서명해서 받는다.** 예전에는 `requests.get(url)`로 익명 GET을 보내, 서명을 요구하는
        CAS에서는 403이 났다 — nexus가 발급하는 자격증명은 역할과 무관하게 `GetObject * *`를
        갖는데도. `CasClient.get`을 지나므로 서명·403 재발급·STS 리다이렉트 거부가 업로드와
        같은 규칙을 따르고, 403 사유(정책 거부/자격증명 만료)도 그쪽이 붙인다.

        실패를 그대로 흘려보내지 않고 원인을 담아 `NexusError`로 올린다 — 스냅샷은 nexus가
        아니라 CAS에서 받으므로 nexus의 에러 모델 밖에서 터진다.

        `hash_hex`가 비어 있으면(해시 없이 기록된 옛 버전) 대조를 건너뛴다.
        """
        import blake3
        import requests as _req

        self._require_cas(what)
        bucket, key = _snapshot_coords(url, self._cas._base)
        requested = f"{self._cas._base}/{bucket}/{key}"
        where = f"\n  URL: {requested}" + (f"\n  서버가 준 URL: {url}" if requested != url else "")
        try:
            data = self._cas.get(bucket, key, timeout=timeout)
        except NexusCasError as e:
            if e.status_code == 404:
                hint = (
                    "객체가 CAS에 없습니다. seal 당시의 CAS와 지금 접속한 CAS가 다르거나"
                    "(cas_url 또는 서버의 cas.base_url 변경), 객체가 지워졌을 수 있습니다."
                )
            else:
                hint = str(e)
            raise NexusError(
                f"{what}을(를) CAS에서 받지 못했습니다({e.status_code}) — {hint}{where}",
                status_code=e.status_code,
                server_message=e.server_message,
            ) from e
        except _req.RequestException as e:
            raise NexusError(
                f"{what}을(를) CAS에서 받지 못했습니다 — 연결할 수 없습니다({e}). "
                f"CAS 주소와 네트워크를 확인하세요.{where}"
            ) from e

        if hash_hex:
            actual = blake3.blake3(data).hexdigest()
            if actual != hash_hex:
                raise NexusError(
                    f"{what}의 해시가 seal 때 기록된 값과 다릅니다 — 받은 객체가 박제된 "
                    f"스냅샷이 아닙니다.\n  기대: {hash_hex}\n  실제: {actual}{where}"
                )
        return data

    def _stream_gt(self, shard_manifest: dict, groups: "list[str] | None"):
        """샤드를 하나씩 다운로드하며 NDJSON 행(dict)을 yield한다. 메모리 = 샤드 1개."""
        for shard in shard_manifest.get("shards", []):
            # manifest는 받아졌는데 샤드가 안 받아지는 경우도 있다(부분 삭제 등) —
            # 여기도 같은 진단을 붙인다.
            data = self._fetch_snapshot(
                shard["url"], shard.get("hash_hex"), "annotation 스냅샷 샤드", timeout=120
            )
            for line in data.decode("utf-8").splitlines():
                line = line.strip()
                if not line:
                    continue
                obj = json.loads(line)
                if groups is not None:
                    obj = {
                        "sample_id": obj.get("sample_id"),
                        "meta": obj.get("meta"),
                        **{g: obj.get(g) for g in groups},
                    }
                yield obj

    def _iter_df_chunks(self, shard_manifest: dict, groups, chunksize: int):
        import pandas as pd

        batch: list[dict] = []
        for obj in self._stream_gt(shard_manifest, groups):
            batch.append(obj)
            if len(batch) >= chunksize:
                yield pd.DataFrame(batch)
                batch = []
        if batch:
            yield pd.DataFrame(batch)

    def _prepare_payload(self, sample: Sample) -> dict:
        ann_spec = self._resolve_annotation(sample._annotation_ref)

        if sample._image_ref is not None:
            image_ref = sample._image_ref
        else:
            ann_src = str(sample._annotation_ref)
            ann_data = ann_spec.get("annotation_data") or {}
            meta = ann_data.get("meta")
            filename = (meta or {}).get("filename")
            if not filename:
                raise NexusCasError(
                    f"[{ann_src}] image 미지정 + annotation meta.filename 없음 — "
                    "Sample(image=ref) 또는 meta.filename(CAS URL)을 지정하세요."
                )
            image_ref = _parse_ref(filename)
            if not isinstance(image_ref, CasRef):
                raise NexusCasError(
                    f"[{ann_src}] meta.filename은 CAS URL이어야 합니다 (s3://·http(s)://). "
                    "로컬 경로는 nx.upload 후 ref를 쓰세요."
                )

        image_spec = self._resolve_asset(image_ref)
        ann_spec = self._ensure_meta(ann_spec, image_ref, image_spec)

        payload: dict = {
            "dataset": self._name,
            "version": self._version,
            "split": sample.split,
            "tags": sample.tags or None,
            "image": image_spec,
            "annotation": ann_spec,
        }
        if sample._asset_refs:
            payload["assets"] = {
                role: self._resolve_asset(ref) for role, ref in sample._asset_refs.items()
            }
        return payload

    def _resolve_asset(self, ref: CasRef) -> dict:
        """CAS ref → ingest asset spec. 리치 CasRef(업로드 출력)는 신뢰, bare는 HEAD."""
        if ref.hash_hex is not None and ref.size is not None and ref.content_type is not None:
            return {
                "bucket": ref.bucket,
                "key": ref.key,
                "size": ref.size,
                "content_type": ref.content_type,
                "logical_name": ref.key.split("/")[-1],
                "hash_hex": ref.hash_hex,
            }
        info = self._cas.head(ref.bucket, ref.key)
        if info is None:
            raise NexusCasError(
                f"CAS object 없음: bucket='{ref.bucket}', key='{ref.key}' — "
                "nx.upload로 먼저 올렸는지 확인하세요."
            )
        return {
            "bucket": ref.bucket,
            "key": ref.key,
            "size": info["size"],
            "content_type": info["content_type"],
            "logical_name": ref.key.split("/")[-1],
            "hash_hex": info.get("hash_hex"),
        }

    def _resolve_annotation(self, ref: "dict | FileRef | None") -> dict:
        """Annotation을 inline JSON dict로 변환. CAS에 업로드하지 않음."""
        if ref is None:
            return {"annotation_data": None}
        if isinstance(ref, dict):
            return {"annotation_data": ref}
        if isinstance(ref, CasRef):
            # 서명해서 받는다 — 익명 GET이면 서명을 요구하는 CAS에서 403이다.
            self._require_cas("annotation")
            return {"annotation_data": json.loads(self._cas.get(ref.bucket, ref.key, timeout=30))}
        path = Path(ref)
        return {"annotation_data": json.loads(path.read_bytes())}

    def _ensure_meta(self, ann_spec: dict, image_ref: "FileRef", image_spec: dict) -> dict:
        """annotation의 meta 처리. 사용자 입력을 신뢰하고 관여하지 않는 것이 원칙이다.

        - meta가 있으면(값이 None이 아니면) **그대로 신뢰** — 어떤 필드도 수정하지 않는다.
        - meta가 없으면 최소 meta만 생성한다: `filename`=실제 CAS URL, `format_version`="1.0.0",
          그리고 `CasRef`에 dims가 있으면 `width`/`height`.

        **dims를 모르면 키를 넣지 않는다.** 0을 적으면 meta.width/height가 facet range와
        히스토그램의 수치 필드라 min:0으로 오염되고, CVAT 정규화 좌표가 0으로 나뉜다.
        키가 없으면 서버 쿼리의 jsonb_typeof 가드가 그 행을 집계에서 조용히 제외한다.
        dims가 필요하면 `nx.upload`(로컬)나 `nx.probe`(CAS)로 ref를 채운 뒤 등록할 것.
        """
        ann_data: dict = ann_spec.get("annotation_data") or {}
        if ann_data.get("meta") is not None:
            return ann_spec  # 사용자가 준 meta를 그대로 사용
        ann_data = dict(ann_data)
        meta: dict = {
            "format_version": "1.0.0",
            "filename": f"{self._cas._base}/{image_spec['bucket']}/{image_spec['key']}",
        }
        w = image_ref.width if isinstance(image_ref, CasRef) else None
        h = image_ref.height if isinstance(image_ref, CasRef) else None
        if w is not None and h is not None:
            meta["width"] = w
            meta["height"] = h
        ann_data["meta"] = meta
        return {"annotation_data": ann_data}

    def __enter__(self) -> "Dataset":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        if exc_type is None:
            self.flush()


class Subset:
    """서브셋 = 저장된 explorer 필터(뷰). ``ds.create_subset()``/``ds.list_subsets()``가 반환.

    version(스냅샷)과 직교하는 슬라이스 축. 재현성은 seal이 담당 — sealed version 위 필터는
    결정적이라 ``to_df()``(sealed 전용)가 재현 export가 된다.

    **다만 그 결정성은 annotation·tags·split 필터에 한한다.** seal이 얼리는 것은 버전의
    샘플 구성과 CoW annotation이고, ``meta``는 그 대상이 아니다 — ``samples.meta``는 샘플당
    하나뿐이라 버전별로 분기되지 않고, sealed version의 meta 조회도 살아 있는 행을 읽는다.
    따라서 ``meta.*``를 조건으로 쓴 서브셋은 sealed version 위에서도 나중에 다른 행을
    돌려줄 수 있다(누군가 그 샘플의 meta를 바꾸면). 재현이 반드시 필요한 슬라이스라면
    ``to_version()``으로 물질화해 스냅샷으로 승격할 것.
    """

    def __init__(self, ds: "Dataset", d: dict) -> None:
        self._ds = ds
        self._client = ds._client
        self._raw = d
        self.subset_id: str = d["subset_id"]
        self.name: str = d["name"]
        self.version: str = d["version"]
        self.filter: dict = d.get("filter_json") or {}

    def __repr__(self) -> str:
        return f"Subset(name={self.name!r}, version={self.version!r}, id={self.subset_id})"

    def samples(
        self, *, include_annotations: "bool | None" = None,
        page_size: int = 1000, max_samples: "int | None" = None,
    ) -> list[dict]:
        """서브셋 필터를 resolve해 샘플을 반환(커서 자동 페이지네이션). explorer와 동일 형식."""
        out: list[dict] = []
        cursor = None
        while True:
            page = self._client.subset_samples(
                self.subset_id, cursor=cursor, limit=page_size,
                include_annotations=include_annotations,
            )
            out.extend(page)
            if len(page) < page_size or (max_samples and len(out) >= max_samples):
                break
            cursor = page[-1]["sample_id"]
        return out[:max_samples] if max_samples else out

    def update(self, *, name: "str | None" = None, filter: "dict | None" = None) -> "Subset":
        """이름/필터 수정(제공한 것만)."""
        self._raw = self._client.update_subset(self.subset_id, name=name, filter=filter)
        self.name = self._raw["name"]
        self.filter = self._raw.get("filter_json") or {}
        return self

    def delete(self) -> None:
        """서브셋 삭제(뷰만 삭제 — 샘플/데이터 무관)."""
        self._client.delete_subset(self.subset_id)

    def to_version(self, version: str) -> "Dataset":
        """서브셋을 **새 버전으로 물질화**(뷰 → 재현 스냅샷). 필터를 resolve한 샘플만 담은
        새 버전을 만들고(필터링된 fork, 라벨은 서브셋 version에서 복제), 그 버전을 가리키는
        Dataset 핸들을 반환한다 — 이어서 patch/추가/seal 가능. 0개 resolve면 에러."""
        ver = self._client.materialize_subset(self.subset_id, version)
        return Dataset(
            self._client, self._ds._cas, self._ds._dataset_id, self._ds._name,
            ver["version"],
        )

    def to_df(self, groups: "list[str] | None" = None):
        """서브셋을 DataFrame으로 (**재현 export**). **sealed version 필요**(재현 정책).

        서브셋 샘플만 resolve해 DataFrame을 만든다 — 버전 전체 NDJSON 샤드를 받지 않는다(Phase 2
        최적화). sealed 버전은 live resolve == 박제 스냅샷이라 결과 동일. `ds.to_df`와 같은 shape
        (`sample_id`/`meta`/`<group_key>`)로 맞춘다.
        """
        import pandas as pd

        ver = self._client.get_version(self._ds._dataset_id, self.version)
        if not ver or ver.get("status") != "sealed":
            raise NexusError(
                f"subset.to_df()는 sealed version에서만 가능합니다(재현 export). "
                f"'{self.version}'를 seal 후 사용하세요."
            )
        rows = self.samples(include_annotations=True)   # 서브셋 샘플만 (평탄 GT)
        df = pd.DataFrame(rows)
        # ds.to_df와 동일 shape: 스냅샷 컬럼(sample_id, meta, <group_key>)만 — 프론트/코어 필드 제거.
        drop = {"split", "tags", "created_at", "image_url", "thumbnail_url"}
        df = df[[c for c in df.columns if c not in drop]]
        if groups is not None:
            keep = ["sample_id", "meta", *groups]
            df = df[[c for c in keep if c in df.columns]]
        return df.reset_index(drop=True)


class AnnotationSession:
    """CVAT 편집 세션. ``ds.create_annotation_session()`` / ``nx.annotation_sessions()``가 반환.

    수명주기는 ``creating`` → ``open`` → ``closed``(또는 ``failed``)이고, **생성은 비동기**다 —
    서버가 CVAT project/task를 만들고 이미지를 내려받는 데 수백 장이면 몇 분이 걸린다.
    그래서 생성 직후에는 ``url``이 ``None``이며 :meth:`wait_open` 으로 기다린다.

    반영(:meth:`pull`)은 **몇 번이든 반복해도 안전**하다(멱등). 작업자가 CVAT에서 계속
    편집하는 동안 원할 때마다 당겨오면 된다.
    """

    def __init__(self, client: "NexusClient", d: dict) -> None:
        self._client = client
        self._raw = d
        self.session_id: str = d["session_id"]

    # ── 상태 (매번 _raw에서 읽는다 — refresh 후 값이 자동으로 최신이 된다) ──────
    @property
    def status(self) -> str:
        """``creating`` | ``open`` | ``closed`` | ``failed``"""
        return self._raw.get("status", "")

    @property
    def url(self) -> "str | None":
        """작업자에게 넘길 CVAT task 주소. ``creating`` 동안에는 ``None``."""
        return self._raw.get("cvat_url")

    @property
    def dataset_id(self) -> str:
        return self._raw["dataset_id"]

    @property
    def version(self) -> str:
        return self._raw.get("version", "")

    @property
    def dataset_name(self) -> "str | None":
        return self._raw.get("dataset_name")

    @property
    def sample_count(self) -> int:
        return int(self._raw.get("sample_count") or 0)

    @property
    def error(self) -> "str | None":
        """``status == "failed"`` 일 때 사유."""
        return self._raw.get("error")

    @property
    def warnings(self) -> list[str]:
        """준비 중 스킵된 것들의 사유. 비어 있지 않으면 CVAT에 안 간 데이터가 있다는 뜻이다."""
        return list(self._raw.get("warnings") or [])

    @property
    def has_unimported_changes(self) -> "bool | None":
        """아직 당겨오지 않은 CVAT 편집이 있는가.

        **3-값이다.** ``None``은 '없음'이 아니라 **'모름'**(CVAT 조회 실패, 또는 세션이
        ``open``이 아님)이다. 목록 조회로 만든 객체는 항상 ``None``이므로
        :meth:`refresh` 를 부른 뒤 읽을 것.
        """
        return self._raw.get("has_unimported_changes")

    def __repr__(self) -> str:
        return (
            f"AnnotationSession(status={self.status!r}, samples={self.sample_count}, "
            f"url={self.url!r}, id={self.session_id})"
        )

    # ── 조회 ────────────────────────────────────────────────────────────────
    def refresh(self) -> "AnnotationSession":
        """서버에서 다시 읽어 상태를 갱신한다(``has_unimported_changes`` 포함)."""
        self._raw = self._client.get_annotation_session(self.session_id)
        return self

    def wait_open(self, *, timeout: float = 600.0, interval: float = 3.0,
                  verbose: bool = True) -> "AnnotationSession":
        """``open``이 될 때까지 기다린다. 준비 실패(``failed``)면 사유를 담아 예외를 던진다.

        서버는 진행률을 주지 않으므로 상태만 폴링한다. 큰 세션(수백~수천 장)은 CVAT이
        이미지를 다 내려받아야 열리므로 ``timeout``을 넉넉히 줄 것.
        """
        import time

        deadline = time.monotonic() + timeout
        with _spinner(f"CVAT 세션 준비 중 ({self.sample_count}장)", disable=not verbose):
            while True:
                self.refresh()
                if self.status == "open":
                    return self
                if self.status == "failed":
                    raise NexusError(
                        f"CVAT 세션 준비 실패: {self.error or '사유 없음'}",
                        status_code=None,
                    )
                if self.status == "closed":
                    raise NexusError("세션이 이미 닫혔습니다", status_code=None)
                if time.monotonic() >= deadline:
                    raise NexusError(
                        f"CVAT 세션이 {timeout:.0f}초 안에 열리지 않았습니다"
                        f"(현재 status={self.status!r}). 서버에서 계속 준비 중일 수 있으니 "
                        f"session_id={self.session_id} 로 다시 조회해 보세요.",
                        status_code=None,
                    )
                time.sleep(interval)

    # ── 반영 / 종료 ─────────────────────────────────────────────────────────
    def pull(self) -> dict:
        """CVAT 편집 결과를 draft에 반영하고 요약을 반환한다(서버의 ``import``).

        **반복 호출이 멱등**이다 — 편집이 없으면 전부 0이 돌아온다. 반환 키:
        ``updated_samples`` / ``created_instances`` / ``removed_instances`` /
        ``updated_components`` / ``deleted_components`` / ``warnings``.

        ``warnings``를 버리지 말 것 — "CVAT에서 지웠는데 GT에 남아 있다"의 이유가 대개
        여기 있다. 부분 실패(샘플 일부 반영 실패)도 예외가 아니라 이 목록으로 온다.
        """
        summary = self._client.import_annotation_session(self.session_id)
        self.refresh()
        return summary

    def close(self, *, force: bool = False) -> "AnnotationSession":
        """작업 종료 — 샘플 잠금만 풀고 **CVAT project는 남긴다**.

        아직 당겨오지 않은 편집이 있으면 `NexusError(status_code=409)`가 난다.
        그 작업을 버리고 닫으려면 ``force=True``. 먼저 :meth:`pull` 을 부르는 편이 보통 맞다.
        """
        self._raw = self._client.close_annotation_session(self.session_id, force=force)
        return self

    def delete(self) -> None:
        """세션과 **CVAT project를 완전히 삭제**한다 — 이미지 사본과 미반영 편집도 사라지며
        되돌릴 수 없다. 결과물을 남기고 잠금만 풀려면 :meth:`close` 를 쓸 것.

        **사람** `editor` 이상이면 가능하다(담당자가 아니어도 된다). `viewer` 와 **로봇 계정**은
        `NexusError(403)` — 로봇이 막히는 것은 사라지는 것에 아직 nexus로 들어오지 않은 작업자
        편집이 섞여 있고 seal이 그것을 지켜 주지 않기 때문이다. 로봇도 :meth:`close` 는 부를 수
        있으므로 잠금이 영구히 남지 않는다.
        """
        self._client.delete_annotation_session(self.session_id)
