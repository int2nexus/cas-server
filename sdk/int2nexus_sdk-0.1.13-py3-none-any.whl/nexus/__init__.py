from __future__ import annotations
import os
import warnings

from nexus._types import (
    IngestResult,
    NexusAuthError,
    NexusBatchError,
    NexusCasError,
    NexusError,
    NexusIngestError,
)
from nexus import settings as _settings
from nexus._version import __version__
from nexus.cas import CasClient
from nexus.client import NexusClient
from nexus.dataset import AnnotationSession, Dataset
from nexus.imageinfo import ImageInfo, image_info
from nexus.probe import probe
from nexus.sample import CasRef, Sample
from nexus.sts import CasSts
from nexus.upload import upload

_client: NexusClient | None = None
_cas: CasClient | None = None


def _apply_insecure_tls(verify: "bool | str") -> None:
    """`verify=False`일 때 urllib3의 요청마다 나오는 경고를 억제하고 **한 번만** 우리 경고를 낸다.

    요청마다 나오는 경고는 대량 적재 로그를 뒤덮어 실제 문제를 가린다. 그렇다고 조용히
    넘기면 "이 연결은 중간자 공격을 탐지하지 못한다"는 사실이 어디에도 남지 않으므로,
    접속 시점에 한 번은 반드시 알린다.
    """
    if verify is not False:
        return
    warnings.warn(
        "TLS 인증서 검증이 꺼져 있습니다(verify=False) — 이 연결은 중간자 공격을 탐지하지 "
        "못합니다. 사내 프록시가 원인이라면 검증을 끄는 대신 루트 CA 번들 경로를 주는 쪽을 "
        "권합니다: nx.connect(verify='/path/to/corp-ca.pem') 또는 설정 파일의 \"verify\" 키.",
        stacklevel=3,
    )
    try:  # urllib3 2.x / 1.x 모두 대응
        from urllib3.exceptions import InsecureRequestWarning

        warnings.simplefilter("ignore", InsecureRequestWarning)
    except Exception:  # pragma: no cover - urllib3 내부 구조가 바뀐 경우
        pass


def _save_cas_credentials_or_explain(
    path: "str | None", key_id: str, secret: str, region: "str | None"
) -> None:
    """발급받은 자격증명을 파일에 쓴다. **쓰기가 실패해도 발급 자체는 이미 끝나 있다** —
    여기서 잡지 않고 그냥 올리면 사용자는 "접속이 실패했다"만 보고, nexus에는 이미 만든
    자격증명 하나가 조용히 남는다(다음 재시도마다 또 하나씩 늘어난다). 그래서 무슨 일이
    있었는지(발급은 됐다, key_id가 무엇이다, 수동으로 저장하거나 폐기해야 한다)를 에러
    메시지에 박아 올린다 — 최소한 사용자가 원인을 알고 조치할 수 있게.
    """
    try:
        _settings.save_cas_credentials(
            _settings.settings_path(path), key_id, secret, region
        )
    except Exception as e:
        raise NexusError(
            f"CAS 자격증명 {key_id}을(를) nexus에서 새로 발급받았지만 설정 파일에 저장하지 "
            f"못했습니다({e}). **자격증명 자체는 이미 발급되어 남아 있습니다** — 그대로 두면 "
            f"다음 접속 시도마다 또 하나씩 새로 발급됩니다. 원인(디스크 권한·용량 등)을 고친 "
            f"뒤 `nexus.settings.save_cas_credentials(path, {key_id!r}, secret, region)`으로 "
            f"직접 저장하거나, 더 쓰지 않을 거라면 "
            f"`DELETE /api/v1/auth/cas-credentials/{key_id}`로 폐기하세요."
        ) from e


def _auto_issue_cas_credentials(client: NexusClient) -> "dict | None":
    """자격증명이 비어 있을 때 nexus에서 자동으로 발급받는다.

    **503(서버에 CAS 관리 자격증명이 구성되지 않음)은 사용자 잘못이 아니다** — 그
    배포는 CAS 익명 접근만 허용하도록 운영진이 의도한 것일 수 있다. 여기서는 조용히
    포기하고 이 기능이 없던 시절과 같은 상태(자격증명 없이 접속, 서명 없는 요청은
    `CasClient._signed_headers`가 그대로 통과시킨다)로 되돌아간다.

    그 외 에러(예: 409 — cas 운영자가 이 사용자의 자격증명을 직접 폐기해 되살릴 수
    없음)는 사용자가 알아야 하는 상태이므로 삼키지 않고 그대로 올린다.
    """
    try:
        return client.issue_cas_credentials()
    except NexusError as e:
        if e.status_code == 503:
            warnings.warn(
                "서버에 CAS 관리 자격증명이 구성되지 않아 자동 발급을 건너뜁니다 — "
                "CAS 익명 접근만 가능합니다. 필요하면 CAS_KEY_ID/CAS_SECRET을 직접 "
                "지정하세요.",
                stacklevel=3,
            )
            return None
        raise


def _cas_credentials_from_user(
    cas_key_id: "str | None", cas_secret: "str | None"
) -> bool:
    """해소된 CAS 자격증명이 **사용자가 직접 준 것**인지(인자 또는 환경변수) 판정한다.

    `settings.resolve()`는 인자·환경변수·설정 파일을 하나의 dict로 합쳐 돌려주므로
    **출처가 남지 않는다.** 그래서 앞의 두 경로를 여기서 직접 본다 — 둘 다 아니면 남는
    것은 설정 파일뿐이다. 이 구분이 필요한 이유는 재발급 콜백을 어디에 거는가가 출처마다
    다르기 때문이다(`connect` 안의 주석 참조).

    빈 문자열은 "지정하지 않음"으로 본다 — `resolve()`가 그렇게 다루므로(빈 값이면 다음
    순위로 넘어간다) 여기서 다르게 보면 판정과 실제 값의 출처가 어긋난다.

    환경변수 이름은 `settings._ENV_VARS`에서 가져온다. 여기 다시 적으면 한쪽만 바뀌는 날
    판정이 조용히 틀린다.
    """
    if cas_key_id or cas_secret:
        return True
    return bool(
        os.environ.get(_settings._ENV_VARS["cas_key_id"])
        or os.environ.get(_settings._ENV_VARS["cas_secret"])
    )


def connect(
    nexus_url: str | None = None,
    email: str | None = None,
    password: str | None = None,
    cas_url: str | None = None,
    cas_key_id: str | None = None,
    cas_secret: str | None = None,
    timeout: "float | tuple[float, float]" = (10.0, 120.0),
    verify: "bool | str | None" = None,
    settings_path: "str | None" = None,
    save_cas_credentials: bool = False,
    robot_token: "str | None" = None,
    cas_sts: "CasSts | None" = None,
) -> NexusClient:
    """nexus/CAS에 접속한다. 인자를 하나도 안 주면 환경변수와 설정 파일에서 해소한다.

    값의 우선순위는 **인자 > 환경변수 > 설정 파일**(`~/.int2nexus/settings.json`,
    `NEXUS_SETTINGS`로 경로 변경 가능). 설정 파일에 다 적어두면 `nx.connect()` 한 줄이면 된다.

    `verify`는 TLS 인증서 검증 — `True`(기본), `False`(검증 끔), 또는 **CA 번들 경로**.
    사내 TLS 검사 장비 때문에 SSL 에러가 난다면 검증을 끄는 대신 사내 루트 CA 경로를 주는
    쪽을 권한다. nexus와 CAS 양쪽 세션에 같은 값이 적용된다.

    **CAS 자격증명이 갖춰지지 않으면 nexus가 이 계정 앞으로 자동 발급해준다**(서버에 CAS
    관리 자격증명이 구성돼 있어야 함) — 운영자가 손으로 만들어 나눠주던 것을 대체한다.

    **판정은 `cas_key_id`와 `cas_secret`이 둘 다 해소됐는가로 한다.** 둘 다 있으면 이
    단계는 실행되지 않는다 — CI·학습 파드가 환경변수로 주입하는 운영자 관리 영구
    자격증명이 항상 이기고, 그 값이 있는 한 nexus를 두드리지 않는다(그래서 파드를 띄울
    때마다 자격증명이 쌓이지 않는다). **한쪽만 있으면 발급이 일어나고 있던 쪽까지 새 값으로
    덮인다** — 한쪽만으로는 `_signed_headers`가 서명을 만들지 못해 그 값이 아무 일도 하지
    못하기 때문이다. 사용자가 넣은 값을 지우는 동작이라 덮어쓰기 전에 `warnings.warn`으로
    알린다.

    **자동 발급된 자격증명은 기본적으로 설정 파일에 쓰지 않는다**(`save_cas_credentials`,
    0.1.10 에서 `True` → `False` 로 뒤집었다). 발급 자체는 그대로 일어나고 이 프로세스
    안에서는 쓰인다 — 파일에 남기지 않을 뿐이다.

    뒤집은 이유는 **자동 발급의 결과가 파일이면 "자격증명이 사람마다 흩어지지 않게 한다" 는
    방침이 자동 발급에서 무너지기 때문**이다. 나중에 뒤집으면 그때는 이미 흩어진 파일을
    회수해야 한다. 지금은 이 경로를 타는 소비자가 없어 뒤집는 비용이 0 이다 — 웹은 CAS
    자격증명이 필요 없고, 노트북과 적재 잡은 환경변수 주입이며 **환경변수가 이긴다**(위의
    "둘 다 있으면 이 단계는 실행되지 않는다").

    저장이 맞는 배포는 `save_cas_credentials=True` 로 명시한다. 저장하지 않으면 프로세스가
    끝날 때 자격증명이 사라지고 다음 실행에서 새로 발급받으므로, `key_id` 가 쌓이는 것이
    싫으면 환경변수로 영구 자격증명을 주입하는 쪽이 맞다(그러면 발급 자체가 안 일어난다).

    **설정 파일에 저장돼 있던 자격증명에도 403 재발급 콜백이 걸린다.** 서버가 CAS
    자격증명에 만료를 붙이면서(요청자 토큰의 만료를 물려받는다) 그 값은 언젠가 반드시
    죽는데, 파일에 있는 값을 갱신할 주체가 이 SDK 말고 없기 때문이다. 갱신하면 파일도
    제자리 갱신한다 — 다음 프로세스가 만료된 값을 또 읽고 403 을 한 번 더 맞는 왕복을
    없앤다. **인자·환경변수로 준 값은 그대로 두어(콜백을 걸지 않아) 위의 탈출구를
    지킨다.**

    **로봇 토큰**(`robot_token=` 또는 `NEXUS_ROBOT_TOKEN`)을 주면 로그인 경로를 타지 않고
    그 값이 그대로 Bearer 로 실린다. `email`/`password` 는 필요 없다. 관리자가
    `POST /api/v1/admin/robots/{user_id}/tokens` 로 발급한 `nxr_` 로 시작하는 값이고,
    워크로드는 보통 sealed-secret 에서 환경변수로 받는다.

    **로봇 토큰은 설정 파일에 저장하지 않는다.** 그 값은 배포가 주입하는 것이지 이 라이브러리가
    관리할 것이 아니고, 파일에 남기면 sealed-secret 으로 관리하는 의미가 사라진다.

    로봇 토큰에는 갱신도 재로그인도 없다. `401` 은 그대로 올라간다 — 폐기·만료·계정 정지
    중 무엇이든 관리자가 조작해야 풀리고, 재시도해 봐야 같은 값을 다시 보내는 것뿐이다.

    **CAS 임시 자격증명(STS)** 은 `cas_sts=CasSts(token_file=...)` 또는
    `CasSts(token_provider=...)` 로 켠다(0.1.12+). 그러면 cas 의 `AssumeRoleWithWebIdentity` 로
    임시 자격증명을 받아 쓰고 만료 전에 스스로 갱신한다. **정적 키 경로 전체를 건너뛴다** —
    `cas_key_id`/`cas_secret` 인자와 함께 주면 `ValueError`, 환경변수·설정 파일의 정적 키는 경고를
    내고 무시하며, nexus 자동 발급을 부르지 않고 설정 파일에 쓰지 않는다. 접속 시점에 한 번 받아
    토큰 파일·매핑이 틀렸으면 여기서 `NexusCasError` 로 실패한다(cas 에 닿지 않으면 재시도 뒤).
    """
    # bucket은 전역 기본값을 두지 않는다 — nx.upload(paths, bucket=...)에서 호출별로 지정.
    # timeout=(connect, read) — read를 넉넉히(배치 적재가 오래 걸릴 수 있음). 없으면 정체가 무한 hang.
    global _client, _cas

    if cas_sts is not None and (cas_key_id or cas_secret):
        raise ValueError(
            "cas_sts 와 cas_key_id/cas_secret 인자는 함께 줄 수 없습니다 — STS 모드는 CAS 자격증명을 "
            "스스로 받습니다"
        )

    # 인자 > 환경변수. 설정 파일은 보지 않는다 — 로봇 토큰은 배포가 주입하는 값이고,
    # 파일에 남기면 sealed-secret 으로 관리하는 의미가 사라진다.
    resolved_robot_token = robot_token or os.environ.get("NEXUS_ROBOT_TOKEN") or None

    cfg = _settings.resolve(
        path=settings_path,
        require_login=resolved_robot_token is None,
        nexus_url=nexus_url,
        email=email,
        password=password,
        cas_url=cas_url,
        cas_key_id=cas_key_id,
        cas_secret=cas_secret,
        verify=verify,
    )
    _apply_insecure_tls(cfg["verify"])

    client = NexusClient(
        cfg["nexus_url"], cfg["email"] or "", cfg["password"] or "",
        timeout=timeout, verify=cfg["verify"],
        robot_token=resolved_robot_token,
    )
    _client = client

    # settings.resolve()가 file/env에서 region을 읽어와 채워둔 값(둘 다 없으면
    # CasClient 기본값과 같은 "cas-default"). 자동 발급이 성공하면 서버 응답값으로
    # 갈아 끼운다 — 아래 IMPORTANT 4 참조(region을 저장해두지 않으면 기본 region이 아닌
    # 배포에서 다음 프로세스부터 영원히 403이 난다).
    region = cfg["cas_region"]

    if cas_sts is not None:
        # **정적 키 분기 전체를 건너뛴다**(한쪽 키 경고·자동 발급·설정 파일 콜백·저장). 환경변수나
        # 설정 파일에 키가 있으면 조용히 버리지 않고 알린다 — 0.1.9 이하 설치본은 설정 파일에 자동
        # 발급 키가 깔려 있을 수 있어 매 접속 보일 수 있고, 그것은 의도다.
        if cfg["cas_key_id"] or cfg["cas_secret"]:
            warnings.warn(
                "CAS_KEY_ID/CAS_SECRET(환경변수 또는 설정 파일)을 무시하고 cas_sts 로 받은 임시 "
                "자격증명을 씁니다",
                stacklevel=2,
            )
        cas = CasClient(cfg["cas_url"], region=region, verify=cfg["verify"], sts=cas_sts)
        try:
            cas.ensure_credentials()
        except Exception:
            # 실패한 접속이 _client/_cas 중 하나라도 남기면 upload/probe 가 재접속하지 않고
            # 옛 클라이언트로 죽는다(probe는 _cas를 직접 본다) — 둘 다 지운다.
            _client = None
            _cas = None
            raise
        _cas = cas
        return client

    def _make_on_forbidden(*, persist: bool):
        """CAS가 403을 주면(자격증명이 폐기됐거나 만료됨) 다시 발급받는 콜백을 만든다.

        **정책 거부에는 불리지 않는다.** cas가 둘을 다른 S3 에러 코드로 내므로
        (`AccessDenied` 대 `InvalidAccessKeyId`) `CasClient`가 코드를 보고 가른다 —
        정책 거부는 자격증명을 새로 받아도 풀리지 않고, 이 기능이 붙이는 정책에서
        403은 예외가 아니라 정상 응답이다(`viewer`의 쓰기, `annotations/`·
        `manifests/` 접두사). 나머지는 `cas.py::_REISSUE_MIN_INTERVAL_SECS`
        간격으로만 불린다.

        재발급 자체가 409(cas 운영자가 직접 폐기해 되살릴 수 없음)면 여기서 잡지 않고
        그대로 올린다 — `cas.py::_retry_with_fresh_credentials` 참조.

        호출 빈도 제한도 잠금도 이 함수는 모른다 — 동시 호출 억제(`_forbidden_lock`)와
        재발급 간격 둘 다 `CasClient`가 한다.

        `persist`는 새 값을 설정 파일에 쓸지다. 만드는 자리가 둘이고 **거기서 답이
        갈린다** — 자동 발급 경로는 `save_cas_credentials`(파일에 남길지는 별개의
        결정이다), 설정 파일에서 온 자격증명은 항상 참(그 파일에 이미 자격증명이 들어
        있으므로 제자리 갱신이다). 콜백 자체를 둘로 나누지 않는 이유는 하는 일이 같아서다
        — 나누면 한쪽만 region 처리를 빠뜨리는 날 기본 region이 아닌 배포가 조용히
        깨진다.
        """

        def on_forbidden() -> "tuple[str, str]":
            fresh = client.issue_cas_credentials()
            if persist:
                _save_cas_credentials_or_explain(
                    settings_path, fresh["cas_key_id"], fresh["secret_key"],
                    fresh.get("region") or region,
                )
            return fresh["cas_key_id"], fresh["secret_key"]

        return on_forbidden

    on_forbidden = None
    if not cfg["cas_key_id"] or not cfg["cas_secret"]:
        if cfg["cas_key_id"] or cfg["cas_secret"]:
            # 한쪽만 있으면 어차피 서명에 못 쓴다(`_signed_headers`가 둘 다 있어야
            # 서명한다) — 자동 발급이 조용히 그 반쪽짜리를 덮어쓰기 전에 알린다.
            warnings.warn(
                "CAS_KEY_ID/CAS_SECRET 중 한쪽만 설정되어 있어 그것만으로는 서명할 수 "
                "없습니다. nexus에서 새로 발급받아 두 값을 함께 덮어씁니다.",
                stacklevel=3,
            )
        issued = _auto_issue_cas_credentials(client)
        if issued is not None:
            cfg["cas_key_id"] = issued["cas_key_id"]
            cfg["cas_secret"] = issued["secret_key"]
            # 명시 인자로 준 cas_url이 있으면(즉 resolve()가 이미 채워뒀으면) 그게
            # 이긴다 — 이 모듈의 문서화된 우선순위(인자 > 환경변수 > 설정 파일)를
            # nexus의 자동 응답값이 뒤엎으면 안 된다. cas_url이 `_REQUIRED`라 지금은
            # 이 분기가 거의 항상 비어 있지 않은 값을 보지만, 나중에 cas_url이 선택이
            # 되더라도 규칙이 깨지지 않도록 명시적으로 "비어 있을 때만" 채운다.
            if not cfg["cas_url"]:
                cfg["cas_url"] = issued["cas_url"]
            region = issued["region"] or region
            cfg["cas_region"] = region
            if save_cas_credentials:
                _save_cas_credentials_or_explain(
                    settings_path, cfg["cas_key_id"], cfg["cas_secret"], region,
                )
            on_forbidden = _make_on_forbidden(persist=save_cas_credentials)
    elif not _cas_credentials_from_user(cas_key_id, cas_secret):
        # **설정 파일에서 온 자격증명에도 재발급을 건다.** 그 값은 이 SDK가 자동 발급
        # 결과로 스스로 써 넣은 것이고, 서버가 CAS 자격증명에 만료를 붙이면서 언젠가
        # 반드시 죽는다 — 갱신할 주체가 SDK 말고 없다. 안 걸면 저장된 키가 만료되는
        # 순간부터 모든 CAS 호출이 403인데 재발급을 시도조차 하지 않고, 힌트는 "정책이
        # 거부했다"로 엉뚱한 곳을 가리킨다(0.1.9 이하는 `save_cas_credentials` 기본값이
        # `True`였으므로 이미 파일에 값이 깔린 설치본이 있다).
        #
        # **인자·환경변수로 준 값에는 걸지 않는다** — 그쪽은 운영자가 관리하는 영구
        # 자격증명일 수 있고, 403 한 번에 nexus 자동 발급으로 바꿔치기하면 위 docstring이
        # 약속한 탈출구가 조용히 무력해진다.
        #
        # 갱신한 값은 파일에도 쓴다(`persist=True`). 그 파일에는 **이미** 자격증명이 들어
        # 있으므로 없던 파일을 만드는 것이 아니라 제자리 갱신이고, 안 쓰면 다음 프로세스가
        # 만료된 값을 또 읽고 403을 한 번 더 맞는 왕복이 남는다. 자동 발급 경로의 저장
        # 규칙(`save_cas_credentials`)은 이것과 다른 결정이라 그대로 둔다.
        on_forbidden = _make_on_forbidden(persist=True)

    _cas = CasClient(
        cfg["cas_url"], cfg["cas_key_id"], cfg["cas_secret"],
        region=region, verify=cfg["verify"], on_forbidden=on_forbidden,
    )
    return client


def _auto_connect() -> NexusClient:
    global _client
    if _client is None:
        connect()
    return _client  # type: ignore[return-value]


def list_datasets(
    *,
    q: str | None = None,
    name: str | None = None,
    description: str | None = None,
    tags: "str | list[str] | None" = None,
    sort: str | None = None,
    order: str | None = None,
    favorite: bool = False,
    mine: bool = False,
    unowned: bool = False,
    limit: int | None = None,
    cursor: str | None = None,
    client: NexusClient | None = None,
) -> list[dict]:
    """등록된 dataset 목록(dict 리스트).

    각 항목: `dataset_id`/`name`/`description`/`tags`/`created_at`와 **`versions`**(버전 문자열
    목록, 예 `['v0','v1']`), **`is_favorite`**(내 즐겨찾기 여부). 옵션 — `name`/`description`: 부분
    검색(ILIKE), `tags`: 하나라도 포함(ANY), `sort`: "name"|"created_at"(기본), `order`: "asc"/"desc"(기본
    desc), `favorite`: True면 내 즐겨찾기만, `mine`: 내가 담당인 것만, `unowned`: 담당자가 없는 것만.

    **`limit`을 안 주면 커서를 자동으로 순회해 전체를 모은다**(서버 0.1.7부터 한 응답에
    기본 100개까지만 실린다). `limit`에 숫자를 주면 그 개수만큼 한 페이지만 반환한다.
    """
    c = client or _auto_connect()
    return c.list_datasets(
        q=q, name=name, description=description, tags=tags, sort=sort, order=order,
        favorite=favorite, mine=mine, unowned=unowned, limit=limit, cursor=cursor,
    )


def annotation_session(
    session_id: str, *, client: NexusClient | None = None
) -> "AnnotationSession":
    """`session_id`로 기존 세션을 다시 잡는다.

    세션은 파이썬 프로세스와 무관하게 서버에 남아 있다 — 스크립트를 껐다 켜도, 다른
    사람이 만든 세션이어도 id만 있으면 이어받을 수 있다. 목록에서 고르려면
    :func:`annotation_sessions` 를 쓴다.
    """
    c = client or _auto_connect()
    return AnnotationSession(c, c.get_annotation_session(session_id))


def annotation_sessions(
    *,
    status: "str | None" = None,
    dataset_id: str | None = None,
    mine: bool = False,
    limit: int | None = None,
    client: NexusClient | None = None,
) -> "list[AnnotationSession]":
    """**전역** CVAT 편집 세션 목록 — dataset·버전을 가로질러 "지금 진행 중인 것"을 모은다.

    기본은 진행 중인 것만(`status="active"` = creating+open)이다. 이력까지 보려면 `"all"`,
    특정 상태만 보려면 `"open"`/`"closed"`/`"failed"`. `mine=True`면 내가 만든 것만.

    각 항목은 `dataset_name`/`version`/`sample_count`를 이미 담고 있어 추가 조회 없이
    목록을 그릴 수 있다. 다만 `has_unimported_changes`는 목록에서 항상 `None`이다
    (세션마다 CVAT 호출이 필요해서) — 필요하면 `.refresh()` 후 읽을 것.
    """
    c = client or _auto_connect()
    rows = c.list_annotation_sessions(
        dataset_id=dataset_id, status=status, mine=mine, limit=limit
    )
    return [AnnotationSession(c, r) for r in rows]


__all__ = [
    "__version__",
    "connect",
    "list_datasets",
    "annotation_sessions",
    "annotation_session",
    "Dataset",
    "AnnotationSession",
    "Sample",
    "CasRef",
    "CasSts",
    "upload",
    "probe",
    "image_info",
    "ImageInfo",
    "IngestResult",
    "NexusError",
    "NexusAuthError",
    "NexusCasError",
    "NexusIngestError",
    "NexusBatchError",
]
