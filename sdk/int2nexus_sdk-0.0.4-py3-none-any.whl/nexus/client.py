from __future__ import annotations
import requests
from nexus._types import NexusAuthError, NexusIngestError


class NexusClient:
    def __init__(
        self,
        nexus_url: str,
        email: str,
        password: str,
        timeout: "float | tuple[float, float]" = (10.0, 120.0),
    ) -> None:
        self._base = nexus_url.rstrip("/")
        self._session = requests.Session()
        # flush가 배치를 병렬 POST하므로 커넥션 풀을 넉넉히 — 기본 pool_maxsize(10)면
        # 동시성 초과 시 커넥션을 버리고 재생성해 오버헤드가 난다.
        adapter = requests.adapters.HTTPAdapter(pool_connections=32, pool_maxsize=32)
        self._session.mount("http://", adapter)
        self._session.mount("https://", adapter)
        # (connect, read) 타임아웃. read는 서버가 응답 바이트를 보내기까지 허용 시간 —
        # 없으면(requests 기본) 일시적 커넥션 정체가 **무한 hang**으로 굳는다. 배치 처리가
        # 오래 걸릴 수 있어 read는 넉넉히. 호출부가 kwargs로 개별 override 가능.
        self._timeout = timeout
        self._token: str | None = None
        self._login(email, password)

    def _login(self, email: str, password: str) -> None:
        r = self._session.post(
            f"{self._base}/api/v1/auth/login",
            json={"email": email, "password": password},
            timeout=self._timeout,
        )
        if not r.ok:
            raise NexusAuthError(f"Login failed ({r.status_code}): {r.text}")
        self._token = r.json()["token"]
        self._session.headers["Authorization"] = f"Bearer {self._token}"

    # _get and _post raise requests.HTTPError on non-2xx responses.
    # Callers (list_datasets, create_dataset, create_version) let this propagate;
    # ingest() wraps it in NexusIngestError for structured batch error handling.
    # 모든 호출에 기본 timeout을 건다(호출부가 timeout= 로 덮어쓸 수 있음).
    def _get(self, path: str, **kwargs) -> requests.Response:
        kwargs.setdefault("timeout", self._timeout)
        r = self._session.get(f"{self._base}{path}", **kwargs)
        r.raise_for_status()
        return r

    def _post(self, path: str, **kwargs) -> requests.Response:
        kwargs.setdefault("timeout", self._timeout)
        r = self._session.post(f"{self._base}{path}", **kwargs)
        r.raise_for_status()
        return r

    def _put(self, path: str, **kwargs) -> requests.Response:
        kwargs.setdefault("timeout", self._timeout)
        r = self._session.put(f"{self._base}{path}", **kwargs)
        r.raise_for_status()
        return r

    def _delete(self, path: str, **kwargs) -> requests.Response:
        kwargs.setdefault("timeout", self._timeout)
        r = self._session.delete(f"{self._base}{path}", **kwargs)
        r.raise_for_status()
        return r

    def delete_version(
        self, dataset_id: str, version: str, confirm: str, delete_cas: bool = True
    ) -> dict:
        """version hard-delete(dataset 유지). confirm=<버전 문자열> 필요. delete_cas=False면 CAS 보존."""
        return self._delete(
            f"/datasets/{dataset_id}/versions/{version}",
            params={"confirm": confirm, "delete_cas": str(bool(delete_cas)).lower()},
        ).json()

    def list_datasets(
        self,
        *,
        q: str | None = None,
        name: str | None = None,
        description: str | None = None,
        tags: "str | list[str] | None" = None,
        sort: str | None = None,
        order: str | None = None,
        favorite: bool = False,
    ) -> list[dict]:
        """dataset 목록. 옵션: q(통합 검색 — name/description/tags 중 하나라도 부분일치, UI 단일 검색창용),
        name/description(개별 ILIKE), tags(ANY), sort(name|created_at), order(asc|desc),
        favorite(True면 내 즐겨찾기만). 각 항목에 is_favorite 포함."""
        params: dict = {}
        if q:
            params["q"] = q
        if name:
            params["name"] = name
        if description:
            params["description"] = description
        if tags:
            params["tags"] = tags if isinstance(tags, str) else ",".join(tags)
        if sort:
            params["sort"] = sort
        if order:
            params["order"] = order
        if favorite:
            params["favorite"] = "true"
        return self._get("/datasets", params=params).json()

    def sample_history(self, dataset_id: str, sample_id: str) -> dict:
        """한 샘플의 버전별 annotation 이력(든 버전만, created_at 오름차순)."""
        return self._get(f"/datasets/{dataset_id}/samples/{sample_id}/history").json()

    def version_diff(
        self, dataset_id: str, version: str, *, against: str | None = None
    ) -> dict:
        """버전 diff — target(version) vs base(against, 없으면 parent_version)."""
        params = {"against": against} if against else {}
        return self._get(
            f"/datasets/{dataset_id}/versions/{version}/diff", params=params
        ).json()

    # ── Subsets (저장된 explorer 필터) ──────────────────────────────────────
    def create_subset(self, dataset_id: str, version: str, name: str, filter: dict) -> dict:
        """서브셋 생성. filter = SampleExplorerRequest 형태. 인증 필요."""
        return self._post(
            f"/datasets/{dataset_id}/versions/{version}/subsets",
            json={"name": name, "filter": filter},
        ).json()

    def list_subsets(self, dataset_id: str, version: str) -> list[dict]:
        return self._get(f"/datasets/{dataset_id}/versions/{version}/subsets").json()

    def get_subset(self, subset_id: str) -> dict:
        return self._get(f"/subsets/{subset_id}").json()

    def update_subset(
        self, subset_id: str, *, name: str | None = None, filter: dict | None = None
    ) -> dict:
        body: dict = {}
        if name is not None:
            body["name"] = name
        if filter is not None:
            body["filter"] = filter
        return self._put(f"/subsets/{subset_id}", json=body).json()

    def delete_subset(self, subset_id: str) -> None:
        self._delete(f"/subsets/{subset_id}")

    def subset_samples(
        self, subset_id: str, *, cursor: str | None = None,
        limit: int | None = None, include_annotations: bool | None = None,
    ) -> list[dict]:
        """서브셋 필터 resolve → 샘플 한 페이지(explorer와 동일 형식)."""
        params: dict = {}
        if cursor is not None:
            params["cursor"] = cursor
        if limit is not None:
            params["limit"] = limit
        if include_annotations is not None:
            params["include_annotations"] = str(include_annotations).lower()
        return self._get(f"/subsets/{subset_id}/samples", params=params).json()

    def materialize_subset(self, subset_id: str, version: str) -> dict:
        """서브셋을 **새 버전**으로 물질화(필터링된 fork). 필터를 resolve한 샘플만 담고
        라벨은 서브셋의 version에서 복제. 0개 resolve면 400. 인증 필요. 생성된 DatasetVersion 반환."""
        return self._post(
            f"/subsets/{subset_id}/version", json={"version": version}
        ).json()

    def add_favorite(self, dataset_id: str) -> None:
        """dataset을 내 즐겨찾기에 추가(멱등). PUT /datasets/{id}/favorite."""
        self._put(f"/datasets/{dataset_id}/favorite")

    def remove_favorite(self, dataset_id: str) -> None:
        """dataset을 내 즐겨찾기에서 해제(멱등). DELETE /datasets/{id}/favorite."""
        self._delete(f"/datasets/{dataset_id}/favorite")

    def create_dataset(
        self,
        name: str,
        tags: list[str] | None = None,
        description: str | None = None,
    ) -> dict:
        body: dict = {"name": name}
        if tags:
            # 문자열 하나를 넘기면 단일 원소 리스트로 자동 변환 (서버는 배열을 기대).
            body["tags"] = [tags] if isinstance(tags, str) else list(tags)
        if description:
            body["description"] = description
        return self._post("/datasets", json=body).json()

    def list_versions(self, dataset_id: str) -> list[dict]:
        """dataset의 version 목록."""
        return self._get(f"/datasets/{dataset_id}/versions").json()

    def get_version(self, dataset_id: str, version: str) -> dict | None:
        r = self._session.get(
            f"{self._base}/datasets/{dataset_id}/versions/{version}"
        )
        if r.status_code == 404:
            return None
        r.raise_for_status()
        return r.json()

    def create_version(
        self,
        dataset_id: str,
        version: str,
        fork_from: str | None = None,
        sample_ids: list[str] | None = None,
    ) -> dict:
        """새 버전 생성. `fork_from`만 주면 그 버전 전량 fork(멤버·라벨 승계).
        `fork_from`+`sample_ids`면 **필터링된 fork** — 그 버전 멤버 중 지정 샘플만 담고
        라벨은 fork_from에서 복제(서버가 비멤버 sample_id는 400). `sample_ids`만 주면(무 fork_from) 400.
        둘 다 없으면 빈 draft 버전."""
        body: dict = {"version": version}
        if fork_from is not None:
            body["fork_from"] = fork_from
        if sample_ids is not None:
            body["sample_ids"] = sample_ids
        return self._post(f"/datasets/{dataset_id}/versions", json=body).json()

    def add_sample_ids(self, dataset_id: str, version: str, sample_ids: list[str]) -> None:
        self._post(
            f"/datasets/{dataset_id}/versions/{version}/samples",
            json={"sample_ids": sample_ids},
        )

    def remove_sample_ids(self, dataset_id: str, version: str, sample_ids: list[str]) -> dict:
        """여러 sample을 version에서 링크 해제(sample·데이터는 유지). `{"removed": n}` 반환."""
        return self._delete(
            f"/datasets/{dataset_id}/versions/{version}/samples",
            json={"sample_ids": sample_ids},
        ).json()

    def seal(self, dataset_id: str, version: str) -> dict:
        """버전을 seal(불변 스냅샷)한다. 성공 시 sealed DatasetVersion을 반환한다.
        이미 sealed면 서버가 409를 반환하며 requests.HTTPError로 전파된다."""
        return self._post(
            f"/datasets/{dataset_id}/versions/{version}/seal"
        ).json()

    def ensure_bucket(self, bucket: str) -> None:
        self._post("/api/v1/buckets/ensure", json={"bucket": bucket})

    def ingest(self, payload: dict) -> dict:
        try:
            return self._post("/ingest", json=payload).json()
        except requests.HTTPError as e:
            raise NexusIngestError(str(e)) from e

    def ingest_batch(self, items: list[dict]) -> dict:
        try:
            return self._post("/ingest/batch", json={"items": items}).json()
        except requests.HTTPError as e:
            raise NexusIngestError(str(e)) from e

    def get_manifest(self, dataset_id: str, version: str) -> dict:
        from nexus._types import NexusError
        try:
            return self._get(f"/datasets/{dataset_id}/versions/{version}/manifest").json()
        except requests.HTTPError as e:
            if e.response is not None and e.response.status_code == 409:
                raise NexusError(
                    f"version '{version}' is not sealed — to_df() requires a sealed version"
                ) from e
            raise

    def get_manifest_samples(
        self, dataset_id: str, version: str,
        cursor: str | None = None, limit: int = 1000,
    ) -> dict:
        params = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return self._get(
            f"/datasets/{dataset_id}/versions/{version}/manifest/samples",
            params=params,
        ).json()

    def patch_annotations(
        self,
        dataset_id: str,
        version: str,
        sample_id: str,
        annotation_data: dict,
    ) -> None:
        self._put(
            f"/datasets/{dataset_id}/versions/{version}/samples/{sample_id}/annotations",
            json={"annotation_data": annotation_data},
        )

    def get_sample(self, dataset_id: str, version: str, sample_id: str) -> dict:
        """단건 GT 조회. 코어 필드 + group_key 배열이 평탄화된 dict를 반환한다."""
        from nexus._types import NexusError
        try:
            return self._get(
                f"/datasets/{dataset_id}/versions/{version}/samples/{sample_id}"
            ).json()
        except requests.HTTPError as e:
            if e.response is not None and e.response.status_code == 404:
                raise NexusError(
                    f"sample {sample_id} not found in {dataset_id}/{version}"
                ) from e
            raise

    def list_sample_ids_by_label(
        self, dataset_id: str, version: str, label: str
    ) -> set[str]:
        # 버전-스코프 explorer의 annotation 필터로 조회. 라벨만 필요하므로
        # include_annotations=False(경량)로 sample_id만 페이징한다.
        ids: set[str] = set()
        cursor = None
        limit = 1000
        while True:
            body: dict = {
                "annotation": [{"label": label}],
                "include_annotations": False,
                "limit": limit,
            }
            if cursor is not None:
                body["cursor"] = cursor
            page = self._post(
                f"/datasets/{dataset_id}/versions/{version}/samples/explorer",
                json=body,
            ).json()
            for s in page:
                ids.add(s["sample_id"])
            if len(page) < limit:
                break
            cursor = page[-1]["sample_id"]  # DESC order → last row is the smallest sample_id
        return ids
