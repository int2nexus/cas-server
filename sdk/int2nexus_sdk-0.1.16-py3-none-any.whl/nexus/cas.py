from __future__ import annotations
import hashlib
import hmac
import mimetypes
import re
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote
import blake3
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from nexus._types import NexusCasError
from nexus._version import apply_user_agent
from nexus.sts import CasSts, Credentials, StsCredentials

# 대량 적재용: 일시적 5xx/네트워크 끊김을 전송 계층에서 백오프 재시도.
# PUT은 key당 내용이 고정(content-addressed)이라 재시도 안전.
_RETRY = Retry(
    total=3,
    backoff_factor=0.5,
    status_forcelist=(429, 500, 502, 503, 504),
    allowed_methods=frozenset(["HEAD", "GET", "PUT"]),
    respect_retry_after_header=True,
    raise_on_status=False,
)

_EMPTY_SHA256 = hashlib.sha256(b"").hexdigest()

# STS 임시 자격증명을 403 때문에 강제로 다시 받는 **최소 간격**(초).
#
# 이 간격이 필요한 이유는 403 이 예외가 아니라 **정상 응답**일 수 있어서다 — STS 세션의
# 권한은 발급 시점 템플릿 키 정책의 스냅샷이고, 그 정책이 막는 동작을 부르면 몇 번을 다시
# 받아도 403 이다. 간격이 없으면 파일 500 개를 올리는 프로세스 하나가 세션을 그만큼 찍어낸다.
#
# **정책 거부는 간격이 아니라 응답이 거른다.** cas 는 둘을 다른 S3 에러 코드로 낸다:
#
#     정책 거부           403  AccessDenied         (cas `src/error.rs` CasError::Forbidden)
#     폐기·만료된 키      403  InvalidAccessKeyId   (cas `src/error.rs` AuthFailure)
#
# 그래서 `AccessDenied` 는 코드로 걸러 아예 갱신하지 않고, 이 간격은 **나머지**(자격증명이
# 실제로 죽은 경우, 그리고 코드를 못 읽는 경우)만 제한한다.
_STS_FORCED_REFRESH_MIN_INTERVAL_SECS = 60.0

# `AccessDenied` — 정책이 막았다. 자격증명을 새로 받아도 절대 풀리지 않는다.
_POLICY_DENIED_HINT = (
    "403 인데 자격증명 문제가 아니라 **정책이 이 동작을 거부**한 것입니다(AccessDenied). "
    "읽기만 되는 키로 쓰기(PutObject)를 불렀거나, 어떤 키로도 쓸 수 없는 "
    "`annotations/`·`manifests/` 접두사(seal 산출물)에 쓴 것입니다. 정책은 CAS 쪽 키에 "
    "걸려 있으므로 CAS 운영자에게 확인하십시오 — 같은 키로 다시 접속해도 달라지지 않습니다"
)

# STS 에서 새 세션을 받아 다시 시도했는데도 403 이다.
_STALE_CREDENTIAL_HINT = (
    "새 자격증명으로 다시 시도했는데도 403입니다. 잠시 뒤 다시 시도하거나 "
    "`nx.connect()`로 다시 접속하세요"
)

# 정적 자격증명인데 에러 코드도 못 읽은 경우.
# **넘겨짚지 않고 둘 다 짚는다** — 아래 `_MANUAL_CREDENTIAL_DEAD_HINT` 가 코드를 읽은
# 경우를 가져가므로, 여기 남는 것은 "모른다" 뿐이다.
_FORBIDDEN_HINT = (
    "403은 자격증명이 폐기·만료되었거나 정책이 이 동작을 거부했다는 뜻입니다 — "
    "읽기만 되는 키로 쓰기(PutObject)를 불렀거나 `annotations/`·`manifests/` 접두사에 "
    "쓴 것이 아닌지, 키가 아직 유효한지 CAS 운영자와 함께 확인하십시오"
)

# 정적 자격증명이 `InvalidAccessKeyId` 를 받았다 — 정책이 아니라 키가 죽었다.
#
# **만료를 반드시 짚는다.** 「폐기되었거나 정책이 거부했다」만 읽은 사용자는 폐기 여부를
# 확인하고 역할을 살피다가 정작 시계를 보지 않는다. 0.1.14 부터는 갱신할 경로가 아예
# 없으므로 무엇을 해야 하는지(새 키를 받거나 STS 로 바꾸거나)까지 문구가 져야 한다.
_MANUAL_CREDENTIAL_DEAD_HINT = (
    "403인데 정책이 아니라 자격증명 자체가 더는 유효하지 않습니다(InvalidAccessKeyId) — "
    "폐기됐거나 만료됐습니다. **SDK는 정적 자격증명을 갱신하지 않습니다**(0.1.14~, nexus가 "
    "CAS 자격증명을 발급하지 않습니다). CAS 운영자에게 새 키를 받아 `cas_key_id`/`cas_secret`"
    "(또는 CAS_KEY_ID/CAS_SECRET)에 주거나, 스스로 갱신하는 STS 모드"
    "(`nx.connect(cas_sts=CasSts(token_file=...))`)로 바꾸세요"
)

# STS 모드 — 정책 거부. **토큰 누락도 같은 와이어 코드다**(cas `MissingCredentials` → `AccessDenied`).
_STS_POLICY_DENIED_HINT = (
    "403 인데 임시 자격증명의 정책이 이 동작을 거부했습니다(AccessDenied) — 세션 권한은 발급 시점의 "
    "템플릿 키 정책 스냅샷이므로 정책을 바꿨다면 새 세션이 필요합니다. 요청 도중 "
    "x-amz-security-token 헤더가 제거된 경우에도 같은 코드가 납니다(프록시를 확인하십시오)"
)

# STS 모드 — 다시 받았는데 cas 가 같은 세션을 돌려줬고 여전히 403.
_STS_SAME_SESSION_HINT = (
    "STS 에서 다시 받았지만 cas 가 같은 세션을 돌려줬고 여전히 403 입니다 — 자격증명이 아니라 "
    "서명·시계·프록시 쪽 원인을 확인하십시오"
)

# STS 모드 — 강제 갱신 간격 안이라 이번에는 다시 받지 않았다.
_STS_THROTTLED_HINT = (
    "403 인데 60초 안에 이미 임시 자격증명을 다시 받아 이번에는 갱신하지 않았습니다 — "
    "잠시 뒤 다시 시도하십시오"
)

# `_signed_headers` 의 `creds` 를 생략했을 때 쓰는 표식(기존 세 인자 호출 호환).
_FROM_CLIENT = object()


def _build_session(
    pool_maxsize: int = 32, verify: "bool | str" = True
) -> requests.Session:
    session = requests.Session()
    adapter = HTTPAdapter(
        max_retries=_RETRY,
        pool_connections=pool_maxsize,
        pool_maxsize=pool_maxsize,
    )
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    # 이 요청들은 nexus 로그에 남지 않지만(바이트는 CAS로 직접 간다) 같은 클라이언트가
    # 낸 것임을 CAS 쪽 로그에서도 알아볼 수 있어야 한다 — 붙이는 자리를 하나만 두면
    # "SDK가 낸 요청인가"의 답이 두 서버에서 갈린다.
    apply_user_agent(session)
    # CAS는 nexus와 별개 세션이고 `nx.upload`가 파일 바이트를 여기로 직접 PUT한다 —
    # 사내 TLS 검사 장비가 nexus를 가로챈다면 CAS도 대개 같으므로 같은 설정을 받는다.
    # CAS를 http로 접속하면 이 값은 아무 일도 하지 않는다(무해).
    session.verify = verify
    return session


_S3_CODE_RE = re.compile(r"<Code>([^<]{1,64})</Code>")


def _s3_error_code(r: "requests.Response") -> str:
    """cas 에러 응답의 S3 에러 코드. 읽을 수 없으면 빈 문자열.

    **HEAD 응답에는 본문이 없다**(HTTP 규약). 그래서 `head()`의 403 은 언제나 빈 문자열이
    되고, 호출부는 그때 "모른다"로 다뤄야 한다 — `AccessDenied` 로 넘겨짚으면 만료된
    자격증명이 갱신되지 않고, `InvalidAccessKeyId` 로 넘겨짚으면 정책 거부에도 갱신이
    난다(STS 모드). 다행히 `head` 는 `GetObject` 만 필요하고 그 권한은 모든 역할에 있어서, 이 경로의
    403 은 사실상 자격증명 문제뿐이다.

    본문을 통째로 파싱하지 않고 정규식으로 한 요소만 집는다 — cas 의 에러 본문은 짧은
    고정 형식이고, 여기에 XML 파서를 들이면 외부 XML 을 파싱하는 경로가 하나 늘어난다.
    """
    body = r.text or ""
    m = _S3_CODE_RE.search(body)
    return m.group(1) if m else ""


def _sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _hmac(key: bytes, data: bytes) -> bytes:
    return hmac.new(key, data, hashlib.sha256).digest()


def _signing_key(secret: str, date: str, region: str) -> bytes:
    k_date = _hmac(("AWS4" + secret).encode(), date.encode())
    k_region = _hmac(k_date, region.encode())
    k_service = _hmac(k_region, b"s3")
    return _hmac(k_service, b"aws4_request")


def _uri_encode_path(path: str) -> str:
    """CanonicalURI 용 경로 인코딩. **S3 SigV4 단일 인코딩**(boto3 와 동일)이다.

    비예약 문자(영숫자·`-_.~`)와 경로 구분자 `/` 는 보존하고, 나머지(`[` `]` 공백 `+` `#` `%`
    한글 등)는 UTF-8 바이트의 `%XX` 로 바꾼다. `requests` 는 전송 시 이미 경로를 이렇게 인코딩하는데,
    예전에는 **서명이 원본 경로**를 써서 전송값과 어긋나 특수문자 키가 403 이 났다(같은 STS 로 boto3
    는 200). 서명과 전송을 이 함수 하나로 통일해 서버(및 boto3)의 검증과 바이트 일치시킨다.
    """
    return quote(path, safe="/")


def _canonical_request(
    method: str, path: str, host: str, payload_hash: str, amz_date: str
) -> str:
    """SigV4 canonical request. 서버 cas_client.rs::sigv4_auth와 **바이트 동일**해야 한다.

    `path` 는 **이미 `_uri_encode_path` 로 인코딩된 CanonicalURI**여야 한다(호출부가 인코딩해서
    넘긴다 — 전송 경로와 동일한 값이라야 서명이 맞는다).
    SignedHeaders = host;x-amz-content-sha256;x-amz-date (고정), CanonicalQueryString 비어 있음.
    줄바꿈/공백 한 글자라도 다르면 서명 불일치 → 절대 변형 금지.
    """
    return (
        f"{method}\n"
        f"{path}\n"
        f"\n"  # CanonicalQueryString (비어 있음)
        f"host:{host}\n"
        f"x-amz-content-sha256:{payload_hash}\n"
        f"x-amz-date:{amz_date}\n"
        f"\n"  # canonical headers 종료 빈 줄
        f"host;x-amz-content-sha256;x-amz-date\n"
        f"{payload_hash}"
    )


def _total_size(resp) -> "int | None":
    """응답에서 객체의 **전체** 크기를 얻는다. 206이면 Content-Range, 200이면 Content-Length.

    200 분기는 `content-encoding` 헤더가 있으면 None을 돌려준다 — `requests`가 기본으로
    보내는 `Accept-Encoding: gzip, deflate` 때문에 CAS가 압축 응답을 줄 수 있는데, 그러면
    Content-Length는 압축 후 바이트 수라 원본 객체 크기가 아니다. 이 값이 `CasRef.size`를
    거쳐 서버 `sample_assets`에 그대로 박히므로 모르는 채로 두는 편이 낫다(206의
    Content-Range는 항상 실제 전체 크기라 영향 없음).
    """
    cr = resp.headers.get("content-range", "") or ""
    if "/" in cr:
        total = cr.rsplit("/", 1)[1].strip()
        if total.isdigit():
            return int(total)
    if resp.status_code == 200 and not resp.headers.get("content-encoding"):
        cl = resp.headers.get("content-length")
        if cl and str(cl).isdigit():
            return int(cl)
    return None


class CasClient:
    def __init__(
        self,
        cas_url: str,
        key_id: str = "",
        secret: str = "",
        region: str = "cas-default",
        verify: "bool | str" = True,
        sts: "CasSts | None" = None,
    ) -> None:
        if sts is not None and (key_id or secret):
            raise ValueError(
                "CasClient 에 sts 와 key_id/secret 을 함께 줄 수 없습니다 — STS 모드는 "
                "임시 자격증명을 스스로 받습니다"
            )
        self._base = cas_url.rstrip("/")
        self._key_id = key_id
        self._secret = secret
        self._region = region
        # 커넥션 재사용(keep-alive) + 재시도를 위해 클라이언트당 Session 하나.
        self._session = _build_session(verify=verify)
        # STS 모드 공급자. 정적 모드면 None 이고 기존 필드(`_key_id`/`_secret`)를 쓴다.
        self._sts: "StsCredentials | None" = (
            StsCredentials(self._base, sts, verify, forced_min_interval=_STS_FORCED_REFRESH_MIN_INTERVAL_SECS)
            if sts is not None
            else None
        )
        # STS 모드는 데이터 요청의 리다이렉트를 따라가지 않는다 — `requests` 는 다른 호스트로 넘어갈
        # 때 `Authorization` 만 떼고 `x-amz-security-token` 은 그대로 보낸다. cas 는 리다이렉트를
        # 내지 않으므로 3xx 는 에러로 바꾼다(`_refuse_redirect`). 정적 모드는 종전 그대로 따라간다.
        self._follow_redirects = self._sts is None

    def _credentials(self) -> "Credentials | None":
        """서명에 쓸 자격증명을 한 곳에서 얻는다. 없으면 None(익명).

        정적 모드는 필드로 만든 값(만료 없음, 세션 토큰 없음)이다. **요청할 때마다 부른다** —
        403 재시도가 갈아 끼운 값으로 다시 서명되게 하려는 것이다.
        """
        if self._sts is not None:
            return self._sts.current()
        if self._key_id and self._secret:
            return Credentials(self._key_id, self._secret, "", float("inf"))
        return None

    def ensure_credentials(self) -> None:
        """STS 모드면 지금 한 번 받아 설정 오류를 드러낸다. 정적 모드는 아무것도 하지 않는다."""
        if self._sts is not None:
            self._sts.current()

    def _host(self) -> str:
        # 스킴만 제거, 포트는 유지 (서버 sigv4_auth와 동일).
        return self._base.removeprefix("http://").removeprefix("https://")

    def _signed_headers(
        self, method: str, path: str, body: bytes, creds: "object" = _FROM_CLIENT
    ) -> dict:
        """SigV4 Authorization/x-amz-date/x-amz-content-sha256 헤더. 자격증명 없으면 {}.

        서버 cas_client.rs::sigv4_auth 그대로 (host;x-amz-content-sha256;x-amz-date 서명).
        세션 토큰이 있으면 `x-amz-security-token` 을 **서명 대상 밖에** 더한다 — cas 는 그 헤더의
        존재와 값만 보고(`sigv4.rs::check_key_usable`), 서명 대상에 넣으면 서버와의 바이트 동일
        제약이 깨진다. `creds` 를 생략하면 `_credentials()` 를 쓴다(기존 세 인자 호출 호환).
        """
        if creds is _FROM_CLIENT:
            creds = self._credentials()
        if creds is None:
            return {}
        assert isinstance(creds, Credentials)
        now = datetime.now(timezone.utc)
        date = now.strftime("%Y%m%d")
        amz_date = now.strftime("%Y%m%dT%H%M%SZ")
        payload_hash = _sha256_hex(body)

        canonical_request = _canonical_request(
            method, path, self._host(), payload_hash, amz_date
        )
        credential_scope = f"{date}/{self._region}/s3/aws4_request"
        string_to_sign = (
            f"AWS4-HMAC-SHA256\n"
            f"{amz_date}\n"
            f"{credential_scope}\n"
            f"{_sha256_hex(canonical_request.encode())}"
        )
        signature = _hmac(
            _signing_key(creds.secret, date, self._region),
            string_to_sign.encode(),
        ).hex()
        auth = (
            f"AWS4-HMAC-SHA256 Credential={creds.key_id}/{credential_scope}, "
            f"SignedHeaders=host;x-amz-content-sha256;x-amz-date, "
            f"Signature={signature}"
        )
        headers = {
            "Authorization": auth,
            "x-amz-date": amz_date,
            "x-amz-content-sha256": payload_hash,
        }
        if creds.session_token:
            headers["x-amz-security-token"] = creds.session_token
        return headers

    def _retry_with_fresh_credentials(
        self, failed: "Credentials | None", error_code: str = ""
    ) -> bool:
        """403 을 받았을 때 STS 임시 자격증명을 갈아 끼운다.

        **갱신하는 것은 STS 모드뿐이다**(0.1.14~). 정적 자격증명은 갈아 끼울 곳이 없어
        그대로 `False` 를 돌려주고, 호출부는 원래의 403 을 실패로 올린다. 이전 판에는
        403 에 nexus 발급을 요청하는 콜백이 걸려 있었는데, nexus 가 CAS 자격증명을
        발급하지 않게 되면서 그 경로가 없어졌다.

        판정 순서(이미 갱신됐는가 → 간격 → 발급)는 `StsCredentials.force_refresh` 가
        자기 락 안에서 한다. 정책 거부(`AccessDenied`)는 여기서 끝난다 — 자격증명을 새로
        받아도 정책은 그대로이고, cas 가 그 구분을 S3 에러 코드로 준다(정책 거부는
        `AccessDenied`, 폐기·만료된 키는 `InvalidAccessKeyId`).

        `error_code` 가 빈 문자열이면(HEAD 응답처럼 본문이 없는 경우) 갱신을 시도한다 —
        모르는 것을 정책 거부로 넘겨짚으면 만료된 자격증명이 영영 갱신되지 않는다.
        """
        if self._sts is None:
            # 정적 자격증명은 갱신할 곳이 없다(0.1.14~). 403 은 그대로 올라간다.
            return False
        if error_code == "AccessDenied" or failed is None:
            return False
        return self._sts.force_refresh(failed)

    def _forbidden_hint(
        self,
        status_code: int,
        error_code: str = "",
        failed: "Credentials | None" = None,
        retried_with: "Credentials | None" = None,
    ) -> str:
        """403 에러 메시지 뒤에 붙일 설명. 403이 아니면 빈 문자열.

        "자격증명이 깨졌다"와 "정책이 막았다"는 사용자가 할 일이 전혀 다르다 — 앞은
        재접속, 뒤는 역할 승격이나 다른 접두사 선택이다. 전에는 상태 코드만으로 구별되지
        않는다고 보고 클라이언트가 아는 것(예산을 이미 썼는가)으로 넘겨짚었는데,
        **cas 는 그 구분을 S3 에러 코드로 이미 주고 있었다.** 이제 그 값을 그대로 읽는다.

        **정적 자격증명은 갱신 경로가 없다**(0.1.14~). 재시도를 하지 않을 뿐이지 죽는
        이유가 다르지 않으므로 코드로 가른다 — `InvalidAccessKeyId` 면 만료·폐기를 짚어
        주고(`_MANUAL_CREDENTIAL_DEAD_HINT`), 코드를 못 읽었을 때만 둘 다 짚는 옛
        문구(`_FORBIDDEN_HINT`)로 떨어진다.

        STS 모드: 정책 거부면 `_STS_POLICY_DENIED_HINT`, 갱신하지 않았으면(간격)
        `_STS_THROTTLED_HINT`, 갱신했는데 같은 `key_id` 면 `_STS_SAME_SESSION_HINT`, 그 밖은
        `_STALE_CREDENTIAL_HINT`. `failed` 는 첫 요청의 자격증명, `retried_with` 는 재시도의 것이다.
        """
        if status_code != 403:
            return ""
        if self._sts is not None:
            if error_code == "AccessDenied":
                return f" — {_STS_POLICY_DENIED_HINT}"
            if failed is None or retried_with is None:
                return f" — {_STS_THROTTLED_HINT}"
            if failed.key_id == retried_with.key_id:
                return f" — {_STS_SAME_SESSION_HINT}"
            return f" — {_STALE_CREDENTIAL_HINT}"
        if error_code == "AccessDenied":
            return f" — {_POLICY_DENIED_HINT}"
        if error_code == "InvalidAccessKeyId":
            return f" — {_MANUAL_CREDENTIAL_DEAD_HINT}"
        return f" — {_FORBIDDEN_HINT}"

    def _refuse_redirect(self, r: "requests.Response", method: str, bucket: str, key: str) -> None:
        """STS 모드에서 3xx 응답을 에러로 바꾼다. 따라가지 않았으므로 `r.ok` 가 참인 채로 남는다."""
        if self._sts is None or not 300 <= r.status_code < 400:
            return
        raise NexusCasError(
            f"CAS {method} 가 리다이렉트({r.status_code})를 돌려줬습니다: {bucket}/{key} → "
            f"{r.headers.get('Location', '')} — STS 모드는 세션 토큰을 다른 위치로 보내지 않도록 "
            "리다이렉트를 따라가지 않습니다. cas_url 을 리다이렉트 없는 주소(스킴·호스트·포트)로 지정하십시오"
        )

    def head(self, bucket: str, key: str) -> dict | None:
        path = _uri_encode_path(f"/{bucket}/{key}")

        def _request():
            creds = self._credentials()
            return creds, self._session.head(
                f"{self._base}{path}", headers=self._signed_headers("HEAD", path, b"", creds)
            )

        used, r = _request()
        failed = None
        if r.status_code == 403 and self._retry_with_fresh_credentials(used, _s3_error_code(r)):
            failed = used
            used, r = _request()
        self._refuse_redirect(r, "HEAD", bucket, key)
        if r.status_code == 404:
            return None
        if not r.ok:
            raise NexusCasError(
                f"CAS HEAD failed ({r.status_code}): {bucket}/{key} — {r.text[:300]}"
                f"{self._forbidden_hint(r.status_code, _s3_error_code(r), failed, used if failed else None)}"
            )
        etag = r.headers.get("ETag", r.headers.get("etag", "")).strip('"')
        hash_hex = r.headers.get("x-cas-hash", "") or etag
        size_str = r.headers.get("content-length", "")
        return {
            "hash_hex": hash_hex,
            "size": int(size_str) if size_str else None,
            "content_type": r.headers.get("content-type"),
        }

    def read_head(self, bucket: str, key: str, max_bytes: int) -> "dict | None":
        """객체 앞부분 `max_bytes`만 받아 bytes와 응답 헤더 정보를 돌려준다. 404면 None.

        **Range를 지원하지 않는 CAS에서도 동작한다.** 206이면 요청한 만큼만 오고, 서버가
        Range를 무시하고 200으로 전체를 보내면 예산만큼 읽고 연결을 닫는다 — 전송은 거기서
        끊긴다. 그래서 CAS의 Range 지원 여부를 사전에 알 필요가 없다.

        Range 헤더는 SigV4 SignedHeaders(host;x-amz-content-sha256;x-amz-date)에 없으므로
        서명에 영향을 주지 않는다(`_canonical_request` 참조).

        `iter_content`로 읽는다 — `raw.read`는 Content-Encoding 디코딩을 건너뛰어 압축
        전송이 걸리면 깨진 바이트를 돌려준다. 첫 청크가 예산보다 작게 올 수 있으므로
        예산에 닿거나 스트림이 끝날 때까지 누적한다.

        `hash_hex`는 `head()`와 같은 규칙 — `x-cas-hash`가 없으면 `ETag`로 폴백한다(CAS가
        GET에는 ETag만 주는 배치가 있다). 여기서 빠지면 리치 ref가 안 되어 `flush`가 매
        샘플마다 HEAD를 한 번씩 더 보내고, 이 기능이 노리는 왕복 절감이 조용히 사라진다.

        403이면 `_retry_with_fresh_credentials`로 한 번 재시도한다(`head`/`get`/`put`과 동일).
        """
        path = _uri_encode_path(f"/{bucket}/{key}")

        def _request():
            creds = self._credentials()
            headers = self._signed_headers("GET", path, b"", creds)
            headers["Range"] = f"bytes=0-{max_bytes - 1}"
            return creds, self._session.get(
                f"{self._base}{path}",
                headers=headers,
                stream=True,
                allow_redirects=self._follow_redirects,
            )

        used, r = _request()
        failed = None
        if r.status_code == 403:
            # 첫 스트리밍 응답은 재시도 여부를 판정하기 전이라도(강제 STS 갱신이 예외를
            # 던지는 경우 포함) 반드시 닫는다 — 열어 둔 채로 예외가 올라가면 연결이 새어
            # 나간다.
            try:
                retry = self._retry_with_fresh_credentials(used, _s3_error_code(r))
            except BaseException:
                r.close()
                raise
            if retry:
                r.close()
                failed = used
                used, r = _request()
        try:
            self._refuse_redirect(r, "GET(range)", bucket, key)
            if r.status_code == 404:
                return None
            if not r.ok:
                raise NexusCasError(
                    f"CAS GET(range) failed ({r.status_code}): {bucket}/{key} — {r.text[:300]}"
                    f"{self._forbidden_hint(r.status_code, _s3_error_code(r), failed, used if failed else None)}"
                )
            buf = bytearray()
            for chunk in r.iter_content(8192):
                buf.extend(chunk)
                # `>`이지 `>=`가 아니다: 206 응답의 바디가 정확히 max_bytes였을 때 `>=`면
                # 마지막 청크를 받은 그 반복에서 바로 break해 스트림이 다 온 것처럼 보이지만
                # 실제로는 서버가 아직 EOF를 보내지 않았을 수 있다 — 그 상태에서 close()하면
                # 다 받은 응답을 미완성으로 취급해 재사용 가능한 keep-alive 연결을 끊게 된다.
                # buf[:max_bytes] 슬라이스가 최대 한 청크(8192B)의 초과분은 어차피 잘라내므로
                # 200 응답(전체를 다 보내는 경우)은 여전히 한 청크 여유로 일찍 멈춘다.
                if len(buf) > max_bytes:
                    break
            etag = r.headers.get("ETag", r.headers.get("etag", "")).strip('"')
            hash_hex = r.headers.get("x-cas-hash", "") or etag
            return {
                "data": bytes(buf[:max_bytes]),
                "hash_hex": hash_hex or None,
                "size": _total_size(r),
                "content_type": r.headers.get("content-type"),
            }
        finally:
            r.close()

    def put(
        self,
        bucket: str,
        key: str,
        data: bytes,
        content_type: str = "application/octet-stream",
    ) -> None:
        path = _uri_encode_path(f"/{bucket}/{key}")

        def _request():
            creds = self._credentials()
            headers = self._signed_headers("PUT", path, data, creds)
            headers["Content-Type"] = content_type  # 서명 대상 아님(SignedHeaders에 미포함)
            return creds, self._session.put(
                f"{self._base}{path}",
                data=data,
                headers=headers,
                allow_redirects=self._follow_redirects,
            )

        used, r = _request()
        failed = None
        if r.status_code == 403 and self._retry_with_fresh_credentials(used, _s3_error_code(r)):
            failed = used
            used, r = _request()
        self._refuse_redirect(r, "PUT", bucket, key)
        if not r.ok:
            raise NexusCasError(
                f"CAS PUT failed ({r.status_code}): {bucket}/{key} — {r.text[:300]}"
                f"{self._forbidden_hint(r.status_code, _s3_error_code(r), failed, used if failed else None)}"
            )

    def get(self, bucket: str, key: str, timeout: "float | None" = None) -> bytes:
        """객체 전체를 받는다. 실패하면 `NexusCasError`에 `status_code`를 실어 올린다 —
        호출부(`Dataset.to_df`)가 404와 403을 다른 말로 안내해야 해서다."""
        path = _uri_encode_path(f"/{bucket}/{key}")

        def _request():
            creds = self._credentials()
            return creds, self._session.get(
                f"{self._base}{path}",
                headers=self._signed_headers("GET", path, b"", creds),
                allow_redirects=self._follow_redirects,
                timeout=timeout,
            )

        used, r = _request()
        failed = None
        if r.status_code == 403 and self._retry_with_fresh_credentials(used, _s3_error_code(r)):
            failed = used
            used, r = _request()
        self._refuse_redirect(r, "GET", bucket, key)
        if not r.ok:
            raise NexusCasError(
                f"CAS GET failed ({r.status_code}): {bucket}/{key} — {r.text[:300]}"
                f"{self._forbidden_hint(r.status_code, _s3_error_code(r), failed, used if failed else None)}",
                status_code=r.status_code,
                server_message=(r.text or "")[:300] or None,
            )
        return r.content

    @staticmethod
    def hash_bytes(data: bytes) -> str:
        return blake3.blake3(data).hexdigest()

    @staticmethod
    def content_type(path: Path) -> str:
        ct, _ = mimetypes.guess_type(str(path))
        return ct or "application/octet-stream"
