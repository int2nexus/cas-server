from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class CasRef:
    bucket: str
    key: str
    hash_hex: str | None = None
    size: int | None = None
    content_type: str | None = None
    width: int | None = None
    height: int | None = None


FileRef = Path | CasRef


def _parse_ref(src: str | Path) -> FileRef:
    # URL 의 %XX 는 풀어서 원래 key 로 쓴다. 안 풀면 CAS 서명이 한 번 더 인코딩해(%20 → %2520)
    # 엉뚱한 객체를 찾는다(SDK 0.1.16 부터 서명 경로를 인코딩하므로). 서버가 key 에 '%' 를
    # 금지하므로(`validate_key`) 경로의 %XX 는 항상 인코딩이라 풀어도 모호하지 않다.
    from urllib.parse import unquote, urlparse
    s = str(src)
    if s.startswith("s3://"):
        without_scheme = s[5:]
        bucket, _, key = without_scheme.partition("/")
        return CasRef(bucket=bucket, key=unquote(key))
    if s.startswith("http://") or s.startswith("https://"):
        path = urlparse(s).path.lstrip("/")
        bucket, _, key = path.partition("/")
        return CasRef(bucket=bucket, key=unquote(key))
    return Path(s)


def _coerce_cas_ref(v: "CasRef | str | Path", what: str) -> CasRef:
    if isinstance(v, CasRef):
        return v
    ref = _parse_ref(v)  # str → CasRef(url) 또는 Path(로컬)
    if isinstance(ref, CasRef):
        return ref
    raise ValueError(
        f"{what}는 CAS 참조여야 합니다 (CasRef 또는 s3://·http(s):// URL). "
        f"로컬 경로는 받지 않습니다 — nx.upload(...)로 먼저 CAS에 올린 뒤 반환된 ref를 넘기세요."
    )


@dataclass
class Sample:
    """등록할 학습 단위. 이미지/asset은 **CAS에 이미 있는 ref**만 받는다.

    - `image`: `CasRef`(nx.upload 반환) 또는 `s3://`·`http(s)://` URL. 로컬 경로는
      받지 않는다 — `nx.upload(...)`로 먼저 CAS에 올린 뒤 반환된 ref를 넘길 것.
    - `assets`: image 외 추가 asset(예: depth map). `{role: ref}` 형태, ref는 image와 동일한
      규칙(CAS ref 전용). `"image"` 키는 예약되어 있어 쓸 수 없다(image= 파라미터를 쓸 것).
    - `annotation`: GT는 nexus DB에 인라인 저장되므로 로컬 JSON 경로 / dict / URL 모두 허용
      (이미지와 달리 CAS 업로드 대상이 아니라 그대로 읽어 전송한다).
    """
    image: "CasRef | str | None" = None
    annotation: "str | Path | dict | None" = None
    assets: "dict[str, CasRef | str] | None" = None
    split: str | None = None
    tags: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        if self.image is None and self.annotation is None:
            raise ValueError("Sample requires at least image or annotation")
        # 문자열 하나를 넘기면 단일 원소 리스트로 자동 변환 (서버는 배열을 기대).
        if isinstance(self.tags, str):
            self.tags = [self.tags]
        self._image_ref: CasRef | None = (
            _coerce_cas_ref(self.image, "Sample.image") if self.image is not None else None
        )
        if self.assets and "image" in self.assets:
            raise ValueError(
                "Sample.assets에 'image' 키는 예약되어 있습니다 — Sample(image=..)를 쓰세요"
            )
        self._asset_refs: dict[str, CasRef] = {
            role: _coerce_cas_ref(v, f"Sample.assets[{role!r}]")
            for role, v in (self.assets or {}).items()
        }
        # annotation: dict(인라인 GT)은 그대로, 그 외(경로/URL)는 _parse_ref
        if isinstance(self.annotation, dict):
            self._annotation_ref: "FileRef | dict | None" = self.annotation
        elif self.annotation is not None:
            self._annotation_ref = _parse_ref(self.annotation)
        else:
            self._annotation_ref = None
