from __future__ import annotations
from .instance import Instance, raw_row_issues
from .labels import Label, _issue
from ._types import Issue, NexusValidationError, raise_for_issues


def _duplicate_id_issues(name: str, ids: list) -> "list[Issue]":
    """같은 비어 있지 않은 id 의 둘째 이후 행마다 `<그룹>[<번호>].id`. `None`·`""` 은 id 없음이다."""
    seen: set = set()
    out: list = []
    for i, id in enumerate(ids):
        if not isinstance(id, str) or id == "":
            continue
        if id in seen:
            p = f"{name}[{i}].id"
            out.append(_issue(p, "duplicate_id", f"{p}: 그룹 안에서 id '{id}' 가 겹침"))
        seen.add(id)
    return out


def _not_instance(row: str, inst) -> Issue:
    # 그룹 행 자리에는 Instance 만 — Label 을 바로 넣으면 행에 id·label 이 없어 서버가 그 행을 버리고,
    # dict 를 넣으면 AttributeError 로 죽는다. 사유·경로는 서버가 원소 수준 공통 필드 위반에 쓰는 것(`common_field`,
    # `<그룹>[<i>]`)과 같다 — 사유 목록 밖의 코드를 만들지 않는다.
    return _issue(row, "common_field",
                  f"{row}: 그룹 행은 Instance 여야 함, {type(inst).__name__} 받음 — "
                  "Label 은 nx.Instance(label, [Label, ...]) 로 감싸 넣으십시오")


def _require_instance_args(where: str, items) -> list:
    """편집 메서드의 인자 검사 — 행 규칙 위반이 아니라 잘못된 호출이라 `TypeError` 다."""
    for inst in items:
        if not isinstance(inst, Instance):
            raise TypeError(
                f"{where} 는 Instance 만 받습니다, {type(inst).__name__} 받음 — "
                "Label 은 nx.Instance(label, [Label, ...]) 로 감싸 넣으십시오")
    return list(items)


class LabelGroup:
    """선언된 `group` 종류의 그룹. 행(`Instance`)은 `instances`(읽기 전용 tuple)·`g[i]`·`len(g)`·순회로 읽고,
    편집은 `add`·`remove`·`replace` 셋으로만 한다(넣기 전에 검사하므로 틀린 행이 그룹에 들어가지 않는다).

    생성자는 검사하지 않는다 — 서버에서 읽은 옛 데이터(규칙에 어긋난 행 포함)도 열 수 있어야 해서다. 직접 만든
    그룹은 `AnnotatedSample` 에 대입할 때 검사되고, 넣은 뒤 행 속성을 고친 것은 `save()` 가 검사한다."""

    def __init__(self, instances=()):
        self._instances: list = list(instances)
        # `add`·`replace` 오류 경로의 그룹 이름. AnnotatedSample 이 스스로 만든 그룹(로드·clear_field·add_labels 의 새
        # 그룹)에만 채운다 — 사용자가 만들어 대입한 그룹은 고치지 않아 "" 이다(대입·save() 검사는 필드 이름을 넘긴다).
        self._name: str = ""

    @property
    def instances(self) -> tuple:
        """행 목록(읽기 전용 tuple). 편집은 `add`·`remove`·`replace`."""
        return tuple(self._instances)

    @classmethod
    def from_list(cls, rows: list) -> "LabelGroup":
        return cls([Instance.from_row(r) for r in rows])

    def to_list(self, name: str = "") -> list:
        self._require_instances(name)
        return [i.to_dict(f"{name}[{n}]") for n, i in enumerate(self._instances)]

    @staticmethod
    def _row_issues(name: str, i: int, inst) -> "list[Issue]":
        row = f"{name}[{i}]"
        if not isinstance(inst, Instance):
            return [_not_instance(row, inst)]
        return inst.issues(row)

    def _group_rule_issues(self, name: str, insts: list) -> "list[Issue]":
        """그룹 규칙(4-2) — 그룹 안 id 유일. container 는 행마다 component 하나·같은 타입을 더한다."""
        return _duplicate_id_issues(name, [i.id if isinstance(i, Instance) else None for i in insts])

    def issues(self, name: str = "") -> "list[Issue]":
        """이 그룹 전체의 위반(행 규칙 + 그룹 규칙). 저장된 행과의 짝짓기는 서버 몫이라 하지 않는다 — 보내는 그룹은
        통째로 검사한다. GT spec 4 장: 그룹 안 id 는 유일해야 한다(중복이면 id 로 행을 가르는 merge·add_labels·CVAT 왕복이
        한 행만 다룬다). save() 는 보내는 그룹만 검증하므로 중복이 있는 레거시 그룹도 열고 읽을 수 있다."""
        out: list = []
        for i, inst in enumerate(self._instances):
            out.extend(self._row_issues(name, i, inst))
        out.extend(self._group_rule_issues(name, self._instances))
        return out

    def _checked(self, new: list, fresh, name: "str | None" = None) -> list:
        """편집 결과 `new` 를 검사한다 — 새로 넣는 행(`fresh` 번호)의 행 규칙과 결과 그룹 전체의 그룹 규칙(설계 6-2).
        이미 있던 행의 행 규칙은 보지 않는다(옛 틀린 행이 남은 그룹에도 맞는 행은 더할 수 있다 — 그 그룹을 보내는
        `save()` 는 그룹 전체를 검사한다). 위반이 있으면 아무것도 바꾸지 않고 `NexusValidationError`."""
        name = self._name if name is None else name
        out: list = []
        for i in fresh:
            out.extend(self._row_issues(name, i, new[i]))
        out.extend(self._group_rule_issues(name, new))
        raise_for_issues(out)
        return new

    def add(self, instance: Instance) -> None:
        """행 하나를 끝에 더한다. 그 행의 규칙과 더한 뒤 그룹의 규칙(id 유일·container)을 넣기 전에 검사하고, 위반이면
        그룹은 그대로이고 `NexusValidationError`."""
        _require_instance_args("add()", [instance])
        new = self._instances + [instance]
        self._instances = self._checked(new, [len(new) - 1])

    def remove(self, instance_id: str) -> None:
        """그 id 의 행을 뺀다(같은 id 가 여럿인 옛 그룹이면 모두). 없는 id 는 `KeyError` — id 없는 행은
        `replace` 로 뺀다. 0.1.30 까지는 instance 객체를 받았으므로 객체가 오면 id 를 넘기라는 `TypeError` 다."""
        if isinstance(instance_id, Instance):
            raise TypeError(
                "remove() 는 instance 객체가 아니라 id 를 받습니다(SDK 0.1.31) — g.remove(inst.id) 로 부르십시오")
        if not isinstance(instance_id, str) or instance_id == "":
            raise KeyError(instance_id)
        kept = [i for i in self._instances if not (isinstance(i, Instance) and i.id == instance_id)]
        if len(kept) == len(self._instances):
            raise KeyError(instance_id)
        self._instances = kept

    def replace(self, instances) -> None:
        """행 전체를 바꾼다. 전부 검사한 뒤 한 번에 바꾸고, 위반이 하나라도 있으면 그룹은 그대로다."""
        if not isinstance(instances, (list, tuple)):
            raise TypeError(f"replace() 는 Instance 의 list 를 받습니다, {type(instances).__name__} 받음")
        new = _require_instance_args("replace()", instances)
        self._instances = self._checked(new, range(len(new)))

    def validate(self, name: str = "") -> None:
        self._require_instances(name)
        raise_for_issues(self.issues(name))

    def _require_instances(self, name: str = "") -> None:
        # 그룹 행 자리에는 Instance 만 — to_list() 가 AttributeError 로 죽기 전에 막는다.
        for i, inst in enumerate(self._instances):
            if not isinstance(inst, Instance):
                raise_for_issues([_not_instance(f"{name}[{i}]", inst)])

    def duplicate_ids(self) -> list:
        """이 그룹 안에서 두 번 이상 나오는 id(정렬)."""
        seen, dup = set(), set()
        for i in self._instances:
            if isinstance(i, Instance):
                (dup if i.id in seen else seen).add(i.id)
        return sorted(dup, key=str)

    def __getitem__(self, idx): return self._instances[idx]
    def __len__(self): return len(self._instances)
    def __iter__(self): return iter(tuple(self._instances))


class LabelContainer(LabelGroup):
    """각 원소는 단일 component이고 모두 같은 타입이다."""

    @property
    def labels(self) -> list:
        return [next(iter(i.components.values())) for i in self._instances]

    @property
    def element_type(self) -> str | None:
        for i in self._instances:
            for lab in i.components.values():
                return lab.type if isinstance(lab, Label) else None
        return None

    def _group_rule_issues(self, name: str, insts: list) -> "list[Issue]":
        out = super()._group_rule_issues(name, insts)
        types: list = []
        for i, inst in enumerate(insts):
            if not isinstance(inst, Instance):
                continue
            comps = list(inst.components.values())
            if len(comps) != 1:
                p = f"{name}[{i}]"
                out.append(_issue(p, "container_component_count",
                                  f"{p}: container 그룹의 행은 component 가 정확히 1개여야 함, {len(comps)}개 받음"))
            elif isinstance(comps[0], Label):
                types.append(comps[0].type)
            # Label 이 아닌 component 는 행 규칙(`Instance.issues`)이 `invalid_type` 으로 낸다 — 타입을 모으지 않는다.
        distinct = sorted({t for t in types if isinstance(t, str)})
        if len(distinct) > 1:
            out.append(_issue(name, "container_mixed_types",
                              f"{name}: container 그룹의 행은 모두 같은 component 타입이어야 함, {', '.join(distinct)} 받음"))
        return out


class RawGroup:
    """미선언 그룹. 원본을 손대지 않고 그대로 왕복한다 — 읽기 전용이라 편집 메서드가 없다(설계 6-1).

    `raw` 를 고쳐도 `AnnotatedSample.save()` 는 이 그룹을 보내지 않는다(서버에서 읽은 값을 그대로 둔다). 편집하려면
    그룹 종류를 선언해 `LabelGroup`/`LabelContainer` 로 읽는다. `clear_field` 로 비운 것만 빈 그룹으로 보낸다."""
    def __init__(self, raw):
        self.raw = raw
        # clear_field 가 비운 그룹이면 True — save() 가 이것만 빈 배열로 보낸다.
        self._cleared = False

    def to_raw(self):
        return self.raw

    def issues(self, name: str = "") -> "list[Issue]":
        """배열이면 행 규칙과 `duplicate_id`, 배열이 아니거나 객체가 아닌 원소는 `common_field`."""
        # 서버 `parser_issue` 와 같이 사유는 common_field, 경로는 그룹(`g`)·원소(`g[i]`)다.
        if not isinstance(self.raw, list):
            return [_issue(name, "common_field", f"{name}: 그룹은 배열이어야 함")]
        out: list = []
        ids: list = []
        for i, row in enumerate(self.raw):
            p = f"{name}[{i}]"
            if not isinstance(row, dict):
                out.append(_issue(p, "common_field", f"{p}: 그룹의 원소는 객체여야 함"))
                ids.append(None)
                continue
            out.extend(raw_row_issues(p, row))
            ids.append(row.get("id"))
        out.extend(_duplicate_id_issues(name, ids))
        return out

    def validate(self, name: str = "") -> None:
        raise_for_issues(self.issues(name))
