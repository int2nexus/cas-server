from __future__ import annotations

import copy
import json
import warnings
from collections.abc import Mapping
from pathlib import Path

from .meta import Meta
from .group import LabelGroup, LabelContainer, RawGroup
from .instance import Instance
from ._types import NexusError, NexusValidationError, raise_for_issues

_KIND = {"group": LabelGroup, "container": LabelContainer}
_MISSING = object()
_ZERO_REPORT = {
    "instances": 0,
    "skipped": 0,
    "skipped_reasons": {"missing_label": 0, "not_an_object": 0, "group_not_an_array": 0},
}
# explorer·샘플 단건 응답에서 서버가 annotation 위에 얹는 코어 키. 행에서 이것을 떼면 annotation 이다
# (서버 `flatten_sample_response` — 이름이 겹치면 코어가 그룹을 이긴다).
_CORE_KEYS = ("sample_id", "split", "tags", "created_at", "image_url", "thumbnail_url")


class SampleSummary(dict):
    """`ds.samples(include_annotations=False)` 의 행 — annotation 없는 코어 필드만 담은 **읽기 전용** dict.

    이 행에는 그룹이 없어 저장 경로에 넘기면 그 버전의 그룹이 지워진다(통째 교체는 받은 dict 전체로 바꾼다).
    그래서 고칠 수 없게 두고 `AnnotatedSample.from_row` 가 받지 않는다. 고쳐 쓸 사본이 필요하면 `dict(row)`.

    **읽기 전용은 최상위 키뿐이다** — `row["meta"]["k"] = v`·`row["tags"].append(x)` 처럼 안쪽 dict·list 를 고치는 것은
    막지 않는다. 안쪽 값을 읽기 전용 타입으로 감싸면 `isinstance(row["meta"], dict)`·`json.dumps(row)` 가 깨지고, 이 타입이
    막으려는 것(저장 경로로 넘기기)은 안쪽 값과 무관하게 타입으로 거부된다. `dict(row)` 는 얕은 사본이라 안쪽 값을 원래
    행과 공유하므로, 안쪽까지 고칠 사본은 `copy.deepcopy(dict(row))` 로 만든다."""

    __slots__ = ()

    def _read_only(self, *args, **kwargs):
        raise TypeError(
            "SampleSummary 는 읽기 전용입니다(include_annotations=False 의 행) — 사본은 dict(row) 로 만드십시오"
        )

    __setitem__ = __delitem__ = __ior__ = _read_only
    update = pop = popitem = setdefault = clear = _read_only

    def __reduce__(self):
        # pickle·copy 가 빈 객체에 __setitem__ 으로 채우려다 막히지 않게 생성자로 되살린다.
        return (type(self), (dict(self),))


def _reject_sample_summary(value, where: str) -> None:
    if isinstance(value, SampleSummary):
        raise TypeError(
            f"{where}: samples(include_annotations=False) 의 행은 저장할 수 없습니다 — 그 행에는 그룹이 없어 "
            "통째 교체가 그 버전의 그룹을 지웁니다. load_sample() 이나 get_annotation() 으로 받은 것을 고쳐 저장하십시오"
        )


def _returned_sample(rows, sample_id) -> dict:
    """샘플 태그 일괄 경로의 응답에서 그 샘플 행을 찾는다. 서버는 없거나 삭제된 샘플을 결과에서
    조용히 빼므로, 빠졌으면 저장되지 않은 것이다."""
    for r in rows or []:
        if isinstance(r, dict) and str(r.get("sample_id")) == str(sample_id):
            return r
    raise NexusError(
        f"sample {sample_id} 이(가) 없거나 삭제돼 태그를 저장하지 못했습니다", status_code=404
    )


class AnnotatedSample:
    def __init__(self, sample_id, meta: Meta, groups: dict, dataset=None, had_meta=True,
                 meta_was_null=False, group_kinds: dict | None = None, tags=None, split=None):
        self.sample_id = sample_id
        self.meta = meta
        self.groups = groups
        self._dataset = dataset
        self.had_meta = had_meta
        # 저장 meta 가 null 이었으면 편집 가능한 빈 맵으로 들고, 변경이 없으면 null 로 되돌린다.
        self._meta_was_null = meta_was_null
        # save() 가 비교할 기준. None 이면 기준이 없어 전부 보낸다(from_dict 가 채운다).
        self._baseline = None
        # 만들 때 받은 그룹 종류 — dataset 핸들이 없을 때 대입·add_labels 가 선언 종류로 본다(`_declared_kind`).
        self._group_kinds: dict = dict(group_kinds) if group_kinds else {}
        # 핸들 없는 사본(`copy()`)이 선언 종류를 읽을 핸들. 저장에는 쓰지 않는다.
        self._kinds_dataset = None
        # 샘플 태그. 행에서 만든 경우만 리스트이고(`from_row`), 태그를 모르는 경로는 None — 그때
        # save() 는 태그를 다루지 않는다. meta 처럼 샘플에 붙어 버전 간에 공유된다.
        self.tags = list(tags) if tags is not None else None
        self._baseline_tags = list(self.tags) if self.tags is not None else None
        self._split = split

    @property
    def split(self):
        """샘플 split. 읽기 전용이다 — save() 가 쓰지 않는다."""
        return self._split

    @classmethod
    def from_dict(cls, ann: dict, group_kinds: dict, *, sample_id=None, dataset=None) -> "AnnotatedSample":
        """dict(annotation JSON)를 객체로 바꾸는 **쓰기 입구**다. 바꾼 뒤 그 자리에서 검사하고(`validate()` — 위반 전부를
        경로와 함께 `NexusValidationError.errors` 로), 통과한 것만 돌려준다. 적재용 샘플은 이것(또는 `from_file`)으로
        만들어 `nx.Sample(annotation=...)` 에 넘긴다.

        `group_kinds`(`{"그룹": "group" | "container"}`)에 선언된 이름은 `LabelGroup`/`LabelContainer` 로, 나머지는
        `RawGroup` 으로 읽고 각각의 규칙으로 검사한다(`RawGroup` 은 종류와 무관한 규칙 — 배열·행 규칙·그룹 안 id 유일).
        서버에서 읽어 오는 경로(`load_sample`·`iter_samples` 등)는 이 검사를 하지 않는다 — 이미 저장된 옛 데이터도 열 수
        있어야 해서다."""
        if not isinstance(ann, Mapping):
            raise TypeError(f"AnnotatedSample.from_dict() 는 dict 를 받습니다, {type(ann).__name__} 받음")
        obj = cls._from_server(ann, group_kinds, sample_id=sample_id, dataset=dataset)
        obj.validate()
        return obj

    @classmethod
    def from_file(cls, path, group_kinds: dict) -> "AnnotatedSample":
        """annotation JSON 파일을 읽어 `from_dict` 로 바꾼다(같은 검사). 파일 최상위는 객체여야 한다."""
        data = json.loads(Path(path).read_bytes())
        if not isinstance(data, dict):
            raise NexusValidationError(
                f"{path}: annotation 파일의 최상위는 JSON 객체여야 합니다, {type(data).__name__} 받음")
        return cls.from_dict(data, group_kinds)

    @staticmethod
    def _parse_groups(ann, group_kinds: dict) -> dict:
        groups: dict = {}
        for key, val in ann.items():
            if key == "meta":
                continue
            kind = group_kinds.get(key)
            # 배열이 아니거나 객체가 아닌 원소가 있으면 행으로 읽을 수 없다 — `RawGroup` 으로 남겨 열고(로드),
            # 쓰기 입구는 그 issues(`<그룹>`·`<그룹>[i]` common_field, 서버와 같은 경로·사유)로 거절한다.
            if kind in _KIND and isinstance(val, list) and all(isinstance(r, dict) for r in val):
                groups[key] = _KIND[kind].from_list(val)
                groups[key]._name = key
            else:
                groups[key] = RawGroup(val)
        return groups

    @classmethod
    def _from_server(cls, ann, group_kinds: dict, *, sample_id=None, dataset=None,
                     _json_input=False) -> "AnnotatedSample":
        """`from_dict` 와 같은 변환이되 **검사하지 않는다** — 서버에서 읽은 값(`from_row`·`load_sample`·`iter_samples`·
        `shuffle` 등)이 이것을 지난다. 이미 저장된 틀린 행(모르는 component 타입 등)도 열 수 있어야 한다."""
        had_meta = "meta" in ann
        meta_raw = ann.get("meta", {})
        meta_was_null = had_meta and meta_raw is None
        if meta_raw is None:
            meta_raw = {}
        meta = Meta.from_dict(meta_raw)
        groups = cls._parse_groups(ann, group_kinds)
        obj = cls(sample_id, meta, groups, dataset=dataset, had_meta=had_meta,
                  meta_was_null=meta_was_null, group_kinds=group_kinds)
        # 원본이 아니라 **정규화된** 현재 상태를 기준으로 뜬다(id 없는 행에 uuid4 가 채워지는
        # 등 — 원본과 비교하면 안 바뀐 그룹이 바뀐 것으로 보여 동시 편집을 덮어쓴다).
        # 객체들이 입력 dict 를 그대로 참조하므로 deepcopy 해야 편집이 기준을 바꾸지 않는다.
        # 서버 응답(JSON)에서 온 입력은 JSON 왕복으로 뜬다 — 같은 사본이고 deepcopy 보다 약 3 배
        # 빠르다(샘플당 박스 20 개, 1000 행 280 ms → 98 ms 실측). 순회(`iter_samples`)가 샘플마다
        # 여기를 지나 변환 비용의 대부분이 이 사본이었다. 호출자가 준 dict 는 tuple·numpy 값처럼
        # JSON 이 아닌 것이 섞일 수 있어 종전대로 deepcopy 한다.
        cur = obj.to_dict()
        obj._baseline = json.loads(json.dumps(cur)) if _json_input else copy.deepcopy(cur)
        return obj

    @classmethod
    def from_row(cls, row: dict, group_kinds: dict, *, dataset=None):
        """explorer 응답 한 행(또는 샘플 단건 조회 응답)에서 만든다. 코어 키를 떼고 남은
        `meta`·그룹은 `from_dict` 와 같은 규칙이고, `tags`·`split` 을 더 든다. `SampleSummary`(annotation 없는
        행)는 받지 않는다 — 그룹이 없어 그룹을 더해 저장하면 서버의 그 그룹을 덮는다."""
        _reject_sample_summary(row, "AnnotatedSample.from_row")
        ann ={k: v for k, v in row.items() if k not in _CORE_KEYS}
        obj = cls._from_server(ann, group_kinds, sample_id=row.get("sample_id"), dataset=dataset,
                               _json_input=True)
        obj.tags = list(row.get("tags") or [])
        obj._baseline_tags = list(obj.tags)
        obj._split = row.get("split")
        return obj

    def to_dict(self) -> dict:
        out = {}
        for key, grp in self.groups.items():
            out[key] = grp.to_raw() if isinstance(grp, RawGroup) else grp.to_list(key)
        meta_dict = self.meta.to_dict()
        if self._meta_was_null and isinstance(meta_dict, dict) and not meta_dict:
            out["meta"] = None
        elif self.had_meta or (isinstance(meta_dict, dict) and meta_dict):
            out["meta"] = meta_dict
        return out

    def get_group(self, name):
        return self.groups.get(name)

    def _field_names(self) -> list:
        """존재하는 필드 이름(그룹 + "meta") — 오타 에러 메시지에 쓴다."""
        return sorted(set(self.groups) | {"meta"})

    def _missing_field_error(self, name) -> AttributeError:
        return AttributeError(
            f"no such field '{name}' (existing fields: {', '.join(self._field_names())})")

    def _declared_kind(self, name):
        """그 이름에 선언된 그룹 종류(`"group"`·`"container"`, 없으면 None). dataset 핸들에 붙은 샘플은 핸들의 지금
        값이 이긴다(샘플을 받은 뒤 `declare_group_kinds` 한 선언도 듣는다 — 설계 6-7). 핸들이 없으면(직접 만든 샘플·
        `copy()`) 만들 때 받은 `group_kinds` 다."""
        src = self._dataset if self._dataset is not None else self._kinds_dataset
        ds_kinds = getattr(src, "_group_kinds", None) if src is not None else None
        if isinstance(ds_kinds, dict) and name in ds_kinds:
            return ds_kinds[name]
        return self._group_kinds.get(name)

    def _declared_class(self, name):
        """그 이름의 선언된 그룹 클래스. 선언이 없으면 `NexusValidationError` — 그룹 규칙 없이 새 그룹이 생기는 입구를
        남기지 않는다(설계 6-3)."""
        kind = self._declared_kind(name)
        cls = _KIND.get(kind)
        if cls is None:
            raise NexusValidationError(
                f"그룹 '{name}' 의 종류가 선언되지 않았습니다 — 먼저 "
                f"ds.declare_group_kinds({{'{name}': 'group'}}) (또는 'container') 로 선언하십시오")
        return cls

    def _coerce_field_value(self, name, value):
        """FiftyOne 호환 setter 들이 공유하는 값 검증. "meta" 는 `Meta` 객체만, 그 외 필드는 그 이름에 선언된 종류의
        그룹 객체(`LabelGroup`/`LabelContainer`)만 받는다. dict·행 list·`RawGroup` 은 `TypeError`, 선언이 없거나 종류와
        클래스가 다르면 `NexusValidationError`, 그룹이면 그 그룹 규칙으로 통째 검사한다(위반이면 대입하지 않는다)."""
        if name == "meta":
            if isinstance(value, Meta):
                return value
            raise TypeError(
                f"'meta' 에는 Meta 객체만 대입할 수 있습니다, {type(value).__name__} 받음 — "
                "키 하나는 s.meta[key] = value 로 고치십시오")
        if isinstance(value, RawGroup):
            raise TypeError(
                f"field '{name}': RawGroup 은 대입할 수 없습니다 — 선언 안 된 그룹은 읽기와 왕복만 됩니다. "
                "그룹 종류를 선언하고 LabelGroup/LabelContainer 로 만드십시오")
        if not isinstance(value, LabelGroup):
            raise TypeError(
                f"field '{name}' must be a LabelGroup/LabelContainer, got {type(value).__name__}")
        cls = self._declared_class(name)
        if type(value) is not cls:
            raise NexusValidationError(
                f"그룹 '{name}' 은 '{self._declared_kind(name)}' 로 선언됨 — {cls.__name__} 이어야 함, "
                f"{type(value).__name__} 받음")
        # 같은 객체를 둔다(대입 뒤 g.add(...) 도 샘플에 반영된다). 오류 경로의 이름은 검사 호출에 넘기고 사용자 객체의
        # `_name` 은 고치지 않는다 — 같은 객체를 두 이름에 대입해도 대입·save() 검사의 경로는 늘 그 필드 이름이다.
        value.validate(name)
        return value

    def __getitem__(self, name):
        if name == "meta":
            return self.meta
        return self.groups[name]

    def __setitem__(self, name, value):
        coerced = self._coerce_field_value(name, value)
        if name == "meta":
            self.meta = coerced
            # 방금 값이 들어왔으니 이제 present 필드다 — null 이었던 상태도 해제한다.
            self.had_meta = True
            self._meta_was_null = False
        else:
            self.groups[name] = coerced

    def get_field(self, name):
        """FiftyOne `get_field` 호환. 없는 필드는 존재하는 필드 목록을 담은
        `AttributeError`로 실패한다(오타를 그 자리에서 드러낸다)."""
        if name == "meta":
            return self.meta
        if name in self.groups:
            return self.groups[name]
        raise self._missing_field_error(name)

    def set_field(self, name, value, create=True) -> None:
        """FiftyOne `set_field` 호환. `create=False`면 이미 있는 필드만 고칠 수 있다
        (오타로 새 필드가 조용히 생기는 것을 막는다). "meta"는 항상 존재하는
        필드로 친다 — 샘플마다 있는 내장 필드라 새로 "만드는" 대상이 아니다."""
        if not create and name != "meta" and name not in self.groups:
            raise self._missing_field_error(name)
        self[name] = value

    def clear_field(self, name) -> None:
        """FiftyOne `clear_field`와 이름·의도(값을 비운다)는 같지만, 이 SDK 의
        wire spec 은 명시적 null 을 금지하므로 `None`이 아니라 **빈 컬렉션**으로
        되돌린다(고객 제안 §3.2). meta 는 빈 `Meta({})`로 되돌리는데, save() 시점에
        기준(baseline)과 비교해 예전에 있던 키가 전부 삭제(null)로 나간다."""
        if name == "meta":
            self.meta = Meta({})
            self.had_meta = True
            self._meta_was_null = False
            return
        if name not in self.groups:
            raise self._missing_field_error(name)
        grp = self.groups[name]
        if isinstance(grp, LabelGroup):
            new = type(grp)([])
            new._name = name
        else:
            new = RawGroup([])
            # RawGroup 은 save() 가 보내지 않는데, 비운 것만은 빈 그룹으로 보낸다(clear_field 는 지금과 같다).
            new._cleared = True
        self.groups[name] = new

    def validate(self) -> None:
        """meta 가 객체인지 본 뒤 모든 그룹의 위반을 모아 한 번에 `NexusValidationError`(`errors` 에 전부)로 낸다."""
        self.meta.validate()
        out: list = []
        for key, grp in self.groups.items():
            out.extend(grp.issues(key))
        raise_for_issues(out)

    def _ingest_body(self, group_kinds: dict) -> dict:
        """적재(`flush`)가 보낼 annotation 본문. 만들 때 받은 종류가 아니라 **넘겨받은 종류(그 dataset 의 서버 저장값,
        `Dataset._ingest_group_kinds`)**로 다시 읽어 검사한다(설계 6-7). 거기 없는 이름은 `RawGroup` 규칙으로 본다(서버도
        선언 없는 그룹에 같은 규칙을 건다). 위반이면 `NexusValidationError` 이고 아무것도 보내지 않는다."""
        body = self.to_dict()
        if "meta" in body and body["meta"] is not None and not isinstance(body["meta"], dict):
            raise NexusValidationError("meta must be a JSON object")
        raise_for_issues(self._issues(group_kinds))
        return body

    def _issues(self, group_kinds: dict) -> list:
        """현재 그룹을 `group_kinds` 로 다시 해석해 모은 위반 전부(`Issue` 목록, 없으면 빈 목록). 던지지 않는다."""
        out: list = []
        for key, grp in self._parse_groups(self.to_dict(), group_kinds).items():
            out.extend(grp.issues(key))
        return out

    def _sent_state(self, for_put: bool = False) -> dict:
        """저장 경로가 보는 현재 상태 — `to_dict()` 와 같되 `RawGroup` 은 기준(서버에서 읽은 값)으로 둔다. `RawGroup`
        은 읽기 전용이라 `.raw` 를 고친 것을 보내지 않는다(설계 6-1). `clear_field` 로 비운 것만 빈 배열이고, 기준에
        없는 `RawGroup` 은 부분 저장(PATCH)에 싣지 않는다. 통째 교체(`for_put`)는 빠진 그룹을 지우므로, 기준이 없는
        샘플이면 `raw` 를 그대로 싣는다(서버 값을 모르니 그 그룹을 지우지 않는 것이 우선이다)."""
        cur = self.to_dict()
        base = self._baseline if self._baseline is not None else {}
        for key, grp in self.groups.items():
            if not isinstance(grp, RawGroup):
                continue
            if grp._cleared:
                cur[key] = []
            elif key in base:
                cur[key] = copy.deepcopy(base[key])
            elif for_put and self._baseline is None:
                pass   # to_dict() 의 raw 그대로
            else:
                cur.pop(key, None)
        return cur

    def _raw_sent_value(self, key, grp):
        """그 `RawGroup` 의 저장 상태 값 — 비운 그룹이면 `[]`, 기준이 있으면 기준값, 없으면 `raw`. 사용자가 고칠 수 있는
        `.raw` 는 save() 가 보내지 않으므로, 「바뀌는 것이 있나」는 이 값으로 판정한다(`_sent_state` 와 같은 규칙)."""
        if grp._cleared:
            return []
        base = self._baseline
        if base is not None and key in base:
            return base[key]
        return grp.raw

    def _diff(self) -> dict:
        """기준과 비교한 부분 저장 본문. 그룹은 통째로, meta 는 키 단위."""
        cur = self._sent_state()
        base = self._baseline if self._baseline is not None else {}
        patch: dict = {}
        for key, val in cur.items():
            if key == "meta":
                continue
            if base.get(key, _MISSING) != val:
                patch[key] = copy.deepcopy(val)
        for key in base:
            if key != "meta" and key not in cur:
                patch[key] = []

        cur_meta = cur.get("meta")
        base_meta = base.get("meta")
        if cur_meta is None and base_meta is None:
            return patch
        bm = {} if base_meta is None else base_meta
        cm = {} if cur_meta is None else cur_meta
        if not isinstance(cm, dict) or not isinstance(bm, dict):
            if cm != bm:
                # 서버도 비객체 meta 에는 병합하지 않는다(409) — 요청 전에 막는다.
                raise NexusValidationError("meta must be a JSON object")
            return patch
        meta_patch = {}
        for k, v in cm.items():
            if v is None:
                if bm.get(k) is not None:
                    meta_patch[k] = None
            elif bm.get(k, _MISSING) != v:
                meta_patch[k] = copy.deepcopy(v)
        for k in bm:
            if k not in cm:
                meta_patch[k] = None
        if meta_patch:
            patch["meta"] = meta_patch
        return patch

    def _tag_diff(self):
        """기준과 비교한 (더해진, 빠진) 태그. 순서만 바뀐 것은 변경이 아니다 — 서버 태그는
        합집합·순서 보존이라 순서를 SDK 가 정할 수 없다."""
        if self.tags is None:
            if self._baseline_tags is not None:
                raise NexusValidationError(
                    "tags 를 None 으로 바꿀 수 없습니다 — 태그를 모두 떼려면 s.tags = [] 로 두십시오"
                )
            return [], []
        if not isinstance(self.tags, (list, tuple)) or not all(
            isinstance(t, str) and t for t in self.tags
        ):
            raise NexusValidationError("tags must be a list of non-empty strings")
        base = self._baseline_tags or []
        added = list(dict.fromkeys(t for t in self.tags if t not in base))
        removed = [t for t in base if t not in self.tags]
        return added, removed

    def _full_for_put(self) -> dict:
        """옛 서버 폴백용 통째 교체 본문. meta 의 삭제 표식(None)은 키를 뺀다 —
        PUT 에서 `k: null` 은 null 저장이지 삭제가 아니다."""
        full = self._sent_state(for_put=True)
        m = full.get("meta")
        if isinstance(m, dict):
            full["meta"] = {k: v for k, v in m.items() if v is not None}
        return full

    def save(self) -> dict:
        """바뀐 그룹·meta 키·태그만 저장한다. 순서:

        1. 태그가 바뀌었으면 버전을 확인한다 — sealed 면 아무것도 보내지 않고 `NexusError(409)`.
           버전 경로가 없는 서버의 태그 경로(`/samples/tags`)에는 버전이 없어 sealed 핸들로도 통하므로, meta 가
           sealed 버전 경로에서 409 인 것과 맞춘다.
        2. 그룹·meta 변경분을 PATCH(옛 서버는 PUT 폴백).
        3. 더해진 태그를 붙이고 빠진 태그를 뗀다.

        2 와 3 은 한 트랜잭션이 아니다 — 3 이 실패하면 2 는 이미 저장됐고, 다시 save() 하면 태그만
        다시 보낸다. 서버가 버전 경로를 가진 판(nexus-server 0.1.37 이상)이면 meta·태그는 이 핸들의 버전에만 반영된다.
        그보다 낮은 판은 meta·태그가 샘플에 붙어 있어 같은 샘플을 공유하는 다른 버전의 조회에도 바뀐 값이 보이고, meta 는
        seal 스냅샷(`to_df()`)에 seal 때 값이 남지만 태그는 스냅샷 결과에 없어 언제나 현재 값이다."""
        ds = self._dataset
        if ds is None:
            raise NexusValidationError("AnnotatedSample has no dataset to save to")
        added, removed = self._tag_diff()
        patch = self._diff()   # meta 는 바뀐 경우에만 여기서 검사된다
        if not patch and not added and not removed:
            return copy.deepcopy(_ZERO_REPORT)
        # 열 때 그룹 종류를 읽지 못한 핸들이면 다시 읽는다 — 못 읽으면 아무것도 보내지 않고 `NexusError`(설계 6-7).
        ensure = getattr(ds, "_ensure_group_kinds_read", None)
        if ensure is not None:
            ensure()
        if added or removed:
            ds._ensure_tags_writable()
        report = copy.deepcopy(_ZERO_REPORT)
        if patch:
            report = self._save_patch(ds, patch)
            self._baseline = copy.deepcopy(self._sent_state())
        # 기준은 응답에 실린 그 샘플의 tags 로 갱신한다 — 서버는 새 태그를 DISTINCT 로 골라 붙여서
        # 여러 개면 순서가 입력과 달라진다(m-pg 실측: z,a,m,q,c → c,z,q,a,m). 응답에 tags 가 없으면
        # 기존 순서 + 새 태그로 어림한다.
        if added:
            row = _returned_sample(
                ds._client.add_tags_bulk(
                    [self.sample_id], added, dataset_id=ds._dataset_id, version=ds._version
                ),
                self.sample_id,
            )
            self._baseline_tags = list(row["tags"]) if isinstance(row.get("tags"), list) \
                else list(self._baseline_tags or []) + added
        if removed:
            row = _returned_sample(
                ds._client.remove_tags_bulk(
                    [self.sample_id], removed, dataset_id=ds._dataset_id, version=ds._version
                ),
                self.sample_id,
            )
            self._baseline_tags = list(row["tags"]) if isinstance(row.get("tags"), list) \
                else [t for t in self._baseline_tags if t not in removed]
        if added or removed:
            # 서버에 저장된 모양(중복 없음, 서버 순서)으로 맞춘다.
            self.tags = list(self._baseline_tags)
        return report

    def _save_patch(self, ds, patch: dict) -> dict:
        # 보낼 그룹만 검증한다 — 안 건드린 그룹의 깨진 데이터가 이 저장을 막으면 안 된다
        # (서버는 그 그룹을 그대로 보존할 뿐, 이번 요청이 그 내용을 책임지지 않는다).
        # 삭제되는 그룹(`patch[key] == []`인데 `self.groups`에 더는 없음)은 검증할 객체가 없다.
        # 405 폴백(통째 PUT)도 같은 patch 로 판단한 것을 그대로 쓴다 — 안 바뀐 그룹은
        # 서버가 이미 들고 있는 데이터이므로 여기서 다시 검증할 이유가 없다.
        for key in patch:
            if key == "meta":
                continue
            grp = self.groups.get(key)
            if grp is not None:
                grp.validate(key)

        unsupported = getattr(ds, "_partial_annotations_unsupported", lambda: False)()
        report = None
        if not unsupported:
            try:
                report = ds._merge_annotation(self.sample_id, patch)
            except NexusError as e:
                if getattr(e, "status_code", None) != 405:
                    raise
                mark = getattr(ds, "_mark_partial_annotations_unsupported", None)
                if mark is not None:
                    mark()
                warnings.warn(
                    "서버가 annotation 부분 저장(PATCH)을 지원하지 않아 통째 교체로 저장했습니다 "
                    "— 그 사이 다른 곳에서 고친 그룹을 덮어쓸 수 있습니다"
                    "(부분 저장은 nexus-server 0.1.18 부터).",
                    RuntimeWarning,
                    stacklevel=3,
                )
                unsupported = True
        if report is None:
            full = self._full_for_put()
            if self._baseline_tags is not None:
                # 행(explorer·샘플 단건 응답)에서 만든 샘플은 코어 키와 이름이 같은 그룹을 못 봤다 —
                # 서버가 코어 키를 그룹보다 우선한다. 통째 PUT 이 그 그룹을 빼고 나가면 이 버전의 그
                # 그룹이 지워지므로, annotation 전용 조회로 저장된 값을 읽어 그대로 실어 보낸다.
                stored = ds.get_annotation(self.sample_id)
                for key in _CORE_KEYS:
                    if key in stored:
                        full[key] = stored[key]
            # meta 는 고쳤을 때만 싣는다 — 안 고친 meta 를 다시 쓰면 그 사이 다른 곳에서 바꾼 값을 되돌린다
            # (meta 키가 없는 PUT 은 0.1.16 서버도 meta 를 건드리지 않는다).
            replace_meta = "meta" in patch
            if not replace_meta:
                full.pop("meta", None)
            m = full.get("meta")
            if m is not None and not isinstance(m, dict):
                raise NexusValidationError("meta must be a JSON object")
            report = ds._save_annotation(self.sample_id, full, replace_meta=replace_meta)
        return report

    def promote(self, name: str, kind: str) -> LabelGroup:
        """선언 안 된 그룹(`RawGroup`)을 그 종류(`"group"`·`"container"`)의 편집 핸들로 바꾼다(설계 6-4).

        순서: ① 이 샘플의 그 그룹(서버에서 읽은 값 — 고친 `.raw` 가 아니다)을 그 종류로 읽어 SDK 규칙으로 검사한다. 위반이면
        `NexusValidationError`(`errors` 에 전부)이고 선언하지 않는다. ② `ds.declare_group_kinds({name: kind})` — **dataset
        전체 검사는 서버가 한다**(`container` 면 draft 버전의 기존 행). 거절되면 그 예외(400 → `NexusValidationError`,
        503 → `NexusError`)이고 이 샘플은 바뀌지 않는다. 서버가 저장하지 못한 경우(403·서버가 저장하지 않는 이름)도
        바꾸지 않고 `NexusError` 다 — 그 그룹은 서버에서 선언 없는 그룹이라 편집해 보내면 갈라진다. ③ 성공하면
        `self[name]` 을 새 그룹 객체로 바꿔 돌려준다. 그 그룹의 기준을 새 그룹의 정규화 값(`to_list`)으로 맞추므로(`from_dict`
        가 기준을 뜨는 규칙과 같다 — id 없는 행에 채운 id, 빠지는 `null` 키) 고치기 전의 `save()` 는 이 그룹을 보내지 않는다.

        서버에 그 이름의 종류가 이미 저장돼 있고 요청한 종류와 다르면(종류를 읽지 못한 채 연 핸들에서 받은 샘플 등) 선언하지
        않고 `NexusValidationError` 다 — 저장된 종류를 조용히 바꾸지 않는다. 바꾸려면 `declare_group_kinds` 를 직접 부른다.

        dataset 핸들에 붙은 샘플(`load_sample`·`iter_samples` 등)만 부를 수 있다."""
        ds = self._dataset
        if ds is None:
            raise NexusValidationError("promote 는 dataset 핸들에 붙은 샘플(load_sample 등)에서만 부를 수 있습니다")
        cls = _KIND.get(kind)
        if cls is None:
            raise ValueError(f"group kind must be 'group' or 'container', got {kind!r}")
        grp = self.groups.get(name)
        if grp is None:
            raise self._missing_field_error(name)
        if not isinstance(grp, RawGroup):
            raise TypeError(f"그룹 '{name}' 은 이미 {type(grp).__name__} 입니다 — promote 는 RawGroup 만 바꿉니다")
        ensure = getattr(ds, "_ensure_group_kinds_read", None)
        if ensure is not None:
            ensure()
        stored_kind = (getattr(ds, "_stored_group_kinds", None) or {}).get(name)
        if stored_kind is not None and stored_kind != kind:
            raise NexusValidationError(
                f"그룹 '{name}' 은 서버에 '{stored_kind}' 로 저장돼 있어 '{kind}' 로 promote 하지 않았습니다 — 샘플을 다시 "
                "읽거나, 종류를 바꾸려면 ds.declare_group_kinds 를 직접 부르십시오")
        value = self._raw_sent_value(name, grp)
        if not (isinstance(value, list) and all(isinstance(r, dict) for r in value)):
            raise_for_issues(RawGroup(value).issues(name))
        new = cls.from_list(copy.deepcopy(value))
        new._name = name
        new.validate(name)
        from .dataset import _storable_group_kind_key
        if not _storable_group_kind_key(name):
            raise NexusValidationError(
                f"그룹 '{name}' 은 서버가 종류를 저장하지 않는 이름이라(meta·샘플 필드 이름·앞뒤 공백·128 자 초과) "
                "promote 할 수 없습니다 — RawGroup 으로 남습니다")
        ds.declare_group_kinds({name: kind})
        stored = getattr(ds, "_stored_group_kinds", None) or {}
        if stored.get(name) != kind:
            raise NexusError(
                f"그룹 '{name}' 의 종류를 서버에 저장하지 못해(쓰기 권한 없음 등) 바꾸지 않았습니다",
                status_code=403 if name in (getattr(ds, "_viewer_group_kinds", None) or {}) else None)
        self.groups[name] = new
        # 기준을 정규화 값으로 맞춘다 — 서버 원본과 비교하면 id 를 채운 행·빠진 null 키 때문에 바뀌지 않은 그룹을 보낸다
        # (사용자가 만들지 않은 id 가 저장되고 그 사이 다른 곳의 편집을 덮는다). 비운 그룹은 기준을 두어 `[]` 를 보낸다.
        if self._baseline is not None and name in self._baseline and not grp._cleared:
            self._baseline[name] = copy.deepcopy(new.to_list(name))
        return new

    @staticmethod
    def _select_fields(available: set, fields, omit_fields) -> set:
        selected = set(available)
        if fields is not None:
            selected &= set(fields)
        if omit_fields is not None:
            selected -= set(omit_fields)
        return selected

    def merge(self, other, fields=None, omit_fields=None, merge_lists=True, overwrite=True) -> None:
        """FiftyOne `Sample.merge` 호환. `other`의 필드를 이 샘플에 합친다(제자리 수정,
        반환값 없음). `other` 는 `AnnotatedSample` 만 받는다 — dict 는 먼저
        `AnnotatedSample.from_dict(d, group_kinds)` 로 바꾼다(그 자리에서 검사된다).

        그룹은 `merge_lists=True`이고 양쪽이 `RawGroup`이 아닐 때만 `Instance.id` 단위로
        병합한다(같은 id는 `overwrite`일 때만 교체, 새 id는 추가) — 그 외에는(`merge_lists=False`
        이거나 어느 한쪽이라도 `RawGroup`) 그룹 전체를 통째로 교체하며 `overwrite=False`면
        이미 있는 필드는 건드리지 않는다. self 에 없는 필드는 `overwrite`와 무관하게 추가된다.
        meta 는 키 단위로 합친다(`overwrite=True`면 other 의 값으로 덮고, 아니면 self 에
        없는 키만 채운다). `other`에서 가져오는 값은 전부 deep copy 한다 — 안 하면 두 샘플이
        같은 Instance 객체를 공유해 한쪽 편집이 다른 쪽에도 번진다."""
        if not isinstance(other, AnnotatedSample):
            raise TypeError(
                f"merge() 는 AnnotatedSample 만 받습니다, {type(other).__name__} 받음 — dict 는 "
                "AnnotatedSample.from_dict(d, group_kinds) 로 먼저 바꾸십시오")

        available = set(other.groups) | {"meta"}
        selected = self._select_fields(available, fields, omit_fields)

        # 실패할 수 있는 검사는 무엇이든 바꾸기 전에 한다 — 그룹을 절반만 합친 채
        # 예외가 나면 안 된다(add_labels 와 같은 기준).
        other_meta = other.meta.to_dict()
        if "meta" in selected:
            if not isinstance(other_meta, dict):
                raise NexusValidationError("meta to merge must be a JSON object")
            if other_meta and not isinstance(self.meta._data, dict):
                raise NexusValidationError("meta must be a JSON object")

        # 그룹은 합친 결과를 먼저 전부 만들고 검사한 뒤(대입 규칙 — 선언·그룹 규칙) 한 번에 바꾼다.
        group_plans = [
            self._plan_merge_group(field, other.groups[field], merge_lists, overwrite)
            for field in sorted(selected) if field != "meta"
        ]
        if "meta" in selected:
            self._merge_meta(other_meta, overwrite)
        for apply in group_plans:   # 새 그룹이 붙는 순서를 결정적으로(필드 이름순)
            if apply is not None:
                apply()

    def _merge_meta(self, other_data: dict, overwrite: bool) -> None:
        base = self.meta._data
        written = False
        for k, v in other_data.items():
            if overwrite or k not in base:
                base[k] = copy.deepcopy(v)
                written = True
        # 실제로 키를 쓴 경우에만 present 로 바꾼다 — 빈 meta 를 합쳤다고 저장된 null 이
        # {} 로 바뀌면 통째 PUT 폴백에서 null 이 {} 로 덮인다.
        if written:
            self.had_meta = True
            self._meta_was_null = False

    def _plan_merge_group(self, field, other_grp, merge_lists: bool, overwrite: bool):
        """그 필드를 합치는 동작(나중에 부를 함수, 할 일이 없으면 None). 실패할 검사는 여기서 다 한다.
        typed 그룹이 새로 들어오거나 통째로 바뀌면 대입(`s[name] = g`)과 같은 검사를 지나고, id 단위 병합은 들어오는 행의
        규칙과 결과 그룹의 그룹 규칙으로 검사한다(`add` 와 같다). `RawGroup` 이 대상을 바꾸는 갈래(빈 자리·다른 값으로
        교체)는 `TypeError` 로 거절하고(대입과 같다), 같은 값의 `RawGroup` 자리는 건너뛴다."""
        exists = field in self.groups
        self_grp = self.groups.get(field)

        def put(grp):
            # RawGroup 이 대상을 실제로 바꾸면 대입과 같이 거절한다 — 옮겨 놓아도 save() 가 보내지 않아 조용히
            # 버려진다(설계 6-1). 대상 자리 RawGroup 의 저장 상태 값(`_raw_sent_value` — 로컬 `.raw` 가 아니다)이 같으면 바뀌는 것이 없어 건너뛴다(같은 dataset
            # 에서 읽은 두 샘플을 합칠 때 그대로인 선언 안 된 그룹이 오류가 되지 않게). 계획 단계에서 던지므로 merge 는
            # 여전히 아무것도 바꾸지 않는다.
            if (isinstance(grp, RawGroup) and exists and isinstance(self_grp, RawGroup)
                    and self._raw_sent_value(field, self_grp) == grp.raw):
                return None
            grp = self._coerce_field_value(field, grp)
            return lambda: self.groups.__setitem__(field, grp)

        if not exists:
            return put(copy.deepcopy(other_grp))
        if not merge_lists or isinstance(self_grp, RawGroup) or isinstance(other_grp, RawGroup):
            return put(copy.deepcopy(other_grp)) if overwrite else None
        # 양쪽 다 LabelGroup/LabelContainer — id 단위 병합
        other_copy = copy.deepcopy(other_grp)
        new = list(self_grp.instances)
        index = {inst.id: idx for idx, inst in enumerate(new)}
        fresh: list = []
        for inst in other_copy.instances:
            existing_idx = index.get(inst.id)
            if existing_idx is None:
                new.append(inst)
                index[inst.id] = len(new) - 1
                fresh.append(len(new) - 1)
            elif overwrite:
                new[existing_idx] = inst
                fresh.append(existing_idx)
        checked = self_grp._checked(new, fresh, field)
        return lambda: setattr(self_grp, "_instances", checked)

    def add_labels(self, labels, label_field=None) -> None:
        """FiftyOne `Sample.add_labels` 호환. `labels`는 `Instance` 하나, `Instance`
        리스트, 또는 `{field: Instance | list[Instance]}` dict다. dict가 아니면
        `label_field`가 필수다(어느 필드에 넣을지 알 수 없다).

        같은 id 가 대상 필드에 이미 있으면(자기 자신끼리든 배치 안에서든) 어느 것도
        추가하지 않고 `ValueError` — 그래서 검증을 전부 마친 뒤에만 실제로 붙인다
        (나쁜 배치가 샘플을 절반만 바꿔 놓고 실패하면 안 된다). "meta"나 `RawGroup`에는
        붙일 수 없다(둘 다 `Instance` 목록이 아니다) — `TypeError`."""
        if isinstance(labels, dict):
            if label_field is not None:
                # FiftyOne 은 여기서 label_field 를 접두어로 쓴다 — 조용히 무시하면 다른 필드에 들어간다.
                raise ValueError("labels가 dict이면 label_field를 줄 수 없다(필드는 dict 키로 정한다)")
            batch = labels
        else:
            if label_field is None:
                raise ValueError("labels가 dict가 아니면 label_field가 필요하다")
            if isinstance(labels, Instance):
                batch = {label_field: [labels]}
            elif isinstance(labels, list):
                batch = {label_field: labels}
            else:
                raise TypeError(
                    f"labels must be an Instance, list of Instance, or dict, "
                    f"got {type(labels).__name__}")

        normalized: dict = {}
        for field, items in batch.items():
            if field == "meta":
                raise TypeError("cannot add_labels to 'meta'")
            if isinstance(items, Instance):
                items = [items]
            elif not isinstance(items, list):
                raise TypeError(
                    f"labels for field '{field}' must be an Instance or list of Instance, "
                    f"got {type(items).__name__}")
            for item in items:
                if not isinstance(item, Instance):
                    raise TypeError(
                        f"labels for field '{field}' must be Instance objects, "
                        f"got {type(item).__name__}")
            existing = self.groups.get(field)
            if isinstance(existing, RawGroup):
                raise TypeError(f"field '{field}' is a RawGroup; cannot add_labels to it")
            if existing is None:
                # 새 그룹은 선언된 이름에만 만든다(설계 6-3) — 바꾸기 전에 확인한다.
                self._declared_class(field)
            normalized[field] = items

        # 아무것도 바꾸기 전에 id 충돌을 전부 검사한다.
        for field, items in normalized.items():
            existing = self.groups.get(field)
            existing_ids = {inst.id for inst in existing} if existing is not None else set()
            seen: set = set()
            for item in items:
                if item.id in existing_ids or item.id in seen:
                    raise ValueError(f"instance id '{item.id}' already exists in field '{field}'")
                seen.add(item.id)

        # 들어오는 행의 규칙과 결과 그룹의 그룹 규칙(container 등)도 전부 검사한 뒤에만 붙인다(`add` 와 같은 검사).
        plans: list = []
        for field, items in normalized.items():
            grp = self.groups.get(field)
            if grp is None:
                grp = self._declared_class(field)([])
                grp._name = field
            # 호출부 객체를 그대로 넣으면 같은 Instance 를 두 샘플(또는 두 필드)이 공유한다.
            new = list(grp.instances) + copy.deepcopy(items)
            plans.append((field, grp, grp._checked(new, range(len(grp), len(new)), field)))
        for field, grp, checked in plans:
            grp._instances = checked
            self.groups[field] = grp

    def copy(self, fields=None, omit_fields=None) -> "AnnotatedSample":
        """FiftyOne `Sample.copy` 호환. 저장되지 않은 deep copy를 만든다 — 새
        객체는 `sample_id=None`·`dataset=None`이라 `save()`가 `NexusValidationError`로
        실패한다(기준(baseline)도 없다). 원본 편집이 복사본에, 복사본 편집이 원본에
        번지지 않도록 선택된 그룹·meta를 전부 deep copy한다."""
        selected_groups = self._select_fields(set(self.groups), fields, omit_fields)
        include_meta = True
        if fields is not None:
            include_meta = "meta" in fields
        if omit_fields is not None:
            include_meta = include_meta and "meta" not in omit_fields

        new_groups = {k: copy.deepcopy(v) for k, v in self.groups.items() if k in selected_groups}
        if include_meta:
            new_meta = copy.deepcopy(self.meta)
            had_meta = self.had_meta
            meta_was_null = self._meta_was_null
        else:
            new_meta = Meta({})
            had_meta = False
            meta_was_null = False

        new = AnnotatedSample(
            None, new_meta, new_groups, dataset=None, had_meta=had_meta,
            meta_was_null=meta_was_null, group_kinds=self._group_kinds,
        )
        # 선언 종류는 원본과 같은 출처(핸들의 지금 값)로 본다 — 저장은 여전히 못 한다(dataset=None).
        new._kinds_dataset = self._dataset if self._dataset is not None else self._kinds_dataset
        return new
