"""서버 부재 재시도 판정.

설계: `docs/superpowers/specs/2026-09-30-server-absence-retry-design.md` §4. 판정은 이 파일에만 둔다 — nexus 클라이언트
(`client.py`)·CAS 세션(`cas.py`)·STS(`sts.py`)가 각자 판정하면 한쪽만 느슨해지는 날 중복 적재가 된다.
"""

from __future__ import annotations

import math
import os
import random
import re
import time
from typing import Callable

import requests
from urllib3.exceptions import ConnectTimeoutError, NewConnectionError, ProtocolError, ReadTimeoutError

#: 한 요청이 **첫 실패부터** 서버 부재를 기다리는 기본 시간(초).
DEFAULT_RETRY_TIMEOUT = 120.0
#: `retry_timeout` 을 주지 않았을 때 읽는 환경변수.
ENV_VAR = "NEXUS_RETRY_TIMEOUT"
#: nexus-server 가 멱등 키를 처리한다는 표시(0.1.20~, 모든 응답).
IDEMPOTENCY_HEADER = "X-Nexus-Idempotency"
#: nexus-server 가 스스로 낸 응답에 붙는 헤더(0.1.20~). 없는 5xx 는 프록시가 낸 것으로 본다.
REQUEST_ID_HEADER = "X-Request-Id"

_BACKOFF_START = 0.5
_BACKOFF_MAX = 8.0


def _now() -> float:
    """단조 시계. 테스트가 이 함수를 바꿔 끼운다."""
    return time.monotonic()


def resolve_timeout(value: "float | int | str | None" = None) -> float:
    """`retry_timeout` 을 해석한다. `None`·빈 문자열이면 환경변수, 그것도 없으면 기본값.

    숫자가 아니면 조용히 기본값으로 가지 않고 `ValueError` 다 — 오타 난 설정이 「재시도가 켜져 있다」로 보이면
    교체 때에야 드러난다.
    """
    if value is None or value == "":
        value = os.environ.get(ENV_VAR) or None
    if value is None:
        return DEFAULT_RETRY_TIMEOUT
    if isinstance(value, bool):
        raise ValueError(f"retry_timeout 은 0 이상의 초여야 합니다: {value!r}")
    try:
        seconds = float(value)
    except (TypeError, ValueError):
        raise ValueError(f"retry_timeout 은 0 이상의 초여야 합니다: {value!r}") from None
    if not math.isfinite(seconds) or seconds < 0:
        raise ValueError(f"retry_timeout 은 0 이상의 초여야 합니다: {value!r}")
    return seconds


def backoff_delay(attempt: int, rand: Callable[[], float] = random.random) -> float:
    """지수 백오프(0.5 초 시작, 최대 8 초) + full jitter. 여러 워커가 같은 순간에 몰려 오지 않게 한다."""
    return rand() * min(_BACKOFF_MAX, _BACKOFF_START * (2 ** attempt))


class Deadline:
    """첫 실패부터 재는 부재 예산.

    요청 시작부터 재면 read timeout(기본 120 초) 뒤에 남는 시간이 없다. 429 는 여기에 들어오지 않는다 — 서버가 살아
    있다는 뜻이라 부재 예산을 먹으면 안 된다.
    """

    def __init__(
        self, timeout: float, clock: "Callable[[], float] | None" = None, *, until: "float | None" = None
    ) -> None:
        """`until` 은 단조 시계의 절대 시각 — 첫 실패와 무관하게 그때를 넘겨 다시 보내지 않는다(호출부의 대기 예산)."""
        self._timeout = timeout
        self._clock = clock or _now
        self._until = until
        self._first: "float | None" = None
        self._attempt = 0

    def next_delay(self, rand: Callable[[], float] = random.random) -> "float | None":
        """다음 시도까지 기다릴 시간. 예산이 떨어졌으면 `None`."""
        now = self._clock()
        if self._first is None:
            self._first = now
        remaining = self._first + self._timeout - now
        if self._until is not None:
            remaining = min(remaining, self._until - now)
        if remaining <= 0:
            return None
        delay = min(backoff_delay(self._attempt, rand), remaining)
        self._attempt += 1
        return delay

    def credit(self, seconds: float) -> None:
        """429 로 기다린 시간을 예산에 돌려준다 — 그동안 서버는 살아 있었으므로 부재가 아니다.

        첫 실패 전에는 잴 시작점이 없어 아무 일도 하지 않는다(그 429 는 애초에 예산 밖이다).
        """
        if self._first is not None:
            self._first += seconds


def is_connect_phase(exc: BaseException) -> bool:
    """요청이 서버에 닿지 않은 실패인가(연결 거부·연결 타임아웃·DNS).

    nexus 세션은 어댑터 재시도가 없어서(`max_retries` 0) requests 가 urllib3 의 `MaxRetryError` 를 `ConnectionError` 로
    감싸고, 그 `reason` 이 원인이다. urllib3 2.x 의 `NameResolutionError` 는 `NewConnectionError` 의 하위 클래스다.
    응답 도중 끊김은 `ProtocolError` 라 여기 걸리지 않는다 — 서버가 처리했을 수 있다.
    """
    if isinstance(exc, requests.exceptions.ConnectTimeout):
        return True
    if isinstance(exc, requests.exceptions.ConnectionError):
        inner = exc.args[0] if exc.args else None
        return isinstance(getattr(inner, "reason", None), (NewConnectionError, ConnectTimeoutError))
    return False


def is_body_interrupted(exc: BaseException) -> bool:
    """응답 헤더를 받은 뒤 본문을 받다가 끊긴 실패인가(연결 리셋·조기 종료·본문 읽기 시한).

    urllib3 의 재시도는 응답 헤더까지만 덮는다 — requests 가 본문을 읽는 단계(`Response.content`)의 실패는 urllib3 를
    지나지 않고 `ChunkedEncodingError`(urllib3 `ProtocolError`)·`ContentDecodingError`·`ConnectionError(ReadTimeoutError)`
    로 올라온다. 헤더 단계의 실패는 urllib3 가 재시도를 다 쓴 뒤 `MaxRetryError` 로 감싸 올리므로 여기 걸리지 않는다.
    """
    if isinstance(exc, (requests.exceptions.ChunkedEncodingError, requests.exceptions.ContentDecodingError)):
        return True
    if isinstance(exc, requests.exceptions.ConnectionError) and not isinstance(exc, requests.exceptions.SSLError):
        inner = exc.args[0] if exc.args else None
        return isinstance(inner, (ReadTimeoutError, ProtocolError))
    return False


def describe_failure(exc: BaseException, timeout: "float | None" = None) -> str:
    """요청 예외를 사람이 고칠 수 있는 말로 가른다 — 「연결할 수 없다」를 연결을 맺지 못한 경우에만 쓴다."""
    if is_connect_phase(exc) or _wrapped_reason(exc, (NewConnectionError, ConnectTimeoutError)):
        return f"연결할 수 없습니다({exc}). 주소와 네트워크를 확인하세요"
    if isinstance(exc, requests.exceptions.ReadTimeout) or _wrapped_reason(exc, ReadTimeoutError) or (
        is_body_interrupted(exc) and isinstance(exc.args[0] if exc.args else None, ReadTimeoutError)
    ):
        limit = f"{timeout:g} 초" if timeout else "읽기 시한"
        return f"응답이 {limit} 넘게 멈춰 받지 못했습니다({exc})"
    if is_body_interrupted(exc):
        return f"받는 도중 연결이 끊겼습니다 — 다시 시도한 뒤에도 같았습니다({exc})"
    if isinstance(exc, requests.exceptions.SSLError):
        return f"TLS 연결에 실패했습니다({exc}). 인증서·CA 설정을 확인하세요"
    return f"요청이 실패했습니다({exc})"


def _wrapped_reason(exc: BaseException, kinds) -> bool:
    """`ConnectionError(MaxRetryError(reason=...))` 의 원인이 `kinds` 인가 — urllib3 가 재시도를 다 쓴 뒤의 모양이다."""
    if not isinstance(exc, requests.exceptions.ConnectionError):
        return False
    inner = exc.args[0] if exc.args else None
    return isinstance(getattr(inner, "reason", None), kinds)


# 다시 보내도 결과가 같은 요청 — 메서드가 아니라 경로로 고정한다. `PUT /api/v1/datasets/{id}/owner` 는 다시 보내면
# 400·403 이라 PUT 이어도 빠진다. 경로 조각은 `_seg` 로 인코딩돼 있어 `/` 가 들어가지 않는다.
_SAFE_ROUTES = (
    ("PUT", re.compile(r"^/datasets/[^/]+/versions/[^/]+/samples/[^/]+/annotations$")),
    ("PUT", re.compile(r"^/subsets/[^/]+$")),
    ("PUT", re.compile(r"^/datasets/[^/]+/favorite$")),
    # 값을 덮어쓰거나 지우는 연산이라 다시 보내도 결과가 같다. by-filter 는 confirm 이 대상 수에 묶여 넣지 않는다.
    ("PATCH", re.compile(r"^/datasets/[^/]+/versions/[^/]+/samples/meta$")),
    # 같은 에셋 좌표를 다시 보내면 role_exists 가 아니라 unchanged 로 세어진다(서버가 같은 값은 건드리지 않는다).
    ("PATCH", re.compile(r"^/datasets/[^/]+/versions/[^/]+/samples/assets$")),
    ("POST", re.compile(r"^/api/v1/buckets/ensure$")),
    ("POST", re.compile(r"^/datasets/[^/]+/versions/[^/]+/samples/explorer(?:/count)?$")),
    ("POST", re.compile(r"^/datasets/[^/]+/versions/[^/]+/facets/counts$")),
    # 같은 버전에 살아 있는 재계산이 있으면 서버가 그 작업을 준다. 끝난 뒤 닿으면 한 번 더 계산할 뿐이다.
    ("POST", re.compile(r"^/datasets/[^/]+/versions/[^/]+/schema/recompute$")),
)
_INGEST_PATHS = frozenset({"/ingest", "/ingest/batch"})


def is_safe(method: str, path: str, *, ingest_idempotent: bool = False) -> bool:
    """처리됐을지 모르는 요청을 다시 보내도 되는가. `/ingest` 는 서버 지원과 모든 item 의 키가 있을 때만."""
    m = method.upper()
    p = path.split("?", 1)[0]
    if m in ("GET", "HEAD"):
        return True
    if m == "POST" and p in _INGEST_PATHS:
        return ingest_idempotent
    return any(m == sm and rx.match(p) for sm, rx in _SAFE_ROUTES)


# 서버에서 전체 탐색을 하는 무거운 읽기 — 시한을 넘긴 뒤 다시 보내면 같은 탐색이 DB 에서 한 번 더 돈다.
_HEAVY_READ_ROUTES = (
    ("POST", re.compile(r"/datasets/[^/]+/versions/[^/]+/samples/explorer(?:/count)?$")),
    ("GET", re.compile(r"/subsets/[^/]+/samples$")),
)
#: 무거운 읽기를 다시 보내지 않고 올릴 때 붙이는 안내.
HEAVY_READ_HINT = "다시 보내지 않았습니다 — 같은 전체 탐색을 되풀이하게 됩니다. timeout 을 늘리거나 필터를 좁히십시오"


#: 401 재로그인(`_login`) 도중에 난 예외에 붙이는 표시 — 무거운 읽기의 「다시 보내지 않음」 규칙에서 뺀다.
RELOGIN_FAILURE_ATTR = "_nexus_relogin_failure"


def is_heavy_read(method: str, path: str) -> bool:
    """시한 초과 뒤 다시 보내면 안 되는 무거운 읽기인가. 쿼리 문자열은 떼고, 기준 URL 의 경로 접두어는 허용한다."""
    m = method.upper()
    p = path.split("?", 1)[0]
    return any(m == hm and rx.search(p) for hm, rx in _HEAVY_READ_ROUTES)


def is_post_connect_timeout(exc: BaseException) -> bool:
    """연결을 맺은 뒤 **응답 헤더를 기다리다** 난 읽기 시한 초과인가. 연결 단계의 실패는 거짓이다.

    본문을 받던 도중의 시한 초과(`is_body_interrupted` 의 `ConnectionError(ReadTimeoutError)`)는 넣지 않는다 — 헤더가
    왔다는 것은 서버가 DB 일을 이미 끝냈다는 뜻이라 다시 보내도 같은 탐색이 서버에서 겹치지 않는다. 그 실패는 종전처럼
    다시 보낸다(안전한 요청이면).
    """
    if is_connect_phase(exc):
        return False
    if isinstance(exc, requests.exceptions.ReadTimeout):
        return True
    return _wrapped_reason(exc, ReadTimeoutError)


def should_retry(
    method: str,
    path: str,
    *,
    exc: "BaseException | None" = None,
    status: "int | None" = None,
    from_nexus: bool = False,
    ingest_idempotent: bool = False,
    heavy_read: "bool | None" = None,
) -> bool:
    """nexus 요청을 부재 재시도할지(스펙 §4-2 표). 401·429 는 여기서 다루지 않는다.

    `heavy_read` 가 None 이면 경로로 정한다(`is_heavy_read`). 호출부가 False 를 주는 자리는 무거운 요청 자체가 아니라
    그 401 뒤의 재로그인이 실패한 경우다 — 무거운 요청은 401 로 끝나 서버에서 돌고 있지 않다.
    """
    safe = lambda: is_safe(method, path, ingest_idempotent=ingest_idempotent)  # noqa: E731
    if heavy_read is None:
        heavy_read = is_heavy_read(method, path)
    if heavy_read:
        # 헤더 대기 중 시한 초과·프록시 504 는 서버에서 아직 돌고 있을 수 있어 다시 보내면 부하가 두 배다. 연결 단계·
        # 502·503·끊김·본문 도중의 시한 초과(헤더가 왔으니 서버 일은 끝났다)는 아래 규칙 그대로다.
        if exc is not None and is_post_connect_timeout(exc):
            return False
        if exc is None and status == 504 and not from_nexus:
            return False
    if exc is not None:
        # TLS·인증서 문제는 서버 부재가 아니다 — 기다려도 풀리지 않는다. `SSLError` 는 `ConnectionError` 의 하위
        # 클래스라 아래 분기보다 먼저 걸러야 한다.
        if isinstance(exc, requests.exceptions.SSLError):
            return False
        if is_connect_phase(exc):
            return True
        # `ChunkedEncodingError`(응답 본문을 읽다 끊김)는 `ConnectionError` 의 하위가 아니지만 같은 post-connect 실패다.
        if isinstance(
            exc,
            (
                requests.exceptions.ConnectionError,
                requests.exceptions.Timeout,
                requests.exceptions.ChunkedEncodingError,
            ),
        ):
            return safe()
        return False
    if status == 502:
        return safe()
    if status in (503, 504):
        # nexus 가 스스로 낸 503·504(CVAT·OIDC 미구성 등)는 기다려도 풀리지 않는다.
        return (not from_nexus) and safe()
    return False


def keeps_pending_payload(exc: BaseException) -> bool:
    """청크 전체가 실패한 적재 요청의 본문을 다음 flush 에 그대로 다시 보내게 붙여 둘지(스펙 §4-3).

    `False` 는 400·422 뿐이다 — 본문이 잘못됐다고 거부된 것이라 기록됐을 리 없고, 붙여 두면 고친 뒤에도 잘못된 본문이
    다시 간다. 나머지는 붙여 둔다. 마지막 예외가 연결 단계여도 같은 요청의 앞선 시도가 보낸 뒤 끊겼을 수 있어
    「닿지 않았다」를 증명하지 못하고, 401·403·429 는 본문과 무관한 거부라 붙여 둔 본문이 해가 되지 않는다.
    """
    return getattr(exc, "status_code", None) not in (400, 422)
