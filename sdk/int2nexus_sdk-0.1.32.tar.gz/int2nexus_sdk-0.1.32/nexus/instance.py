from __future__ import annotations
import uuid
from ._types import Issue, NexusValidationError, raise_for_issues
from .labels import COMPONENT_TYPES, Label, _is_int, _is_number, _issue, _join, component_issues

COMMON_KEYS = ("id", "label", "track_id", "confidence")

_I32_MIN, _I32_MAX = -(2**31), 2**31 - 1
_F32_MAX = 3.4028234663852886e38


def common_issues(path: str, id, label, track_id, confidence, *, require_label: bool) -> "list[Issue]":
    """공통 필드(`id`·`label`·`track_id`·`confidence`)의 위반(`common_field`). 경로는 `<path>.<필드>`.

    `id` 가 `None`·`""` 이면 「id 없음」이라 위반이 아니다. `confidence` 는 서버 저장이 f32 라 f32 범위를 본다."""
    out: list = []

    def bad(field: str, msg: str) -> None:
        p = _join(path, field)
        out.append(_issue(p, "common_field", f"{p} {msg}"))

    if id is not None and not isinstance(id, str):
        bad("id", "는 문자열이어야 함")
    if label is None:
        if require_label:
            bad("label", "은 문자열이어야 함")
    elif not isinstance(label, str):
        bad("label", "은 문자열이어야 함")
    if track_id is not None and not (_is_int(track_id) and _I32_MIN <= track_id <= _I32_MAX):
        bad("track_id", "는 32 비트 정수여야 함")
    if confidence is not None and not (_is_number(confidence) and abs(confidence) <= _F32_MAX):
        bad("confidence", "는 f32 범위의 유한한 수여야 함")
    return out


def extras_issues(path: str, extras: dict) -> "list[Issue]":
    """component 로 분류되지 못한 키의 위반 — `type` 이 문자열이 아닌 객체(`invalid_type`), `type` 이 없는데 키가
    component 타입 이름인 객체(`missing_type`). 그 밖의 extras 는 거부하지 않는다(설계 4-1)."""
    out: list = []
    for k, v in extras.items():
        if not isinstance(v, dict):
            continue
        p = _join(path, k)
        if "type" in v:
            if not isinstance(v["type"], str):
                out.append(_issue(p, "invalid_type", f"{p}.type 은 문자열이어야 함"))
        elif k in COMPONENT_TYPES:
            out.append(_issue(p, "missing_type", f"{p} 는 component 타입 이름인데 'type' 이 없음"))
    return out


def raw_row_issues(path: str, row: dict) -> "list[Issue]":
    """미선언 그룹(`RawGroup`)의 dict 행 하나 — 서버 쓰기와 같이 문자열 `label` 이 없으면 거절하고(적재는 그런 행을
    조용히 스킵해 데이터가 빠진다), 나머지 공통 필드는 있을 때만 보고, 나머지 키는 서버와 같이 분류한다."""
    out = common_issues(path, row.get("id"), row.get("label"), row.get("track_id"), row.get("confidence"),
                        require_label=True)
    for k, v in row.items():
        if k in COMMON_KEYS:
            continue
        if isinstance(v, dict) and isinstance(v.get("type"), str):
            out.extend(component_issues(_join(path, k), v))
        else:
            out.extend(extras_issues(path, {k: v}))
    return out


class Instance:
    def __init__(self, label, components=None, *, id=None, track_id=None, confidence=None,
                 extras: dict | None = None):
        """`components` 는 `{이름: Label}` dict 이거나 `Label` 의 list/tuple 이다(list 는 키가 `lab.type`,
        같은 type 이 둘 이상이면 `NexusValidationError`). 없으면 빈 dict. `id` 는 키워드 전용이다."""
        components = self._components_from(components)
        # id 가 없거나 빈 문자열이면 UUID v4(하이픈 형식, GT spec)를 붙인다. 서버는 id 없이 적재된
        # 행을 빈 문자열로 돌려주는데, 그대로 두면 그런 행끼리 구분되지 않아 id 로 행을 가르는
        # merge·add_labels·CVAT 왕복이 틀어진다. 채운 id 는 로드 기준에 포함되므로, 그 그룹을
        # 고쳐 저장할 때만 서버에 기록된다.
        self.id = id if (id is not None and id != "") else str(uuid.uuid4())
        self.label = label
        self.track_id = track_id
        self.confidence = confidence
        self.components: dict = components
        # 공통 키도 아니고 component 도 아닌 나머지 키(예: "occluded": true, `type` 없는 객체) — component로 오인해
        # Label.validate()에 걸리지 않도록 verbatim 보존만 한다(검증 대상 아님).
        self.extras: dict = extras if extras is not None else {}

    @staticmethod
    def _components_from(components) -> dict:
        if components is None:
            return {}
        if isinstance(components, (list, tuple)):
            out: dict = {}
            for i, lab in enumerate(components):
                if not isinstance(lab, Label):
                    raise_for_issues([_issue(
                        f"components[{i}]", "invalid_type",
                        f"components[{i}]: Label 이어야 함, {type(lab).__name__} 받음")])
                if lab.type in out:
                    raise_for_issues([_issue(
                        f"components[{i}]", "duplicate_component_type",
                        f"components[{i}]: type '{lab.type}' 이 둘 이상 — 같은 type 은 이름을 붙인 dict 로 넘기십시오")])
                out[lab.type] = lab
            return out
        if not isinstance(components, dict):
            raise_for_issues([_issue(
                "components", "invalid_type",
                f"components 는 dict 또는 Label 의 list/tuple 이어야 함, {type(components).__name__} 받음")])
        return components

    @classmethod
    def from_row(cls, row: dict) -> "Instance":
        comps = {}
        extras = {}
        for k, v in row.items():
            if k in COMMON_KEYS:
                continue
            # 서버 스키마 관측(`catalog::instance`)과 같은 규칙 — `type` 문자열이 있는 객체만 컴포넌트다.
            # 없는 객체(`"attributes": {...}`)는 extras 로 보존한다.
            if isinstance(v, dict) and isinstance(v.get("type"), str):
                comps[k] = Label.from_dict(v)
            else:
                extras[k] = v
        return cls(id=row.get("id"), label=row.get("label"), components=comps,
                   track_id=row.get("track_id"), confidence=row.get("confidence"),
                   extras=extras)

    def to_dict(self, path: str = "") -> dict:
        out = {"id": self.id}
        if self.label is not None:
            out["label"] = self.label
        if self.track_id is not None:
            out["track_id"] = self.track_id
        if self.confidence is not None:
            out["confidence"] = self.confidence
        for name, lab in self.components.items():
            self._require_label(name, lab, path)
            out[name] = lab.to_dict()
        out.update(self.extras)
        return out

    def get_component(self, name):
        return self.components.get(name)

    def set_component(self, name, label):
        self.components[name] = label
        # to_dict()가 extras를 components 뒤에 덮어쓰므로, 같은 이름의 여분 키가
        # 남아 있으면 방금 설정한 component를 가려버린다.
        self.extras.pop(name, None)

    def remove_component(self, name):
        self.components.pop(name, None)

    def issues(self, path: str = "") -> "list[Issue]":
        """이 행의 위반 전부. `path` 는 이 행의 경로(`<그룹>[<번호>]`, 빈 문자열이면 접두 없음)."""
        out = common_issues(path, self.id, self.label, self.track_id, self.confidence, require_label=True)
        for name, lab in self.components.items():
            if not isinstance(lab, Label):
                # component 자리에는 단수 Label 만 — 그룹·컨테이너를 넣는 중첩은 금지다.
                p = _join(path, name)
                out.append(_issue(p, "invalid_type",
                                  f"{p}: component 는 Label 이어야 함, {type(lab).__name__} 받음"))
                continue
            out.extend(lab.issues(_join(path, name)))
        out.extend(extras_issues(path, self.extras))
        return out

    def validate(self) -> None:
        raise_for_issues(self.issues(""))

    def _require_label(self, name, lab, path: str = "") -> None:
        # save() 는 검증보다 먼저 to_dict() 로 diff 를 만들므로 거기서도 부른다
        # (안 그러면 검증 에러가 아니라 AttributeError 로 죽는다).
        if not isinstance(lab, Label):
            raise_for_issues([_issue(
                _join(path, name), "invalid_type",
                f"instance {self.id}: component '{name}' 은 Label 이어야 함, {type(lab).__name__} 받음")])
