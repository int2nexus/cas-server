from __future__ import annotations
import math

from ._types import Issue, NexusValidationError, raise_for_issues
from ._coco_rle import decode_counts

LABEL_REGISTRY: dict[str, "type[Label]"] = {}

#: 서버가 받는 component `type` 값 열 가지 — `COMPONENT_TYPES`(`catalog::annotation_validate`)와 같다.
COMPONENT_TYPES = (
    "classification", "value", "values", "keypoint_2d", "keypoint_3d",
    "bounding_box", "cuboid_3d", "mask", "polygon", "polyline",
)
MAX_MASK_PIXELS = 50_000_000  # 서버 mask_rle::MAX_MASK_PIXELS 와 같다.


def _finite(x) -> bool:
    """`math.isfinite` 와 같되 f64 를 넘는 큰 정수(`10**400`)에서 `OverflowError` 로 죽지 않고 거짓이다 — 서버(serde_json)는
    f64 로 읽어 무한대가 되는 수를 본문 해석에서 거절하므로 유한한 수가 아니다."""
    try:
        return math.isfinite(x)
    except OverflowError:
        return False


def _is_number(v) -> bool:
    """유한한 수(bool 제외). NaN·무한대는 JSON 으로 나갈 수 없어 수로 보지 않는다."""
    return isinstance(v, (int, float)) and not isinstance(v, bool) and _finite(v)


def _is_int(v) -> bool:
    """서버 `is_i64 || is_u64` 와 같은 범위의 정수(bool 제외). 범위 밖의 큰 정수는 서버가 실수로 읽어 정수가 아니다."""
    return isinstance(v, int) and not isinstance(v, bool) and -(2**63) <= v < 2**64


def _join(prefix: str, name: str) -> str:
    return f"{prefix}.{name}" if prefix else name


def _has(d: dict, k: str) -> bool:
    return d.get(k) is not None


def _issue(path: str, reason: str, message: str) -> Issue:
    return Issue(path, reason, message)


def _num_list(path: str, v, out: list) -> "list | None":
    """숫자 목록이면 그 목록을, 아니면 `field_type`(NaN·무한대만 문제면 `non_finite`)을 내고 None."""
    if not isinstance(v, list):
        out.append(_issue(path, "field_type", f"{path} 는 숫자 목록이어야 함"))
        return None
    plain = [x for x in v if isinstance(x, (int, float)) and not isinstance(x, bool)]
    if len(plain) != len(v):
        out.append(_issue(path, "field_type", f"{path} 의 원소는 유한한 수여야 함"))
        return None
    if not all(_finite(x) for x in v):
        out.append(_issue(path, "non_finite", f"{path} 에 NaN 또는 무한대가 있음"))
        return None
    return v


def _num_scalar(path: str, v, out: list) -> None:
    if isinstance(v, (int, float)) and not isinstance(v, bool) and not _finite(v):
        out.append(_issue(path, "non_finite", f"{path} 는 유한한 수여야 함"))
    elif not _is_number(v):
        out.append(_issue(path, "field_type", f"{path} 는 숫자여야 함"))


def _fixed_list(base: str, field: str, v, n: int, out: list) -> None:
    path = _join(base, field)
    a = _num_list(path, v, out)
    if a is not None and len(a) != n:
        out.append(_issue(path, "field_length", f"{path}: 숫자 {n}개 필요, {len(a)}개 받음"))


def _confidence(base: str, d: dict, out: list) -> None:
    if _has(d, "confidence"):
        _num_scalar(_join(base, "confidence"), d["confidence"], out)


def _label_confidence(base: str, d: dict, out: list) -> None:
    if _has(d, "label") and not isinstance(d["label"], str):
        p = _join(base, "label")
        out.append(_issue(p, "field_type", f"{p} 은 문자열이어야 함"))
    _confidence(base, d, out)


def component_issues(path: str, data) -> list:
    """component dict 하나의 위반(서버 `component_issues` 와 같은 규칙). `path` 는 그 component 키의 경로."""
    out: list = []
    if not isinstance(data, dict):
        return [_issue(path, "invalid_type", "component 는 객체여야 함")]
    if "type" not in data:
        return [_issue(path, "missing_type", f"{path or 'component'}: 'type' 이 없음")]
    ty = data["type"]
    if not isinstance(ty, str):
        return [_issue(path, "invalid_type", f"{path or 'component'}.type 은 문자열이어야 함")]
    f = lambda name: _join(path, name)  # noqa: E731
    if ty == "bounding_box":
        _fixed_list(path, "rect", data.get("rect"), 4, out)
        _label_confidence(path, data, out)
    elif ty == "classification":
        lab = data.get("label")
        if isinstance(lab, str) and lab != "":
            pass
        elif lab is not None and not isinstance(lab, str):
            out.append(_issue(f("label"), "field_type", f"{f('label')} 은 문자열이어야 함"))
        else:
            out.append(_issue(f("label"), "empty_label", f"{f('label')} 은 비지 않은 문자열이어야 함"))
        _confidence(path, data, out)
    elif ty in ("keypoint_2d", "keypoint_3d"):
        _keypoint_issues(path, ty, data, out)
    elif ty == "value":
        _num_scalar(f("value"), data.get("value"), out)
    elif ty == "values":
        _num_list(f("values"), data.get("values"), out)
        if _has(data, "dim") and not _is_int(data["dim"]):
            out.append(_issue(f("dim"), "field_type", f"{f('dim')} 은 정수여야 함"))
    elif ty == "cuboid_3d":
        _fixed_list(path, "center", data.get("center"), 3, out)
        _fixed_list(path, "dimensions", data.get("dimensions"), 3, out)
        if _has(data, "rotation"):
            _fixed_list(path, "rotation", data.get("rotation"), 9, out)
    elif ty in ("polygon", "polyline"):
        mn = 3 if ty == "polygon" else 2
        p = f("points")
        pts = _num_list(p, data.get("points"), out)
        if pts is not None:
            if len(pts) % 2 != 0:
                out.append(_issue(p, "field_length", f"{p} 는 짝수 길이의 평탄한 수 목록이어야 함"))
            elif len(pts) < mn * 2:
                out.append(_issue(p, "min_points", f"{p} 는 점 {mn}개 이상 필요, {len(pts) // 2}개 받음"))
    elif ty == "mask":
        _mask_issues(path, data, out)
    else:
        out.append(_issue(path, "unknown_type", f"알 수 없는 component type '{ty}'"))
    return out


def _keypoint_issues(path: str, ty: str, d: dict, out: list) -> None:
    axes = ("x", "y", "z") if ty == "keypoint_3d" else ("x", "y")
    n = None
    what = "num_keypoints"
    explicit = _has(d, "num_keypoints")
    if explicit:
        if _is_int(d["num_keypoints"]):
            # 서버는 `as_i64` 라 2**63 이상은 n 이 없는 것으로 보고 길이 검사를 건너뛴다.
            n = d["num_keypoints"] if d["num_keypoints"] < 2**63 else None
        else:
            p = _join(path, "num_keypoints")
            out.append(_issue(p, "field_type", f"{p} 는 정수여야 함"))
    lists = [(ax, _num_list(_join(path, ax), d.get(ax), out)) for ax in axes]
    if not explicit and lists[0][1] is not None:
        n = len(lists[0][1])
        what = f"len({axes[0]})"
    vis = _num_list(_join(path, "visibility"), d["visibility"], out) if _has(d, "visibility") else None
    if n is not None:
        for ax, lst in lists:
            if lst is not None and len(lst) != n:
                p = _join(path, ax)
                out.append(_issue(p, "length_mismatch", f"len({ax}) 는 {what}({n}) 와 같아야 함, {len(lst)}개 받음"))
        if vis is not None and len(vis) != n:
            p = _join(path, "visibility")
            out.append(_issue(p, "length_mismatch", f"len(visibility) 는 {what}({n}) 와 같아야 함, {len(vis)}개 받음"))
    _label_confidence(path, d, out)


def _mask_issues(path: str, d: dict, out: list) -> None:
    p = _join(path, "rle")
    rle = d.get("rle")
    if not isinstance(rle, dict):
        out.append(_issue(p, "field_type", f"{p} 는 객체여야 함"))
    else:
        size = rle.get("size")
        hw = None
        if not isinstance(size, list):
            out.append(_issue(p, "field_type", f"{p}.size 는 [높이, 너비] 여야 함"))
        elif len(size) != 2:
            out.append(_issue(p, "field_length", f"{p}.size 는 정수 2개여야 함"))
        elif all(_is_int(x) and x >= 1 for x in size):  # 서버 `as_u64`: 1 <= x < 2**64
            hw = (size[0], size[1])
        else:
            out.append(_issue(p, "field_type", f"{p}.size 는 1 이상의 정수 둘이어야 함"))
        counts = rle.get("counts")
        if not isinstance(counts, str):
            out.append(_issue(p, "field_type", f"{p}.counts 는 COCO compressed string 이어야 함"))
        if hw is not None and isinstance(counts, str):
            h, w = hw
            if h * w > MAX_MASK_PIXELS:
                out.append(_issue(p, "mask_invalid", f"{p}.size 의 화소 수가 상한({MAX_MASK_PIXELS})을 넘음"))
            else:
                try:
                    runs = decode_counts(counts)
                except ValueError as e:
                    out.append(_issue(p, "mask_invalid", f"{p}.counts 는 유효한 COCO compressed string 이 아님: {e}"))
                else:
                    if any(r < 0 for r in runs):
                        out.append(_issue(p, "mask_invalid", f"{p}.counts 에 음수 런이 있음"))
                    elif sum(runs) != h * w:
                        out.append(_issue(p, "mask_invalid", f"{p}.counts 런의 합이 높이 * 너비와 다름"))
                    elif sum(runs[1::2]) == 0:
                        out.append(_issue(p, "mask_invalid", "mask 에 foreground 화소가 없음"))
    _label_confidence(path, d, out)


class Label:
    """component 1개. 내부 dict를 verbatim 보존한다."""

    def __init__(self, data: dict):
        self._data = data

    @property
    def type(self) -> str:
        return self._data.get("type")

    def to_dict(self) -> dict:
        return self._data

    def issues(self, path: str = "") -> "list[Issue]":
        """이 component 의 위반 전부(서버와 같은 규칙·사유 코드). `path` 는 이 component 키의 경로다."""
        return component_issues(path, self._data)

    def validate(self) -> None:
        raise_for_issues(self.issues(""))

    @classmethod
    def from_dict(cls, d: dict) -> "Label":
        t = d.get("type") if isinstance(d, dict) else None
        sub = LABEL_REGISTRY.get(t)
        return sub(d) if sub else Label(d)


class _Typed(Label):
    """_data 필드를 속성으로 노출하는 베이스.

    두 가지로 만든다: `Detection({...})`(wire dict 를 그대로 — 로드 경로) 또는
    `Detection(rect=[...], label=...)`(키워드 — 새로 만들 때, 생성 끝에서 `validate()` 하므로 위반이면
    `NexusValidationError`). 키워드 쪽은 `type`을
    클래스가 채우고, 클래스가 아는 필드(`_FIELDS`)만 받는다 — 오타(`rct=`)가 저장 때가
    아니라 그 자리에서 `TypeError`로 드러난다. 값이 `None`인 키워드는 빼고 만든다(wire
    spec 이 명시적 null 을 금지한다). 목록에 없는 필드를 담아야 하면 dict 형태를 쓴다."""
    _TYPE: str = ""
    _FIELDS: tuple = ()

    def __init__(self, data: dict | None = None, **fields):
        if data is not None:
            if fields:
                raise TypeError(f"{type(self).__name__}() takes a dict or keywords, not both")
            super().__init__(data)
            return
        unknown = sorted(set(fields) - set(self._FIELDS))
        if unknown:
            raise TypeError(
                f"{type(self).__name__}() got unexpected field(s) {', '.join(unknown)} "
                f"(allowed: {', '.join(self._FIELDS)})")
        d = {"type": self._TYPE}
        d.update({k: v for k, v in fields.items() if v is not None})
        self._complete(d)
        super().__init__(d)
        # 키워드로 새로 만든 것은 그 자리에서 검증한다(dict 인자 = 로드 경로는 검증하지 않는다).
        self.validate()

    def _complete(self, d: dict) -> None:
        """키워드 생성 때 유도 가능한 필드를 채운다(기본은 없음)."""

    def issues(self, path: str = "") -> "list[Issue]":
        # 클래스와 wire type 이 어긋나면(Detection 인데 "polygon") 이 클래스의 규칙으로 검사한 것이
        # 서버에 나가는 타입과 무관해진다.
        if isinstance(self._data, dict) and self._data.get("type") != self._TYPE:
            return [_issue(path, "invalid_type",
                           f"{type(self).__name__} 의 type 은 '{self._TYPE}' 여야 함, '{self._data.get('type')}' 받음")]
        return super().issues(path)

    def _get(self, k):
        return self._data.get(k)
    def _set(self, k, v):
        self._data[k] = v


class Detection(_Typed):
    _TYPE = "bounding_box"
    _FIELDS = ("rect", "label", "confidence", "rotation")

    @property
    def rect(self): return self._get("rect")
    @rect.setter
    def rect(self, v): self._set("rect", v)
    @property
    def label(self): return self._get("label")
    @label.setter
    def label(self, v): self._set("label", v)
    @property
    def confidence(self): return self._get("confidence")
    @confidence.setter
    def confidence(self, v): self._set("confidence", v)
    @property
    def rotation(self): return self._get("rotation")


class Classification(_Typed):
    _TYPE = "classification"
    _FIELDS = ("label", "confidence")

    @property
    def label(self): return self._get("label")
    @label.setter
    def label(self, v): self._set("label", v)
    @property
    def confidence(self): return self._get("confidence")


class Keypoint2D(_Typed):
    _TYPE = "keypoint_2d"
    _FIELDS = ("x", "y", "visibility", "num_keypoints", "label", "confidence")
    _AXES = ("x", "y")

    def _complete(self, d: dict) -> None:
        # num_keypoints 는 x 의 길이에서 나온다 — 따로 적게 하면 외울 규칙이 하나 는다.
        if "num_keypoints" not in d and isinstance(d.get("x"), list):
            d["num_keypoints"] = len(d["x"])

    @property
    def num_keypoints(self):
        return self._get("num_keypoints")

    @property
    def x(self):
        return self._get("x")

    @x.setter
    def x(self, v):
        self._set("x", v)

    @property
    def y(self):
        return self._get("y")

    @y.setter
    def y(self, v):
        self._set("y", v)

    @property
    def visibility(self):
        return self._get("visibility")

    @visibility.setter
    def visibility(self, v):
        self._set("visibility", v)

    @property
    def label(self):
        return self._get("label")

    @property
    def confidence(self):
        return self._get("confidence")


class Keypoint3D(Keypoint2D):
    _TYPE = "keypoint_3d"
    _FIELDS = ("x", "y", "z", "visibility", "num_keypoints", "label", "confidence")
    _AXES = ("x", "y", "z")

    @property
    def z(self):
        return self._get("z")

    @z.setter
    def z(self, v):
        self._set("z", v)


class ScalarValue(_Typed):
    _TYPE = "value"
    _FIELDS = ("value",)

    @property
    def value(self):
        return self._get("value")

    @value.setter
    def value(self, v):
        self._set("value", v)


class VectorValue(_Typed):
    _TYPE = "values"
    _FIELDS = ("values", "dim")

    @property
    def values(self):
        return self._get("values")

    @values.setter
    def values(self, v):
        self._set("values", v)


class Cuboid3D(_Typed):
    _TYPE = "cuboid_3d"
    _FIELDS = ("center", "dimensions", "rotation")

    @property
    def center(self):
        return self._get("center")

    @property
    def dimensions(self):
        return self._get("dimensions")

    @property
    def rotation(self):
        return self._get("rotation")


class Polygon(_Typed):
    _TYPE = "polygon"
    _FIELDS = ("points",)
    _MIN_POINTS = 3

    @property
    def points(self):
        return self._get("points")

    @points.setter
    def points(self, v):
        self._set("points", v)


class Polyline(Polygon):
    _TYPE = "polyline"
    _FIELDS = ("points", "closed")
    _MIN_POINTS = 2

    @property
    def closed(self):
        return self._get("closed")

    @closed.setter
    def closed(self, v):
        self._set("closed", v)


class Mask(_Typed):
    """래스터 마스크. `rle` 는 COCO 압축 RLE `{"size": [높이, 너비], "counts": 문자열}`(픽셀 단위, 열 우선)이다.

    pycocotools 의 `encode` 가 주는 `counts` 는 `bytes` 라 생성 때 ASCII 문자열로 바꾼다(JSON 으로 못 나가서다)."""
    _TYPE = "mask"
    _FIELDS = ("rle", "label", "confidence")
    MAX_PIXELS = MAX_MASK_PIXELS  # SDK 에서 통과한 마스크는 CVAT 로 보낼 수 있다.

    def __init__(self, data: dict | None = None, **fields):
        if data is not None:
            super().__init__(data, **fields)
            self._complete(self._data)
        else:
            super().__init__(data, **fields)  # 키워드 경로는 _complete 가 검증 전에 이미 바꿨다

    def _complete(self, d: dict) -> None:
        rle = d.get("rle")
        if isinstance(rle, dict) and isinstance(rle.get("counts"), (bytes, bytearray)):
            # 호출자의 rle dict 는 바꾸지 않는다(pycocotools 결과를 다른 곳에서 bytes 로 계속 쓸 수 있다).
            rle = dict(rle)
            try:
                rle["counts"] = bytes(rle["counts"]).decode("ascii")
            except UnicodeDecodeError:
                raise NexusValidationError("mask.rle.counts must be an ASCII COCO compressed string") from None
            d["rle"] = rle

    @property
    def rle(self): return self._get("rle")
    @rle.setter
    def rle(self, v): self._set("rle", v)
    @property
    def label(self): return self._get("label")
    @label.setter
    def label(self, v): self._set("label", v)
    @property
    def confidence(self): return self._get("confidence")
    @confidence.setter
    def confidence(self, v): self._set("confidence", v)


for _cls in (Detection, Classification, Keypoint2D, Keypoint3D, ScalarValue, VectorValue,
             Cuboid3D, Polygon, Polyline, Mask):
    LABEL_REGISTRY[_cls._TYPE] = _cls
