from __future__ import annotations
import warnings
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, as_completed, wait
from pathlib import Path

from tqdm import tqdm

from nexus._types import NexusCasError
from nexus.cas import CasClient
from nexus.imageinfo import image_info
from nexus.sample import CasRef

THUMBNAIL_MAX_EDGE = 256
THUMBNAIL_QUALITY = 80

# 16 비트(깊이 맵 등) 그레이스케일 모드. Pillow 가 PNG 16 비트를 열 때 쓰는 이름들이다.
_GRAY16_MODES = ("I;16", "I;16L", "I;16B", "I;16N", "I")


def _gray16_to_l(img) -> "Image.Image":
    """16 비트 그레이스케일 → 8 비트 L. 0 은 무효(깊이 없음)라 검정으로 두고, 0 이 아닌 값의
    2~98 백분위 구간을 1..255 로 선형 사상한다(구간 밖은 클립). 255 에서 자르면 mm 단위
    깊이 맵이 전부 하얗게 날아간다. 유효값이 없으면 전부 0, 구간 폭이 0 이면 유효값을 255 로 둔다.
    """
    from PIL import Image
    img = img.convert("I")
    img.thumbnail((THUMBNAIL_MAX_EDGE, THUMBNAIL_MAX_EDGE), Image.NEAREST)
    data = list(img.getdata())
    valid = sorted(v for v in data if v != 0)
    out = Image.new("L", img.size)
    if not valid:
        return out
    n = len(valid)
    lo = valid[round(0.02 * (n - 1))]
    hi = valid[round(0.98 * (n - 1))]
    span = hi - lo

    def _map(v: int) -> int:
        if v == 0:
            return 0
        if span <= 0:
            return 255
        return max(1, min(255, 1 + round((v - lo) / span * 254)))

    out.putdata([_map(v) for v in data])
    return out


def _make_thumbnail(image_bytes: bytes) -> "bytes | None":
    """원본 이미지 bytes → longest-edge 256 WebP bytes. 디코딩 실패 시 None."""
    try:
        from PIL import Image
    except ImportError:
        raise ImportError("pillow is required for thumbnails: pip install pillow")
    import io
    try:
        img = Image.open(io.BytesIO(image_bytes))
        if img.mode in _GRAY16_MODES:
            img = _gray16_to_l(img)
        img = img.convert("RGB")
        img.thumbnail((THUMBNAIL_MAX_EDGE, THUMBNAIL_MAX_EDGE))
        buf = io.BytesIO()
        img.save(buf, format="WEBP", quality=THUMBNAIL_QUALITY)
        return buf.getvalue()
    except Exception as exc:
        warnings.warn(f"thumbnail generation failed: {exc}", RuntimeWarning, stacklevel=2)
        return None


def upload(
    paths,
    bucket: str,
    prefix: str = "",
    *,
    workers: int = 8,
    verbose: bool = True,
    strict: bool = False,
    overwrite: bool = False,
    client=None,
    cas=None,
) -> "dict[str, CasRef]":
    """로컬 파일들을 CAS에 직접 업로드하고 {경로: 리치 CasRef} 를 반환한다.

    각 파일: key={prefix}/{filename}, blake3 hash·size·content_type 계산, HEAD-skip(동일 hash)
    /충돌(다른 hash) 검사 후 PUT, WebP 256px 썸네일을 thumb/<key>에 함께 업로드(best-effort).

    같은 key에 **다른 내용**이 이미 있으면 기본은 충돌 에러다. `overwrite=True`면 대신 그
    key를 덮어쓴다 — 썸네일도 새 내용으로 함께 덮어쓴다(안 그러면 옛 이미지의 썸네일이
    새 이미지에 그대로 남는다). 같은 내용이면 overwrite 여부와 무관하게 PUT을 건너뛴다
    (이미 맞는 상태라 다시 쓸 이유가 없다).

    일시적 네트워크/5xx 오류는 CAS 클라이언트가 전송 계층에서 재시도한다. 재시도 후에도
    실패한 파일은 **건당 격리**되어 배치 전체를 중단시키지 않는다 — 성공분만 반환한다.
    `strict=True`면 실패가 하나라도 있으면 `NexusCasError`를 던진다(기본 False는 경고만).
    같은 paths로 다시 호출하면 이미 올라간 건 HEAD-skip되어 실패분만 재시도(resume)된다.
    """
    import nexus as _nx
    _client = client
    _cas = cas
    if _client is None or _cas is None:
        if _nx._client is None:
            _nx._auto_connect()
        _client = _client or _nx._client
        _cas = _cas or _nx._cas

    _client.ensure_bucket(bucket)
    prefix = prefix.strip("/") if prefix else ""

    def _one(path) -> "tuple[str, CasRef]":
        p = Path(path)
        data = p.read_bytes()
        hash_hex = CasClient.hash_bytes(data)
        key = f"{prefix}/{p.name}" if prefix else p.name
        content_type = CasClient.content_type(p)

        existing = _cas.head(bucket, key)
        content_changed = existing is None
        if existing is None:
            _cas.put(bucket, key, data, content_type)
        elif existing.get("hash_hex") and existing["hash_hex"] != hash_hex:
            if not overwrite:
                raise NexusCasError(
                    f"CAS key 충돌: '{bucket}/{key}'에 다른 내용이 이미 존재합니다 "
                    f"(기존 {existing['hash_hex'][:12]} != 신규 {hash_hex[:12]}). "
                    "prefix·파일명을 바꾸거나 overwrite=True로 덮어쓰세요."
                )
            _cas.put(bucket, key, data, content_type)
            content_changed = True

        info = image_info(data)
        thumb = _make_thumbnail(data)
        if thumb is not None:
            try:
                thumb_key = f"thumb/{key}"
                # 내용을 덮어썼으면 썸네일도 무조건 다시 쓴다 — 안 그러면 옛 이미지의
                # 썸네일이 새 이미지에 그대로 남는다. 내용이 그대로면(HEAD-skip) 기존과
                # 동일하게 없을 때만 쓴다.
                if content_changed or _cas.head(bucket, thumb_key) is None:
                    _cas.put(bucket, thumb_key, thumb, "image/webp")
            except Exception as exc:
                warnings.warn(f"thumbnail upload failed: {exc}", RuntimeWarning, stacklevel=2)

        return str(path), CasRef(
            bucket=bucket, key=key, hash_hex=hash_hex,
            size=len(data), content_type=content_type,
            width=info.width if info else None,
            height=info.height if info else None,
        )

    refs: dict[str, CasRef] = {}
    errors: dict[str, Exception] = {}
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(_one, p): p for p in paths}
        for f in tqdm(as_completed(futures), total=len(futures),
                      desc="Uploading", disable=not verbose):
            try:
                k, ref = f.result()
                refs[k] = ref
            except Exception as exc:   # 건당 격리: 한 파일 실패가 배치를 죽이지 않음
                errors[str(futures[f])] = exc

    if errors:
        shown = ", ".join(list(errors)[:5])
        more = f" 외 {len(errors) - 5}건" if len(errors) > 5 else ""
        first_err = next(iter(errors.values()))
        msg = (
            f"{len(errors)}개 파일 업로드 실패(재시도 후): {shown}{more}. "
            f"첫 에러: {first_err}. "
            "같은 paths로 nx.upload를 다시 호출하면 성공분은 건너뛰고 실패분만 재시도합니다."
        )
        if strict:
            raise NexusCasError(msg)
        warnings.warn(msg, RuntimeWarning, stacklevel=2)
    return refs


# `rewrite_thumbnails` 가 일꾼 하나당 한꺼번에 띄워 두는 작업 수(읽기가 앞서 나가지 않게 하는 창).
_REWRITE_IN_FLIGHT_PER_WORKER = 4


def _attach_partial(exc: BaseException, result: dict) -> None:
    """`rewrite_thumbnails` 가 멈출 때 그때까지의 결과를 예외의 `partial_result` 에 싣는다(속성을 받지 않는 예외는 그대로)."""
    try:
        exc.partial_result = result
    except AttributeError:
        pass


def rewrite_thumbnails(refs, *, workers: int = 8, verbose: bool = True, cas=None) -> dict:
    """이미 CAS 에 올라간 객체들의 썸네일(`thumb/<key>`)을 **조건 없이** 다시 만들어 쓴다.

    `refs` 는 `CasRef` 또는 `s3://`·`http(s)://` URL 목록. 원본을 GET 해 썸네일을 만들고
    기존 썸네일이 있어도 덮어쓴다(HEAD 하지 않는다) — 썸네일 생성 규칙이 바뀐 뒤 옛 썸네일을
    고칠 때 쓴다. 이미지가 아니어서 썸네일을 못 만들면 `skipped`, 읽기·쓰기 실패는 건당
    격리되어 `failed` 에 담긴다(배치를 중단하지 않는다).

    같은 `(bucket, key)` 는 한 번만 처리한다(처음 나온 순서). 결과의 키는 `"{bucket}/{key}"` 다 —
    refs 에 bucket 이 섞일 수 있어 key 만으로는 구분되지 않는다.

    `refs` 는 제너레이터여도 된다 — 목록을 먼저 만들지 않고 읽는 대로 넘기며, 한꺼번에 진행 중인 작업은
    `workers × _REWRITE_IN_FLIGHT_PER_WORKER`(4) 개까지다. 그래서 메모리는 refs 의 길이가 아니라 처리한 객체 수(본
    `(bucket, key)` 집합)와 실패 수에 비례한다. 진행 막대의 전체 수는 refs 가 `len()` 을 가질 때만 그 값(중복·잘못된
    참조 포함)이고, 끝나면(멈춰도) 실제로 처리한 수로 맞춘다. 도중에 멈추면(`refs` 가 예외를 냈다, `KeyboardInterrupt` 등)
    아직 시작하지 않은 작업은 취소하고 도는 작업만 마저 거둔 뒤 그때까지의 결과(반환과 같은 dict)를 그 예외의
    `partial_result` 속성에 실어 올린다. 거두는 동안 다시 멈추면(두 번째 Ctrl-C) 도는 작업을 기다리지 않고 그 나중
    예외를 올리며(첫 예외는 `__cause__`), 그 작업이 뒤에서 쓴 썸네일은 결과에 없을 수 있다. 도는 작업의 스레드는 멈출 수
    없어, 프로세스가 끝날 때는 표준 라이브러리가 그 작업이 끝나기를 기다린다(CAS 응답이 멈춰 있으면 종료도 멈춘다). `failed` 의 키 순서는 실패한 순서다(잘못된
    참조와 읽기·쓰기 실패가 섞인다).

    반환: `{"written": int, "skipped": ["bucket/key"], "failed": {"bucket/key": 오류 문자열}}`.
    """
    import nexus as _nx
    from nexus.sample import _parse_ref

    _cas = cas
    if _cas is None:
        if _nx._client is None:
            _nx._auto_connect()
        _cas = _nx._cas

    def _coerce(src) -> CasRef:
        ref = src if isinstance(src, CasRef) else _parse_ref(src)
        if not isinstance(ref, CasRef):
            raise ValueError("CAS 참조(CasRef 또는 s3://·http(s):// URL)여야 합니다")
        return ref

    def _one(ref: CasRef) -> bool:
        data = _cas.get(ref.bucket, ref.key)
        thumb = _make_thumbnail(data)
        if thumb is None:
            return False
        _cas.put(ref.bucket, f"thumb/{ref.key}", thumb, "image/webp")
        return True

    written = 0
    skipped: list = []
    failed: dict = {}
    seen: set = set()

    def _result() -> dict:
        return {"written": written, "skipped": skipped, "failed": failed}

    def _collect(done, pending: dict, bar) -> None:
        nonlocal written
        for f in done:
            ref = pending.pop(f)
            # 결과를 먼저 적고 막대를 움직인다 — 막대가 터져도 끝난 작업이 셈에서 빠지지 않게.
            try:
                ok = f.result()
            except Exception as exc:
                failed[f"{ref.bucket}/{ref.key}"] = str(exc)
            else:
                if ok:
                    written += 1
                else:
                    skipped.append(f"{ref.bucket}/{ref.key}")
            bar.update(1)

    total = len(refs) if hasattr(refs, "__len__") else None
    pool = ThreadPoolExecutor(max_workers=workers)
    # 창은 풀이 실제로 잡은 일꾼 수로 정한다(`workers=None` 의 기본값을 따로 셈하면 판마다 풀과 어긋난다). 비공개
    # 속성이라 없으면 받은 값(없으면 1)로 좁게 잡는다 — 창이 작으면 느려질 뿐 틀리지 않는다.
    n_workers = getattr(pool, "_max_workers", None) or workers or 1
    window = n_workers * _REWRITE_IN_FLIGHT_PER_WORKER
    abandon = False  # 거두는 도중 다시 멈췄다 — 도는 작업을 기다리지 않고 돌아간다
    try:
        with tqdm(total=total, desc="Rewriting thumbnails", disable=not verbose) as bar:
            pending: dict = {}
            try:
                for src in refs:
                    try:
                        ref = _coerce(src)
                    except Exception as exc:
                        failed[str(src)] = str(exc)
                        continue
                    if (ref.bucket, ref.key) in seen:
                        continue
                    pending[pool.submit(_one, ref)] = ref
                    seen.add((ref.bucket, ref.key))  # 넣은 뒤에 본다 — 넣다 실패한 참조가 어디에도 안 남지 않게
                    # 읽는 쪽이 앞서 나가지 않게 진행 중인 작업 수를 묶는다 — 넘치면 하나라도 끝날 때까지 기다린다.
                    if len(pending) >= window:
                        done, _ = wait(pending, return_when=FIRST_COMPLETED)
                        _collect(done, pending, bar)
                # 끝나는 대로 하나씩 거둔다(`as_completed` 는 부를 때의 집합을 잡아 두므로 거두며 빼도 된다).
                _collect(as_completed(pending), pending, bar)
            except BaseException as exc:
                # 도중에 멈췄다(`refs` 가 서버 오류를 냈다, Ctrl-C 등). 아직 시작하지 않은 작업은 취소하고(쓰지 않았으니
                # 결과에도 없다 — 다시 부르면 처리된다) 도는 작업만 마저 거둬 그때까지의 결과를 예외에 싣는다. 쓴 썸네일은
                # 되돌리지 않으므로 무엇을 썼는지 알아야 남은 것만 다시 한다.
                for f in list(pending):
                    if f.cancel():
                        pending.pop(f)
                try:
                    _collect(as_completed(pending), pending, bar)
                except BaseException as again:
                    # 거두다 다시 멈췄다(두 번째 Ctrl-C 등) — 거둔 데까지만 싣고 도는 작업은 기다리지 않는다. 그 작업은
                    # 뒤에서 끝날 수 있어 결과에 없는 썸네일이 쓰였을 수 있다(다시 써도 같은 결과다). 나중 예외를 올린다 —
                    # 첫 예외(서버 오류 등)를 올리면 그것을 잡아 다시 도는 호출부가 사용자의 Ctrl-C 를 삼킨다.
                    abandon = True
                    _attach_partial(again, _result())
                    raise again from exc
                _attach_partial(exc, _result())
                raise
            finally:
                bar.total = bar.n  # 처리한 수로 맞춘다(중복·잘못된 참조·취소한 작업은 처리하지 않았다)
                bar.refresh()
    finally:
        pool.shutdown(wait=not abandon, cancel_futures=True)
    return _result()
