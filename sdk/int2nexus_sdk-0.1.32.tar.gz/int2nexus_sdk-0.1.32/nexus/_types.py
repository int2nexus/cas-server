from __future__ import annotations
from dataclasses import dataclass
from typing import TYPE_CHECKING

from urllib.parse import urlsplit

import requests

from nexus import _retry

if TYPE_CHECKING:
    from nexus.sample import Sample


class NexusError(Exception):
    """모든 nexus 예외의 베이스. HTTP 에러로 발생한 경우 `status_code`/`server_message`가
    채워진다(`server_message` = 서버 응답 바디의 `{"error": "..."}` 텍스트, 없으면 None) —
    `str(e)`에도 포함되지만, 프로그램적으로 분기하려면 이 두 속성을 쓴다:
    `except NexusError as e: if e.status_code == 403: ...`."""

    def __init__(
        self,
        message: str = "",
        *,
        status_code: "int | None" = None,
        server_message: "str | None" = None,
        code: "str | None" = None,
        rejected: "list[dict] | None" = None,
        needs_origin: "list[dict] | None" = None,
    ) -> None:
        self.status_code = status_code
        self.server_message = server_message
        self.code = code
        self.rejected = rejected
        # 링크의 400 `from_version_required` 본문 — `[{"sample_id", "versions": [...]}]`(`sample_id` 순 앞 1,000 개 샘플, 샘플마다
        # 그 샘플이 든 버전 앞 100 개 — 전체 수는 본문의 `needs_origin_total`).
        self.needs_origin = needs_origin
        super().__init__(message)


class NexusVersionJobPending(NexusError):
    """seal·fork 가 서버 작업 줄(202)에 올랐는데 `wait` 안에 끝나지 않았다. 작업은 서버에서 계속 돈다.

    `job_id`·`job`(마지막으로 읽은 작업 dict)으로 `NexusClient.get_version_job(job_id)` 를 다시 불러 확인한다."""

    def __init__(self, job: dict, message: "str | None" = None) -> None:
        self.job = job
        self.job_id = job.get("job_id")
        super().__init__(
            message or f"버전 작업 {self.job_id} 이(가) 아직 끝나지 않았습니다 (state={job.get('state')})"
        )


class NexusSchemaJobPending(NexusError):
    """스키마 재계산 작업이 `wait` 안에 끝나지 않았다. 작업은 서버에서 계속 돈다.

    `job_id`·`job`(마지막으로 읽은 작업 dict)으로 `NexusClient.get_schema_job(job_id)` 를 다시 불러 확인한다.
    seal·fork 의 `NexusVersionJobPending` 과는 다른 작업 줄이라 따로 둔다."""

    def __init__(self, job: dict, message: "str | None" = None) -> None:
        self.job = job
        self.job_id = job.get("job_id")
        super().__init__(
            message or f"스키마 재계산 작업 {self.job_id} 이(가) 아직 끝나지 않았습니다 (state={job.get('state')})"
        )


def _raise_for_status(response: "requests.Response") -> None:
    """`response.raise_for_status()` 대체 — 실패 시 서버가 보낸 `{"error": "..."}` 본문을
    담아 `NexusError`를 던진다. `str(requests.HTTPError)`는 상태코드/URL만 담고 응답 바디는
    버리므로, 이 함수 없이 raw HTTPError를 그대로 전파하면 서버가 공들여 만든 에러 메시지
    (예: sealed 버전 안내, 403 사유, 필터링된 fork의 비멤버 sample_id 목록)가 전부 사라진다."""
    if response.ok:
        return
    code = rejected = needs_origin = None
    errors = None
    try:
        body = response.json()
        server_message = body.get("error") if isinstance(body, dict) else None
        if isinstance(body, dict):
            code = body.get("code")
            rejected = body.get("rejected")
            needs_origin = body.get("needs_origin")
            errors = body.get("errors")
    except ValueError:
        server_message = None
    server_message = server_message or (response.text or None)
    message = f"{response.status_code} {response.reason} for {response.request.method} {response.url}"
    if server_message:
        message = f"{message} — {server_message}"
    if code == "annotation_invalid":
        # 서버의 component·그룹 규칙 위반 — SDK 가 거른 것과 같은 모양(`errors` 에 `Issue`)으로 올린다.
        issues = [
            Issue(path=str(e.get("path", "")), reason=str(e.get("reason", "")), message=str(e.get("message", "")))
            for e in (errors if isinstance(errors, list) else []) if isinstance(e, dict)
        ]
        raise NexusValidationError(
            message, errors=issues, status_code=response.status_code, server_message=server_message, code=code,
        )
    if (
        response.status_code == 504
        and _retry.REQUEST_ID_HEADER not in response.headers
        and _retry.is_heavy_read(response.request.method, urlsplit(response.request.url).path)
    ):
        message = f"{message} ({_retry.HEAVY_READ_HINT})"
    raise NexusError(
        message, status_code=response.status_code, server_message=server_message,
        code=code, rejected=rejected, needs_origin=needs_origin,
    )


class NexusAuthError(NexusError):
    pass


class NexusCasError(NexusError):
    pass


class NexusIngestError(NexusError):
    pass


class NexusValidationError(NexusError):
    """보낸 데이터의 형식 오류. SDK 가 보내기 전에 거른 것(save() 시점 type check 등, `status_code` 없음)과
    annotation 쓰기(`AnnotatedSample.save()`)에서 서버가 400 으로 거절한 것
    (`status_code=400`, `server_message` 에 서버 사유 — nexus-server 0.1.30 부터)이 이 예외다.

    SDK 가 거른 것은 `errors` 에 위반 전부를 `Issue(path, reason, message)` 로 담는다(메시지는 앞 5 개 요약).
    `path` 는 `<그룹>[<행 번호>].<component 키>.<필드>`, `reason` 은 서버 `annotation_invalid` 와 같은 코드다."""

    def __init__(self, message: str = "", errors: "list[Issue] | None" = None, **kwargs) -> None:
        super().__init__(message, **kwargs)
        self.errors: "list[Issue]" = list(errors or [])


@dataclass(frozen=True)
class Issue:
    """검증 위반 하나. 서버 `annotation_invalid` 본문의 `errors` 원소와 같은 모양이다."""
    path: str
    reason: str
    message: str


def _issue_line(i: Issue) -> str:
    """요약 한 줄 `<path>: <message>`. message 는 서버와 같은 값이라 흔히 필드 이름(`rect: …`·`bounding_box.rect: …`)으로
    시작한다 — 그 머리가 path 의 끝과 같으면 떼어 `rect: rect: …` 처럼 두 번 찍히지 않게 한다(`Issue.message` 는 그대로)."""
    if not i.path:
        return i.message
    head, sep, rest = i.message.partition(": ")
    if sep and (i.path == head or i.path.endswith("." + head)):
        return f"{i.path}: {rest}"
    return f"{i.path}: {i.message}"


def raise_for_issues(issues: "list[Issue]") -> None:
    """위반이 있으면 앞 5 개를 요약한 메시지로 `NexusValidationError`(`errors` 는 전부)를 던진다."""
    if not issues:
        return
    shown = "; ".join(_issue_line(i) for i in issues[:5])
    more = f" (외 {len(issues) - 5}건)" if len(issues) > 5 else ""
    raise NexusValidationError(f"{shown}{more}", errors=issues)


class NexusBatchError(NexusError):
    def __init__(self, failures: list[IngestResult]) -> None:
        self.failures = failures
        super().__init__(f"{len(failures)} sample(s) failed to ingest")


@dataclass
class IngestResult:
    ok: bool
    sample: Sample | None
    sample_id: str | None = None
    error: str | None = None
    #: 실패 item의 HTTP 상태코드(배치는 전체가 200이라 본문에서만 알 수 있다).
    #: 401/403은 데이터 문제가 아니라 권한 문제여서 재시도해도 소용없다.
    status_code: int | None = None
    #: 입력에서의 위치(0부터) — `flush` 는 호출 시점 큐.
    #: 결과 목록도 이 순서로 온다(0.1.18). 병렬 처리라 끝나는 순서는 다르다.
    index: int | None = None
    #: 멱등 키 재전송으로 서버가 기존 결과를 돌려준 것이면 True(서버 0.1.20~). 성공으로 센다.
    replayed: bool = False
    #: 실패의 원인 예외. 서버가 item 을 `annotation_invalid` 로 거절했거나 SDK 사전 검사가 걸렀으면
    #: `NexusValidationError`(`errors` 에 `Issue(path, reason, message)`)라 두 경우를 같은 방식으로 다룬다.
    #: annotation 검증 실패(서버 `annotation_invalid` 또는 SDK 사전 검사)만 담고 그 밖의 실패는 늘 `None` 이다(이때는 `error` 문자열만 본다).
    exception: "NexusError | None" = None
