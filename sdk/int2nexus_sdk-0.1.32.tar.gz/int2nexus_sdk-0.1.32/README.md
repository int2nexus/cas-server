# int2nexus-sdk

Python SDK for uploading ML training data to a nexus-server instance. (배포명 `int2nexus-sdk`, import는 `import nexus`.)

## Installation

공개 인덱스(PEP 503)에서 설치:

```bash
pip install --extra-index-url https://int2nexus.github.io/cas-server/sdk/simple/ int2nexus-sdk
```

- 배포명은 `int2nexus-sdk`지만 **import는 `import nexus`** 다. (PyPI의 동명 `nexus-sdk`와 충돌을 피하려 배포명을 네임스페이스화했다.)
- `--extra-index-url`(≠ `--index-url`): `int2nexus-sdk`는 위 인덱스에서, 의존성은 PyPI에서 받습니다.
- 버전 고정: `int2nexus-sdk==0.1.3`.
- 개발 설치(소스): `pip install -e ./sdk`.

## Quick Start

### 설정 파일 (권장)

`~/.int2nexus/settings.json`에 한 번 적어두면 `nx.connect()` 한 줄로 접속된다. 스크립트에 자격증명을 적지 않아도 된다.

```json
{
  "nexus_url": "http://localhost:8090",
  "email": "user@example.com",
  "password": "secret",
  "cas_url": "http://localhost:8080",
  "cas_key_id": "mykey",
  "cas_secret": "mysecret"
}
```

```bash
mkdir -p ~/.int2nexus
$EDITOR ~/.int2nexus/settings.json
chmod 600 ~/.int2nexus/settings.json     # 비밀번호·CAS secret이 들어 있다
```

- **비밀번호와 CAS secret이 평문으로 저장된다.** POSIX에서는 권한이 느슨하면 SDK가 경고한다. **Windows에서는 `chmod`가 사실상 무의미**하므로 검사하지 않는다 — 파일 위치와 접근 권한은 사용자 책임이다.
- `nexus_url` 은 nexus-server 가 받는 경로의 기준 주소다. 앞단(nexus-client 등)이 경로 접두어를 떼고 넘기면 그 접두어까지 적는다 —
  nexus-client 를 거치면 `http://<nexus-client 주소>/api`. 틀리면 로그인이 `404` 다(`usage.md` 「0. SDK 설치 & 연결」).
- 경로를 바꾸려면 `NEXUS_SETTINGS=/path/to/settings.json` 또는 `nx.connect(settings_path=...)`.
- `cas_key_id`/`cas_secret`/`verify`는 선택. 모르는 키는 경고한다(오타 탐지).

### 워크로드는 로봇 토큰으로 (0.1.10+)

사람이 없는 환경(적재 잡, 스케줄러, CI)에서는 로그인할 수 없다. 관리자가 만든 **로봇 계정**의 장수명 토큰을 그대로 제시한다 — `email`/`password`는 필요 없다.

```python
nx.connect(robot_token="nxr_...")     # 또는 NEXUS_ROBOT_TOKEN 환경변수
```

**서버 부재를 기다린다 (0.1.19+).** `nx.connect(retry_timeout=120)`(기본 120초, 환경변수 `NEXUS_RETRY_TIMEOUT`, 설정 파일 키 `retry_timeout`, `0` 이면 끔) — cas-server·nexus-server 교체 중의 연결 실패·502·503·504 를 첫 실패부터 이 시간까지 기다렸다 다시 보낸다. 단 무거운 읽기(explorer·explorer 개수·subset 샘플 — `ds.samples()`·`len(ds)` 등)는 응답 헤더를 기다리다 난 읽기 시한 초과와 nexus 가 내지 않은 504 를 다시 보내지 않고 곧바로 예외다(0.1.30). 자세한 것은 `CHANGELOG.md`.

**설정 파일에 저장하지 않는다.** 배포가 sealed-secret에서 환경변수로 주입하는 값이지 이 라이브러리가 관리할 것이 아니다.

갱신도 재로그인도 없다 — `401`은 그대로 올라온다(폐기·만료·계정 정지 중 무엇이든 관리자가 조작해야 풀린다). 로봇은 **삭제를 못 한다**(적재·수정·seal은 된다). 자세한 것은 `usage.md` §19.

### CAS 임시 자격증명 — STS (0.1.12+)

cas 에 STS(`auth.oidc.issuers`)가 켜져 있으면 장수명 CAS 키 대신 OIDC 토큰으로 임시 자격증명을
받아 쓸 수 있다. **명시 인자로만 켜진다** — AWS 환경변수(`AWS_WEB_IDENTITY_TOKEN_FILE` 등)는 읽지
않으므로 같은 프로세스의 다른 저장소 키와 섞이지 않는다.

```python
import nexus as nx

# 쿠버네티스 projected 토큰 — 갱신할 때마다 파일을 다시 읽는다
nx.connect(nexus_url="http://nexus-server", robot_token="nxr_...", cas_url="http://cas-server",
           cas_sts=nx.CasSts(token_file="/var/run/secrets/tokens/cas"))

# 토큰을 코드가 가져오는 경우(예: Keycloak) — 갱신할 때마다 다시 호출된다
nx.connect(nexus_url="http://nexus-server", robot_token="nxr_...", cas_url="http://cas-server",
           cas_sts=nx.CasSts(token_provider=get_access_token, duration_seconds=3600))
```

- **토큰의 남은 수명은 900초 이상이어야 한다**(cas 발급 하한). projected 토큰은 `expirationSeconds`
  7200 이상을, Keycloak 은 realm 액세스 토큰 수명(기본 300초)을 올린다.
- 남은 수명이 600초 이하가 되면 새로 받는다. 갱신이 실패해도 기존 자격증명이 60초 넘게 남아
  있으면 경고만 내고 계속 쓴다.
- `cas_key_id`/`cas_secret` 인자와 함께 주면 `ValueError`. 환경변수·설정 파일의 정적 키는 경고와
  함께 무시하고, nexus 자동 발급을 부르지 않으며 설정 파일에 쓰지 않는다.
- 접속 시점에 한 번 받는다 — 토큰 파일·매핑이 틀리면 `nx.connect` 가 곧바로 `NexusCasError` 로
  실패한다(cas 에 닿지 않으면 재시도 뒤 실패한다).

| STS 코드 | 뜻 |
|---|---|
| `ExpiredToken` | 토큰이 만료됐거나 남은 수명이 900초 미만 |
| `InvalidIdentityToken` | 서명·`iss`·`aud` 가 cas 설정과 맞지 않음 |
| `AccessDenied` | `(issuer, subject)` 매핑이 없거나 템플릿 키가 폐기·만료 |
| `IDPCommunicationError` | cas 가 IdP 의 JWKS 를 가져오지 못함 |
| `ValidationError` | STS 요청 형식이 맞지 않음(`duration_seconds` 범위 등) |
| STS 가 켜져 있지 않음 | cas 의 `auth.oidc.issuers` 가 비어 있음 |

STS 호출이 느려도(타임아웃 15초 × 최대 4회) **남은 수명이 60초를 넘는 자격증명이 있으면 워커는 기다리지 않고
그것을 쓴다.** 기다리는 것은 자격증명이 없거나 60초 이하로 남았을 때뿐이다.
STS 모드는 CAS 데이터 요청의 **리다이렉트를 따라가지 않는다**(세션 토큰이 다른 호스트로 가지 않게) —
`cas_url` 은 리다이렉트 없는 주소(`http`→`https` 전환 포함)로 지정한다.
`urllib`·이미지 라이브러리로 `https://…` 를 직접 여는 코드에는 적용되지 않는다.

### 값의 우선순위

**인자 > 환경변수 > 설정 파일.** 코드에 명시한 값이 항상 이기고, CI는 환경변수로 로컬 파일을 덮을 수 있다.

```bash
export NEXUS_URL=http://localhost:8090
export NEXUS_EMAIL=user@example.com
export NEXUS_PASSWORD=secret
export CAS_URL=http://localhost:8080
export CAS_KEY_ID=mykey
export CAS_SECRET=mysecret
export NEXUS_VERIFY=true          # 선택 — false 또는 CA 번들 경로
```

### 사내 프록시 · TLS 인증서 (`verify`)

사내 보안 장비가 TLS를 검사하면 `nx.connect()`가 SSL 인증서 에러로 죽는다. 세 가지 방법이 있고, **위쪽이 안전하다.**

```python
# 1) 사내 루트 CA를 신뢰 — 검증을 유지한 채 해결(권장)
nx.connect(verify="/path/to/corp-root-ca.pem")

# 2) 환경변수 — SDK 수정/재배포 없이 오늘 바로 쓸 수 있다(requests 기본 동작)
#    export REQUESTS_CA_BUNDLE=/path/to/corp-root-ca.pem

# 3) 검증 끄기 — 최후의 수단
nx.connect(verify=False)
```

설정 파일에 적어두면 매번 넘기지 않아도 된다:

```json
{ "verify": "C:/certs/corp-root-ca.pem" }
```

- `verify`는 **nexus와 CAS 양쪽 세션**에 적용된다. `nx.upload()`는 CAS로 직접 PUT하므로 한쪽만 고치면 업로드에서 같은 에러가 다시 난다.
- CAS를 `http://`로 접속한다면 `verify`는 아무 일도 하지 않는다(TLS가 없으므로).
- `verify=False`는 **그 연결의 중간자 공격 탐지를 포기하는 것**이다. 접속 시 한 번 경고가 뜨고, 이후 요청마다 나오는 urllib3 경고는 억제된다.

### Upload

Ingest is **2-phase**: first upload the image bytes to CAS (`nx.upload`), then register the
returned refs as samples (`nx.Sample` + `flush`).

```python
import nexus as nx

nx.connect()

# Phase 1 — data plane: upload local files to CAS (parallel, idempotent, +WebP thumbnail)
refs = nx.upload([img1, img2], bucket="kitti", prefix="images")   # {path: CasRef}

# Phase 2 — catalog: register the refs as samples
KINDS = {"det": "group"}   # 그룹 종류 — 적재할 annotation 의 그룹을 선언한다
with nx.Dataset.load_or_create("kitti-mini", version="v1", tags=["3d_detection"],
                               group_kinds=KINDS) as ds:
    for img_path, ann_path in pairs:
        ds.add(nx.Sample(
            image=refs[img_path],                                  # CAS ref (not a local path)
            annotation=nx.AnnotatedSample.from_file(ann_path, KINDS),  # 읽는 자리에서 검사한다
            split="train",
        ))
# flush() called automatically on __exit__
```

**annotation 은 `AnnotatedSample` 객체로만 넘긴다.** `Sample(annotation=...)` 은 `AnnotatedSample` 또는 `None` 만
받고, 경로·URL·dict 는 `TypeError` 다. JSON 파일은 `nx.AnnotatedSample.from_file(path, group_kinds)`, dict 는
`nx.AnnotatedSample.from_dict(d, group_kinds)` 로 바꾼다 — 바꾸는 순간 component·instance·그룹 규칙으로 검사해
위반이 있으면 `NexusValidationError`(`errors` 에 `Issue(path, reason, message)` 전부, 경로는
`det[0].bounding_box.rect` 모양)다. 객체로 직접 만들어도 된다:

```python
ann = nx.AnnotatedSample.from_dict({"meta": {"width": 1280, "height": 720}, "det": []}, KINDS)
ann["det"].add(nx.Instance("car", [nx.Detection(rect=[0.1, 0.2, 0.3, 0.4])]))
ds.add(nx.Sample(image=ref, annotation=ann))
```

- `group_kinds` 에 선언한 그룹은 `LabelGroup`/`LabelContainer` 규칙으로, 선언하지 않은 그룹은 종류와 무관한 규칙
  (배열·행 규칙·그룹 안 id 유일)으로 검사한다.
- **`flush` 는 보내기 전에 그 dataset 에 저장된 그룹 종류로 다시 검사한다** — 만들 때 준 `group_kinds` 와 다르면 서버
  저장값이 이긴다(저장되지 않은 그룹은 선언 안 된 그룹의 규칙 — 서버도 그렇게 본다). 위반이 있는 샘플은 보내지 않고
  그 샘플의 결과가 실패(`ok=False`, 준비 단계)다.
- `meta.filename` 이 CAS URL 이면 `image` 없이 `Sample(annotation=ann)` 만으로도 등록된다(이미지 ref 를 거기서 얻는다).

### Manual flush

```python
refs = nx.upload([img for img, _ in pairs], bucket="kitti", prefix="images")

ds = nx.Dataset.load_or_create("kitti-mini", version="v1", group_kinds=KINDS)
ds.add([nx.Sample(image=refs[img], annotation=nx.AnnotatedSample.from_file(ann, KINDS))
        for img, ann in pairs])

results = ds.flush(workers=4, strict=False)
failures = [r for r in results if not r.ok]
```

**`flush(workers=)` 의 상한은 한 사람이 아니라 동시에 적재하는 전원의 합에 걸린다.**
서버 기본값에서 그 합이 4다 — 다섯 명이 각자 `workers=8` 로 돌리면 상한의 10배다. 넘치면
서버가 `429` + `Retry-After` 로 돌려주고 SDK 가 물러났다 다시 오므로 적재가 실패하지는
않지만, 그만큼 느려진다. 처리량을 올리려면 서버의 `database.max_connections` 를 함께
올려야 한다(`nexus-server` README 「적재 동시 실행 상한」).

`nx.upload(workers=)` 는 다르다 — 그쪽은 CAS 로 직접 가므로 이 상한과 무관하다.

### Explicit connection

```python
nx.connect(
    nexus_url="http://localhost:8090",
    email="user@example.com",
    password="secret",
    cas_url="http://localhost:8080",
    cas_key_id="mykey",
    cas_secret="mysecret",
    verify=True,          # 선택 — False 또는 CA 번들 경로
)
```

설정이 부족하면 **무엇이 빠졌고 어디에 넣으면 되는지**를 담은 `NexusError`가 난다(예전에는 `KeyError`였다).

### 계정 관리

```python
client = nx.connect()

# 비밀번호 변경 — 현재 비밀번호를 재확인한다
client.change_password("old-pass", "new-pass-123")

# 소유한 dataset을 다른 계정으로 넘긴다 (서버 0.1.6+)
client.transfer_dataset_owner("0198f3c1-6b2a-77e1-9a40-3d5c9f0e1b22", "new-owner@int2.us")

# 계정 삭제 (되돌릴 수 없다). 소유한 dataset이 남아 있으면 409로 거부된다.
result = client.delete_account("new-pass-123")
# {"deleted_user_id": 7, "released_datasets": 0, "warning": "…"}
```

- 비밀번호를 바꿔도 **이미 발급된 토큰은 만료(최대 24시간)까지 유효**하다. 변경은 새 로그인부터 적용된다.
- `~/.int2nexus/settings.json`에 비밀번호를 적어두었다면 **그 파일도 함께 고쳐야 한다.**
- **서버 `0.1.6`부터 소유한 dataset이 남아 있으면 `delete_account`가 `NexusError(status_code=409)`로 거부된다** —
  `transfer_dataset_owner`로 전부 넘긴 뒤 다시 부른다. 그래서 성공했을 때 `released_datasets`는 항상 0이다.
  구버전 서버(`0.1.5` 이하)는 그대로 지우며, 그때 `released_datasets`가 0이 아니면 그 dataset들은 주인이
  없어져 **누구나 수정·삭제할 수 있는 상태**가 된다.
- 비밀번호를 잊어 로그인조차 못 하는 계정은 본인이 처리할 수 없다 — 운영자가 DB에서 재설정해야 한다.

### annotation 쓰기는 객체로만

이미 등록된 샘플의 annotation 은 `load_sample()`(또는 `iter_samples()` 등)로 받은 `AnnotatedSample` 을 고쳐
`save()` 로 저장한다(아래 절). draft 버전에서만 가능하다(sealed 는 409).

```python
ds = nx.Dataset.load_or_create("kitti-mini", version="v1", group_kinds={"det": "group"})

s = ds.load_sample(sample_id)
s["det"].add(nx.Instance("person", [nx.Detection(rect=[0.5, 0.5, 0.1, 0.2])]))
try:
    s.save()                                     # 보낼 그룹을 검사한 뒤 바뀐 그룹만 부분 저장
except nx.NexusValidationError as e:
    for issue in e.errors:                       # SDK 가 거른 위반 — 아무것도 보내지 않았다
        print(issue.path, issue.reason, issue.message)
```

- **dict 를 받는 쓰기 경로는 공개 API 에서 빠졌다**: `Dataset.save_annotation`·`Dataset.merge_annotation`·
  `Dataset.patch_annotations`, `AnnotatedSample.merge` 의 dict 입력, `Sample(annotation=dict | 경로 | URL)`, 저수준
  `NexusClient.ingest`·`ingest_batch`·`patch_annotations`·`merge_sample_annotations`. 손에 dict 가 있으면
  `nx.AnnotatedSample.from_dict(d, group_kinds)` 로 바꾼 뒤(그 자리에서 검사된다) `Sample(annotation=...)` 로 적재하거나
  `merge` 로 합친다.
- 읽기는 그대로다. `ds.get_annotation(sample_id)`·`ds.get_sample(sample_id)` 는 dict 를 돌려주고, `load_sample()`·
  `iter_samples()`·`shuffle()`·`sort_by()` 는 객체를 돌려준다. **읽는 경로는 검사하지 않는다** — 이미 저장된 틀린 행
  (모르는 component 타입 등)도 열린다. 그 그룹을 고쳐 보내려면 `save()` 전에 위반을 고쳐야 한다.
- 서버의 형식 거절(400)은 `NexusValidationError`(`status_code=400`, `server_message` 에 서버 사유)로 올라온다. 서버가
  `code: "annotation_invalid"` 로 거절하면 `errors` 에 서버의 `{path, reason, message}` 가 `Issue` 로 담긴다.
- **검증은 세 시점에서 같은 규칙으로 한다.** ⑴ 생성 — 키워드로 만든 component(`nx.Detection(rect=[0.1, 0.2])`)는 그 자리에서
  `NexusValidationError` 라 `nx.Detection()` 을 빈 채로 만들고 나중에 채우는 방식은 실패한다(wire dict 로 만든
  `nx.Detection({...})` 는 검사하지 않는다). ⑵ 대입·편집 — `add`·`replace`·그룹 객체 대입·`add_labels`·`merge`·`from_dict`·
  `from_file`. ⑶ `save()`·`flush` — 보낼 그룹 전체를 그 dataset 에 저장된 그룹 종류로 다시 검사하고, 위반이 있으면 아무것도
  보내지 않는다. 생성 뒤 속성을 바꾼 경우(`det.rect = [0.1]`)는 ⑶ 에서 걸린다.
- **`save()` 는 보내는 그룹 전체를 검사하므로 서버보다 엄격하다.** 서버는 이 요청이 새로 넣거나 바꾼 component 만 거절하지만,
  SDK 는 그 그룹의 옛 틀린 행(모르는 component 타입, `type` 이 문자열이 아닌 객체, 32 비트를 넘는 `track_id`, 32 비트 실수를 넘는
  `confidence` 등)도 걸러 그 그룹을 보내지 않는다. 그 행을 고치거나 빼야 같은 그룹의 다른 행을 저장할 수 있다. 같은 이유로
  이미 저장된 틀린 값이 있는 샘플의 `s.validate()` 는 예외다. 틀린 행은 `ds.find_invalid_annotations()`(아래)로 찾는다.

### annotation을 그룹 단위로 부분 저장 — `load_sample()` / `save()` (SDK 0.1.16+)

annotation을 타입 객체로 받아 고치고, **바뀐 것만** 저장한다.

```python
ds = nx.Dataset.load_or_create("seatbelt", version="v1",
                               group_kinds={"seatbelt_gt": "group"})

s = ds.load_sample(sample_id)
s["seatbelt_gt"][0].get_component("bounding_box").rect = [0.1, 0.1, 0.4, 0.8]
s.meta["width"] = 1280
s.save()          # 검증 후 바뀐 그룹·meta 키만 보낸다
```

- **`save()`는 바뀐 그룹과 바뀐 `meta` 키만 보낸다.** 안 바꾼 그룹·`meta` 키는 서버가 보존하므로, **양쪽 모두 `save()`(서버 `0.1.18` 이상)로 저장할 때는** 두 곳에서 같은 샘플의 **다른** 그룹을 동시에 고쳐도 서로 지우지 않는다. 같은 그룹을 동시에 고치면 나중 저장이 이긴다. 한쪽이 CVAT `pull()`(아래)이거나 옛 서버라 `save()`가 통째 교체로 폴백한 경우는 그 저장이 오래된 스냅샷 전체를 쓰므로, 그 사이 `save()`가 쓴 다른 그룹까지 덮어쓴다.
- `meta`의 키를 지우려면 `del s.meta[k]` 또는 `s.meta[k] = None`.
- **부분 저장은 nexus-server `0.1.18` 이상이 필요하다.** 그 이하 서버에서는 `RuntimeWarning`과 함께 통째 교체(PUT)로 저장한다(이 경우 동시 편집 보호가 없다). `load_sample` 자체는 서버 판을 가리지 않지만, 이 통째 교체 저장은 annotation 전용 조회를 함께 쓰므로 `0.1.5` 이상이 필요하다.
- **SDK 0.1.21 부터 `load_sample` 이 `s.tags`(고칠 수 있는 리스트)와 `s.split`(읽기 전용)을 든다.** `s.tags` 를 고치고 `save()` 하면 더해진·빠진 태그도 저장된다 — 핸들의 버전이 sealed 면 `409`, 샘플이 삭제됐으면 `404`. 태그는 meta 처럼 샘플에 붙어 버전 간에 공유된다.
- 그룹 하나를 비우는 저장(`clear_field`·빈 리스트)은 된다. 저장 결과 그 샘플의 인스턴스가 하나도 남지 않아도 그룹 단위 CoW 판 서버부터는 200이다(그 전 서버는 공유 원본(base)이 있으면 409였고 이 버전에서 비우려면 unlink해야 했다).

**FiftyOne 호환 필드 함수**(`AnnotatedSample`, 제자리 수정 후 `save()`로 저장한다). 필드는 그룹 이름 또는 `"meta"`다.

```python
s.get_field("dets")                       # 없으면 AttributeError(있는 필드 목록 포함)
inst = nx.Instance("Person", [nx.Detection(rect=[0.1, 0.2, 0.3, 0.4])])   # id 를 생략하면 새 id 를 붙인다
# components 는 Label 의 list(키는 각 Label 의 type) 또는 {이름: Label} dict. 같은 type 이 둘이면 dict 로
g = s["dets"]
g.add(inst)                               # 넣기 전에 검사한다(행 규칙 + id 유일·container)
g.remove(inst.id)                         # id 로 뺀다, 없으면 KeyError
g.replace([inst])                         # 전부 검사한 뒤 한 번에 바꾼다
g.instances                               # 읽기 전용 tuple — g[i]·len(g)·순회도 된다
s.set_field("dets", nx.LabelGroup([inst]), create=False)   # create=False면 오타로 새 필드가 생기지 않는다
s["meta"] = nx.Meta({"width": 1280})      # s[f] / s[f] = v 도 같다
s.clear_field("dets")                     # None이 아니라 빈 그룹, "meta"는 저장된 키 전부 삭제
s.add_labels(inst, label_field="dets")    # Instance / list / {field: ...}
s.merge(other, fields=None, omit_fields=None, merge_lists=True, overwrite=True)
c = s.copy(fields=["dets"])               # 저장되지 않은 deep copy — c.save()는 실패한다
```

- `merge`: `other`는 `AnnotatedSample` 만 받는다(dict 는 `TypeError` — `nx.AnnotatedSample.from_dict(d, group_kinds)` 로 먼저 바꾼다). `merge_lists=True`면 `Instance.id` 단위로 합친다(같은 id는 `overwrite`일 때만 교체, 새 id는 뒤에 추가 — 들어오는 행의 규칙과 결과 그룹의 규칙을 `add` 처럼 검사한다). `merge_lists=False`면 통째 교체이고 `overwrite=False`면 기존 필드를 건드리지 않는다. 새로 들어오거나 통째로 바뀌는 그룹은 대입과 같은 검사(선언 종류·그룹 규칙)를 지난다. **`other` 의 `RawGroup`(선언 안 된 그룹)이 이 샘플을 실제로 바꾸면 `TypeError`** 다(빈 자리에 넣기, 다른 값으로 덮기) — 대입할 수 없는 그룹이라 옮겨 놓아도 `save()` 가 보내지 않는다. 이 샘플에 같은 값의 `RawGroup` 이 이미 있으면 바뀌는 것이 없어 건너뛰므로, 같은 dataset 에서 읽은 두 샘플은 선언 안 된 그룹이 그대로면 그냥 합쳐진다. 다를 때는 `fields`·`omit_fields` 로 그 그룹을 빼고 합친다. `meta`는 키 단위(`overwrite=False`면 없는 키만 채운다). 가져온 값은 전부 복사하므로 두 샘플이 객체를 공유하지 않는다. 실패하면 아무것도 바꾸지 않는다.
- **그룹 편집은 `add`·`remove`·`replace` 셋이다.** `instances` 는 읽기 전용 tuple 이라 `g.instances[0] = ...`·`g.instances.append(...)` 는 `TypeError`·`AttributeError` 다. `add`·`replace` 는 넣으려는 행의 규칙과 결과 그룹의 규칙(그룹 안 id 유일, `container` 는 행마다 component 하나·같은 타입)을 넣기 전에 검사해 위반이면 그룹을 바꾸지 않고 `NexusValidationError`(`errors` 에 경로) 다. `Instance` 가 아니면 `TypeError`. 넣은 뒤 행 속성을 고친 것은 `save()` 가 검사한다.
- `add` 는 결과 그룹 전체의 그룹 규칙을 보므로 **서버에서 읽은 옛 그룹에 id 중복·`container` 위반이 이미 있으면 맞는 행도 거절한다** — 먼저 `remove`/`replace` 로 그 위반을 고친다.
- `remove(id)` 는 그 id 의 행을 **모두** 뺀다(같은 id 가 여럿인 옛 그룹이면 전부). 하나만 남기려면 `replace` 를 쓴다.
- `add_labels`: 같은 id가 대상 필드(또는 같은 배치 안)에 이미 있으면 `ValueError`이고, 행·그룹 규칙 위반은 `NexusValidationError` 다 — 어느 쪽이든 아무것도 붙지 않는다. 넣은 `Instance`는 복사해서 붙인다. `"meta"`와 선언 안 된 그룹(`RawGroup`)에는 붙일 수 없다(`TypeError`).
- **대입(`s[f] = v`·`set_field`)은 객체만 받는다** — `"meta"` 는 `Meta`, 그룹은 그 이름에 선언된 종류의 `LabelGroup`/`LabelContainer` 이고 대입할 때 그 그룹 규칙으로 통째 검사한다. dict·행 list·`RawGroup` 은 `TypeError` 다.
- **새 그룹은 그룹 종류를 먼저 선언해야 만든다.** 선언되지 않은 이름이나 선언 종류와 다른 클래스를 대입하거나 `add_labels` 로 새 필드를 만들면 `NexusValidationError` 다 — `ds.declare_group_kinds({"dets": "group"})` 로 먼저 선언한다. 핸들에 붙은 샘플과 그 `copy()` 사본은 핸들의 지금 선언을 보고(샘플을 받은 뒤 선언해도 된다), 핸들 없는 샘플은 만들 때 받은 `group_kinds` 를 본다.
- **선언 안 된 그룹(`RawGroup`)은 읽기와 왕복만 된다.** `.raw` 를 고쳐도 `save()` 는 그 그룹을 보내지 않는다(`clear_field` 로 비운 것만 빈 그룹으로 보낸다).
- **그룹 종류는 dataset 에 저장되고, 그 저장값이 기준이다**(서버 0.1.29+). `declare_group_kinds`·`load_or_create(group_kinds=)` 가 서버에 쓰고, `load_or_create`·`Dataset.open` 이 열 때 읽는다 — 한 번 선언하면 그 dataset 을 여는 모든 스크립트가 같은 종류로 읽는다. `load_or_create(group_kinds=)` 는 저장값과 다른 키만 보내므로(같으면 요청 없음) `viewer` 도 이미 같은 값인 dataset 을 경고 없이 연다. 저장값과 다른 선언은 그 dataset 의 전역 값을 덮는다. 핸들은 서버 응답(저장 뒤 dataset 전체)으로 바뀌고 `flush`·`save()` 의 검사도 그 값을 쓴다.
- **저장이 실패하면 예외다.** `container` 로 바꾸려는데 draft 버전들의 기존 행이 container 규칙(행마다 component 하나·한 샘플 안 같은 타입)에 어긋나면 서버가 400 으로 거절하고 아무것도 바꾸지 않는다 — `NexusValidationError` 의 `errors` 에 어긋난 행마다 `Issue(path="<그룹>[id=<instance id>]", reason="container_component_count" | "container_mixed_types", message=<샘플 id·버전 포함>)`, `rejected` 에 서버 목록 그대로(`group`·`sample_id`·`version`·`instance_id`·`reason`, 앞 100 건까지 — 100 건이면 메시지가 「100 건 이상」)가 실린다. 그 행을 고친 뒤 다시 선언한다. 큰 dataset 에서 그 검사가 서버 시한(50 초)을 넘기면 503 `NexusError`(`code == "group_kind_check_incomplete"`)이고 역시 바뀌지 않는다 — 자동으로 다시 보내지 않는다(같은 검사를 다시 돌릴 뿐이다). `group` 선언·이미 `container` 인 키는 검사하지 않는다. 저장 경로가 없는 0.1.28 이하 서버도 `NexusError` 다.
- **예외 둘만 그 핸들에 두고 `RuntimeWarning` 을 낸다.** `viewer`(403)의 선언은 읽기(`load_sample` 등)에만 쓰이고 `flush` 검사에는 쓰이지 않는다. 서버가 저장하지 않는 이름(`meta`·`tags`·`split` 같은 샘플 필드 이름, 앞뒤 공백, 128 자 초과 — 서버와 같은 판정)은 보내지 않고, 그 그룹은 `RawGroup` 으로 남는다(편집할 수 없다 — 선언할 수 없는 이름이라서다).
- 핸들을 열 때 그룹 종류를 읽지 못하면(일시 장애) 경고하고 연 뒤, 그 핸들의 첫 쓰기(`flush`·`save()`·`promote`)가 다시 읽는다. 그래도 못 읽으면 아무것도 보내지 않고 `NexusError` 다(종류 없이 검사하면 선언된 그룹의 규칙을 놓친다). 모르는 종류 값은 무시한다(`RawGroup`).
- **선언 안 된 그룹을 편집하려면 `s.promote(name, kind)`** — 그 샘플의 그 그룹(서버에서 읽은 값)을 그 종류로 읽어 SDK 규칙으로 먼저 검사하고(위반이면 `NexusValidationError`, 선언하지 않는다), 통과하면 `ds.declare_group_kinds({name: kind})` 를 불러 dataset 전체 검사를 서버에 맡긴다. 서버가 거절하면 그 예외이고 샘플은 바뀌지 않는다(403 이라 저장하지 못한 경우도 바뀌지 않고 `NexusError`). 성공하면 `s[name]` 이 새 `LabelGroup`/`LabelContainer` 가 되어 돌아온다. 그 그룹의 기준을 새 그룹의 값으로 맞추므로(id 없는 행에 채운 id 포함) 고치기 전의 `save()` 는 그 그룹을 보내지 않는다. 서버에 그 이름이 이미 다른 종류로 저장돼 있으면 선언하지 않고 `NexusValidationError` 다(저장된 종류를 조용히 바꾸지 않는다 — 바꾸려면 `declare_group_kinds` 를 직접 부른다).

  ```python
  s = ds.load_sample(sid)
  dets = s.promote("dets", "container")   # 이 dataset 의 draft 행 전체가 container 규칙에 맞아야 한다
  dets.add(nx.Instance("car", [nx.Detection(rect=[0.1, 0.2, 0.3, 0.4])]))
  s.save()
  ```
- 제안과의 차이: `Label.id`·component 단위 id는 없다(id는 `Instance`에만 있다). 그룹은 FiftyOne의 `Detections([Detection])` 같은 이름 붙은 컨테이너 클래스가 아니라 `LabelGroup`/`LabelContainer` 두 종류다.
- 그룹 종류 선언·component 타입 등 객체 모델 자체는 `sdk/CHANGELOG.md`의 `0.1.16` 절을 참고.

### CVAT annotation 편집 세션

draft 버전의 샘플을 CVAT으로 보내 사람이 편집하고, 결과를 다시 draft에 당겨온다.
서버에 `[cvat]` 설정이 필요하다(없으면 503).

```python
ds = nx.Dataset.load_or_create("kitti-mini", version="v1")
ids = [r["sample_id"] for r in ds.list_samples(max_samples=50)]

ses = ds.create_annotation_session(ids)   # open 될 때까지 대기 후 반환
print(ses.url)                            # 작업자에게 넘길 CVAT 주소

summary = ses.pull()                      # CVAT → draft 반영 (멱등, 반복 호출 안전)
ses.close()                               # 잠금 해제 (CVAT project는 보존)

nx.annotation_sessions()                  # 전역 — 지금 진행 중인 세션
```

- **생성은 비동기다.** 수백 장이면 CVAT이 이미지를 받는 데만 몇 분 — `wait=False`로 받고
  나중에 `ses.wait_open(timeout=1800)` 해도 된다.
- `pull()`이 돌려주는 `warnings`를 버리지 말 것 — 반영되지 않은 것의 사유가 거기 있다.
- **`pull()`은 통째 교체다** — 세션 시작 이후 `save()`로 이 샘플의 다른 그룹을 고쳤다면 그 변경도 함께 덮어쓴다(위 「그룹 단위로 부분 저장」).
- `delete()`는 CVAT project와 **아직 당겨오지 않은 편집까지** 지운다. `close()`와 다르다.
- 같은 샘플을 두 세션이 잡을 수 없다(409). sealed 버전에는 만들 수 없다(409).
- **`ids` 의 순서가 CVAT 프레임 순서다**(서버 0.1.26~). 영상 프레임은 프레임 번호로 정렬해 넘긴다.
- 점이 아직 없는 dataset 에서 점 라벨을 만들려면 `extra_labels=[{"group": "face", "label": "person",
  "components": ["keypoint_2d"], "keypoints": ["l_eye", "r_eye", "nose"], "component_key": "FACE_KP"}]`
  (서버 0.1.26~). CVAT 라벨은 `face/person/kp`, 점 이름은 `keypoints` 그대로다.
- CVAT 트랙은 `pull()` 이 프레임별 인스턴스로 들인다(서버 0.1.27~, 그 전 서버는 버리고 그 수를 `warnings` 에 남긴다).
- 열린 세션이 있는 버전은 `ds.delete()` 가 409 다(서버 0.1.26~) — 세션을 닫거나 지운 뒤 지운다.

### dataset 찾기와 지우기

```python
nx.dataset_exists("kitti-mini")                       # 이름이 정확히 같은 dataset 이 있는가
nx.list_datasets(name_exact="kitti-mini")             # 이름 정확히 일치(서버 0.1.26~, 그 이하는 무시)
nx.delete_dataset("kitti-mini", confirm_dataset_name="kitti-mini", delete_cas=False)   # 버전째 삭제(서버 0.1.26~)
```

- `delete_dataset` 은 버전마다 `ds.delete()` 와 같은 규칙으로 지우고 마지막 버전과 함께 dataset 이 사라진다. sealed 버전이
  있으면 관리자만 지우고, seal 이 진행 중이거나 열린 세션이 있으면 409 로 아무것도 지우지 않는다. 0.1.25 이하 서버는 405 다.

### 즐겨찾기 그룹

```python
fav = nx.favorite_groups()
for g in fav["groups"]:
    print(g["name"], [d["name"] for d in g["datasets"]])
print("미분류", [d["name"] for d in fav["unassigned"]])
```

- 웹 사이드바와 같은 그룹 순서·그룹 안 순서다. `datasets`·`unassigned` 의 항목은 `list_datasets()` 와 같은 dict 이다.
- 소속과 순서는 즐겨찾기 목록 행의 `favorite_group_id`·`favorite_position` 으로 정해 두 그룹에 나오지 않는다. 그룹 이름·순서는 그 앞에 읽은 그룹 구성에서 오고, 그 뒤에 만든 그룹은 맨 뒤의 `name: None` 그룹이다. 즐겨찾기가 1,000 개(한 페이지)를 넘으면 목록을 여러 페이지로 읽어, 그 사이에 순서를 바꾸면 그룹 안 순서가 섞일 수 있고 페이지 경계의 dataset 이 지워지면 뒤 항목이 빠질 수 있다.
- id 만 필요하면 `client.get_favorite_layout()` 이 서버 응답(`groups[].dataset_ids`·`unassigned`)을 그대로 준다.

### Fork a version

```python
ds = nx.Dataset.load_or_create("kitti-mini", version="v1.1", fork_from="v1.0")
```

### Link existing samples (without ingest)

```python
ds.link_samples(["0192f0a1-...", "0192f0a1-..."])
```

### Convert sealed version to DataFrame

```python
import nexus as nx

nx.connect()
ds = nx.Dataset.load_or_create("kitti-mini", version="v1")

# all samples (sealed: seal snapshot; draft: explorer, warns once)
df = ds.to_df()

# only some group keys
df_boxes = ds.to_df(groups=["objects"])

# fingerprint of what was read (draft vs. sealed comparison)
fp = ds.fingerprint()
```

## API Reference

### `nexus.connect(...)`

Authenticates against nexus-server and initializes the module-level client. 설정이 인자·환경변수·설정 파일(`~/.int2nexus/settings.json`) 중 어디에든 갖춰져 있으면 첫 API 호출이 자동으로 접속하므로, 명시적으로 부르지 않아도 된다.

```python
nx.connect(
    nexus_url=None, email=None, password=None,          # 없으면 환경변수 → 설정 파일 순으로 해소
    cas_url=None, cas_key_id=None, cas_secret=None,
    timeout=(10.0, 120.0),                              # (connect, read)
    verify=None,                                        # True(기본) | False | CA 번들 경로
    settings_path=None,                                 # 설정 파일 경로 직접 지정
)
```

- `cas_sts` — `nx.CasSts(token_file=… | token_provider=…, duration_seconds=3600)`. CAS 임시 자격증명(STS) 모드(0.1.12+). 위 「CAS 임시 자격증명 — STS」 참조

### `nexus.upload(paths, bucket, prefix="", *, workers=8, verbose=True, strict=False, overwrite=False)`

Uploads local files to CAS and returns `{path: CasRef}`, mapping each input path to its
`CasRef` (which carries `bucket` / `key` / `hash_hex` / `size` / `content_type`). This is
**phase 1** of ingest — pass the returned refs to `nx.Sample(image=...)`.

```python
refs = nx.upload(
    ["data/img001.png", "data/img002.png"],
    bucket="kitti",
    prefix="images",   # CAS key = "{prefix}/{filename}"
    workers=8,         # parallel uploads
)
ref = refs["data/img001.png"]   # CasRef(bucket="kitti", key="images/img001.png", ...)
```

- Uploads in parallel; idempotent — already-present objects (same key + content) are skipped.
- Generates a WebP 256px thumbnail alongside each image (best-effort). 16-bit grayscale images (e.g. depth maps) are mapped to 8 bits by the 2nd–98th percentile of their non-zero values (0 stays black) instead of being clipped at 255.
- Uploading the same content again does not rewrite an existing thumbnail. To regenerate thumbnails of objects already in CAS (e.g. depth maps uploaded before the 16-bit mapping), call `nx.rewrite_thumbnails(refs)` (`CasRef` or `s3://`·`http(s)://` URLs) or `ds.rewrite_thumbnails(role)`. It unconditionally rewrites `thumb/<key>` and returns `{"written": n, "skipped": ["bucket/key"], "failed": {"bucket/key": error}}`. Keys are `"bucket/key"`, except inputs that are not CAS references, whose `failed` key is the input string. `refs` may be a generator: it is read as work completes (at most `workers × 4` objects in flight), so `ds.rewrite_thumbnails(role)` streams the version without building a URL list.
- Re-using the same key with **different** content is a per-file failure (collision) by default. Pass `overwrite=True` to replace it instead — the thumbnail is regenerated too, so a stale thumbnail from the old content never lingers. Same content is always skipped regardless of `overwrite`.
- Transient network/5xx errors are retried with backoff at the transport layer. Per-file failures are **isolated** (one bad file doesn't abort the batch) — only successes are returned. `strict=True` raises `NexusCasError` if any file failed; default `strict=False` warns. Re-running `nx.upload` with the same paths resumes (already-uploaded files are skipped).

### `nexus.probe(refs, *, workers=8, verbose=True, strict=False, max_header_bytes=65536)`

이미지를 다른 경로로 이미 CAS에 올렸고 로컬 사본이 없다면, `nx.upload` 없이 CAS 좌표만으로
샘플을 만들 수 있다. 다만 그대로 등록하면 `meta`에 `width`/`height`가 빠진다 — CAS는
객체의 픽셀 크기를 헤더로 알려주지 않기 때문이다.

`nx.probe`는 각 객체의 **앞부분 64KB만** 받아 이미지 헤더를 파싱해 크기를 채운다.

```python
import nexus as nx
from nexus import CasRef

nx.connect()

refs = [CasRef(bucket="incabin", key=f"lg_dataset/{name}") for name in names]
refs = nx.probe(refs, workers=8)          # 앞부분만 range GET

ds = nx.load_or_create("lg_dataset", version="v1")
ds.add([nx.Sample(r) for r in refs])
ds.flush()
```

- 입력은 `CasRef` 또는 `s3://`·`http(s)://` URL 문자열의 리스트, **또는 `nx.upload`가
  돌려주는 `{path: CasRef}` 그대로**다(`Sample.image`와 같은 CAS 참조 규칙 + dict는
  `.values()`로 풀어서 받는다 — dict를 직접 for로 돌리면 키인 로컬 경로 문자열이 나와
  거부되므로, 업로드 결과를 그대로 이어붙이려면 이 형태로 넘긴다).
- 반환은 **입력 순서를 보존한 리스트**다. 실패한 객체도 자리를 지키며 크기만 비어 있다.
- 이미 크기가 채워진 ref는 네트워크를 타지 않는다. 같은 리스트로 다시 호출해 실패분만
  재시도해도 된다.
- CAS가 Range 요청을 지원하지 않아도 동작한다 — 앞부분만 읽고 연결을 끊는다.
- `max_header_bytes`(기본 64KB): 객체 앞부분에서 받아올 바이트 수. 헤더가 유난히 뒤에
  있는 포맷(예: 특정 TIFF)이거나 "이미지 헤더를 읽지 못했습니다" 경고가 뜨면 이 값을
  올려본다. 1 미만은 `ValueError` — Range 헤더가 애초에 성립하지 않는다.
- `strict`(기본 `False`): `False`면 실패를 `RuntimeWarning`으로 모아 경고하고 계속
  진행한다(실패한 항목은 원본 ref 그대로, width/height는 `None`). `True`면 하나라도
  실패했을 때 `NexusCasError`를 던진다 — 크기 누락을 절대 허용하지 않는 파이프라인에.

크기를 못 구하면 `meta`에 `width`/`height` 키를 **넣지 않는다**. 0을 적으면 크기 facet의
range가 `min:0`으로 오염되고, CVAT 세션이 그 값으로 정규화 좌표를 계산해 좌표가 망가진다.
키가 없으면 집계에서 조용히 제외되고, CVAT 세션 생성은 명확한 에러로 거부된다.

**로컬 파일이 있다면 network를 탈 이유가 없다.** 같은 파서를 직접 부르면 된다.

```python
info = nx.image_info(path.read_bytes())   # width/height/mime/channels, 헤더만 읽음
ref = CasRef(bucket="incabin", key=key, width=info.width, height=info.height)
```

### 이미 적재된 샘플의 크기 보정 — `ds.backfill_dims()`

`nx.probe`가 생기기 전에 등록된 샘플은 `meta.width`/`meta.height`가 `0`으로 들어가 있다.
`0`은 크기 facet의 range를 `min:0`으로 오염시키고, CVAT에서는 세션 검증을 통과한 뒤
export 단계에서 해당 인스턴스가 조용히 빠지게 만든다.

```python
ds = nx.load_or_create("lg_dataset", version="v1")

report = ds.backfill_dims(dry_run=True)   # 대상 규모와 실제 측정 가능 건수 확인
report = ds.backfill_dims(workers=8)      # 적용
print(report)   # {'scanned': 12000, 'targeted': 840, 'measured': 838, 'unchanged': 0,
                #  'applied': 838, 'corrected': 0, 'rejected': [...], 'changes': [...]}
```

- 대상은 `meta.width`/`height` 중 **적어도 한 축이** 없거나, `null`이거나, 0 이하인 샘플이다. 두 축 모두 0보다 큰 값이 있는 샘플은 건드리지 않는다.
- `dry_run=True`도 **실제로 측정까지** 한다. 쓰기만 건너뛴다.
- image asset이 없거나 헤더를 읽지 못한 샘플은 건너뛰고 `measured`에서 빠진다.
- 서버는 **축(width/height) 단위로** 기록된 값을 절대 덮어쓰지 않는다 — 한쪽 축만 기록되어 있어도 그 축은 그대로 두고 반대쪽만 채운다. 값이 존재하지만 숫자가 아니면(문자열·bool 등) fail-closed로 "기록됨" 취급해 역시 손대지 않는다. 채울 축이 하나도 없는 샘플을 보내면 `rejected`에 사유와 함께 담겨 돌아온다.
- 쓴 값은 그 버전에만 남는다(서버 0.1.37+). 다른 버전도 담은 샘플은 그 버전의 사본에 쓰인다. sealed 버전 핸들로 부르면 409 다 — 고치려면 그 샘플을 담은 draft 버전에서 부른다.
- **한 페이지(1,000 개)씩 훑고 재고 보낸다**(0.1.29+). 버전 전체를 메모리에 올리지 않으므로 수백만 샘플 버전에도 메모리가 늘지 않는다 — 늘어나는 것은 반환의 `changes`(보낸 항목마다 하나, 약 400 B)뿐이고, 아주 큰 버전에 적용할 때는 `record_changes=False` 로 끈다(개수는 그대로 센다). 0.1.28 이하는 행 전부를 모은 뒤 재고 썼다(meta 3 KB 면 행당 약 10 KB).
- 도중에 멈춰도 그때까지 보낸 청크는 반영돼 있다. 다시 부르면 채우기 모드는 남은 것만 고른다. 훑는 동안 그 버전에 새로 들어온 샘플은 빠질 수 있다(다시 부르면 잡힌다). 헤더를 읽지 못한 객체는 끝에 경고 한 번으로 모아 알린다.

#### 잘못 적재된 값 고치기 — `overwrite=True` (0.1.10+)

`0`이나 빈칸이 아니라 **처음부터 틀린 값**이 들어간 경우가 있다. ingest 때 넘긴 `ann.json`의
`meta.width/height`가 실제 이미지와 달랐던 경우다. 이런 값은 서버가 "기록됨"으로 보므로
위의 채우기 모드로는 닿지 않는다.

```python
report = ds.backfill_dims(overwrite=True, dry_run=True)   # 무엇이 어떻게 바뀌는지 먼저 본다
#   018f...a1: 1280x720 -> 1920x1080
#   018f...b7: 1280x720 -> 1920x1080
#   ... 외 312건
report = ds.backfill_dims(overwrite=True)                 # 적용
```

- **`image_url`이 있는 전량을 probe한다.** "이미 기록됨" 스킵이 빠지기 때문이다. 기본 모드보다 훨씬 오래 걸린다.
- 그렇게 잰 뒤 **실측값이 기록값과 다른 건만** 보낸다. 같은 값이었던 건수는 `unchanged`에 담긴다.
- `corrected`는 적용된 것 중 **기존 값을 덮은** 건수다. `applied - corrected`가 빈칸을 채운 건수다.
- **안전장치는 `dry_run`이다**(sealed 버전은 서버 0.1.37 부터 두 모드 다 409 지만, 그것은 「probe 가 엉뚱한 객체를 잰다」를 잡지 못한다). 변경 목록이 전부 같은 비율로 어긋나 있으면 `ann.json` 쪽의 일관된 실수이고, 제각각이면 probe가 엉뚱한 객체를 재고 있다는 신호다. 쓰기 전에 반드시 본다.
- 헤더를 읽지 못한 샘플은 이 모드에서도 보내지 않는다 — 흘려보내면 멀쩡한 값을 측정 실패값으로 덮게 된다.
- 도중에 멈춘 뒤 다시 부르면 전량을 다시 재되, 이미 고친 것은 「이미 맞는 값」(`unchanged`)이라 보내지 않는다.

### `nexus.Sample`

```python
nx.Sample(
    image=ref,                       # CAS ref ONLY: a CasRef (from nx.upload) or s3://·http(s):// URL
    annotation=nx.AnnotatedSample.from_file("data/ann001.json", group_kinds),  # AnnotatedSample ONLY
    assets={"depth": depth_ref},     # optional extra assets, {role: ref} — same rules as image
    split="train",                  # optional
    tags=["rainy", "night"],        # optional
)
```

`image` and every value in `assets` accept **CAS refs only** — a `CasRef` returned by
`nx.upload`, or an `s3://bucket/key` / `http(s)://…` URL. **Local file paths raise `ValueError`**
— upload them with `nx.upload` first. For URL refs the SDK uses a CAS HEAD to retrieve metadata.
`"image"` is a reserved key in `assets` (raises `ValueError`) — use the `image=` parameter instead.
`annotation` accepts **an `AnnotatedSample` (or `None`) only** — a path, URL or dict raises `TypeError`.
Build it with `nx.AnnotatedSample.from_file(path, group_kinds)` / `nx.AnnotatedSample.from_dict(d, group_kinds)`,
which validate on the spot (`NexusValidationError` with every `Issue` in `errors`); `flush` re-checks it
against the dataset handle's group kinds before sending.

### `nexus.Dataset.load_or_create(name, version, ...)`

Finds an existing dataset+version by name or creates it. Idempotent.

```python
nx.Dataset.load_or_create(
    name: str,
    version: str,
    tags: list[str] | None = None,       # dataset tags, applied on create
    description: str | None = None,
    fork_from: str | None = None,        # version to fork from on create
)
```

`load_or_create` also takes `wait=600.0, block=True` (SDK 0.1.26), used only when it creates the version by forking: see below.

### `ds.seal(...)` and `ds.fork(...)` against a job queue (SDK 0.1.26)

```python
ds.seal(if_sealed="error", wait=600.0, description=..., block=True)
ds.fork(new_version, ..., wait=600.0, block=True)
```

nexus-server 0.1.33+ answers seal and fork with `202` (`{"job", "version"}`, `Location: /api/v1/version-jobs/{id}`) when
the work has to wait in the server's job queue. With `block=True` (default) the call polls `GET /api/v1/version-jobs/{id}`
every 2 s for up to `wait` seconds (the same budget that covers the old 429 wait) and returns what a `200`/`201` would have
returned: the sealed version dict for `seal`, the new `Dataset` handle for `fork`. A job that ends `failed` or `cancelled`
raises `NexusError(status_code=409, server_message=<job error>)`. If `wait` runs out, `nx.NexusVersionJobPending` is raised
(a `NexusError` subclass with `.job_id` and `.job`); the work keeps running on the server, and
`client.get_version_job(job_id)` reads its state. Calling `load_or_create`/`fork` again for a version that is still `preparing` waits on its job the same way (`block=False` returns the handle at once; writes to it get 409 `version_preparing` until the fork finishes); a `failed` version raises `NexusError(409)`. `block=False` returns immediately: `seal` returns the `202` body
(`{"job", "version"}`), `fork` returns the handle of a version that may still be preparing. `NexusClient.create_version`
takes the same `wait`/`block`. `200`/`201` answers and nexus-server 0.1.32 and older (429 `seal_busy`/`seal_in_progress`,
retried per `Retry-After` up to `wait`) behave as before.

### `nexus.Dataset.open(dataset_id, version, *, client=None, cas=None)`

Opens an **existing** dataset version by id (0.1.18). It never creates anything: if the dataset
or the version does not exist it raises `NexusError` with `status_code=404`. Use it in readers
(e.g. `to_df()` workers) that already know the id. The handle itself is not restricted —
write permission is still decided by the server's role check. Without both `client` and `cas` it
uses the connection made by `nx.connect()` (auto-connecting if needed). If only one is given, the
other is taken from an existing `nx.connect()` connection only — never auto-connected — and
`ValueError` is raised if there is none.

```python
ds = nx.Dataset.open(dataset_id, "v1")
df = ds.to_df()
```

### `nexus.cas_client()`

Returns the `CasClient` of the current `nx.connect()` connection (auto-connecting if needed,
0.1.18). Use it instead of the private module global `nexus._cas`. `nx.CasClient` and
`nx.NexusClient` are part of the public API, so a `CasClient` can also be built directly and
passed as `Dataset.open(..., cas=)`.

### `Dataset.link_samples(sample_ids)`

Links already-ingested samples to this version without re-ingesting them.

### `Dataset.flush(workers=4, strict=False, verbose=True, batch_size=256)`

Prepares the registration payloads from the queued samples' refs (no upload — uploads happen
earlier in `nx.upload`), then sends them to the server's `/ingest/batch` endpoint in chunks of
`batch_size`. Returns `list[IngestResult]`.

- **Results come back in input order** (0.1.18; earlier versions returned them in completion order,
  with prepare failures first). Each result's `index` is its position in the queue at flush time.
- **A CAS 401/403 while preparing (CAS HEAD) raises `NexusCasError` before anything is ingested**
  (0.1.18). It is a CAS credential/policy problem, not a nexus role problem; fix it and flush the same
  samples again.
- **Replayed items (0.1.19, nexus-server 0.1.20+).** `flush` sends an `idempotency_key` per item; when the server returns an existing result for a re-sent item, `IngestResult.replayed` is `True`, it counts as success, and the summary line shows `replayed N`.
- **Re-sending failed samples (0.1.19).** `flush` does not put failed samples back in the queue. Add them back yourself: `ds.add([r.sample for r in results if not r.ok])`. The SAME `Sample` objects carry the idempotency key and the remembered payload; building new `Sample` objects means new keys and can duplicate. This state lives in process memory and is lost on restart. Copies made with `copy.copy`/`copy.deepcopy`/`dataclasses.replace` start fresh (no key). Do not rename the dataset with `ds.update(name=...)` between an ambiguous failure and the re-send: keys are kept per (dataset name, version), so the renamed handle sends a new key instead of the remembered payload, and an item that was already committed is silently duplicated. Re-send before renaming. With `ingest.verify_assets=true` on the server, new items still fail during a cas-server replacement (the server's own CAS HEAD has no retry; the item fails with 502, which the SDK treats as a definitive item error); only already-committed keys replay without CAS.
- `strict=True` raises `NexusBatchError` on first failure; `error.failures` contains the failed results.
- `strict=False` (default) records failures in results and continues.
- **Permission failures (401/403) always raise `NexusError`, regardless of `strict`.** They mean the
  account cannot write to this dataset at all, so every item fails for the same reason — swallowing
  them would let a CI job ingest nothing and still exit 0.
- **Annotations are checked before sending.** Each queued `Sample.annotation` (an `AnnotatedSample`) is
  re-checked against this handle's group kinds (the handle wins over the kinds given to `from_dict`);
  a sample that fails is not sent and its result is a prepare failure (`ok=False`).
- **Validation failures carry the same shape from both sides.** When the server rejects an item with `code: "annotation_invalid"` (servers with annotation write validation), or the SDK pre-check above fails, `IngestResult.exception` is a `NexusValidationError` whose `errors` hold `Issue(path, reason, message)` (`path` starts with the group name, e.g. `boxes[0].bounding_box.rect`). `error` stays the summary string and `NexusBatchError.failures` is unchanged. Items carry at most 100 errors, so a list of exactly 100 may be truncated. Other failures leave `exception` as `None`.
- **`429`(서버가 적재 자리를 못 준 것)는 실패로 세지 않는다.** SDK 가 `Retry-After` 를
  존중해 최대 8회 물러났다 다시 온다(지수 백오프 + 지터). 그래도 안 되면 그때서야 `429`
  가 올라온다. `workers` 의 의미는 위 「Manual flush」 를 볼 것. 이 429 는 nexus 요청에만 해당하고 부재 시간
  (`retry_timeout`)을 먹지 않는다. CAS 요청의 429·503 대기(서버 `Retry-After` 포함, 예산에 맞춰 자르지 않는다)는
  `retry_timeout` 을 먹고, CAS 500 은 예산 전체 동안 다시 보낸다.

### `Dataset.find_invalid_annotations(*, page_size=1000, **filters)`

이미 저장된 annotation 중 지금 규칙(component `type`·필수 필드·그룹 종류)을 어기는 것을 찾아 `(sample_id, path, reason)` 목록으로 돌려준다. `iter_samples` 로 검사 없이 읽고, dataset 의 서버 저장 그룹 종류로 샘플마다 다시 판정한다(저장 종류에 없는 이름은 선언 없는 그룹 규칙). `path` 는 그룹 이름으로 시작하고 `reason` 은 서버 `annotation_invalid` 와 같은 코드다. 읽기만 하며 고치지 않는다.

```python
for sample_id, path, reason in ds.find_invalid_annotations():
    print(sample_id, path, reason)   # s2 boxes[1].bounding_box.rect field_length
```

draft 버전에서 서버가 대량 읽기를 껐으면(`403 draft_bulk_read_disabled`) 그 `NexusError` 가 그대로 올라온다. sealed 버전은 동작한다.

### `Dataset.get_annotation(sample_id)`

이 버전에서 그 샘플의 annotation만 가져온다(`{"meta": {...}, "<group_key>": [...], ...}`). `get_sample`과 달리 코어
필드(`sample_id`/`split`/…)를 섞지 않는다. 읽기 전용이다 — 고쳐 저장하려면 `load_sample()` 로 객체를 받아 `save()` 하거나,
이 dict 를 `nx.AnnotatedSample.from_dict(d, group_kinds)` 로 바꾼다. dict 를 받는 저장 메서드(`save_annotation`·
`merge_annotation`·`patch_annotations`)는 없어졌다(위 「annotation 쓰기는 객체로만」).

### `Dataset.transfer_owner(email)` / `NexusClient.transfer_dataset_owner(dataset_id, email)`

이 dataset의 소유권을 다른 계정으로 넘긴다(`PUT /api/v1/datasets/{dataset_id}/owner`).
**현재 소유자만** 부를 수 있고, 갱신된 dataset dict를 돌려준다. **SDK 0.1.6+, 서버 0.1.6+.**

- 넘긴 뒤에는 이 계정이 그 dataset을 **지울 수 없다** — `NexusError(status_code=403)`.
  수정·적재는 역할이 가르므로 `editor` 이상이면 계속 된다(서버 0.1.7+).
  되돌리려면 새 소유자가 다시 넘겨주거나 운영자(superuser)가 지정해야 한다.
- **주인이 없는(`owner_user_id`가 `None`) dataset에는 쓸 수 없다** — `403`. 주인 없는 것을 인수하는
  것은 운영자(superuser)의 관리 조작이다.
- **자기 자신에게 넘기면** `400`. `email`로 가입된 계정이 없거나 dataset이 없으면 `404`.
- 소유권은 dataset 단위다 — 핸들이 어느 버전을 가리키든 그 dataset의 모든 버전이 함께 넘어간다.

### FiftyOne 식 조회·집계 (SDK 0.1.21+)

필드는 서버 경로 문법이다 — `"meta.<키>"`, 샘플 속성은 `"tags"`·`"split"`·`"sample_id"`.

```python
import nexus as nx

if not nx.dataset_exists("kitti"):
    ...
ds = nx.Dataset.load_or_create("kitti", "v1")

print(ds.name, len(ds))                      # len 은 정확한 샘플 수, bool(ds) 는 항상 True
for s in ds.iter_samples(split="train"):     # AnnotatedSample, annotation 전부 포함
    s.meta["reviewed"] = True
    s.tags.append("checked")
    s.save()                                 # 바뀐 meta 키·태그만 저장
ds.refresh()                                 # 다른 곳의 rename 을 반영
ds.values("meta.driver_id")                  # 샘플마다 값 하나, 없으면 None
ds.distinct("meta.weather", split="val")     # 필터 붙은 고유 값
ds.distinct("meta.weather")                  # 정렬된 고유 값 (훑기, 원래 타입)
ds.distinct("meta.weather", fast=True)       # 서버 histogram 한 번 (섞인 타입은 문자열)
ds.count_values("det.label")                 # {값: 샘플 수}
ds.count_sample_tags()
ds.get_field_schema()                        # {"meta.width": "int", ...}
ds.tags; ds.add_tag("reviewed"); ds.remove_tag("wip")
ds.set_values("meta.driver_id", {"<sample_id>": 7})   # None 이면 그 키 삭제
ds.update_meta({"reviewed": True}, split="val")      # 필터에 걸린 전부, 서버 0.1.24+
for s in ds.shuffle(seed=0, split="train"):
    ...
for s in ds.sort_by("meta.score", reverse=True, split="val"):   # 값 없는 샘플은 맨 뒤
    ...
```

`len(ds)` 는 핸들이 기억한다. sealed 버전은 서버가 seal 때 저장한 수를 읽고(서버 0.1.24+, `Dataset.open` 으로 열었거나 `seal()` 직후면 요청 없이 끝난다) draft 버전은 한 번 세고 기억한다. 이 핸들의 `flush`·`link_samples`·`unlink_samples`·`import_samples`·`seal`·`delete`·`refresh` 뒤에는 버리고 다시 센다. 핸들 밖의 변경(다른 프로세스·다른 핸들·웹 화면·REST)은 `ds.refresh()` 전까지 반영되지 않고, 버전이 지워졌으면 `NexusError(404)` 다. `count_values` 는 서버의 전수 모드로 세어 서버 0.1.24+ 에서 값 종류 100,000 개·50 초까지 본다(그 이하 서버는 500 개·3 초). 한계를 넘으면 `RuntimeWarning`(값 종류) 또는 `NexusError`(시간)이고 숫자 meta 키는 받지 않는다.

`distinct` 는 SDK 0.1.25 부터 기본이 걸린 샘플을 훑어 원래 타입으로 돌려준다(그 전에는 필터가 없으면 histogram 을 써 타입이 섞인 필드가 문자열로 나왔다). `fast=True` 는 필터가 없는 `meta.<키>` 에서 종전 histogram 경로다. `sort_by` 는 서버 정렬이 아니라 `(id, 값)` 을 모아 클라이언트에서 정렬한 뒤 묶음으로 본문을 받는다(`shuffle` 과 같은 구조) — 값 없는 샘플은 `reverse` 와 무관하게 맨 뒤, 같은 값은 `sample_id` 오름차순, 값 종류가 섞이면 `ValueError`. 롤링 교체 중 옛 파드가 답해 `count_values` 가 옛 상한에 걸리거나 `set_values` 가 샘플별로 내려가면 경고 문구에 그 원인을 적는다(서버 판은 응답 헤더 `X-Nexus-Version`).

`samples(include_annotations=False)` 의 행은 최상위 키가 읽기 전용인 `nx.SampleSummary`(dict 하위 타입)다(SDK 0.1.25). 안쪽 `meta`·`tags` 는 일반 dict·list 라 고칠 수 있고 원래 행이 바뀐다. 고쳐 쓸 사본은 `dict(row)`(얕은 사본), 안쪽까지는 `copy.deepcopy(dict(row))`.

`page_size` 는 1~1000, 모르는 필터 키워드는 `TypeError`. `iter_samples`·`shuffle`·`sort_by` 는 `include_annotations` 를 받지 않는다. meta·태그는 샘플에 붙어 버전 간에 공유된다. `set_values` 는 10,000 건 또는 본문 약 800 KB 마다 요청 한 번이고(먼저 닿는 쪽, `413` 이면 반으로 나눠 다시 보낸다) 요청 단위로 전부 아니면 없음이다(서버 0.1.24+, 옛 서버는 샘플별) — 실패하면 멈추고 예외의 `applied`·`failed_sample_id`·`rejected` 로 알린다. `update_meta` 는 대상이 10,000 건을 넘으면 `confirm=<건수>` 가 필요하고 sealed 버전은 409 다. 제약 전체는 `CHANGELOG.md` 의 0.1.21·0.1.22 절.

#### meta 필터의 `exclude`·「값 없음」과 `get_field_schema()` 의 타입 (서버 0.1.24+)

```python
# 값을 가진 샘플을 뺀다 — 키가 없는 샘플은 남는다
ds.distinct("meta.weather", meta={"camera_rig": {"type": "exclude", "value": ["front"]}})
ds.update_meta({"reviewed": True}, meta={"closure_flag": {"type": "exclude", "value": [1]}})
# 선언 필드에 값이 없는 샘플 (width=0 은 값이 있다)
ds.values("meta.weather", meta={"width": {"type": "ternary", "none": True}})
```

`exclude` 의 숫자·불리언은 값으로 비교해 `1` 이 `1`·`1.0` 을 함께 빼고, 문자열은 텍스트로 비교합니다(`"1"` 은 `1.0` 을 빼지 않습니다). 필터 쓰기(`update_meta`)에 걸면 그 키가 없는 샘플까지 대상입니다. 선언 스칼라 필드는 `ternary` 의 `none` 만 받습니다. SDK 는 필터를 바꾸지 않고 그대로 보내며 서버 `0.1.23` 이하는 400 입니다.

`ds.get_field_schema()` 는 서버의 `meta_schema.fields` 와 `meta_schema.other_fields` 를 합칩니다. 타입은 아래 값입니다. 서버 `0.1.23` 이하는 관측만 된 숫자 필드가 늘 `float` 이고 `other_fields` 가 없습니다.

| `get_field_schema()` 값 | 의미 | FiftyOne 대응 |
|---|---|---|
| `int` | 정수 | `IntField` |
| `float` | 실수 (정수가 섞여도) | `FloatField` |
| `string`·`enum` | 문자열 | `StringField` |
| `bool` | 불리언 | `BooleanField` |
| `datetime` | 선언 필드만 (관측 문자열은 승격하지 않음) | `DateTimeField` |
| `list`·선언 `list<…>` | 배열 (원소 타입은 주지 않음) | `ListField` |
| `object`·선언 `object`·`dict<…>` | 객체 | `DictField` |
| `any` | 배열과 객체가 섞임 | 대응 없음 |

#### 스키마 재계산·지정 삭제 (서버 0.1.37+)

```python
job = ds.recompute_schema()                  # 끝날 때까지 기다린다(기본 600 초)
job["result"]                                # {"conflicts": [...], "replaced": True, "samples": 1200}
ds.delete_schema_items("components", [{"group": "gt", "name": "score"}])   # 지운 행 수
nx.recompute_dataset_schema("kitti-mini")    # 모든 버전, 버전마다 {"version", "state", "result", ...}
```

스키마(`/schema`, `get_field_schema()`, 사이드바 목록)는 서버 0.1.37 부터 버전마다 따로 쌓입니다. draft 는 쓰기마다 더하기만 하므로 지운 그룹·컴포넌트가 남고, 판 올림 전부터 있던 버전(`schema_state: "legacy"`)은 dataset 전체 관측을 읽어 다른 버전에만 있는 그룹도 보입니다. 0.1.37 에서 seal 한 버전은 seal 이 정확한 값으로 바꿔 두었으므로(`exact`) 다시 계산할 필요가 없습니다. `recompute_schema()` 는 그 버전의 지금 데이터(sealed 는 seal 스냅샷)로 다시 만들어 그런 항목을 걷어 내고, 타입은 실데이터를 따릅니다. 한 컴포넌트 이름에 타입이 둘 이상 모이면 샘플이 많은 타입을 남기고 `result["conflicts"]` 에 적습니다 — 이런 그룹은 데이터를 정리하기 전까지 annotation 수정이 400 입니다. draft 는 재계산 도중의 쓰기와 겹치면 정확하다고 보장하지 않습니다.

- `wait` 초 안에 안 끝나면 `nx.NexusSchemaJobPending`(`job_id`)이고 작업은 서버에서 계속 돕니다. `client.get_schema_job(job_id)` 로 확인합니다. `block=False` 는 기다리지 않고 작업 dict 를 돌려줍니다.
- 재계산은 파드마다 하나씩 돌아 큰 버전·많은 버전은 오래 걸립니다. `recompute_dataset_schema` 는 모든 버전을 줄에 세우고 합쳐 `wait`(기본 3600 초)까지 기다린 뒤 버전마다 결과를 돌려줍니다 — 거절(`rejected`, 준비 중 버전 409·지워진 버전 404 등)·실패(`failed`)·기다리는 동안 버전 삭제(`gone`)·요청이나 조회가 끝내 안 됨(`unknown`, `job_id` 가 있으면 그것으로 확인)은 그 버전의 `state` 에 남고 다른 버전을 멈추지 않습니다. 옛 서버와 401·403 은 아직 세운 작업이 하나도 없을 때만 올립니다.
- `delete_schema_items(kind, items)` 는 데이터를 보지 않고 스키마 항목만 지웁니다. `kind` 는 `labels`(`{"group", "label"}`)·`components`(`{"group", "name"}`)·`meta_fields`(`{"field", "value_type"?}` — 실수 필드는 `number`·`float` 두 행이라 `value_type` 을 빼고 지웁니다)이고 items 는 1~1,000 개, draft 만 됩니다(sealed·준비 중 버전은 409). 데이터가 남아 있으면 그 그룹을 다시 쓰거나 재계산할 때 다시 기록됩니다.
- viewer 는 403, 0.1.20~0.1.36 서버는 판을 밝힌 `NexusError(404, code="schema_jobs_unsupported")` 입니다(그보다 옛 서버·프록시의 404 는 그대로). 지정 삭제는 응답을 받기 전에 끊겨도 다시 보내지 않습니다. 기다리는 동안 버전이 지워지면 작업도 지워져 404 입니다. 재계산에서 seal 스냅샷이 없는 sealed 버전은 409(`code` 없음)입니다.

### `Dataset.to_df(groups=None, *, path=None, format=None, chunksize=None, sample_fields=False)` / `Dataset.fingerprint(groups=None, *, source="auto")`

`to_df` returns the version's GT annotation as a `pandas.DataFrame` (one row per sample: `sample_id`, `meta`, one list column per group key). A **sealed** version reads the seal snapshot (NDJSON). A **draft** version reads the explorer in the snapshot's shape (without `split`/`tags`/`created_at`/`image_url`/`thumbnail_url`; a `groups=` entry with one of those names is `None`), using the *current* `meta`, and warns once per handle (`RuntimeWarning`) because edits made while reading can be mixed in. Without `chunksize` rows are sorted by `sample_id` ascending; a draft `chunksize` iterator streams in server order (`sample_id` descending). `chunksize <= 0` or `chunksize` with `path` raises `ValueError` before any request.

`sample_fields=True` (SDK 0.1.25) adds `tags` and `split` columns. For a sealed version these are the **values at seal time**, read from the main manifest the seal wrote to CAS (nexus-server 0.1.29+; the CAS key needs read access to `manifests/`, and the whole manifest JSON is fetched even with `chunksize`). If its BLAKE3 differs from the recorded hash (a seal by nexus-server 0.1.23 or older whose name-based manifest was overwritten) the columns are `None` with a `RuntimeWarning`. A draft version uses the current explorer values. A group named `tags` or `split` raises `ValueError` before anything is downloaded (without `groups=`, the dataset's observed group keys from `/schema` decide, so draft and sealed agree). The fingerprint is computed without these columns.

Without `chunksize`, `df.attrs["nexus_fingerprint"]` holds the fingerprint of the rows. `ds.fingerprint()` returns the same `"nxfp1:<blake3>"` string without pandas: compare a draft's fingerprint (read before training) with the sealed version's to confirm the data read is what was sealed. `source="auto"` (default) uses the snapshot when sealed and the explorer when draft; `"snapshot"` reads only the snapshot (`NexusError` on draft); `"explorer"` reads the explorer even when sealed (no draft warning) — it differs from the snapshot if `meta` was edited after sealing.

These explorer reads (draft `to_df`, `fingerprint`, `iter_samples`, `samples(include_annotations=True)`, `shuffle`, `sort_by`) carry the header `x-nexus-bulk-read: 1`. If the operator has turned off draft bulk reads, a draft version raises `NexusError` (`code == "draft_bulk_read_disabled"`, status 403, not retried) — use a sealed version.

### `nexus.IngestResult`

```python
@dataclass
class IngestResult:
    ok: bool
    sample: Sample | None
    sample_id: str | None  # set on success
    error: str | None      # set on failure
    status_code: int | None  # HTTP status of the failure, if any (CAS errors too, 0.1.18)
    index: int | None      # position in the input (0.1.18); result lists follow this order
    exception: NexusError | None  # NexusValidationError(errors=...) only for annotation validation failures (server annotation_invalid or SDK pre-check); None otherwise
```

## Error Handling

| Exception | Trigger |
|---|---|
| `NexusAuthError` | Login failure or token expired |
| `NexusCasError` | CAS upload/HEAD failure |
| `NexusIngestError` | Server ingest failure (4xx/5xx) |
| `NexusBatchError` | `strict=True` and one or more samples failed |

## Development

```bash
pip install -e "./sdk[dev]"
pytest sdk/tests/ -v
```
