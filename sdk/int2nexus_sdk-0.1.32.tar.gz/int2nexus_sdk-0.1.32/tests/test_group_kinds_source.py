"""그룹 종류의 기준은 서버 저장값이다(설계 6-7)와 `AnnotatedSample.promote`(설계 6-4).

`declare_group_kinds` 는 서버 저장이 실패하면 예외다 — 403(viewer)과 서버가 저장하지 않는 이름만 핸들에 두고 경고한다.
`flush` 사전 검사는 서버가 받아 둔 종류만 쓴다. 열 때 종류를 읽지 못한 핸들은 첫 쓰기가 다시 읽는다.
"""
import warnings
from unittest.mock import MagicMock

import pytest

from nexus._retry import should_retry
from nexus._types import NexusError, NexusValidationError
from nexus.annotated import AnnotatedSample
from nexus.cas import CasClient
from nexus.client import NexusClient
from nexus.dataset import Dataset
from nexus.group import LabelContainer, RawGroup
from nexus.instance import Instance
from nexus.labels import Detection
from nexus.sample import CasRef, Sample

from tests.test_dataset import _batch_ok

BASE = "http://nexus"
KINDS_URL = f"{BASE}/datasets/d1/group-kinds"
META = {"format_version": "1.0.0", "filename": "http://cas/kitti/images/a.png", "width": 4, "height": 4}
BOX = {"type": "bounding_box", "rect": [0.1, 0.2, 0.3, 0.4]}
POLY = {"type": "polygon", "points": [0, 0, 1, 0, 1, 1]}
ONE = {"id": "a", "label": "car", "bounding_box": BOX}
# container 규칙(행마다 component 하나) 위반이지만 선언 없는 그룹 규칙으로는 맞는 행.
TWO = {"id": "t", "label": "car", "bounding_box": BOX, "polygon": POLY}
REF = CasRef("kitti", "images/a.png", hash_hex="h", size=10, content_type="image/png")

REJECTED = [
    {"group": "dets", "sample_id": "0190a1b2-0000-7000-8000-000000000001", "version": "v1",
     "instance_id": "t", "reason": "container_component_count"},
    {"group": "dets", "sample_id": "0190a1b2-0000-7000-8000-000000000002", "version": "v2",
     "instance_id": "p", "reason": "container_mixed_types"},
]


@pytest.fixture
def client(requests_mock):
    requests_mock.post(f"{BASE}/api/v1/auth/login",
                       json={"token": "tok", "user_id": 1, "email": "u@x.com"})
    return NexusClient(BASE, "u@x.com", "pass")


@pytest.fixture
def cas():
    return CasClient("http://cas")


def _open(client, cas, requests_mock, stored=None):
    requests_mock.get(f"{BASE}/datasets/d1", json={"dataset_id": "d1", "name": "kitti", "tags": []})
    requests_mock.get(f"{BASE}/datasets/d1/versions/v1", json={"version": "v1", "status": "draft"})
    requests_mock.get(KINDS_URL, json={"kinds": stored or {}})
    return Dataset.open("d1", "v1", client=client, cas=cas)


def _mock_ds(stored=None):
    """가짜 클라이언트 핸들 — 저장 응답·조회가 같은 저장소를 본다."""
    client = MagicMock()
    client._no_partial_annotations = False
    store = dict(stored or {})

    def patch(_id, kinds):
        store.update(kinds)
        return dict(store)

    client.patch_group_kinds.side_effect = patch
    client.get_group_kinds.side_effect = lambda _id: dict(store)
    cas = MagicMock()
    cas._base = "http://cas"
    ds = Dataset(client, cas, "d1", "kitti", "v1")
    ds._load_group_kinds()
    return ds, client


def _load(ds, client, ann):
    client.get_sample.return_value = {**ann, "sample_id": "s1", "split": None, "tags": [],
                                      "created_at": "2026-11-01T00:00:00Z"}
    return ds.load_sample("s1")


# ── declare_group_kinds ─────────────────────────────────────────────────────


def test_선언_400_은_예외이고_rejected_를_싣는다(client, cas, requests_mock):
    ds = _open(client, cas, requests_mock, stored={"other": "group"})
    requests_mock.patch(KINDS_URL, status_code=400, json={
        "error": "2 건이 container 규칙에 어긋나 그룹 종류를 바꾸지 않았습니다",
        "code": "group_kind_rejected", "rejected": REJECTED,
    })
    with pytest.raises(NexusValidationError) as ei:
        ds.declare_group_kinds({"dets": "container"})
    e = ei.value
    assert e.status_code == 400 and e.code == "group_kind_rejected"
    assert e.rejected == REJECTED
    assert [(i.path, i.reason) for i in e.errors] == [
        ("dets[id=t]", "container_component_count"), ("dets[id=p]", "container_mixed_types")]
    assert REJECTED[0]["sample_id"] in e.errors[0].message and "v1" in e.errors[0].message
    assert "바꾸지 않았습니다" in str(e)

    # 모르는·없는 reason 은 서버 값(없으면 unknown) 그대로이고, 객체가 아닌 원소도 버리지 않는다.
    odd = [{"group": "dets", "sample_id": "s", "version": "v1", "instance_id": "q", "reason": "container_future"},
           {"group": "dets", "sample_id": "s", "version": "v1", "instance_id": "r"}, "weird"]
    requests_mock.patch(KINDS_URL, status_code=400, json={
        "error": "3 건이 container 규칙에 어긋나", "code": "group_kind_rejected", "rejected": odd})
    with pytest.raises(NexusValidationError) as ei:
        ds.declare_group_kinds({"dets": "container"})
    assert [(i.path, i.reason) for i in ei.value.errors] == [
        ("dets[id=q]", "container_future"), ("dets[id=r]", "unknown"), ("", "unknown")]
    assert "섞임" not in ei.value.errors[0].message and "weird" in ei.value.errors[2].message
    assert ei.value.rejected == odd
    # 아무것도 바뀌지 않는다 — 핸들은 서버 저장값 그대로.
    assert ds._group_kinds == {"other": "group"}


def test_선언_503_은_예외이고_다시_보내지_않는다(client, cas, requests_mock):
    # 50 초 시한에 걸린 기존 행 검사 — 다시 보내면 같은 검사를 다시 돌릴 뿐이라 자동 재전송하지 않는다.
    ds = _open(client, cas, requests_mock)
    for headers in ({"X-Request-Id": "r1"}, {}):   # nexus 가 낸 것·프록시가 낸 것처럼 보이는 것 모두
        m = requests_mock.patch(KINDS_URL, status_code=503, headers=headers, json={
            "error": "기존 행 검사를 시한 안에 끝내지 못해 그룹 종류를 바꾸지 않았습니다",
            "code": "group_kind_check_incomplete",
        })
        with pytest.raises(NexusError) as ei:
            ds.declare_group_kinds({"dets": "container"})
        assert not isinstance(ei.value, NexusValidationError)
        assert ei.value.status_code == 503 and ei.value.code == "group_kind_check_incomplete"
        assert "시한" in str(ei.value)
        assert m.call_count == 1
    assert ds._group_kinds == {}
    for from_nexus in (True, False):
        assert not should_retry("PATCH", "/datasets/d1/group-kinds", status=503, from_nexus=from_nexus)


def test_선언_403_은_경고하고_핸들에_둔다(client, cas, requests_mock):
    ds = _open(client, cas, requests_mock, stored={"other": "group"})
    requests_mock.patch(KINDS_URL, status_code=403, json={"error": "forbidden"})
    with pytest.warns(RuntimeWarning, match="viewer"):
        ds.declare_group_kinds({"dets": "container"})
    # 읽기에는 쓴다.
    assert ds._group_kinds == {"other": "group", "dets": "container"}
    requests_mock.get(f"{BASE}/datasets/d1/versions/v1/samples/s1", json={
        "sample_id": "s1", "tags": [], "meta": META, "dets": [ONE]})
    assert isinstance(ds.load_sample("s1").get_group("dets"), LabelContainer)
    # 적재 사전 검사는 서버가 받아 둔 종류만 쓴다 — 서버는 이 그룹을 선언 없는 그룹으로 본다.
    assert ds._ingest_group_kinds() == {"other": "group"}
    ann = AnnotatedSample.from_dict({"meta": META, "dets": [TWO]}, {})
    assert ds._resolve_annotation(ann)["annotation_data"]["dets"] == [TWO]


def test_저장하지_않는_이름은_경고하고_RawGroup_으로_남는다(client, cas, requests_mock):
    ds = _open(client, cas, requests_mock)
    m = requests_mock.patch(KINDS_URL, json={"kinds": {}})
    for name in (" pad", "x" * 129, "created_at", "\u3000wide"):
        ds._group_kinds_save_warned = False
        with pytest.warns(RuntimeWarning, match="저장하지 않는 이름"):
            ds.declare_group_kinds({name: "container"})
        assert name not in ds._group_kinds and ds._unstored_group_kinds[name] == "container"
    assert not m.called
    # 서버와 같은 공백 판정 — Rust trim 이 지우지 않는 `\x1c` 는 서버가 저장하므로 보낸다.
    ds.declare_group_kinds({"\x1cfs": "group"})
    assert m.call_count == 1 and ds._group_kinds == {}   # 가짜 서버 응답이 빈 저장값이다

    requests_mock.get(f"{BASE}/datasets/d1/versions/v1/samples/s1", json={
        "sample_id": "s1", "tags": [], "meta": META, " pad": [ONE]})
    s = ds.load_sample("s1")
    assert isinstance(s.get_group(" pad"), RawGroup)
    with pytest.raises(NexusValidationError, match="선언되지 않았습니다"):
        s[" pad"] = LabelContainer([Instance("car", [Detection(rect=[0, 0, 1, 1])], id="n")])
    ann = AnnotatedSample.from_dict({"meta": META, " pad": [TWO]}, {})
    assert ds._resolve_annotation(ann)["annotation_data"][" pad"] == [TWO]


def test_열_때_못_읽은_종류는_첫_쓰기에서_다시_읽는다():
    client = MagicMock()
    client._no_partial_annotations = False
    client._ingest_batch.return_value = _batch_ok(1)
    cas = MagicMock(); cas._base = "http://cas"
    client.get_group_kinds.side_effect = [NexusError("boom", status_code=500), {"dets": "container"}]
    ds = Dataset(client, cas, "d1", "kitti", "v1")
    with pytest.warns(RuntimeWarning, match="첫 쓰기"):
        ds._load_group_kinds()
    assert ds._group_kinds_unread and ds._group_kinds == {}

    # flush 가 다시 읽고 그 종류(container)로 검사한다 — 종류 없이 봤다면 통과했을 행이다.
    ds.add([Sample(image=REF, annotation=AnnotatedSample.from_dict({"meta": META, "dets": [TWO]}, {})),
            Sample(image=REF, annotation=AnnotatedSample.from_dict({"meta": META, "dets": [ONE]}, {}))])
    bad, ok = ds.flush(workers=1, verbose=False)
    assert client.get_group_kinds.call_count == 2
    assert not ds._group_kinds_unread and ds._group_kinds == {"dets": "container"}
    assert not bad.ok and "dets[0]" in bad.error and ok.ok

    # 다시 읽어도 실패하면 쓰지 않는다 — flush 는 큐를 그대로 두고, save() 는 아무것도 보내지 않는다.
    client.get_group_kinds.side_effect = NexusError("boom", status_code=500)
    ds2 = Dataset(client, cas, "d1", "kitti", "v1")
    with pytest.warns(RuntimeWarning):
        ds2._load_group_kinds()
    client._ingest_batch.reset_mock()
    ds2.add(Sample(image=REF, annotation=AnnotatedSample.from_dict({"meta": META}, {})))
    with pytest.raises(NexusError, match="쓰지 않았습니다"):
        ds2.flush(workers=1, verbose=False)
    assert len(ds2._queue) == 1
    client._ingest_batch.assert_not_called()

    client.get_sample.return_value = {"sample_id": "s1", "split": None, "tags": [], "meta": {"w": 1}}
    s = ds2.load_sample("s1")
    s.meta["w"] = 2
    with pytest.raises(NexusError, match="쓰지 않았습니다"):
        s.save()
    client._merge_sample_annotations.assert_not_called()

    # 아무것도 바뀌지 않은 save() 는 다시 읽지도 않는다.
    calls = client.get_group_kinds.call_count
    s2 = ds2.load_sample("s1")
    s2.save()
    assert client.get_group_kinds.call_count == calls


def test_옛_서버는_첫_쓰기에서_예외다():
    client = MagicMock()
    client.get_group_kinds.side_effect = NexusError("404", status_code=404, server_message="")
    ds = Dataset(client, MagicMock(), "d1", "kitti", "v1")
    with warnings.catch_warnings():
        warnings.simplefilter("error")
        ds._load_group_kinds()   # 여는 것은 조용히 된다(읽기에는 종류가 없어도 된다)
    ds.add(Sample(image=REF, annotation=AnnotatedSample.from_dict({"meta": META}, {})))
    with pytest.raises(NexusError, match="0.1.29 이상"):
        ds.flush(workers=1, verbose=False)


# ── promote ────────────────────────────────────────────────────────────────


def test_promote_는_샘플_검사_실패면_선언하지_않는다():
    ds, client = _mock_ds()
    s = _load(ds, client, {"meta": META, "dets": [ONE, TWO]})
    assert isinstance(s.get_group("dets"), RawGroup)
    with pytest.raises(NexusValidationError) as ei:
        s.promote("dets", "container")
    assert [(i.path, i.reason) for i in ei.value.errors] == [("dets[1]", "container_component_count")]
    client.patch_group_kinds.assert_not_called()
    assert isinstance(s.get_group("dets"), RawGroup) and "dets" not in ds._group_kinds

    # 행으로 읽을 수 없는 값도 선언 전에 같은 사유로 거절한다.
    s = _load(ds, client, {"meta": META, "dets": [None]})
    with pytest.raises(NexusValidationError) as ei:
        s.promote("dets", "group")
    assert [(i.path, i.reason) for i in ei.value.errors] == [("dets[0]", "common_field")]
    client.patch_group_kinds.assert_not_called()

    # 서버가 저장하지 않는 이름도 요청 없이 거절한다.
    s = _load(ds, client, {"meta": META, " pad": [ONE]})
    with pytest.raises(NexusValidationError, match="저장하지 않는"):
        s.promote(" pad", "group")
    client.patch_group_kinds.assert_not_called()


def test_promote_는_서버_거절이면_그룹을_바꾸지_않는다():
    ds, client = _mock_ds()
    s = _load(ds, client, {"meta": META, "dets": [ONE]})
    client.patch_group_kinds.side_effect = NexusError(
        "400", status_code=400, server_message="1 건이 container 규칙에 어긋나 그룹 종류를 바꾸지 않았습니다",
        code="group_kind_rejected", rejected=REJECTED[:1])
    with pytest.raises(NexusValidationError) as ei:
        s.promote("dets", "container")
    assert [i.path for i in ei.value.errors] == ["dets[id=t]"]
    assert isinstance(s.get_group("dets"), RawGroup) and ds._group_kinds == {}

    # 403 — 핸들에는 읽기용 선언으로 남지만 이 샘플의 그룹은 바꾸지 않는다(서버에서는 선언 없는 그룹이다).
    client.patch_group_kinds.side_effect = NexusError("403", status_code=403)
    with pytest.warns(RuntimeWarning, match="viewer"), pytest.raises(NexusError) as ei:
        s.promote("dets", "container")
    assert ei.value.status_code == 403
    assert isinstance(s.get_group("dets"), RawGroup)


def test_promote_뒤_save_는_그_그룹을_보내지_않는다():
    ds, client = _mock_ds({"other": "group"})
    client._merge_sample_annotations.return_value = {"instances": 1, "skipped": 0}
    s = _load(ds, client, {"meta": META, "dets": [ONE], "other": [ONE]})
    s.get_group("dets").raw.append(TWO)   # 고친 raw 는 보내지 않는 값이라 승격에도 쓰지 않는다
    g = s.promote("dets", "container")
    assert isinstance(g, LabelContainer) and s["dets"] is g and [i.id for i in g] == ["a"]
    assert client.patch_group_kinds.call_args[0][1] == {"dets": "container"}
    assert ds._group_kinds == {"other": "group", "dets": "container"}

    s.save()
    client._merge_sample_annotations.assert_not_called()

    # 이제 편집 핸들이다 — 고친 것은 보낸다.
    g.add(Instance("bus", [Detection(rect=[0, 0, 1, 1])], id="b"))
    s.save()
    sent = client._merge_sample_annotations.call_args[0][3]
    assert set(sent) == {"dets"} and [r["id"] for r in sent["dets"]] == ["a", "b"]

    with pytest.raises(TypeError, match="RawGroup 만"):
        s.promote("dets", "group")


@pytest.mark.parametrize("row", [
    {"label": "car", "bounding_box": BOX},                                            # id 없음 — SDK 가 id 를 채운다
    {"id": "c", "label": "car", "bounding_box": BOX, "track_id": None, "confidence": None},   # null 키 — 빠진다
], ids=["id_없음", "null_키"])
def test_promote_뒤_정규화되는_행도_save_는_보내지_않는다(row):
    ds, client = _mock_ds()
    client._merge_sample_annotations.return_value = {"instances": 1, "skipped": 0}
    s = _load(ds, client, {"meta": META, "dets": [row], "other": [ONE]})
    g = s.promote("dets", "container")
    assert s._baseline["dets"] == g.to_list("dets")   # 기준이 정규화 값이다
    s.save()
    client._merge_sample_annotations.assert_not_called()

    # 한 행을 고치면 그 그룹만 보낸다.
    g[0].label = "bus"
    s.save()
    sent = client._merge_sample_annotations.call_args[0][3]
    assert set(sent) == {"dets"} and sent["dets"][0]["label"] == "bus"


def test_promote_는_저장된_다른_종류를_덮지_않는다():
    # 종류를 읽지 못한 채 연 핸들 — 그 샘플의 dets 는 RawGroup 으로 열린다. promote 가 다시 읽어 서버에 container 로
    # 저장된 것을 알면 group 으로 바꾸지 않는다.
    ds, client = _mock_ds({"dets": "container"})
    client.get_group_kinds.side_effect = [NexusError("boom", status_code=500), {"dets": "container"}]
    with pytest.warns(RuntimeWarning):
        ds._load_group_kinds()
    s = _load(ds, client, {"meta": META, "dets": [ONE]})
    assert isinstance(s.get_group("dets"), RawGroup)
    with pytest.raises(NexusValidationError, match="'container' 로 저장돼"):
        s.promote("dets", "group")
    client.patch_group_kinds.assert_not_called()
    assert isinstance(s.get_group("dets"), RawGroup) and ds._stored_group_kinds == {"dets": "container"}
    # 같은 종류면 그대로 승격한다.
    assert isinstance(s.promote("dets", "container"), LabelContainer)


def test_선언_403_경고는_핸들당_한_번이다(client, cas, requests_mock):
    ds = _open(client, cas, requests_mock)
    requests_mock.patch(KINDS_URL, status_code=403, json={"error": "forbidden"})
    with pytest.warns(RuntimeWarning, match="viewer") as rec:
        ds.declare_group_kinds({"a": "group"})
        ds.declare_group_kinds({"b": "container"})
    assert len([w for w in rec if issubclass(w.category, RuntimeWarning)]) == 1
    assert ds._viewer_group_kinds == {"a": "group", "b": "container"}


def test_파생_핸들은_viewer_와_저장하지_않는_이름의_기록을_복사해_받는다():
    src, _ = _mock_ds({"dets": "group"})
    src._viewer_group_kinds = {"ro": "container"}
    src._group_kinds = {"dets": "group", "ro": "container"}
    src._unstored_group_kinds = {" pad": "group"}
    new, _ = _mock_ds({"dets": "group", "other": "container"})
    out = src._derived(new)
    assert out is new
    assert new._stored_group_kinds == {"dets": "group", "other": "container"}
    assert new._group_kinds == {"dets": "group", "other": "container", "ro": "container"}
    assert new._viewer_group_kinds == {"ro": "container"} and new._unstored_group_kinds == {" pad": "group"}
    assert new._ingest_group_kinds() == {"dets": "group", "other": "container"}
    src._viewer_group_kinds["x"] = "group"
    src._unstored_group_kinds["y"] = "group"
    assert "x" not in new._viewer_group_kinds and "y" not in new._unstored_group_kinds
