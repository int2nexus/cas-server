"""Test that annotation object layer symbols are exposed at package top level."""
import nexus as nx


def test_public_symbols_exposed():
    """Verify that all annotation object layer symbols are exported from nexus package."""
    for name in [
        "AnnotatedSample",
        "LabelGroup",
        "LabelContainer",
        "RawGroup",
        "Instance",
        "Meta",
        "Label",
        "Detection",
        "Keypoint2D",
        "Keypoint3D",
        "Classification",
        "ScalarValue",
        "VectorValue",
        "Cuboid3D",
        "Polygon",
        "Polyline",
        "NexusValidationError",
    ]:
        assert hasattr(nx, name), f"nexus.{name} not exported"


def test_client_classes_and_cas_accessor_are_public():
    """`nx.Dataset(client, cas, ...)` 를 직접 만들 수 있도록 두 클라이언트 클래스와 접속된
    CAS 클라이언트 접근자를 공개 목록에 올린다(0.1.18)."""
    for name in ["CasClient", "NexusClient", "cas_client"]:
        assert name in nx.__all__, f"{name} not in nexus.__all__"
        assert hasattr(nx, name)


def test_dataset_exists_is_public():
    assert "dataset_exists" in nx.__all__
    assert callable(nx.dataset_exists)


def test_delete_dataset_is_public():
    assert "delete_dataset" in nx.__all__
    assert callable(nx.delete_dataset)


def test_issue_is_public():
    """`NexusValidationError.errors` 의 원소 타입을 `nx.Issue` 로 쓸 수 있다(0.1.31)."""
    from nexus._types import Issue
    assert "Issue" in nx.__all__
    assert nx.Issue is Issue


def test_top_level_list_datasets_forwards_cursor_value():
    """`limit` 이 찬 경고가 안내하는 `cursor_value=` 를 `nx.list_datasets` 도 받아 저수준에 넘긴다(0.1.31)."""
    from unittest.mock import MagicMock
    c = MagicMock()
    c.list_datasets.return_value = []
    nx.list_datasets(limit=10, cursor="d1", cursor_value="2026-11-01T00:00:00Z", client=c)
    kwargs = c.list_datasets.call_args.kwargs
    assert kwargs["cursor"] == "d1"
    assert kwargs["cursor_value"] == "2026-11-01T00:00:00Z"
