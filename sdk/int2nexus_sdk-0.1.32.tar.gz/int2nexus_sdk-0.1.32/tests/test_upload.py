from unittest.mock import MagicMock
import pytest


def _png(w, h):
    import struct, zlib
    def chunk(name, d):
        crc = zlib.crc32(name + d) & 0xFFFFFFFF
        return struct.pack(">I", len(d)) + name + d + struct.pack(">I", crc)
    sig = b"\x89PNG\r\n\x1a\n"
    ihdr = chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
    row = b"\x00" + b"\x80\x80\x80" * w
    idat = chunk(b"IDAT", zlib.compress(row * h))
    iend = chunk(b"IEND", b"")
    return sig + ihdr + idat + iend


def test_upload_puts_image_and_thumbnail_returns_rich_ref(tmp_path):
    from nexus.upload import upload
    from nexus.sample import CasRef
    from nexus.cas import CasClient

    img = tmp_path / "img.png"
    data = _png(400, 300)
    img.write_bytes(data)

    cas = MagicMock(); cas.head.return_value = None
    client = MagicMock()

    refs = upload([str(img)], bucket="kitti", prefix="images",
                  workers=1, verbose=False, client=client, cas=cas)

    client.ensure_bucket.assert_called_once_with("kitti")
    ref = refs[str(img)]
    assert isinstance(ref, CasRef)
    assert ref.bucket == "kitti" and ref.key == "images/img.png"
    assert ref.hash_hex == CasClient.hash_bytes(data)
    assert ref.size == len(data)
    assert ref.content_type == "image/png"
    assert ref.width == 400 and ref.height == 300  # 업로드 시 dims 캐시
    assert cas.put.call_count == 2  # image + thumbnail
    thumb = [c for c in cas.put.call_args_list if c[0][1] == "thumb/images/img.png"]
    assert len(thumb) == 1 and thumb[0][0][3] == "image/webp"


def test_upload_skips_put_when_same_hash_exists(tmp_path):
    from nexus.upload import upload
    from nexus.cas import CasClient
    img = tmp_path / "img.png"; data = _png(10, 10); img.write_bytes(data)
    cas = MagicMock()
    cas.head.return_value = {"hash_hex": CasClient.hash_bytes(data), "size": len(data), "content_type": "image/png"}
    refs = upload([str(img)], bucket="b", prefix="p", workers=1, verbose=False,
                  client=MagicMock(), cas=cas)
    cas.put.assert_not_called()
    assert refs[str(img)].key == "p/img.png"


def test_upload_collision_is_reported_as_failure(tmp_path):
    # 충돌은 건당 격리되어 실패로 보고된다 → strict=True면 raise.
    from nexus.upload import upload
    from nexus._types import NexusCasError
    img = tmp_path / "img.png"; img.write_bytes(_png(10, 10))
    cas = MagicMock()
    cas.head.return_value = {"hash_hex": "different", "size": 1, "content_type": "image/png"}
    with pytest.raises(NexusCasError, match="업로드 실패"):
        upload([str(img)], bucket="b", prefix="p", workers=1, verbose=False,
               strict=True, client=MagicMock(), cas=cas)


def test_upload_isolates_per_file_failure(tmp_path):
    # 한 파일이 실패해도 배치를 죽이지 않고 성공분만 반환 (strict=False는 경고).
    from nexus.upload import upload
    from nexus._types import NexusCasError
    a = tmp_path / "a.png"; a.write_bytes(_png(8, 8))
    b = tmp_path / "b.png"; b.write_bytes(_png(8, 8))
    cas = MagicMock(); cas.head.return_value = None

    def put_side(bucket, key, data, ct):
        if key.endswith("b.png"):
            raise NexusCasError("boom")
    cas.put.side_effect = put_side

    with pytest.warns(RuntimeWarning, match="업로드 실패"):
        refs = upload([str(a), str(b)], bucket="bk", prefix="p", workers=1,
                      verbose=False, client=MagicMock(), cas=cas)
    assert str(a) in refs and str(b) not in refs


def test_upload_strict_raises_on_any_failure(tmp_path):
    from nexus.upload import upload
    from nexus._types import NexusCasError
    a = tmp_path / "a.png"; a.write_bytes(_png(8, 8))
    cas = MagicMock(); cas.head.return_value = None
    cas.put.side_effect = NexusCasError("boom")
    with pytest.raises(NexusCasError, match="업로드 실패"):
        upload([str(a)], bucket="bk", prefix="p", workers=1, verbose=False,
               strict=True, client=MagicMock(), cas=cas)


def test_upload_overwrite_false_still_raises_on_collision(tmp_path):
    # 기본값(overwrite=False)은 기존 동작 그대로 충돌을 에러로 낸다.
    from nexus.upload import upload
    from nexus._types import NexusCasError
    img = tmp_path / "img.png"; img.write_bytes(_png(10, 10))
    cas = MagicMock()
    cas.head.return_value = {"hash_hex": "different", "size": 1, "content_type": "image/png"}
    with pytest.raises(NexusCasError, match="업로드 실패"):
        upload([str(img)], bucket="b", prefix="p", workers=1, verbose=False,
               strict=True, client=MagicMock(), cas=cas)
    cas.put.assert_not_called()


def test_upload_overwrite_true_replaces_differing_content(tmp_path):
    # overwrite=True면 다른 내용이 있어도 에러 대신 덮어쓴다 — 이미지 + 썸네일 둘 다.
    from nexus.upload import upload
    from nexus.cas import CasClient
    img = tmp_path / "img.png"; data = _png(10, 10); img.write_bytes(data)
    cas = MagicMock()
    # 이미지 key는 다른 내용, 썸네일 key는 이미 존재(이전 내용의 썸네일) — 둘 다 덮어써야 함.
    cas.head.return_value = {"hash_hex": "different", "size": 1, "content_type": "image/png"}

    refs = upload([str(img)], bucket="b", prefix="p", workers=1, verbose=False,
                  overwrite=True, client=MagicMock(), cas=cas)

    assert refs[str(img)].hash_hex == CasClient.hash_bytes(data)
    assert cas.put.call_count == 2  # image + thumbnail, 썸네일 head 존재 여부와 무관하게 덮어씀
    put_keys = [c[0][1] for c in cas.put.call_args_list]
    assert "p/img.png" in put_keys
    assert "thumb/p/img.png" in put_keys


def test_upload_overwrite_true_skips_put_when_same_hash(tmp_path):
    # overwrite=True라도 내용이 같으면(HEAD-skip) 다시 쓰지 않는다.
    from nexus.upload import upload
    from nexus.cas import CasClient
    img = tmp_path / "img.png"; data = _png(10, 10); img.write_bytes(data)
    cas = MagicMock()
    cas.head.return_value = {"hash_hex": CasClient.hash_bytes(data), "size": len(data), "content_type": "image/png"}

    refs = upload([str(img)], bucket="b", prefix="p", workers=1, verbose=False,
                  overwrite=True, client=MagicMock(), cas=cas)

    cas.put.assert_not_called()
    assert refs[str(img)].key == "p/img.png"


def test_upload_no_prefix_uses_bare_filename(tmp_path):
    from nexus.upload import upload
    img = tmp_path / "img.png"; img.write_bytes(_png(8, 8))
    cas = MagicMock(); cas.head.return_value = None
    refs = upload([str(img)], bucket="b", workers=1, verbose=False,
                  client=MagicMock(), cas=cas)
    assert refs[str(img)].key == "img.png"


def test_rewrite_thumbnails_puts_even_when_thumbnail_exists():
    from nexus.upload import rewrite_thumbnails
    from nexus.sample import CasRef

    cas = MagicMock()
    cas.get.return_value = _png(400, 300)
    cas.head.return_value = {"hash_hex": "x"}   # 썸네일이 이미 있어도

    res = rewrite_thumbnails(
        [CasRef(bucket="b", key="d/a.png"), "s3://b/d/c.png"],
        workers=1, verbose=False, cas=cas,
    )

    assert res == {"written": 2, "skipped": [], "failed": {}}
    puts = {c.args[1]: c.args for c in cas.put.call_args_list}
    assert set(puts) == {"thumb/d/a.png", "thumb/d/c.png"}
    assert all(a[0] == "b" and a[3] == "image/webp" for a in puts.values())
    cas.head.assert_not_called()


def test_rewrite_thumbnails_skips_non_images():
    import warnings
    from nexus.upload import rewrite_thumbnails

    cas = MagicMock()
    cas.get.return_value = b"not an image"
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        res = rewrite_thumbnails(["s3://b/x.bin"], workers=1, verbose=False, cas=cas)
    assert res == {"written": 0, "skipped": ["b/x.bin"], "failed": {}}
    cas.put.assert_not_called()


def test_rewrite_thumbnails_reports_failures():
    from nexus.upload import rewrite_thumbnails

    cas = MagicMock()
    cas.get.side_effect = RuntimeError("boom")
    res = rewrite_thumbnails(["s3://b/x.png"], workers=1, verbose=False, cas=cas)
    assert res["written"] == 0 and res["skipped"] == []
    assert "boom" in res["failed"]["b/x.png"]
    cas.put.assert_not_called()


def test_dataset_rewrite_thumbnails_collects_role_urls(monkeypatch):
    from nexus.dataset import Dataset
    import sys
    up = sys.modules["nexus.upload"]   # nexus.upload 속성은 함수가 가린다

    ds = Dataset.__new__(Dataset)
    ds._cas = None
    ds._iter_manifest_samples = MagicMock(return_value=iter([
        {"sample_id": "1", "assets": {"depth": {"cas_url": "s3://b/d1.png"}, "image": {"cas_url": "s3://b/i1.png"}}},
        {"sample_id": "2", "assets": {"image": {"cas_url": "s3://b/i2.png"}}},
        {"sample_id": "3", "assets": {"depth": {"cas_url": "s3://b/d3.png"}}},
    ]))
    seen = {}
    def fake(refs, **kw):
        seen["refs"] = list(refs); seen["kw"] = kw
        return {"written": 2, "skipped": [], "failed": {}}
    monkeypatch.setattr(up, "rewrite_thumbnails", fake)

    res = ds.rewrite_thumbnails("depth", workers=2)
    assert seen["refs"] == ["s3://b/d1.png", "s3://b/d3.png"]
    assert seen["kw"] == {"workers": 2}
    assert res["written"] == 2


def test_rewrite_thumbnails_mixed_batch():
    import warnings
    from nexus.upload import rewrite_thumbnails

    def get(bucket, key):
        if key == "bad.png":
            raise RuntimeError("boom")
        return b"junk" if key == "x.bin" else _png(100, 100)
    cas = MagicMock(); cas.get.side_effect = get
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        res = rewrite_thumbnails(
            ["s3://b/ok.png", "s3://b/bad.png", "s3://c/x.bin"],
            workers=1, verbose=False, cas=cas)
    assert res["written"] == 1
    assert res["skipped"] == ["c/x.bin"]
    assert list(res["failed"]) == ["b/bad.png"] and "boom" in res["failed"]["b/bad.png"]
    assert [c.args[1] for c in cas.put.call_args_list] == ["thumb/ok.png"]


def test_rewrite_thumbnails_dedupes_refs():
    from nexus.upload import rewrite_thumbnails
    from nexus.sample import CasRef

    cas = MagicMock(); cas.get.return_value = _png(50, 50)
    res = rewrite_thumbnails(
        ["s3://b/a.png", CasRef(bucket="b", key="a.png"), "s3://c/a.png"],
        workers=1, verbose=False, cas=cas)
    assert res["written"] == 2
    assert cas.get.call_count == 2 and cas.put.call_count == 2


def test_dataset_rewrite_thumbnails_without_targets_calls_once(monkeypatch):
    import sys
    from nexus.dataset import Dataset
    up = sys.modules["nexus.upload"]
    ds = Dataset.__new__(Dataset)
    ds._cas = None
    ds._iter_manifest_samples = lambda *a, **k: iter([{"assets": {}}])
    calls = []
    monkeypatch.setattr(up, "rewrite_thumbnails",
                        lambda refs, **kw: calls.append(list(refs)) or {"written": 0, "skipped": [], "failed": {}})
    assert ds.rewrite_thumbnails("depth") == {"written": 0, "skipped": [], "failed": {}}
    assert calls == [[]]


def test_dataset_rewrite_thumbnails_uses_the_handles_cas(monkeypatch):
    # 핸들의 CAS 를 넘긴다 — 넘기지 않으면 모듈 전역 접속(없으면 자동 접속)을 써 다른 CAS 에 닿는다. 직접 준 cas= 가 이긴다.
    import sys
    from nexus.dataset import Dataset
    up = sys.modules["nexus.upload"]
    ds = Dataset.__new__(Dataset)
    ds._cas = handle_cas = MagicMock()
    ds._iter_manifest_samples = lambda *a, **k: iter([{"assets": {"depth": {"cas_url": "s3://b/d.png"}}}])
    seen = []
    monkeypatch.setattr(up, "rewrite_thumbnails",
                        lambda refs, **kw: seen.append(kw.get("cas")) or {"written": 1, "skipped": [], "failed": {}})
    ds.rewrite_thumbnails("depth")
    other = MagicMock()
    ds._iter_manifest_samples = lambda *a, **k: iter([{"assets": {"depth": {"cas_url": "s3://b/d.png"}}}])
    ds.rewrite_thumbnails("depth", cas=other)
    ds._iter_manifest_samples = lambda *a, **k: iter([{"assets": {"depth": {"cas_url": "s3://b/d.png"}}}])
    ds.rewrite_thumbnails("depth", cas=None)
    assert seen == [handle_cas, other, handle_cas]


def test_dataset_rewrite_thumbnails_streams_urls_and_returns_the_result(monkeypatch):
    # 목록을 만들지 않고 제너레이터로 넘기며(중복 거르기는 nx.rewrite_thumbnails 몫), 그 결과를 그대로 돌려준다.
    import inspect
    import sys
    from nexus.dataset import Dataset
    up = sys.modules["nexus.upload"]
    ds = Dataset.__new__(Dataset)
    ds._cas = None
    ds._iter_manifest_samples = lambda *a, **k: iter([
        {"assets": {"depth": {"cas_url": "s3://b/d.png"}}},
        {"assets": {"image": {"cas_url": "s3://b/i.png"}}},
        {"assets": {"depth": {"cas_url": "s3://b/d.png"}}},
    ])
    seen = {}
    result = {"written": 1, "skipped": [], "failed": {}, "extra": 1}

    def fake(refs, **kw):
        seen["generator"] = inspect.isgenerator(refs)
        seen["refs"] = list(refs)
        return result
    monkeypatch.setattr(up, "rewrite_thumbnails", fake)
    assert ds.rewrite_thumbnails("depth") is result
    assert seen == {"generator": True, "refs": ["s3://b/d.png", "s3://b/d.png"]}


def test_rewrite_thumbnails_reads_a_generator_lazily_within_the_window(monkeypatch):
    # 제너레이터를 먼저 다 읽지 않는다 — 읽었지만 끝나지 않은 작업은 workers × 창 크기(+ 읽는 중인 하나)까지다.
    import sys
    import threading
    from nexus.upload import rewrite_thumbnails
    up = sys.modules["nexus.upload"]   # nexus.upload 속성은 함수가 가린다

    lock = threading.Lock()
    consumed, finished, ahead = [0], [0], []

    def refs():
        for i in range(50):
            with lock:
                consumed[0] += 1
            yield f"s3://b/{i}.png"

    def get(bucket, key):
        with lock:
            ahead.append(consumed[0] - finished[0])
        return b"junk"

    def make(data):
        with lock:
            finished[0] += 1
        return None  # 이미지가 아니다 — skipped
    monkeypatch.setattr(up, "_make_thumbnail", make)
    cas = MagicMock(); cas.get.side_effect = get

    res = rewrite_thumbnails(refs(), workers=1, verbose=False, cas=cas)

    assert res["written"] == 0 and len(res["skipped"]) == 50 and res["failed"] == {}
    cas.put.assert_not_called()
    assert max(ahead) <= up._REWRITE_IN_FLIGHT_PER_WORKER + 1


def test_rewrite_thumbnails_generator_dedupes_across_notations_and_reports_bad_refs():
    from nexus.upload import rewrite_thumbnails

    cas = MagicMock(); cas.get.return_value = _png(50, 50)

    def refs():
        yield "s3://b/a.png"
        yield "./local.png"
        for i in range(20):
            yield f"s3://b/x{i}.png"
        yield "http://cas/b/a.png"  # 같은 객체 — 창을 여러 번 넘긴 뒤에도 거른다
    res = rewrite_thumbnails(refs(), workers=1, verbose=False, cas=cas)
    assert res["written"] == 21
    assert list(res["failed"]) == ["./local.png"]
    assert cas.get.call_count == 21


def test_rewrite_thumbnails_accepts_workers_none():
    # ThreadPoolExecutor 처럼 `workers=None` 은 기본 일꾼 수다 — 창 계산이 None 에서 터지지 않는다.
    from nexus.upload import rewrite_thumbnails
    cas = MagicMock(); cas.get.return_value = _png(50, 50)
    res = rewrite_thumbnails(["s3://b/a.png", "s3://b/b.png"], workers=None, verbose=False, cas=cas)
    assert res["written"] == 2


def test_rewrite_thumbnails_failure_while_reading_refs_carries_the_partial_result():
    # `refs` 를 읽다 멈추면 이미 띄운 작업을 거둬 그때까지의 결과를 예외에 싣는다 — 쓴 썸네일은 되돌리지 않는다.
    from nexus.upload import rewrite_thumbnails
    cas = MagicMock(); cas.get.return_value = _png(50, 50)

    def refs():
        yield "s3://b/a.png"
        yield "./local.png"
        yield "s3://b/b.png"
        raise RuntimeError("page 50 failed")
    with pytest.raises(RuntimeError, match="page 50") as e:
        rewrite_thumbnails(refs(), workers=2, verbose=False, cas=cas)
    part = e.value.partial_result
    # 시작하지 않은 작업은 취소된다 — 결과는 실제로 쓴 것과 같아야 한다.
    assert part["written"] == cas.put.call_count
    assert list(part["failed"]) == ["./local.png"]


def test_rewrite_thumbnails_interrupt_carries_the_partial_result():
    # Ctrl-C 도 같다 — 띄운 작업은 풀을 닫을 때 끝나므로 마저 거둬 예외에 싣는다.
    from nexus.upload import rewrite_thumbnails
    cas = MagicMock(); cas.get.return_value = _png(50, 50)

    def refs():
        yield "s3://b/a.png"
        raise KeyboardInterrupt
    with pytest.raises(KeyboardInterrupt) as e:
        rewrite_thumbnails(refs(), workers=1, verbose=False, cas=cas)
    part = e.value.partial_result
    assert part["written"] == cas.put.call_count and part["skipped"] == [] and part["failed"] == {}


def test_rewrite_thumbnails_interrupt_cancels_queued_work():
    # 멈추면 아직 시작하지 않은 작업은 쓰지 않는다 — 도는 하나만 마저 끝내고 결과에 싣는다.
    import threading
    import time
    from nexus.upload import rewrite_thumbnails

    release = threading.Event()
    cas = MagicMock()

    def get(bucket, key):
        if key == "0.png":
            release.wait(5)
            time.sleep(0.2)  # 그 사이 본 스레드가 대기 작업을 취소한다
        return _png(50, 50)
    cas.get.side_effect = get

    def refs():
        for i in range(3):  # 창(workers × 4)보다 적게 — 창이 차면 본 스레드가 첫 작업을 기다리며 멈춘다
            yield f"s3://b/{i}.png"
        release.set()
        raise KeyboardInterrupt
    with pytest.raises(KeyboardInterrupt) as e:
        rewrite_thumbnails(refs(), workers=1, verbose=False, cas=cas)
    assert [c.args[1] for c in cas.put.call_args_list] == ["thumb/0.png"]
    assert e.value.partial_result["written"] == 1


def test_rewrite_thumbnails_second_interrupt_wins_over_the_first_error():
    # 서버 오류로 멈춰 거두는 동안 Ctrl-C 를 누르면 그 Ctrl-C 를 올린다 — 첫 오류를 올리면 그것을 잡아 다시 도는 호출부가
    # 사용자의 멈춤을 삼킨다. 첫 오류는 원인으로 남는다.
    import threading
    from nexus.upload import rewrite_thumbnails

    started = threading.Event()
    release = threading.Event()
    cas = MagicMock()

    def get(bucket, key):
        started.set()
        release.wait(5)
        return _png(50, 50)
    cas.get.side_effect = get

    def refs():
        yield "s3://b/a.png"
        started.wait(5)
        raise RuntimeError("page failed")

    import sys
    up = sys.modules["nexus.upload"]
    real = up.as_completed

    def interrupted(fs):
        raise KeyboardInterrupt  # 거두는 도중의 두 번째 Ctrl-C
    up.as_completed = interrupted
    try:
        with pytest.raises(KeyboardInterrupt) as e:
            rewrite_thumbnails(refs(), workers=1, verbose=False, cas=cas)
    finally:
        up.as_completed = real
        release.set()
    assert isinstance(e.value.__cause__, RuntimeError)
    assert e.value.partial_result == {"written": 0, "skipped": [], "failed": {}}
