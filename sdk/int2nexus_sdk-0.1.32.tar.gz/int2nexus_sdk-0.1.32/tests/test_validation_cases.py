"""서버와 같은 사례 파일(`tests/fixtures/annotation_validation/cases.json`)로 SDK 검증기의 `(path, reason)` 을 대조한다.

Rust 쪽은 같은 파일을 `catalog::annotation_validate` 시험이 읽는다 — 두 언어가 갈라지면 어느 한쪽이 깨진다."""
import json
import math
from pathlib import Path

import pytest

from nexus._types import Issue, NexusValidationError
from nexus.group import LabelContainer, LabelGroup, RawGroup
from nexus.instance import Instance
from nexus.labels import Detection, Label

CASES = json.loads(
    (Path(__file__).parents[2] / "tests/fixtures/annotation_validation/cases.json").read_text(encoding="utf-8"))


def _pairs(issues):
    return sorted((i.path, i.reason) for i in issues)


def _want(case):
    return sorted((e["path"], e["reason"]) for e in case["expect"])


@pytest.mark.parametrize("case", CASES["components"], ids=lambda c: c["name"])
def test_components_사례(case):
    # 행 하나에 component 키 하나만 둔다 — 분류(component·extras·invalid_type·missing_type)까지 SDK 가 한다.
    inst = Instance.from_row({"id": "x", "label": "car", case["key"]: case["value"]})
    assert _pairs(inst.issues("")) == _want(case)


@pytest.mark.parametrize("case", CASES["groups"], ids=lambda c: c["name"])
def test_groups_사례(case):
    if case.get("parser"):
        # 서버에서는 파서 거절(`parser_issue`)이 내는 항목이라 RawGroup 만 본다.
        assert _pairs(RawGroup(case["rows"]).issues(case["group"])) == _want(case)
        return
    cls = LabelContainer if case["kind"] == "container" else LabelGroup
    grp = cls.from_list(case["rows"])
    assert _pairs(grp.issues(case["group"])) == _want(case)
    # RawGroup 은 컨테이너 규칙을 모르므로 group 종류 사례만 같은 결과여야 한다.
    if case["kind"] == "group":
        assert _pairs(RawGroup(case["rows"]).issues(case["group"])) == _want(case)


def test_사례_파일은_두_절이_모두_채워져_있다():
    assert len(CASES["components"]) >= 30
    assert len(CASES["groups"]) >= 10


def test_validate_는_앞_다섯_개를_요약하고_errors_에_전부_담는다():
    rows = [{"id": f"i{n}", "label": "car", "bounding_box": {"type": "bounding_box", "rect": [0]}} for n in range(7)]
    with pytest.raises(NexusValidationError) as ei:
        LabelGroup.from_list(rows).validate()
    e = ei.value
    assert len(e.errors) == 7
    assert all(isinstance(i, Issue) and i.reason == "field_length" for i in e.errors)
    assert e.errors[0].path == "[0].bounding_box.rect"
    assert "(외 2건)" in str(e)
    assert e.status_code is None


def test_errors_기본값은_빈_목록이다():
    assert NexusValidationError("x").errors == []


def test_NaN_과_무한대는_non_finite() -> None:
    lab = Detection({"type": "bounding_box", "rect": [0, 0, math.nan, 1]})
    assert [(i.path, i.reason) for i in lab.issues("bb")] == [("bb.rect", "non_finite")]
    assert [i.reason for i in Label.from_dict({"type": "value", "value": math.inf}).issues("v")] == ["non_finite"]
    assert [i.reason for i in Detection({"type": "bounding_box", "rect": [0, 0, 1, 1], "confidence": math.nan}).issues("bb")] == ["non_finite"]


@pytest.mark.parametrize("kw,path", [
    ({"id": 5}, "g[0].id"),
    ({"label": None}, "g[0].label"),
    ({"label": 3}, "g[0].label"),
    ({"track_id": 2**31}, "g[0].track_id"),
    ({"track_id": True}, "g[0].track_id"),
    ({"confidence": float("nan")}, "g[0].confidence"),
    ({"confidence": 1e39}, "g[0].confidence"),
])
def test_공통_필드_위반은_common_field(kw, path):
    args = {"id": "a", "label": "car", "components": {}}
    args.update(kw)
    assert [(i.path, i.reason) for i in Instance(**args).issues("g[0]")] == [(path, "common_field")]


def test_공통_필드_정상값은_통과한다():
    Instance(id="a", label="car", components={}, track_id=-(2**31), confidence=0.5).validate()
    Instance(id="a", label="car", components={}, track_id=2**31 - 1, confidence=3.4e38).validate()


def test_Instance_가_아닌_행은_그룹_이름부터의_전체_경로로_거절한다():
    g = LabelGroup([Instance(id="a", label="car", components={}), Detection(rect=[0, 0, 1, 1])])
    with pytest.raises(NexusValidationError) as ei:
        g.to_list("det")
    assert [i.path for i in ei.value.errors] == ["det[1]"]
    with pytest.raises(NexusValidationError) as ei:
        g.validate("det")
    assert [i.path for i in ei.value.errors] == ["det[1]"]
    inst = Instance(id="a", label="car", components={"bb": {"type": "bounding_box"}})
    with pytest.raises(NexusValidationError) as ei:
        LabelGroup([inst]).to_list("det")
    assert [i.path for i in ei.value.errors] == ["det[0].bb"]


def test_summary_does_not_repeat_the_path():
    """요약 문구가 `path: message` 인데 message 가 이미 필드 이름으로 시작해 `rect: rect: …` 로 찍혔다."""
    with pytest.raises(NexusValidationError) as ei:
        Detection(rect=[0.1, 0.2])
    assert str(ei.value) == "rect: 숫자 4개 필요, 2개 받음"
    assert ei.value.errors[0].message == "rect: 숫자 4개 필요, 2개 받음"  # 위반 하나의 message 는 그대로(서버와 같은 값)

    inst = Instance(id="a", label="car", components={"bb": Detection({"type": "bounding_box", "rect": [0.1]})})
    with pytest.raises(NexusValidationError) as ei:
        LabelGroup([inst]).validate("det")
    assert str(ei.value) == "det[0].bb.rect: 숫자 4개 필요, 1개 받음"


def test_summary_keeps_message_when_it_does_not_start_with_the_path():
    from nexus._types import raise_for_issues
    with pytest.raises(NexusValidationError) as ei:
        raise_for_issues([Issue("det", "duplicate_id", "id 'a' 가 둘"), Issue("", "x", "경로 없음")])
    assert str(ei.value) == "det: id 'a' 가 둘; 경로 없음"
