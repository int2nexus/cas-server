import re

import pytest

import nexus as nx
from nexus import Instance
from nexus._types import NexusValidationError


def test_키워드_생성은_그_자리에서_검증한다():
    with pytest.raises(NexusValidationError) as e:
        nx.Detection(rect=[0.1, 0.2])
    assert e.value.errors[0].reason == "field_length"


def test_dict_생성은_검증하지_않는다():
    d = nx.Detection({"type": "bounding_box", "rect": [1]})
    assert d.rect == [1]


def test_리스트_components_의_키는_type_값():
    inst = Instance("p", [nx.Detection(rect=[0, 0, 1, 1]), nx.ScalarValue(value=1.0)])
    assert set(inst.components) == {"bounding_box", "value"}


def test_같은_type_둘이면_거부():
    with pytest.raises(NexusValidationError) as e:
        Instance("p", [nx.Detection(rect=[0, 0, 1, 1]), nx.Detection(rect=[0, 0, 1, 1])])
    assert e.value.errors[0].reason == "duplicate_component_type"


def test_id_생략은_uuid4():
    assert re.fullmatch(r"[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}",
                        Instance("p").id)
    assert Instance("p").components == {}


def test_위치_인자_id_는_더_이상_받지_않는다():
    with pytest.raises(TypeError):
        Instance("x", "lbl", {})
    with pytest.raises(NexusValidationError) as e:
        Instance("x", "lbl")
    assert (e.value.errors[0].path, e.value.errors[0].reason) == ("components", "invalid_type")


def test_비_Label_원소는_invalid_type():
    with pytest.raises(NexusValidationError) as e:
        Instance("p", [{"type": "bounding_box"}])
    assert e.value.errors[0].reason == "invalid_type"


def test_tuple_components_도_받는다():
    inst = Instance("p", (nx.Detection(rect=[0, 0, 1, 1]),))
    assert set(inst.components) == {"bounding_box"}
