"""배치 item 의 `annotation_invalid` 를 `NexusValidationError` 로 드러내고, 저장된 틀린 annotation 을 찾는다."""
from unittest.mock import MagicMock

import pytest

from nexus import NexusError
from nexus._types import NexusBatchError, NexusValidationError
from nexus.annotated import AnnotatedSample
from nexus.cas import CasClient
from nexus.client import NexusClient
from nexus.dataset import Dataset
from nexus.sample import CasRef, Sample

from tests.test_dataset import _ds

META = {"format_version": "1.0.0", "filename": "http://cas/kitti/images/a.png", "width": 4, "height": 4}
GOOD = {"id": "c", "label": "car", "bounding_box": {"type": "bounding_box", "rect": [0.1, 0.2, 0.3, 0.4]}}
BAD_TYPE = {"id": "a", "label": "car", "bounding_box": {"type": "detection", "rect": [0.1, 0.2, 0.3, 0.4]}}
BAD_RECT = {"id": "b", "label": "car", "bounding_box": {"type": "bounding_box", "rect": [0.1, 0.2]}}
REF = CasRef("kitti", "images/a.png", hash_hex="h", size=10, content_type="image/png")


def _sample():
    return Sample(image=REF, annotation=AnnotatedSample.from_dict({"meta": META}, {}))


def test_flush_는_item_errors_를_검증_오류로_올린다():
    errors = [{"path": "boxes[0].bounding_box", "reason": "unknown_type", "message": "모르는 type"},
              {"path": "boxes[1].bounding_box.rect", "reason": "field_length", "message": "길이 4"}]
    client = MagicMock()
    client._ingest_batch.return_value = {"results": [
        {"index": 0, "error": "annotation 이 올바르지 않습니다", "status": 400,
         "code": "annotation_invalid", "errors": errors},
        {"index": 1, "error": "database error", "status": 500},
        {"index": 2, "sample_id": "s2", "dataset_id": "d1"},
    ]}
    ds = _ds(client, MagicMock())
    ds.add([_sample(), _sample(), _sample()])
    bad, other, ok = ds.flush(workers=1, verbose=False)
    assert ok.ok and ok.exception is None
    assert isinstance(bad.exception, NexusValidationError) and bad.status_code == 400
    assert [(i.path, i.reason) for i in bad.exception.errors] == [
        ("boxes[0].bounding_box", "unknown_type"), ("boxes[1].bounding_box.rect", "field_length")]
    assert "100건" not in str(bad.exception)
    # code 없는 실패는 종전 그대로 — 문자열만.
    assert not other.ok and other.exception is None and other.error == "database error"

    ds.add([_sample(), _sample(), _sample()])
    with pytest.raises(NexusBatchError) as ei:
        ds.flush(workers=1, verbose=False, strict=True)
    assert len(ei.value.failures) == 2
    assert isinstance(ei.value.failures[0].exception, NexusValidationError)


def test_flush_는_위반이_100건이면_잘렸을_수_있다고_적는다():
    errors = [{"path": f"boxes[{i}]", "reason": "common_field", "message": "m"} for i in range(100)]
    client = MagicMock()
    client._ingest_batch.return_value = {"results": [
        {"index": 0, "error": "bad", "status": 400, "code": "annotation_invalid", "errors": errors}]}
    ds = _ds(client, MagicMock())
    ds.add(_sample())
    (r,) = ds.flush(workers=1, verbose=False)
    assert len(r.exception.errors) == 100 and "더 있을 수 있습니다" in str(r.exception)


def test_flush_사전_검사_실패도_같은_모양이다():
    client = MagicMock()
    ds = _ds(client, MagicMock())
    ds._stored_group_kinds = ds._group_kinds = {"boxes": "group"}
    ann = AnnotatedSample._from_server({"meta": META, "boxes": [BAD_RECT]}, {"boxes": "group"})
    ds.add(Sample(image=REF, annotation=ann))
    (r,) = ds.flush(workers=1, verbose=False)
    assert not r.ok and isinstance(r.exception, NexusValidationError)
    assert [(i.path, i.reason) for i in r.exception.errors] == [("boxes[0].bounding_box.rect", "field_length")]
    client._ingest_batch.assert_not_called()


_NEXUS = "http://nexus.test"
VER = f"{_NEXUS}/datasets/d1/versions/v1"
EXPLORER = f"{VER}/samples/explorer"


@pytest.fixture
def ds(requests_mock):
    requests_mock.post(f"{_NEXUS}/api/v1/auth/login", json={"token": "t", "user_id": 1, "email": "u@x.com"})
    d = Dataset(NexusClient(_NEXUS, "u@x.com", "pass", retry_timeout=0), CasClient("http://cas"), "d1", "kitti", "v1")
    d._stored_group_kinds = d._group_kinds = {"boxes": "group"}
    return d


def _row(sid, boxes):
    return {"sample_id": sid, "meta": META, "tags": [], "split": None, "boxes": boxes}


def test_find_invalid_는_경로와_사유를_돌려준다(ds, requests_mock):
    requests_mock.get(VER, json={"version": "v1", "status": "sealed"})
    requests_mock.post(EXPLORER, json=[
        _row("s3", [GOOD]),
        _row("s2", [GOOD, BAD_RECT]),
        _row("s1", [BAD_TYPE]),
    ])
    assert ds.find_invalid_annotations() == [
        ("s2", "boxes[1].bounding_box.rect", "field_length"),
        ("s1", "boxes[0].bounding_box", "unknown_type"),
    ]


def test_find_invalid_는_draft_bulk_read_403_을_올린다(ds, requests_mock):
    requests_mock.get(VER, json={"version": "v1", "status": "draft"})
    requests_mock.get(f"{VER}/manifest", json={"annotation_snapshot": None})
    requests_mock.post(EXPLORER, status_code=403, json={"error": "x", "code": "draft_bulk_read_disabled"})
    with pytest.raises(NexusError) as ei:
        ds.find_invalid_annotations()
    assert ei.value.status_code == 403 and ei.value.code == "draft_bulk_read_disabled"


def test_find_invalid_는_못_읽은_종류를_다시_읽어_container_위반을_찾는다(ds, requests_mock):
    requests_mock.get(VER, json={"version": "v1", "status": "sealed"})
    two = {"id": "t", "label": "car",
           "bounding_box": {"type": "bounding_box", "rect": [0.1, 0.2, 0.3, 0.4]},
           "polygon": {"type": "polygon", "points": [0, 0, 1, 0, 1, 1]}}
    requests_mock.post(EXPLORER, json=[_row("s1", [two])])
    ds._stored_group_kinds = ds._group_kinds = {}
    ds._group_kinds_unread = True
    ds._read_group_kinds = lambda: {"boxes": "container"}
    out = ds.find_invalid_annotations()
    assert out and out[0][0] == "s1" and out[0][1].startswith("boxes[0]")

    ds._stored_group_kinds = ds._group_kinds = {}
    ds._group_kinds_unread = True
    def boom():
        raise NexusError("읽기 실패")
    ds._read_group_kinds = boom
    with pytest.raises(NexusError):
        ds.find_invalid_annotations()


def test_find_invalid_는_filters_를_iter_samples_로_넘긴다(ds):
    with pytest.raises(TypeError):
        ds.find_invalid_annotations(no_such_filter=1)
