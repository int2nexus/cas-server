import pytest
from pathlib import Path
from nexus.annotated import AnnotatedSample
from nexus.sample import CasRef, Sample, _parse_ref


def test_parse_local_path_string():
    ref = _parse_ref("data/img.png")
    assert isinstance(ref, Path)
    assert ref == Path("data/img.png")


def test_parse_local_path_object():
    ref = _parse_ref(Path("data/img.png"))
    assert isinstance(ref, Path)


def test_parse_s3_url():
    ref = _parse_ref("s3://my-bucket/images/img.png")
    assert isinstance(ref, CasRef)
    assert ref.bucket == "my-bucket"
    assert ref.key == "images/img.png"


def test_parse_s3_nested_key():
    ref = _parse_ref("s3://bucket/a/b/c/file.json")
    assert ref.bucket == "bucket"
    assert ref.key == "a/b/c/file.json"


def test_sample_rejects_local_path_image():
    with pytest.raises(ValueError, match="nx.upload"):
        Sample(image="img.png")


def test_sample_rejects_local_path_in_assets():
    with pytest.raises(ValueError, match="nx.upload"):
        Sample(image="s3://b/img.png", assets={"depth": "depth.png"})


def test_sample_annotation_takes_only_annotated_sample():
    # annotation 은 AnnotatedSample 만 — 경로·URL·dict 는 from_file·from_dict 로 바꿔 넘긴다.
    for bad in ("ann.json", "s3://b/ann.json", Path("ann.json"), {"meta": {}}):
        with pytest.raises(TypeError, match="from_dict"):
            Sample(image="s3://b/img.png", annotation=bad)
    ann = AnnotatedSample.from_dict({"meta": {}}, {})
    s = Sample(image="s3://b/img.png", annotation=ann)
    assert isinstance(s._image_ref, CasRef)
    assert s._annotation_ref is ann
    assert s._asset_refs == {}


def test_sample_s3_refs():
    s = Sample(image="s3://b/img.png")
    assert isinstance(s._image_ref, CasRef)
    assert s._annotation_ref is None


def test_sample_assets_multiple_roles():
    s = Sample(
        image="s3://b/img.png",
        assets={"depth": "s3://b/depth.png", "thermal": "s3://b/th.png"},
    )
    assert set(s._asset_refs.keys()) == {"depth", "thermal"}
    assert s._asset_refs["depth"].bucket == "b"
    assert s._asset_refs["depth"].key == "depth.png"
    assert s._asset_refs["thermal"].key == "th.png"


def test_sample_assets_reserved_image_key_raises():
    with pytest.raises(ValueError, match="'image'"):
        Sample(image="s3://b/img.png", assets={"image": "s3://b/other.png"})


def test_sample_split_and_tags():
    s = Sample(image="s3://b/img.png", split="train", tags=["highway", "night"])
    assert s.split == "train"
    assert s.tags == ["highway", "night"]


def test_sample_coerces_str_tag_to_list():
    # tags="x" 문자열을 넘기면 ["x"]로 자동 변환.
    s = Sample(image="s3://b/img.png", tags="rainy")
    assert s.tags == ["rainy"]


def test_parse_http_url():
    ref = _parse_ref("http://192.168.50.78:8080/lg-incabin/img/file.bmp")
    assert isinstance(ref, CasRef)
    assert ref.bucket == "lg-incabin"
    assert ref.key == "img/file.bmp"


def test_parse_https_url():
    ref = _parse_ref("https://cas.example.com/mybucket/path/to/img.png")
    assert isinstance(ref, CasRef)
    assert ref.bucket == "mybucket"
    assert ref.key == "path/to/img.png"


def test_sample_http_url_sets_cas_ref():
    s = Sample(image="http://192.168.50.78:8080/lg-incabin/img/file.bmp")
    assert isinstance(s._image_ref, CasRef)
    assert s._image_ref.bucket == "lg-incabin"
    assert s._image_ref.key == "img/file.bmp"


def test_sample_annotation_only_sets_none_image_ref():
    ann = AnnotatedSample.from_dict({"meta": {"filename": "http://cas/b/img.png"}}, {})
    s = Sample(annotation=ann)
    assert s._image_ref is None
    assert s._annotation_ref is ann


def test_sample_no_image_no_annotation_raises():
    with pytest.raises(ValueError, match="image.*annotation"):
        Sample()


def test_parse_http_url_decodes_percent_encoding():
    # 브라우저에서 복사한 URL 처럼 key 가 인코딩돼 있으면 풀어서 원래 key 로 쓴다 — 안 풀면
    # CAS 서명이 한 번 더 인코딩해(%20 → %2520) 엉뚱한 객체를 찾는다. 서버가 key 에 '%' 를
    # 금지하므로 경로의 %XX 는 항상 인코딩이라 풀어도 모호하지 않다.
    ref = _parse_ref("http://cas:8080/b/space%20dir/%ED%95%9C%EA%B8%80%20a%2Bb.png")
    assert (ref.bucket, ref.key) == ("b", "space dir/한글 a+b.png")


def test_parse_http_url_raw_key_unchanged():
    ref = _parse_ref("http://cas:8080/b/space dir/한글 a+b.png")
    assert (ref.bucket, ref.key) == ("b", "space dir/한글 a+b.png")


def test_parse_s3_url_decodes_percent_encoding():
    ref = _parse_ref("s3://b/a%20b.png")
    assert (ref.bucket, ref.key) == ("b", "a b.png")


# ── URL 의 '#' '?' ';' 는 key 의 일부다 (0.1.18) ─────────────────────────────────
# urlparse 는 '#' 뒤를 fragment, '?' 뒤를 query 로 떼어내 key 를 잘랐다. CAS 는 이 문자가 든
# key 를 허용하므로 실제로 그런 객체가 있다 — URL 을 직접 나눠 전부 key 로 남긴다.

def test_parse_http_url_keeps_hash_in_key():
    ref = _parse_ref(
        "https://cas.example.com/archive/[INF]_SBD0.8.12#1_step_20260608/"
        "ICMU_VEH_40145_SB04_Seq1_20241126_141942_982000_159_abfe0cd59232.png"
    )
    assert ref.bucket == "archive"
    assert ref.key == (
        "[INF]_SBD0.8.12#1_step_20260608/"
        "ICMU_VEH_40145_SB04_Seq1_20241126_141942_982000_159_abfe0cd59232.png"
    )


def test_parse_http_url_keeps_query_and_semicolon_in_key():
    ref = _parse_ref("http://cas:8080/b/a?b;c#d.png")
    assert (ref.bucket, ref.key) == ("b", "a?b;c#d.png")


def test_parse_http_url_encoded_hash_decodes_to_same_key():
    ref = _parse_ref("http://cas:8080/b/x%231%3Fy.png")
    assert (ref.bucket, ref.key) == ("b", "x#1?y.png")


def test_sample_http_url_with_hash_sets_full_key():
    s = Sample(image="http://cas:8080/archive/dir#1/img.png")
    assert (s._image_ref.bucket, s._image_ref.key) == ("archive", "dir#1/img.png")


def test_parse_http_url_tolerates_double_slash_after_host():
    # f"{CAS_URL}/{bucket}/{key}" 에 CAS_URL 이 '/' 로 끝나면 이 모양이 된다 — 0.1.17 은 읽었다.
    ref = _parse_ref("http://cas:8080//b/k#1.png")
    assert (ref.bucket, ref.key) == ("b", "k#1.png")
