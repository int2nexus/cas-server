import pytest
from nexus._types import NexusValidationError
from nexus.group import LabelGroup, RawGroup
from nexus.instance import Instance


def test_labelgroup_roundtrip():
    rows = [{"id": "a", "label": "car", "bounding_box": {"type": "bounding_box", "rect": [0, 0, 1, 1]}}]
    g = LabelGroup.from_list(rows)
    assert len(g) == 1
    assert isinstance(g[0], Instance)
    assert g.to_list() == rows


def test_labelgroup_add_remove():
    g = LabelGroup([])
    inst = Instance(id="x", label="a", components={})
    g.add(inst)
    assert len(g) == 1
    g.remove("x")
    assert len(g) == 0


def test_rawgroup_verbatim_even_when_not_a_list():
    weird = {"unexpected": "shape"}
    rg = RawGroup(weird)
    assert rg.to_raw() == weird
    # 읽고 되쓰는 것(왕복)은 그대로이지만, 보낼 때는 서버가 거절할 모양이라 검증이 거른다.
    with pytest.raises(NexusValidationError) as ei:
        rg.validate()
    assert [(i.path, i.reason) for i in ei.value.errors] == [("", "common_field")]
    rows = [{"anything": 1}]
    assert RawGroup(rows).to_raw() == rows


def _row(t="bounding_box", id_="a"):
    return {"id": id_, "label": "car", t: {"type": t, "rect": [0, 0, 1, 1]}}


def test_container_roundtrip_and_labels_accessor():
    from nexus.group import LabelContainer
    rows = [_row(id_="a"), _row(id_="b")]   # 그룹 안 id 는 유일해야 한다(GT spec 4 장)
    c = LabelContainer.from_list(rows)
    c.validate()
    assert c.element_type == "bounding_box"
    assert len(c.labels) == 2
    assert c.to_list() == rows


def test_container_rejects_multi_component_row():
    from nexus.group import LabelContainer
    from nexus._types import NexusValidationError
    row = {"id": "a", "label": "car",
           "bounding_box": {"type": "bounding_box", "rect": [0, 0, 1, 1]},
           "extra": {"type": "classification", "label": "x"}}
    with pytest.raises(NexusValidationError):
        LabelContainer.from_list([row]).validate()


def test_container_rejects_mixed_types():
    from nexus.group import LabelContainer
    from nexus._types import NexusValidationError
    with pytest.raises(NexusValidationError):
        LabelContainer.from_list([_row("bounding_box"), _row("classification")]).validate()


def test_non_instance_row_is_common_field_at_row_path():
    # 서버가 원소 수준 공통 필드 위반에 쓰는 사유·경로(common_field, g[i])와 같다.
    from nexus.labels import Detection
    issues = LabelGroup([Detection(rect=[0, 0, 1, 1])]).issues("g")
    assert [(i.path, i.reason) for i in issues] == [("g[0]", "common_field")]


def test_container_with_non_label_component_collects_issues():
    # Label 이 아닌 component 는 행 규칙이 invalid_type 으로 내고, 그룹 규칙은 AttributeError 로 죽지 않는다.
    from nexus.group import LabelContainer
    from nexus.labels import Detection
    a = Instance(id="a", label="car", components={"bounding_box": Detection(rect=[0, 0, 1, 1])})
    b = Instance(id="b", label="car", components={"bounding_box": Detection(rect=[0, 0, 1, 1])})
    b.components["bounding_box"] = {"type": "bounding_box", "rect": [0, 0, 1, 1]}
    c = LabelContainer([a, b])
    assert [(i.path, i.reason) for i in c.issues("c")] == [("c[1].bounding_box", "invalid_type")]
    assert LabelContainer([b]).element_type is None


def test_remove_with_instance_object_says_to_pass_id():
    """0.1.30 의 `remove(inst)` 처럼 객체를 넘기면 무엇을 고칠지 알려 주는 `TypeError` 다(0.1.31 — id 를 받는다)."""
    g = LabelGroup([Instance(id="x", label="a", components={})])
    with pytest.raises(TypeError, match=r"remove\(inst\.id\)"):
        g.remove(g[0])
    assert len(g) == 1
