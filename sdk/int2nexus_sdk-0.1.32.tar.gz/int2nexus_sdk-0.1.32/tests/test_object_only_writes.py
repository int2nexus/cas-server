"""annotation 쓰기는 객체로만(설계 6-1·6-7): dict 쓰기 경로가 공개 API 에서 빠지고, 적재는 `AnnotatedSample` 만 받으며,
읽는 경로는 검사하지 않는다."""
import json
from pathlib import Path
from unittest.mock import MagicMock

import pytest

import nexus as nx
from nexus.annotated import AnnotatedSample
from nexus.client import NexusClient
from nexus.dataset import Dataset
from nexus.sample import CasRef, Sample
from nexus._types import NexusValidationError

from tests.test_dataset import _batch_ok, _ds

# 고객 실측 두 사례(제안서 §1) — 모르는 타입 `detection` 과 숫자 2 개짜리 `rect`.
DETECTION_TYPE = {"id": "a", "label": "car",
                  "bounding_box": {"type": "detection", "rect": [0.1, 0.2, 0.3, 0.4]}}
RECT_TWO = {"id": "b", "label": "car",
            "bounding_box": {"type": "bounding_box", "rect": [0.1, 0.2]}}
GOOD = {"id": "c", "label": "car",
        "bounding_box": {"type": "bounding_box", "rect": [0.1, 0.2, 0.3, 0.4]}}
META = {"format_version": "1.0.0", "filename": "http://cas/kitti/images/a.png", "width": 4, "height": 4}


def _paths(e: NexusValidationError) -> "list[tuple[str, str]]":
    return [(i.path, i.reason) for i in e.errors]


def test_sample_은_dict_annotation_을_받지_않는다():
    ref = CasRef("kitti", "images/a.png", hash_hex="h", size=10, content_type="image/png")
    for bad in ({"meta": META}, "ann.json", "s3://b/ann.json", Path("ann.json")):
        with pytest.raises(TypeError) as ei:
            Sample(image=ref, annotation=bad)
        assert "AnnotatedSample.from_dict" in str(ei.value) and "from_file" in str(ei.value)
    ok = Sample(image=ref, annotation=AnnotatedSample.from_dict({"meta": META}, {}))
    assert isinstance(ok.annotation, AnnotatedSample)
    # 만든 뒤 dict 를 대입해도 보낼 때(준비 단계) 같은 규칙으로 막힌다 — 그 샘플만 실패하고 아무것도 보내지 않는다.
    ok.annotation = {"meta": META}
    client = MagicMock()
    ds = _ds(client, MagicMock())
    ds.add(ok)
    (r,) = ds.flush(workers=1, verbose=False)
    assert not r.ok and "AnnotatedSample.from_dict" in r.error
    client._ingest_batch.assert_not_called()


@pytest.mark.parametrize("kinds", [{"boxes": "group"}, {}], ids=["선언된_그룹", "선언_없는_그룹"])
def test_from_dict_는_검증한다(kinds, tmp_path):
    with pytest.raises(NexusValidationError) as ei:
        AnnotatedSample.from_dict({"meta": META, "boxes": [DETECTION_TYPE]}, kinds)
    assert _paths(ei.value) == [("boxes[0].bounding_box", "unknown_type")]

    with pytest.raises(NexusValidationError) as ei:
        AnnotatedSample.from_dict({"meta": META, "boxes": [RECT_TWO]}, kinds)
    assert _paths(ei.value) == [("boxes[0].bounding_box.rect", "field_length")]

    # 위반은 첫 하나에서 멈추지 않고 전부 모은다(그룹을 가로질러서도).
    with pytest.raises(NexusValidationError) as ei:
        AnnotatedSample.from_dict({"boxes": [DETECTION_TYPE, GOOD, RECT_TWO], "more": [RECT_TWO]}, kinds)
    assert _paths(ei.value) == [
        ("boxes[0].bounding_box", "unknown_type"),
        ("boxes[2].bounding_box.rect", "field_length"),
        ("more[0].bounding_box.rect", "field_length"),
    ]

    # 파일 입구도 같은 검사다.
    p = tmp_path / "ann.json"
    p.write_text(json.dumps({"boxes": [DETECTION_TYPE]}), encoding="utf-8")
    with pytest.raises(NexusValidationError) as ei:
        AnnotatedSample.from_file(p, kinds)
    assert _paths(ei.value) == [("boxes[0].bounding_box", "unknown_type")]
    p.write_text(json.dumps({"meta": META, "boxes": [GOOD]}), encoding="utf-8")
    assert AnnotatedSample.from_file(str(p), kinds).to_dict()["boxes"] == [GOOD]
    p.write_text("[1, 2]", encoding="utf-8")
    with pytest.raises(NexusValidationError):
        AnnotatedSample.from_file(p, kinds)
    with pytest.raises(TypeError):
        AnnotatedSample.from_dict([GOOD], kinds)


def test_load_sample_은_틀린_저장값도_연다():
    stored = {"meta": META, "boxes": [DETECTION_TYPE, RECT_TWO], "other": [GOOD]}
    client = MagicMock()
    client._no_partial_annotations = False
    client.get_sample.return_value = {**stored, "sample_id": "s1", "split": None, "tags": [],
                                      "created_at": "2026-11-01T00:00:00Z"}
    ds = Dataset(client, MagicMock(), "d1", "kitti", "v1")
    ds._stored_group_kinds = ds._group_kinds = {"boxes": "group", "other": "group"}

    s = ds.load_sample("s1")
    assert s["boxes"][0].get_component("bounding_box").type == "detection"
    assert s.to_dict()["boxes"] == [DETECTION_TYPE, RECT_TWO]
    with pytest.raises(NexusValidationError):
        s.validate()   # 고쳐 보내려면 걸린다 — 읽기만 검사하지 않는다

    # 틀린 그룹을 건드리지 않은 저장은 그 그룹을 보내지 않으므로 막히지 않는다.
    client._merge_sample_annotations.return_value = {"instances": 1, "skipped": 0}
    s["other"][0].label = "truck"
    s.save()
    sent = client._merge_sample_annotations.call_args[0][3]
    assert set(sent) == {"other"}


def test_삭제된_메서드는_없다():
    ds = _ds(MagicMock(), MagicMock())
    assert hasattr(ds, "save_annotation") is False
    assert hasattr(ds, "merge_annotation") is False
    assert hasattr(ds, "patch_annotations") is False
    # merge 의 dict 입력도 없다.
    s = AnnotatedSample.from_dict({"boxes": [GOOD]}, {"boxes": "group"})
    with pytest.raises(TypeError, match="from_dict"):
        s.merge({"boxes": [GOOD]})


def test_client_의_dict_쓰기는_공개가_아니다():
    for name in ("ingest", "ingest_batch", "patch_annotations", "merge_sample_annotations"):
        assert not hasattr(NexusClient, name), name
        assert callable(getattr(NexusClient, f"_{name}")), name
    # 공개 패키지에도 그런 함수가 새로 생기지 않았다.
    assert not any(n in nx.__all__ for n in ("save_annotation", "patch_annotations", "merge_annotation"))


def test_flush_는_객체를_보낸다():
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    client = MagicMock(); client._ingest_batch.return_value = _batch_ok(1)
    ds = _ds(client, mock_cas)
    ds._stored_group_kinds = ds._group_kinds = {"boxes": "group"}
    ref = CasRef("kitti", "images/a.png", hash_hex="h", size=10, content_type="image/png")
    ann = AnnotatedSample.from_dict({"meta": META}, {"boxes": "group"})
    ann["boxes"] = nx.LabelGroup([nx.Instance("car", [nx.Detection(rect=[0.1, 0.2, 0.3, 0.4])], id="c")])
    ds.add(Sample(image=ref, annotation=ann))
    (r,) = ds.flush(workers=1, verbose=False)
    assert r.ok
    payload = client._ingest_batch.call_args[0][0][0]
    assert payload["annotation"]["annotation_data"] == ann.to_dict()
    assert payload["annotation"]["annotation_data"]["boxes"][0]["bounding_box"]["rect"] == [0.1, 0.2, 0.3, 0.4]


def test_flush_는_핸들_종류로_다시_검사한다():
    # 만들 때 종류 없이(RawGroup 규칙으로) 통과한 annotation 도 핸들이 그 그룹을 container 로 선언했으면 container 규칙
    # (행마다 component 하나)으로 다시 본다 — 핸들 값이 이긴다(설계 6-7). 위반이면 그 샘플은 보내지 않는다.
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    client = MagicMock(); client._ingest_batch.return_value = _batch_ok(1)
    ds = _ds(client, mock_cas)
    ds._stored_group_kinds = ds._group_kinds = {"boxes": "container"}
    two = {"id": "t", "label": "car",
           "bounding_box": {"type": "bounding_box", "rect": [0.1, 0.2, 0.3, 0.4]},
           "polygon": {"type": "polygon", "points": [0, 0, 1, 0, 1, 1]}}
    ann = AnnotatedSample.from_dict({"meta": META, "boxes": [two]}, {})
    ref = CasRef("kitti", "images/a.png", hash_hex="h", size=10, content_type="image/png")
    good = AnnotatedSample.from_dict({"meta": META, "boxes": [GOOD]}, {})
    ds.add([Sample(image=ref, annotation=ann), Sample(image=ref, annotation=good)])
    bad_r, ok_r = ds.flush(workers=1, verbose=False)
    assert not bad_r.ok and "boxes[0]" in bad_r.error
    assert ok_r.ok
    (sent,) = client._ingest_batch.call_args[0][0]
    assert sent["annotation"]["annotation_data"]["boxes"] == [GOOD]

    # 반대로 만들 때 선언한 종류가 핸들에 없으면 핸들 기준(선언 없는 그룹 규칙)으로 본다.
    client._ingest_batch.reset_mock(); client._ingest_batch.return_value = _batch_ok(1)
    ds._stored_group_kinds = ds._group_kinds = {}
    built_as_container = AnnotatedSample.from_dict({"meta": META, "boxes": [GOOD]}, {"boxes": "container"})
    ds.add(Sample(image=ref, annotation=built_as_container))
    (r,) = ds.flush(workers=1, verbose=False)
    assert r.ok


BAD_SHAPES = [
    ([None], [("det[0]", "common_field")]),
    ([5], [("det[0]", "common_field")]),
    ([GOOD, "x"], [("det[1]", "common_field")]),
    ("not-an-array", [("det", "common_field")]),
    ({"id": "a"}, [("det", "common_field")]),
]


@pytest.mark.parametrize("kind", ["group", "container"])
@pytest.mark.parametrize("value,expect", BAD_SHAPES, ids=["None", "숫자", "섞임", "문자열", "객체"])
def test_객체가_아닌_원소와_배열이_아닌_그룹은_검증_오류다(kind, value, expect):
    kinds = {"det": kind}
    # 쓰기 입구 — AttributeError 가 아니라 서버와 같은 경로·사유의 NexusValidationError.
    with pytest.raises(NexusValidationError) as ei:
        AnnotatedSample.from_dict({"meta": META, "det": value}, kinds)
    assert _paths(ei.value) == expect

    # 읽기 경로는 예외 없이 연다(그 그룹은 RawGroup 으로 남는다).
    s = AnnotatedSample._from_server({"meta": META, "det": value}, kinds)
    assert s.to_dict()["det"] == value

    # flush 사전 검사 — 만들 때 종류 없이 통과할 수 없는 값이므로 로드 객체를 적재에 넘겨 본다.
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    client = MagicMock()
    ds = _ds(client, mock_cas)
    ds._stored_group_kinds = ds._group_kinds = kinds
    ref = CasRef("kitti", "images/a.png", hash_hex="h", size=10, content_type="image/png")
    ds.add(Sample(image=ref, annotation=s))
    (r,) = ds.flush(workers=1, verbose=False)
    assert not r.ok and expect[0][0] in r.error
    client._ingest_batch.assert_not_called()
