"""그룹 편집 API(설계 6-3) — add·remove·replace 만 편집하고, 대입은 선언된 종류의 그룹 객체만 받아 검사한다."""
import copy

import pytest

from nexus.annotated import AnnotatedSample
from nexus.group import LabelContainer, LabelGroup, RawGroup
from nexus.instance import Instance
from nexus.labels import Detection, Polygon
from nexus.meta import Meta
from nexus._types import NexusValidationError

KINDS = {"boxes": "group", "dets": "container"}


def _box(id_, label="car"):
    return Instance(label, [Detection(rect=[0, 0, 1, 1])], id=id_)


def _bad_box(id_):
    # dict 로 만든 component 는 생성 때 검사하지 않는다 — rect 숫자 2 개는 행 규칙 위반이다.
    return Instance("car", {"bounding_box": Detection.from_dict({"type": "bounding_box", "rect": [0, 0]})},
                    id=id_)


class _FakeDataset:
    def __init__(self):
        self.merged = []
        self._group_kinds = dict(KINDS)

    def _merge_annotation(self, sample_id, patch):
        self.merged.append((sample_id, copy.deepcopy(patch)))
        return {"instances": 0, "skipped": 0, "skipped_reasons": {}}

    def _partial_annotations_unsupported(self):
        return False


def _sample(ds=None, extra=None):
    ann = {
        "boxes": [{"id": "a", "label": "car", "bounding_box": {"type": "bounding_box", "rect": [0, 0, 1, 1]}}],
        "dets": [{"id": "d", "label": "car", "bounding_box": {"type": "bounding_box", "rect": [0, 0, 1, 1]}}],
        "free": [{"id": "r", "label": "x", "whatever": 1}],
        "meta": {"w": 1},
    }
    ann.update(extra or {})
    return AnnotatedSample._from_server(ann, KINDS, sample_id="s1", dataset=ds)


def test_add_는_넣기_전에_검사한다():
    g = _sample()["boxes"]
    before = g.instances
    with pytest.raises(NexusValidationError) as e:
        g.add(_bad_box("b"))
    assert g.instances == before
    assert [i.path for i in e.value.errors] == ["boxes[1].bounding_box.rect"]
    g.add(_box("b"))
    assert [i.id for i in g] == ["a", "b"]


def test_add_는_id_중복을_거부():
    g = _sample()["boxes"]
    with pytest.raises(NexusValidationError) as e:
        g.add(_box("a"))
    assert [i.reason for i in e.value.errors] == ["duplicate_id"]
    assert len(g) == 1


def test_add_는_Instance_만_받는다():
    g = _sample()["boxes"]
    with pytest.raises(TypeError):
        g.add(Detection(rect=[0, 0, 1, 1]))
    assert len(g) == 1


def test_remove_는_id_를_받는다():
    g = _sample()["boxes"]
    g.add(_box("b"))
    g.remove("a")
    assert [i.id for i in g] == ["b"]
    with pytest.raises(KeyError):
        g.remove("a")
    with pytest.raises(TypeError, match=r"remove\(inst\.id\)"):
        g.remove(_box("b"))   # 객체가 아니라 id 를 받는다 — 옛 호출에는 고칠 방법을 알려 준다


def test_replace_는_전부_검사_뒤_교체():
    g = _sample()["boxes"]
    before = g.instances
    with pytest.raises(NexusValidationError) as e:
        g.replace([_box("x"), _bad_box("y"), _box("x")])
    assert g.instances == before
    assert [(i.path, i.reason) for i in e.value.errors] == [
        ("boxes[1].bounding_box.rect", "field_length"), ("boxes[2].id", "duplicate_id")]
    g.replace([_box("x"), _box("y")])
    assert [i.id for i in g] == ["x", "y"]
    g.replace([])
    assert len(g) == 0


def test_instances_는_대입할_수_없다():
    g = _sample()["boxes"]
    assert isinstance(g.instances, tuple)
    with pytest.raises(TypeError):
        g.instances[0] = _box("z")
    with pytest.raises(AttributeError):
        g.instances.append(_box("z"))
    with pytest.raises(AttributeError):
        g.instances = [_box("z")]
    assert [i.id for i in g] == ["a"]


def test_container_에_component_둘은_add_에서_거부():
    g = _sample()["dets"]
    two = Instance("car", [Detection(rect=[0, 0, 1, 1]), Polygon(points=[0, 0, 1, 0, 1, 1])], id="t")
    with pytest.raises(NexusValidationError) as e:
        g.add(two)
    assert [i.reason for i in e.value.errors] == ["container_component_count"]
    poly = Instance("car", [Polygon(points=[0, 0, 1, 0, 1, 1])], id="p")
    with pytest.raises(NexusValidationError) as e:
        g.add(poly)
    assert [i.reason for i in e.value.errors] == ["container_mixed_types"]
    assert [i.id for i in g] == ["d"]


def test_dict_대입은_TypeError():
    s = _sample()
    with pytest.raises(TypeError):
        s["boxes"] = [{"id": "z", "label": "car"}]
    with pytest.raises(TypeError):
        s["boxes"] = {"id": "z"}
    with pytest.raises(TypeError):
        s["meta"] = {"w": 2}
    with pytest.raises(TypeError):
        s["free"] = RawGroup([])
    with pytest.raises(TypeError):
        s.set_field("boxes", Meta({}))
    assert [i.id for i in s["boxes"]] == ["a"]


def test_대입은_그룹_규칙으로_검사한다():
    s = _sample()
    before = s["boxes"]
    with pytest.raises(NexusValidationError):
        s["boxes"] = LabelGroup([_box("x"), _box("x")])
    with pytest.raises(NexusValidationError):
        s["boxes"] = LabelContainer([_box("x")])   # 선언 종류와 클래스가 다르다
    assert s["boxes"] is before
    s["boxes"] = LabelGroup([_box("x")])
    assert [i.id for i in s["boxes"]] == ["x"]


def test_선언_없는_이름에_새_그룹은_거부():
    s = _sample()
    with pytest.raises(NexusValidationError, match="declare_group_kinds"):
        s["brand_new"] = LabelGroup([_box("x")])
    with pytest.raises(NexusValidationError):
        s.set_field("free", LabelGroup([_box("x")]))   # 서버에서 RawGroup 으로 읽힌 이름
    assert "brand_new" not in s.groups
    assert isinstance(s["free"], RawGroup)


def test_핸들에_나중에_선언한_종류도_듣는다():
    ds = _FakeDataset()
    s = _sample(ds)
    ds._group_kinds["brand_new"] = "group"
    s["brand_new"] = LabelGroup([_box("x")])
    assert [i.id for i in s["brand_new"]] == ["x"]


def test_add_labels_는_선언_없는_그룹을_만들지_않는다():
    s = _sample()
    with pytest.raises(NexusValidationError):
        s.add_labels({"boxes": _box("b"), "brand_new": _box("c")})
    assert "brand_new" not in s.groups
    assert [i.id for i in s["boxes"]] == ["a"]   # 다른 필드도 바꾸지 않았다
    with pytest.raises(NexusValidationError):
        s.add_labels(_bad_box("b"), label_field="boxes")
    assert [i.id for i in s["boxes"]] == ["a"]
    s.add_labels(_box("b"), label_field="boxes")
    assert [i.id for i in s["boxes"]] == ["a", "b"]


def test_RawGroup_을_고쳐도_save_는_보내지_않는다():
    ds = _FakeDataset()
    s = _sample(ds)
    s["free"].raw.append({"id": "q", "label": "y"})
    s["free"].raw[0]["label"] = "changed"
    assert s.save()["instances"] == 0
    assert ds.merged == []
    s["boxes"].add(_box("b"))
    s.save()
    (_, patch), = ds.merged
    assert set(patch) == {"boxes"}


def test_clear_field_는_RawGroup_도_비운다():
    ds = _FakeDataset()
    s = _sample(ds)
    s.clear_field("free")
    s.save()
    (_, patch), = ds.merged
    assert patch == {"free": []}


def test_로드는_틀린_옛_행도_검사하지_않고_연다():
    s = _sample(extra={"boxes": [
        {"id": "a", "label": "car", "bounding_box": {"type": "bounding_box", "rect": [0, 0]}},
        {"id": "a", "label": "car"},
    ]})
    g = s["boxes"]
    assert len(g) == 2
    # 옛 틀린 행이 남은 그룹이어도 결과 그룹의 그룹 규칙(id 중복)에 걸리면 더할 수 없다.
    with pytest.raises(NexusValidationError):
        g.add(_box("b"))
    g.remove("a")
    g.add(_box("b"))
    assert [i.id for i in g] == ["b"]


def test_merge_는_RawGroup_을_빈_자리에도_넣지_않고_아무것도_바꾸지_않는다():
    s = _sample()
    other = AnnotatedSample("o", Meta({"w": 9}), {
        "boxes": LabelGroup([_box("b")]),
        "zzz": RawGroup([{"id": "q", "label": "y"}]),
    })
    with pytest.raises(TypeError):
        s.merge(other)
    assert "zzz" not in s.groups
    assert [i.id for i in s["boxes"]] == ["a"]
    assert s.meta["w"] == 1


def test_copy_사본도_핸들의_지금_선언을_본다():
    ds = _FakeDataset()
    s = _sample(ds)
    ds._group_kinds["later"] = "group"
    c = s.copy()
    c["later"] = LabelGroup([_box("x")])
    assert [i.id for i in c["later"]] == ["x"]


class _PutOnlyDataset(_FakeDataset):
    def __init__(self):
        super().__init__()
        self.saved = None

    def _partial_annotations_unsupported(self):
        return True

    def _save_annotation(self, sample_id, ann, replace_meta=False):
        self.saved = (sample_id, copy.deepcopy(ann))
        return {"instances": 0, "skipped": 0, "skipped_reasons": {}}


def test_기준_없는_샘플의_통째_교체는_RawGroup_을_빼지_않는다():
    ds = _PutOnlyDataset()
    base = _sample()
    s = AnnotatedSample("s1", base.meta, base.groups, dataset=ds)   # 기준 없음
    s.save()
    _, full = ds.saved
    assert full["free"] == [{"id": "r", "label": "x", "whatever": 1}]


def test_같은_그룹_객체를_두_이름에_대입해도_경로가_맞다():
    # 대입은 같은 객체를 둔다(별칭) — 대입 뒤 g.add 도 샘플에 반영된다. 사용자 객체의 _name 은 바뀌지 않고, 대입·save()·
    # add_labels 검사의 경로는 늘 그 필드 이름이다(마지막 대입의 이름이 정하지 않는다).
    ds = _FakeDataset()
    ds._group_kinds.update({"g1": "group", "g2": "group"})
    s = AnnotatedSample.from_dict({}, {}, sample_id="s1", dataset=ds)
    g = LabelGroup([_box("x")])
    s["g1"] = g
    s["g2"] = g
    assert s["g1"] is g and s["g2"] is g
    assert g._name == ""
    g.add(_box("y"))
    assert [i.id for i in s["g1"]] == ["x", "y"]
    bad = LabelGroup([_box("z"), _box("z")])
    with pytest.raises(NexusValidationError) as e1:
        s["g1"] = bad
    with pytest.raises(NexusValidationError) as e2:
        s["g2"] = bad
    assert [i.path for i in e1.value.errors] == ["g1[1].id"]
    assert [i.path for i in e2.value.errors] == ["g2[1].id"]
    with pytest.raises(NexusValidationError) as e3:
        s.add_labels(_bad_box("b"), label_field="g1")
    with pytest.raises(NexusValidationError) as e4:
        s.add_labels(_bad_box("b"), label_field="g2")
    assert [i.path for i in e3.value.errors] == ["g1[2].bounding_box.rect"]
    assert [i.path for i in e4.value.errors] == ["g2[2].bounding_box.rect"]
    assert g._name == ""
    g._instances.append(_bad_box("b"))   # 넣은 뒤 고친 것은 save() 가 필드 이름으로 잡는다
    with pytest.raises(NexusValidationError) as e5:
        s.save()
    assert {i.path for i in e5.value.errors} >= {"g1[2].bounding_box.rect"}
    assert ds.merged == []


def test_merge_는_같은_값의_RawGroup_은_건너뛴다():
    ds = _FakeDataset()
    s = _sample(ds)
    other = _sample()   # 같은 dataset 에서 읽은 것처럼 같은 free 그룹
    other["boxes"].add(_box("b"))
    s.merge(other)
    assert [i.id for i in s["boxes"]] == ["a", "b"]
    assert s["free"].raw == [{"id": "r", "label": "x", "whatever": 1}]
    s.merge(other, merge_lists=False, overwrite=True)
    s.save()
    (_, patch), = ds.merged
    assert set(patch) == {"boxes"}


def test_merge_는_다른_값의_RawGroup_이면_TypeError():
    s = _sample()
    other = _sample(extra={"free": [{"id": "r", "label": "changed"}]})
    other["boxes"].add(_box("b"))
    with pytest.raises(TypeError):
        s.merge(other)
    assert [i.id for i in s["boxes"]] == ["a"]
    assert s["free"].raw == [{"id": "r", "label": "x", "whatever": 1}]
    s.merge(other, overwrite=False)   # 덮지 않으면 바뀌는 것이 없어 통과
    assert s["free"].raw == [{"id": "r", "label": "x", "whatever": 1}]


def test_merge_의_RawGroup_비교는_로컬_raw_가_아니라_저장_상태를_본다():
    changed = [{"id": "r", "label": "changed"}]
    # 로컬 raw 를 other 와 같게 고쳐 두어도 저장 상태는 다르다 — 건너뛰면 save() 가 0 건이라 뜻이 조용히 사라진다.
    s = _sample()
    s["free"].raw[:] = copy.deepcopy(changed)
    other = _sample(extra={"free": copy.deepcopy(changed)})
    with pytest.raises(TypeError):
        s.merge(other)
    # 로컬 raw 만 고쳤고 other 가 저장값과 같으면 바뀌는 것이 없다 — 통과.
    s = _sample()
    s["free"].raw.append({"id": "q", "label": "y"})
    s.merge(_sample())


def test_merge_는_비운_RawGroup_자리를_빈_값과_같게_본다():
    s = _sample()
    s.clear_field("free")
    s.merge(_sample(extra={"free": []}))
    with pytest.raises(TypeError):
        s.merge(_sample())
