import copy
import json
import pathlib
import pytest

from nexus.annotated import AnnotatedSample
from nexus.group import LabelGroup, LabelContainer, RawGroup
from nexus.instance import Instance
from nexus.meta import Meta
from nexus._types import NexusError, NexusValidationError

FIX = pathlib.Path(__file__).parent / "fixtures" / "annotation_sample.json"
KINDS = {"raw_dets": "container", "raw_kps": "container", "merged": "group"}


def _load():
    return json.loads(FIX.read_text(encoding="utf-8"))


def _loaded(ds=None, sample_id="s1", extra_kinds=None):
    kinds = {**KINDS, **(extra_kinds or {})}
    return AnnotatedSample.from_dict(copy.deepcopy(_load()), kinds, sample_id=sample_id, dataset=ds)


def _inst(id_, label="car", rect=(0, 0, 1, 1)):
    return Instance(id=id_, label=label,
                     components={"bounding_box": _row_to_label(rect)})


def _row_to_label(rect):
    from nexus.labels import Label
    return Label.from_dict({"type": "bounding_box", "rect": list(rect)})


class _FakeDataset:
    def __init__(self, merge_status=None):
        self.saved = None
        self.merged = []
        self.merge_status = merge_status
        self.unsupported = False

    def _save_annotation(self, sample_id, ann):
        self.saved = (sample_id, copy.deepcopy(ann))
        return {"instances": 1, "skipped": 0, "skipped_reasons": {}}

    def _merge_annotation(self, sample_id, patch):
        if self.merge_status is not None:
            err = NexusError("method not allowed")
            err.status_code = self.merge_status
            raise err
        self.merged.append((sample_id, copy.deepcopy(patch)))
        return {"instances": 0, "skipped": 0, "skipped_reasons": {}}

    def _partial_annotations_unsupported(self):
        return self.unsupported

    def _mark_partial_annotations_unsupported(self):
        self.unsupported = True


# ---------------------------------------------------------------------------
# __getitem__ / __setitem__
# ---------------------------------------------------------------------------

def test_getitem_meta_returns_meta_object():
    s = _loaded()
    assert s["meta"] is s.meta


def test_setitem_meta_rejects_dict():
    # 대입은 객체만 받는다(설계 6-1) — dict 는 TypeError, Meta 는 받는다.
    s = _loaded()
    with pytest.raises(TypeError):
        s["meta"] = {"foo": 1}
    s["meta"] = Meta({"foo": 1})
    assert s.meta["foo"] == 1


def test_setitem_meta_accepts_meta_object():
    s = _loaded()
    s["meta"] = Meta({"foo": 1})
    assert s.meta["foo"] == 1


def test_setitem_meta_makes_it_serialize_even_if_absent_before():
    d = {"raw_dets": []}
    s = AnnotatedSample.from_dict(d, KINDS)
    assert "meta" not in s.to_dict()
    s["meta"] = Meta({"w": 1})
    assert s.to_dict()["meta"] == {"w": 1}


def test_setitem_group_rejects_list_of_rows():
    s = _loaded()
    with pytest.raises(TypeError):
        s["merged"] = [{"id": "zzzz", "label": "dog"}]
    s["merged"] = LabelGroup([Instance("dog", id="zzzz")])
    assert s.get_group("merged")[0].id == "zzzz"


def test_setitem_group_accepts_group_object():
    s = _loaded()
    s["merged"] = LabelGroup([])
    assert isinstance(s.get_group("merged"), LabelGroup)
    assert len(s.get_group("merged")) == 0


def test_setitem_rejects_other_types():
    s = _loaded()
    with pytest.raises(TypeError):
        s["merged"] = "not a group"
    with pytest.raises(TypeError):
        s["meta"] = [1, 2, 3]


# ---------------------------------------------------------------------------
# get_field / set_field
# ---------------------------------------------------------------------------

def test_get_field_returns_group_and_meta():
    s = _loaded()
    assert s.get_field("merged") is s.groups["merged"]
    assert s.get_field("meta") is s.meta


def test_get_field_missing_raises_attributeerror_listing_fields():
    s = _loaded()
    with pytest.raises(AttributeError) as ei:
        s.get_field("nope")
    msg = str(ei.value)
    assert "merged" in msg and "meta" in msg


def test_set_field_create_true_adds_new_field():
    s = _loaded(extra_kinds={"brand_new": "group"})
    s.set_field("brand_new", LabelGroup([Instance("x", id="a")]))
    assert isinstance(s.get_field("brand_new"), LabelGroup)


def test_set_field_create_false_rejects_new_field():
    s = _loaded()
    with pytest.raises(AttributeError):
        s.set_field("typo_field", [], create=False)


def test_set_field_create_false_allows_existing_field():
    s = _loaded()
    s.set_field("merged", LabelGroup([]), create=False)
    assert len(s.get_field("merged")) == 0


def test_set_field_create_false_allows_meta():
    s = _loaded()
    s.set_field("meta", Meta({"w": 5}), create=False)
    assert s.meta["w"] == 5


# ---------------------------------------------------------------------------
# clear_field
# ---------------------------------------------------------------------------

def test_clear_field_label_group_resets_to_empty_group():
    s = _loaded()
    s.clear_field("merged")
    grp = s.get_group("merged")
    assert isinstance(grp, LabelGroup)
    assert not isinstance(grp, LabelContainer)
    assert len(grp) == 0


def test_clear_field_label_container_resets_to_empty_container():
    s = _loaded()
    s.clear_field("raw_dets")
    grp = s.get_group("raw_dets")
    assert isinstance(grp, LabelContainer)
    assert len(grp) == 0


def test_clear_field_raw_group_resets_to_empty_raw_group():
    s = _loaded()
    s.clear_field("some_undeclared_group")
    grp = s.get_group("some_undeclared_group")
    assert isinstance(grp, RawGroup)
    assert grp.to_raw() == []


def test_clear_field_meta_resets_to_empty_meta_not_none():
    s = _loaded()
    s.clear_field("meta")
    assert s.meta.to_dict() == {}
    assert s.to_dict()["meta"] == {}


def test_clear_field_missing_raises():
    s = _loaded()
    with pytest.raises(AttributeError):
        s.clear_field("nope")


def test_clear_field_then_save_sends_empty_list_patch():
    ds = _FakeDataset()
    s = _loaded(ds)
    s.clear_field("raw_kps")
    s.save()
    (_, patch), = ds.merged
    assert patch == {"raw_kps": []}


def test_clear_field_meta_then_save_deletes_every_prior_key():
    ds = _FakeDataset()
    s = _loaded(ds)
    prior_keys = set(s.meta.to_dict().keys())
    s.clear_field("meta")
    s.save()
    (_, patch), = ds.merged
    assert set(patch) == {"meta"}
    assert set(patch["meta"]) == prior_keys
    assert all(v is None for v in patch["meta"].values())


# ---------------------------------------------------------------------------
# merge
# ---------------------------------------------------------------------------

def test_merge_rejects_bad_type():
    s = _loaded()
    with pytest.raises(TypeError):
        s.merge(123)


def test_merge_adds_field_missing_on_self():
    s = _loaded(extra_kinds={"new_group": "group"})
    other = AnnotatedSample("s2", Meta({}), {"new_group": LabelGroup([_inst("x1")])})
    s.merge(other)
    assert "new_group" in s.groups
    assert s.get_group("new_group")[0].id == "x1"


def test_merge_deep_copies_taken_groups():
    s = _loaded(extra_kinds={"new_group": "group"})
    other_grp = LabelGroup([_inst("x1")])
    other = AnnotatedSample("s2", Meta({}), {"new_group": other_grp})
    s.merge(other)
    s.get_group("new_group")[0].label = "changed"
    assert other_grp.instances[0].label != "changed"


def test_merge_id_merge_replaces_same_id_and_appends_new_id():
    s = _loaded()  # merged group has instance id aaaa0000
    other_same_id = _inst("aaaa0000", label="replaced")
    other_new_id = _inst("newid0001", label="added")
    other = AnnotatedSample("s2", Meta({}), {"merged": LabelGroup([other_same_id, other_new_id])})
    s.merge(other)  # merge_lists=True, overwrite=True by default
    grp = s.get_group("merged")
    ids = [i.id for i in grp.instances]
    assert ids == ["aaaa0000", "newid0001"]  # 위치 보존 + 새 id는 추가
    assert grp[0].label == "replaced"


def test_merge_id_merge_overwrite_false_keeps_self_instance():
    s = _loaded()
    other_same_id = _inst("aaaa0000", label="replaced")
    other = AnnotatedSample("s2", Meta({}), {"merged": LabelGroup([other_same_id])})
    s.merge(other, overwrite=False)
    grp = s.get_group("merged")
    assert len(grp) == 1
    assert grp[0].label == "car"  # 원본 유지


def test_merge_lists_false_replaces_whole_group_when_overwrite():
    s = _loaded()
    other = AnnotatedSample("s2", Meta({}), {"merged": LabelGroup([_inst("only")])})
    s.merge(other, merge_lists=False, overwrite=True)
    grp = s.get_group("merged")
    assert [i.id for i in grp.instances] == ["only"]


def test_merge_lists_false_overwrite_false_leaves_field_untouched():
    s = _loaded()
    other = AnnotatedSample("s2", Meta({}), {"merged": LabelGroup([_inst("only")])})
    before = [i.id for i in s.get_group("merged").instances]
    s.merge(other, merge_lists=False, overwrite=False)
    assert [i.id for i in s.get_group("merged").instances] == before


def test_merge_raw_group_is_rejected_like_assignment():
    # RawGroup 은 대입할 수 없고 save() 가 보내지 않으므로 merge 도 거절한다(조용히 버려지지 않게).
    s = _loaded()
    original = s.get_group("some_undeclared_group").to_raw()
    other = AnnotatedSample("s2", Meta({}), {"some_undeclared_group": RawGroup([{"x": 1}])})
    with pytest.raises(TypeError):
        s.merge(other, merge_lists=True, overwrite=True)
    assert s.get_group("some_undeclared_group").to_raw() == original


def test_merge_raw_group_overwrite_false_leaves_untouched():
    s = _loaded()
    original = s.get_group("some_undeclared_group").to_raw()
    other = AnnotatedSample("s2", Meta({}), {"some_undeclared_group": RawGroup([{"x": 1}])})
    s.merge(other, overwrite=False)
    assert s.get_group("some_undeclared_group").to_raw() == original


def test_merge_fields_whitelist():
    s = _loaded()
    other = AnnotatedSample("s2", Meta({"w": 1}),
                             {"merged": LabelGroup([_inst("added")]),
                              "raw_dets": LabelContainer([])})
    s.merge(other, fields=["merged"])
    assert s.get_group("merged")[-1].id == "added"
    assert "w" not in s.meta.to_dict()
    # raw_dets 도 안 바뀌어야 함(원래 항목 유지)
    assert len(s.get_group("raw_dets")) == 1


def test_merge_omit_fields():
    s = _loaded()
    other = AnnotatedSample("s2", Meta({"w": 1}), {"merged": LabelGroup([_inst("added")])})
    s.merge(other, omit_fields=["meta"])
    assert s.get_group("merged")[-1].id == "added"
    assert "w" not in s.meta.to_dict()


def test_merge_meta_key_level_overwrite_true():
    s = _loaded()
    other = AnnotatedSample("s2", Meta({"width": 9999, "brand_new": "x"}), {})
    s.merge(other, overwrite=True)
    assert s.meta["width"] == 9999
    assert s.meta["brand_new"] == "x"


def test_merge_meta_key_level_overwrite_false_only_fills_missing():
    s = _loaded()
    other = AnnotatedSample("s2", Meta({"width": 9999, "brand_new": "x"}), {})
    orig_width = s.meta["width"]
    s.merge(other, overwrite=False)
    assert s.meta["width"] == orig_width
    assert s.meta["brand_new"] == "x"


def test_merge_rejects_dict_and_takes_from_dict_object():
    s = _loaded()  # group_kinds carried from from_dict()
    other_dict = {"raw_dets": [{"id": "newdet", "label": "car",
                                 "bounding_box": {"type": "bounding_box", "rect": [0, 0, 1, 1]}}]}
    with pytest.raises(TypeError, match="from_dict"):
        s.merge(other_dict)          # dict 입력은 없어졌다 — from_dict 로 먼저 바꾼다
    s.merge(AnnotatedSample.from_dict(other_dict, KINDS))
    grp = s.get_group("raw_dets")
    assert isinstance(grp, LabelContainer)  # KINDS 에 따라 container 로 파싱됨
    assert any(i.id == "newdet" for i in grp.instances)


def test_merge_then_save_sends_only_merged_field():
    ds = _FakeDataset()
    s = _loaded(ds)
    other = AnnotatedSample("s2", Meta({}), {"merged": LabelGroup([_inst("added")])})
    s.merge(other, fields=["merged"])
    s.save()
    (_, patch), = ds.merged
    assert set(patch) == {"merged"}
    assert any(row["id"] == "added" for row in patch["merged"])


# ---------------------------------------------------------------------------
# add_labels
# ---------------------------------------------------------------------------

def test_add_labels_single_instance_requires_label_field():
    s = _loaded()
    with pytest.raises(ValueError):
        s.add_labels(_inst("new1"))


def test_add_labels_single_instance():
    s = _loaded()
    s.add_labels(_inst("new1"), label_field="merged")
    assert any(i.id == "new1" for i in s.get_group("merged").instances)


def test_add_labels_list_of_instances():
    s = _loaded()
    s.add_labels([_inst("n1"), _inst("n2")], label_field="merged")
    ids = {i.id for i in s.get_group("merged").instances}
    assert {"n1", "n2"} <= ids


def test_add_labels_dict_multiple_fields():
    s = _loaded()
    s.add_labels({"merged": _inst("n1"), "raw_dets": [_inst("n2")]})
    assert any(i.id == "n1" for i in s.get_group("merged").instances)
    assert any(i.id == "n2" for i in s.get_group("raw_dets").instances)


def test_add_labels_creates_new_field():
    s = _loaded(extra_kinds={"brand_new_field": "group"})
    s.add_labels(_inst("n1"), label_field="brand_new_field")
    assert isinstance(s.get_group("brand_new_field"), LabelGroup)
    assert s.get_group("brand_new_field")[0].id == "n1"


def test_add_labels_duplicate_id_rejected_and_leaves_sample_unchanged():
    s = _loaded()
    before = s.to_dict()
    with pytest.raises(ValueError):
        s.add_labels(_inst("aaaa0000"), label_field="merged")  # already exists in merged
    assert s.to_dict() == before


def test_add_labels_duplicate_within_batch_rejected_and_leaves_sample_unchanged():
    s = _loaded()
    before = s.to_dict()
    with pytest.raises(ValueError):
        s.add_labels([_inst("dup"), _inst("dup")], label_field="merged")
    assert s.to_dict() == before


def test_add_labels_non_instance_items_rejected():
    s = _loaded()
    with pytest.raises(TypeError):
        s.add_labels(["not an instance"], label_field="merged")


def test_add_labels_to_meta_rejected():
    s = _loaded()
    with pytest.raises(TypeError):
        s.add_labels({"meta": _inst("n1")})


def test_add_labels_to_raw_group_rejected():
    s = _loaded()
    with pytest.raises(TypeError):
        s.add_labels(_inst("n1"), label_field="some_undeclared_group")


def test_add_labels_without_label_field_and_not_dict_raises_value_error():
    s = _loaded()
    with pytest.raises(ValueError):
        s.add_labels([_inst("n1")])


# ---------------------------------------------------------------------------
# copy
# ---------------------------------------------------------------------------

def test_copy_is_unsaved():
    s = _loaded()
    c = s.copy()
    assert c.sample_id is None
    assert c._dataset is None
    with pytest.raises(NexusValidationError):
        c.save()


def test_copy_is_isolated_from_original():
    s = _loaded()
    c = s.copy()
    c.get_group("merged")[0].label = "changed"
    assert s.get_group("merged")[0].label != "changed"
    c.meta["width"] = -1
    assert s.meta["width"] != -1


def test_copy_preserves_data():
    s = _loaded()
    c = s.copy()
    assert c.to_dict() == s.to_dict()


def test_copy_fields_whitelist():
    s = _loaded()
    c = s.copy(fields=["merged"])
    assert set(c.groups) == {"merged"}
    assert "meta" not in c.to_dict()


def test_copy_omit_fields():
    s = _loaded()
    c = s.copy(omit_fields=["meta", "raw_dets"])
    assert "raw_dets" not in c.groups
    assert "merged" in c.groups
    assert "meta" not in c.to_dict()


def test_copy_carries_group_kinds_for_further_merge():
    s = _loaded()
    c = s.copy()
    other_dict = {"raw_dets": [{"id": "newdet", "label": "car",
                                 "bounding_box": {"type": "bounding_box", "rect": [0, 0, 1, 1]}}]}
    c.merge(AnnotatedSample.from_dict(other_dict, KINDS))
    assert isinstance(c.get_group("raw_dets"), LabelContainer)


# ---------------------------------------------------------------------------
# 리뷰 회귀: 선언 종류·부분 변경·별칭
# ---------------------------------------------------------------------------

def _box_row(id_):
    return {"id": id_, "label": "car", "bounding_box": {"type": "bounding_box", "rect": [0, 0, 1, 1]}}


def test_setitem_on_declared_container_requires_container():
    s = _loaded()
    with pytest.raises(NexusValidationError):
        s["raw_dets"] = LabelGroup.from_list([_box_row("x1")])
    s["raw_dets"] = LabelContainer.from_list([_box_row("x1")])
    assert isinstance(s.get_group("raw_dets"), LabelContainer)


def test_setitem_on_declared_container_enforces_container_rule_at_assignment():
    ds = _FakeDataset()
    s = _loaded(ds)
    before = s.get_group("raw_dets")
    row = _box_row("x1")
    row["polygon"] = {"type": "polygon", "points": [[0, 0], [1, 0], [1, 1]]}
    with pytest.raises(NexusValidationError):
        s["raw_dets"] = LabelContainer.from_list([row])
    assert s.get_group("raw_dets") is before
    s.save()
    assert ds.merged == []


def test_setitem_list_of_non_dicts_raises_typeerror():
    s = _loaded()
    with pytest.raises(TypeError):
        s["merged"] = [1, 2]


def test_add_labels_new_field_follows_declared_kind():
    s = AnnotatedSample.from_dict({}, KINDS)
    s.add_labels(_inst("n1"), label_field="raw_dets")
    assert isinstance(s.get_group("raw_dets"), LabelContainer)


def test_add_labels_copies_instances():
    s = _loaded(extra_kinds={"newf": "group"})
    inst = _inst("n1")
    s.add_labels({"merged": inst, "newf": inst})
    assert s.get_group("merged")[-1] is not s.get_group("newf")[0]
    assert s.get_group("newf")[0] is not inst


def test_add_labels_dict_with_label_field_rejected():
    s = _loaded()
    with pytest.raises(ValueError):
        s.add_labels({"merged": _inst("n1")}, label_field="merged")


def test_merge_non_object_self_meta_fails_before_touching_groups():
    s = AnnotatedSample._from_server({"meta": [1, 2], "merged": []}, KINDS)
    other = AnnotatedSample.from_dict(
        {"meta": {"w": 1}, "merged": [_box_row("m1")], "zz": [_box_row("z1")]}, KINDS)
    before = s.to_dict()
    for _ in range(3):
        with pytest.raises(NexusValidationError):
            s.merge(other)
        assert s.to_dict() == before


def test_merge_empty_meta_keeps_stored_null():
    s = AnnotatedSample.from_dict({"meta": None, "merged": []}, KINDS)
    s.merge(AnnotatedSample.from_dict({"merged": [_box_row("m1")]}, KINDS))
    assert s.to_dict()["meta"] is None


def test_nested_container_component_fails_save_with_validation_error():
    ds = _FakeDataset()
    s = _loaded(ds)
    s["merged"][0].set_component("bounding_box", LabelContainer([]))
    with pytest.raises(NexusValidationError):
        s.save()
    assert ds.merged == [] and ds.saved is None



# ---------------------------------------------------------------------------
# 그룹 행은 Instance 만
# ---------------------------------------------------------------------------

def test_group_row_that_is_a_label_fails_save_with_validation_error():
    from nexus.labels import Detection
    ds = _FakeDataset()
    s = _loaded(ds)
    # add 는 Instance 만 받는다(TypeError). 생성자로 끼운 그룹은 대입에서 걸린다.
    with pytest.raises(TypeError):
        s["merged"].add(Detection(rect=[0, 0, 1, 1], label="q"))
    with pytest.raises(NexusValidationError):
        s["merged"] = LabelGroup([Detection(rect=[0, 0, 1, 1], label="q")])
    s.save()
    assert ds.merged == [] and ds.saved is None


def test_group_row_that_is_a_dict_fails_save_with_validation_error():
    ds = _FakeDataset()
    s = _loaded(ds)
    with pytest.raises(TypeError):
        s["merged"].add({"id": "b", "label": "p"})
    with pytest.raises(NexusValidationError):
        s["merged"] = LabelGroup([{"id": "b", "label": "p"}])
    s.save()
    assert ds.merged == [] and ds.saved is None


# ---------------------------------------------------------------------------
# 빈 id 채움과 기준(baseline), 그룹 안 중복 id 경고
# ---------------------------------------------------------------------------



def _row(id_):
    return {"id": id_, "label": "car", "bounding_box": {"type": "bounding_box", "rect": [0, 0, 1, 1]}}


def test_empty_ids_filled_on_load_do_not_trigger_a_save_by_themselves():
    ds = _FakeDataset()
    s = AnnotatedSample.from_dict({"g": [_row(""), _row("")]}, {"g": "group"}, sample_id="s1", dataset=ds)
    a, b = s["g"][0].id, s["g"][1].id
    assert a and b and a != b
    s.save()
    assert ds.merged == []  # 채운 id 만으로는 변경이 아니다


def test_filled_ids_are_written_when_the_group_is_saved():
    ds = _FakeDataset()
    s = AnnotatedSample.from_dict({"g": [_row(""), _row("")]}, {"g": "group"}, sample_id="s1", dataset=ds)
    s["g"][0].label = "truck"
    s.save()
    (_, patch), = ds.merged
    ids = [r["id"] for r in patch["g"]]
    assert all(ids) and len(set(ids)) == 2


def test_duplicate_ids_in_a_sent_group_are_rejected():
    ds = _FakeDataset()
    s = AnnotatedSample._from_server({"g": [_row("dup"), _row("dup")]}, {"g": "group"}, sample_id="s1", dataset=ds)
    s["g"][0].label = "truck"
    with pytest.raises(NexusValidationError, match="dup"):
        s.save()
    assert ds.merged == [] and ds.saved is None


def test_duplicate_ids_in_an_untouched_group_do_not_block_saving_others():
    ds = _FakeDataset()
    s = AnnotatedSample._from_server({"g": [_row("dup"), _row("dup")], "h": [_row("a")]},
                                  {"g": "group", "h": "group"}, sample_id="s1", dataset=ds)
    s["h"][0].label = "truck"
    s.save()
    (_, patch), = ds.merged
    assert set(patch) == {"h"}


def test_unique_ids_save_normally():
    ds = _FakeDataset()
    s = AnnotatedSample.from_dict({"g": [_row("a"), _row("b")]}, {"g": "group"}, sample_id="s1", dataset=ds)
    s["g"][0].label = "truck"
    s.save()
    assert len(ds.merged) == 1
