from __future__ import annotations
import json
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from contextlib import contextmanager
from pathlib import Path, PurePosixPath

from tqdm import tqdm


@contextmanager
def _spinner(desc: str, *, disable: bool = False):
    """블로킹 호출(예: delete) 동안 경과시간 스피너를 별도 스레드로 돌린다."""
    if disable:
        yield
        return
    bar = tqdm(total=0, desc=desc, bar_format="{desc} {elapsed}", leave=False)
    stop = threading.Event()

    def _tick() -> None:
        while not stop.wait(0.25):
            bar.refresh()

    th = threading.Thread(target=_tick, daemon=True)
    th.start()
    try:
        yield
    finally:
        stop.set()
        th.join(timeout=1)
        bar.close()

def _prompt(question: str) -> "str | None":
    """대화형이면 `input()`으로 답을 받고, 입력이 불가능하면 None.

    Jupyter/IPython은 `sys.stdin.isatty()`가 False라도 `input()`이 입력 박스로 동작하므로
    isatty로 판단하지 않는다. 진짜 비대화형(파이프/CI: EOFError, pytest 캡처: OSError)에서만
    None을 돌려준다."""
    try:
        return input(question)
    except (EOFError, OSError):
        return None


def _resolve_delete_cas(delete_cas: "bool | None", what: str) -> bool:
    """delete_cas가 명시되면 그대로, None이면 대화형으로 한 번 묻는다.
    입력이 불가능한 비대화형(스크립트/CI)이면 안전하게 False(CAS 파일 보존)로 둔다."""
    if delete_cas is not None:
        return bool(delete_cas)
    ans = _prompt(
        f"{what} 삭제: 미참조 CAS 파일(이미지/썸네일)도 함께 삭제할까요? "
        f"삭제=y / 보존=N [y/N]: "
    )
    if ans is None:
        return False
    return ans.strip().lower() in ("y", "yes")


from nexus._types import IngestResult, NexusBatchError, NexusCasError, NexusError
from nexus.cas import CasClient
from nexus.client import NexusClient
from nexus.sample import CasRef, FileRef, Sample, _parse_ref


def _sample_label(s: "Sample | None") -> str:
    """진행 로그용 짧은 식별 문자열 — 이미지 키 파일명 > annotation 파일명 순."""
    if s is None:
        return "<sample>"
    key = getattr(getattr(s, "_image_ref", None), "key", None)
    if key:
        return PurePosixPath(key).name
    ann = getattr(s, "annotation", None)
    if isinstance(ann, (str, Path)):
        return Path(str(ann)).name
    return "<sample>"

_DF_EXT_FORMAT = {
    "csv": "csv", "json": "json",
    "jsonl": "jsonl", "ndjson": "jsonl",
    "parquet": "parquet", "pq": "parquet",
}


def _write_dataframe(df, path: "str | Path", fmt: "str | None" = None):
    """DataFrame을 파일로 저장. fmt 생략 시 확장자로 추론.
    지원: csv / json / jsonl(ndjson) / parquet. 중첩(dict·list) 셀은 csv에서 JSON 문자열로 직렬화."""
    p = Path(path)
    fmt = (fmt or _DF_EXT_FORMAT.get(p.suffix.lower().lstrip(".")))
    if fmt is None:
        raise ValueError(
            f"format을 지정하거나 확장자(.csv/.json/.jsonl/.parquet)를 사용하세요: {path}"
        )
    fmt = fmt.lower()
    if fmt == "csv":
        out = df.copy()
        for col in out.columns:
            out[col] = out[col].apply(
                lambda v: json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else v
            )
        out.to_csv(p, index=False)
    elif fmt == "json":
        df.to_json(p, orient="records", force_ascii=False, indent=2)
    elif fmt == "jsonl":
        df.to_json(p, orient="records", lines=True, force_ascii=False)
    elif fmt == "parquet":
        try:
            df.to_parquet(p)
        except ImportError as e:
            raise ImportError("parquet 저장은 pyarrow가 필요합니다: pip install pyarrow") from e
    else:
        raise ValueError(f"지원하지 않는 format '{fmt}' (csv/json/jsonl/parquet)")
    return p


class Dataset:
    def __init__(
        self,
        client: NexusClient,
        cas: CasClient,
        dataset_id: str,
        name: str,
        version: str,
    ) -> None:
        self._client = client
        self._cas = cas
        self._dataset_id = dataset_id
        self._name = name
        self._version = version
        self._queue: list[Sample] = []

    @property
    def dataset_id(self) -> str:
        return self._dataset_id

    @property
    def version(self) -> str:
        return self._version

    @classmethod
    def load_or_create(
        cls,
        name: str,
        version: str,
        tags: list[str] | None = None,
        description: str | None = None,
        *,
        fork_from: str | None = None,
        sample_ids: list[str] | None = None,
        client: NexusClient | None = None,
        cas: CasClient | None = None,
    ) -> "Dataset":
        """dataset을 이름으로 찾거나 만들고, 없으면 version을 생성해 Dataset 핸들 반환.
        `fork_from`: 그 버전 전량 fork. `fork_from`+`sample_ids`: **필터링된 fork**
        (그 버전 멤버 중 지정 샘플만, 라벨째로) — "이 샘플들만 담은 새 버전" 용도.
        (순수 카탈로그 — bucket/prefix 인자 없음.)"""
        import nexus as _nx

        _client = client
        _cas = cas

        if _client is None or _cas is None:
            if _nx._client is None:
                _nx._auto_connect()
            _client = _client or _nx._client
            _cas = _cas or _nx._cas

        datasets = _client.list_datasets()
        matched = next((d for d in datasets if d["name"] == name), None)
        if matched:
            dataset_id = matched["dataset_id"]
        else:
            dataset_id = _client.create_dataset(
                name, tags=tags, description=description
            )["dataset_id"]

        if not _client.get_version(dataset_id, version):
            # fork_from+sample_ids → 필터링된 fork(그 버전 샘플 중 일부만 라벨째로).
            _client.create_version(
                dataset_id, version, fork_from=fork_from, sample_ids=sample_ids
            )

        return cls(_client, _cas, dataset_id, name, version)

    def link_samples(self, sample_ids: list[str]) -> None:
        """이미 존재하는 sample_id들을 이 버전에 연결. ingest 없이 참조만 추가."""
        self._client.add_sample_ids(self._dataset_id, self._version, sample_ids)

    def update(self, *, name: "str | None" = None, description: "str | None" = None) -> dict:
        """dataset의 name/description을 제공된 것만 수정한다(둘 다 생략하면 no-op). dataset은
        생성 시 이름이 고정되고 rename 전용 API가 따로 없었는데, 이 메서드가 그 유일한 경로다
        (참고: 통째로 새 dataset을 원하면 `clone()`).

        name을 바꾸면 이 `Dataset` 핸들의 내부 이름도 함께 갱신한다 — 안 하면 이후 `add`+`flush`가
        **예전 이름으로 ingest**해서 그 이름의 dataset이 새로 생겨버린다(치명적인 함정이라 자동 처리).

        - name이 이미 다른 dataset에 쓰이고 있으면 `NexusError(status_code=409)`.
        - **소유자 게이트**: dataset에 owner가 있으면 그 계정만 가능 —
          `NexusError(status_code=403)`(`Dataset.delete()`와 동일 정책).
        """
        out = self._client.update_dataset(self._dataset_id, name=name, description=description)
        if name is not None:
            self._name = out["name"]
        return out

    def favorite(self) -> None:
        """이 dataset을 내 즐겨찾기에 추가(멱등). `GET /datasets`의 `is_favorite`·`favorite=` 필터에 반영."""
        self._client.add_favorite(self._dataset_id)

    def unfavorite(self) -> None:
        """이 dataset을 내 즐겨찾기에서 해제(멱등)."""
        self._client.remove_favorite(self._dataset_id)

    def sample_history(self, sample_id: str) -> dict:
        """이 dataset에서 한 샘플의 **버전별 annotation 이력**(그 샘플이 든 버전만, 오래된→최신).
        반환: `{sample_id, dataset_id, versions:[{version, status, parent_version, created_at, annotation}]}`."""
        return self._client.sample_history(self._dataset_id, sample_id)

    def diff(self, against: "str | None" = None) -> dict:
        """이 버전 vs base(`against`, 없으면 `parent_version`)의 annotation/멤버십 diff.
        반환: `{base, target, summary{samples, instances, labels[]}, changed_samples{count, sample_ids},
        base_audit{created_by, updated_by, updated_at}, target_audit{...}}`.
        `against` 없고 parent_version도 없으면 400."""
        return self._client.version_diff(self._dataset_id, self._version, against=against)

    def create_subset(self, name: str, filter: dict) -> "Subset":
        """이 버전에 **서브셋**(저장된 explorer 필터) 생성. `filter`는 explorer 바디 형태
        (`meta`/`annotation`/`tags`/`split`). 인증 필요, 이름 중복 시 409."""
        d = self._client.create_subset(self._dataset_id, self._version, name, filter)
        return Subset(self, d)

    def list_subsets(self) -> "list[Subset]":
        """이 버전의 서브셋 목록."""
        return [
            Subset(self, d)
            for d in self._client.list_subsets(self._dataset_id, self._version)
        ]

    def unlink_samples(self, sample_ids: list[str]) -> dict:
        """여러 sample을 이 버전에서 **링크 해제**(sample·데이터는 유지 — 다른 버전엔 그대로).
        반환: `{"removed": n}`(실제 해제된 링크 수). sealed 버전이면 409."""
        return self._client.remove_sample_ids(self._dataset_id, self._version, sample_ids)

    def import_samples(
        self, source_dataset_id: str, source_version: str, sample_ids: list[str]
    ) -> dict:
        """다른 dataset(`source_dataset_id`/`source_version`)의 sample들을 **이 버전으로 복사**해온다
        (크로스 데이터셋 재사용 — sample은 이제 dataset 범위 객체라 직접 링크는 불가, 이 방식이 유일한 경로).
        asset은 재사용(재업로드 없음)하지만 sample/annotation은 독립 복제 — 이후 이 버전에서 수정해도
        source에 영향 없음. 반환: `{"imported": [{"source_sample_id", "sample_id"}, ...]}`."""
        return self._client.import_samples(
            self._dataset_id, self._version, source_dataset_id, source_version, sample_ids
        )

    def fork(
        self,
        new_version: str,
        *,
        sample_ids: "list[str] | None" = None,
        group_key: str | None = None,
        label: str | None = None,
        confidence_min: float | None = None,
        confidence_max: float | None = None,
        track_id: int | None = None,
        split: str | None = None,
        tags: "list[str] | None" = None,
        meta: dict | None = None,
    ) -> "Dataset":
        """이 버전을 조건에 맞는 샘플만 담아 **같은 dataset의 새 버전**으로 만든다(필터링된 fork).
        필터를 하나도 안 주면 이 버전 전체를 그대로 fork한다(`load_or_create(fork_from=)`와 동일).

        필터는 `samples()`와 같은 의미 — `sample_ids`는 다른 필터와 AND, `group_key`/`label`/
        `confidence_min`/`confidence_max`/`track_id`는 **같은 instance**가 모두 만족해야 하는
        단일 annotation 조건. 내부적으로 `samples()`(필터가 있으면 전체 자동 수집)로 매칭되는
        sample_id를 모은 뒤 `fork_from=`+`sample_ids=`로 새 버전을 만든다. 매칭이 0개면 `ValueError`.

        **다른 dataset**으로 옮기고 싶으면, 먼저 이 메서드로 필터링된 버전을 만들고 그 결과에
        `clone(new_name, new_version)`을 이어서 부르면 된다(필터링된 버전 전체를 복제하는 방식).
        """
        has_filter = any([
            sample_ids, group_key, label,
            confidence_min is not None, confidence_max is not None,
            track_id is not None, split, tags, meta,
        ])
        ids: "list[str] | None" = None
        if has_filter:
            ids = [
                s["sample_id"]
                for s in self.samples(
                    sample_ids=sample_ids, group_key=group_key, label=label,
                    confidence_min=confidence_min, confidence_max=confidence_max,
                    track_id=track_id, split=split, tags=tags, meta=meta,
                    include_annotations=False,
                )
            ]
            if not ids:
                raise ValueError("필터에 매칭되는 샘플이 없습니다.")
        return Dataset.load_or_create(
            self._name, new_version,
            fork_from=self._version, sample_ids=ids,
            client=self._client, cas=self._cas,
        )

    def clone(
        self, new_name: str, new_version: str, *,
        batch_size: int = 256, verbose: bool = True,
    ) -> "Dataset":
        """이 (dataset, version)을 새 dataset의 새 버전으로 **완전히 복제**한다(독립 복제 —
        이후 어느 쪽을 수정해도 서로 영향 없음). dataset 이름을 바꾸는 API가 따로 없어서,
        새 이름으로 다시 만들고 싶을 때의 우회로로도 쓸 수 있다.

        - 원본 dataset의 `tags`/`description`을 그대로 복사해 새 dataset을 만든다(없으면 생성 —
          `load_or_create`와 동일하게 멱등, 이미 있으면 재사용).
        - 새 버전은 **항상 draft**로 시작한다(원본이 sealed여도 복제본은 draft — 바로 이어서
          patch/추가 가능).
        - 내부적으로 `import_samples`를 `batch_size`만큼 청크로 나눠 호출한다(대량 데이터셋
          대비, `flush()`와 동일한 관례).
        - **멱등하지 않다** — 같은 대상에 두 번 부르면 `flush()`를 두 번 부르는 것처럼 샘플이
          중복 복사된다.
        """
        src = self._client.get_dataset(self._dataset_id) or {}
        new_ds = Dataset.load_or_create(
            new_name, new_version,
            tags=src.get("tags"), description=src.get("description"),
            client=self._client, cas=self._cas,
        )
        sample_ids = [s["sample_id"] for s in self.list_samples()]
        for i in tqdm(
            range(0, len(sample_ids), batch_size),
            desc="Cloning", disable=not verbose,
        ):
            chunk = sample_ids[i : i + batch_size]
            new_ds.import_samples(self._dataset_id, self._version, chunk)
        return new_ds

    def list_samples(
        self,
        *,
        split: str | None = None,
        page_size: int = 1000,
        max_samples: int | None = None,
    ) -> list[dict]:
        """이 dataset/version에 포함된 샘플 목록을 모두 가져온다 (cursor 페이지네이션 자동).

        각 항목은 dict로 `sample_id`/`split`/`tags`와 `assets`(`{image: {cas_url, hash_hex,
        size, content_type}, depth: {...}}`)를 담는다. 프론트 전용 `image_url`/`thumbnail_url`은 포함하지 않는다.
        sealed 여부와 무관하게 동작한다(`to_df`와 달리 draft에서도 조회 가능).

        - `split`: 지정 시 해당 split만 (클라이언트 측 필터).
        - `page_size`: 요청당 페이지 크기. `max_samples`: 최대 수집 개수(상한).
        """
        out: list[dict] = []
        cursor = None
        seen: set = set()
        while True:
            page = self._client.get_manifest_samples(
                self._dataset_id, self._version, cursor=cursor, limit=page_size,
            )
            for s in page.get("samples", []):
                if split is not None and s.get("split") != split:
                    continue
                out.append(s)
                if max_samples is not None and len(out) >= max_samples:
                    return out
            cursor = page.get("next_cursor")
            # 끝(falsy)이거나 서버가 전진하지 않는 cursor를 주면 중단 (무한 루프 방지).
            if not cursor or cursor in seen:
                break
            seen.add(cursor)
        return out

    def samples(
        self,
        *,
        sample_ids: "list[str] | None" = None,
        group_key: str | None = None,
        label: str | None = None,
        confidence_min: float | None = None,
        confidence_max: float | None = None,
        track_id: int | None = None,
        split: str | None = None,
        tags: "list[str] | None" = None,
        meta: dict | None = None,
        include_annotations: bool = True,
        limit: int | None = None,
        after: str | None = None,
    ) -> list[dict]:
        """이 버전의 샘플을 조회한다(explorer를 감싼 범용 조회). 필터를 하나도 안 주면 버전의
        전체 샘플을 반환. 반환은 `get_sample()`과 같은 평탄 GT dict 리스트
        (`include_annotations=False`면 annotation 없는 경량 코어만).

        - `sample_ids`: 이 sample_id들로만 좁힌다(다른 필터와 AND).
        - `group_key`/`label`/`confidence_min`/`confidence_max`/`track_id` 중 하나라도 주면,
          그 조건을 **모두 만족하는 같은 instance**를 찾는 단일 필터가 된다(예:
          `samples(group_key="det", label="car")` = "det 그룹에 label이 car인 instance가
          있는 샘플"). `split`/`tags`/`meta`는 샘플 자체의 속성으로 별도 필터링된다.
        - `limit`을 **안 주면**(기본) 커서를 자동으로 순회해 매칭되는 전체를 모아서 반환한다.
          `limit`에 숫자를 주면 그 개수만큼 **한 페이지만** 반환하고(자동 페이지네이션 없음),
          `after`(이전 결과의 마지막 `sample_id`)로 호출부가 직접 다음 페이지를 요청해야 한다.

        더 복잡한 조건(component 필터, 여러 instance에 대한 AND 조건 등)이 필요하면
        `self._client.explore_samples(...)`를 직접 쓸 것 — 이 메서드는 흔한 단일 조건 검색용이다.
        """
        annotation_filter: dict = {}
        if group_key is not None:
            annotation_filter["group_key"] = group_key
        if label is not None:
            annotation_filter["label"] = label
        if confidence_min is not None or confidence_max is not None:
            annotation_filter["confidence"] = {"min": confidence_min, "max": confidence_max}
        if track_id is not None:
            annotation_filter["track_id"] = track_id
        annotation = [annotation_filter] if annotation_filter else None

        if limit is not None:
            return self._client.explore_samples(
                self._dataset_id, self._version,
                cursor=after, limit=limit,
                split=split, tags=tags, meta=meta, annotation=annotation,
                include_annotations=include_annotations, sample_ids=sample_ids,
            )

        page_size = 1000
        out: list[dict] = []
        cursor = after
        while True:
            page = self._client.explore_samples(
                self._dataset_id, self._version,
                cursor=cursor, limit=page_size,
                split=split, tags=tags, meta=meta, annotation=annotation,
                include_annotations=include_annotations, sample_ids=sample_ids,
            )
            out.extend(page)
            if len(page) < page_size:
                break
            cursor = page[-1]["sample_id"]
        return out

    def patch_annotations(
        self,
        sample_id: "str | dict[str, dict]",
        annotation_data: dict | None = None,
        *,
        workers: int = 8,
        strict: bool = False,
        verbose: bool = True,
    ) -> "None | list[IngestResult]":
        """샘플 annotation을 이 버전 전용으로 교체한다 (CoW — 공유 원본·다른 버전 보존).

        단일/배치를 하나로 처리한다:
        - **단일**: `patch_annotations(sample_id, annotation_data)` → 반환 `None`.
        - **배치**: `patch_annotations({sample_id: annotation_data, ...})` → PUT을 워커로
          **병렬** 처리하고 건당 `IngestResult` 리스트를 반환(`sample_id`/`ok`/`error`).
          (`[(sample_id, annotation_data), ...]` 형태의 시퀀스도 받는다.)

        `strict=True`면 배치 중 실패가 있으면 `NexusBatchError`를 던진다.
        """
        if annotation_data is not None:
            # 단일
            self._client.patch_annotations(
                self._dataset_id, self._version, sample_id, annotation_data
            )
            return None

        # 배치: dict 또는 (sample_id, annotation_data) 시퀀스
        items = list(sample_id.items()) if isinstance(sample_id, dict) else [tuple(x) for x in sample_id]

        def _one(sid: str, ann: dict) -> str:
            self._client.patch_annotations(self._dataset_id, self._version, sid, ann)
            return sid

        results: list[IngestResult] = []
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {pool.submit(_one, sid, ann): sid for sid, ann in items}
            for future in tqdm(
                as_completed(futures), total=len(futures),
                desc="Patching", disable=not verbose,
            ):
                sid = futures[future]
                try:
                    future.result()
                    results.append(IngestResult(ok=True, sample=None, sample_id=sid))
                except Exception as e:
                    results.append(IngestResult(ok=False, sample=None, sample_id=sid, error=str(e)))

        if strict:
            failures = [r for r in results if not r.ok]
            if failures:
                raise NexusBatchError(failures)
        return results

    def get_sample(self, sample_id: str) -> dict:
        """이 dataset+version에 속한 샘플의 코어 필드와 annotation을 평탄한 GT dict로 조회한다.

        반환 dict는 코어 필드와 annotation의 group_key 배열을 **같은 root**에 담는다:
          {"sample_id", "split", "tags", "created_at", "meta",
           "image_url", "thumbnail_url",
           "<group_key>": [ {"id", "label", "track_id"?, "confidence"?, ...components} ], ...}

        - annotation은 항상 포함되며, 버전-해소(CoW) instances로 재구성된다.
        - "meta"는 top-level 단일 키(공유 samples.meta, 버전 격리되지 않음).
        - group_key가 코어 키와 충돌하면 코어 필드가 우선한다.
        - asset 원시 참조는 이 응답에 없다 — ds.list_samples() 또는 GET /samples/{id}/assets로 조회.
        버전에 없는 sample → NexusError.
        """
        return self._client.get_sample(self._dataset_id, self._version, sample_id)

    def add(self, sample: "Sample | list[Sample]") -> None:
        """샘플을 등록 큐에 추가한다. 단일 `Sample` 또는 `Sample` 리스트 모두 받는다."""
        if isinstance(sample, Sample):
            self._queue.append(sample)
            return
        samples = list(sample)  # 리스트/튜플/제너레이터 허용
        for s in samples:
            if not isinstance(s, Sample):
                raise TypeError(
                    f"add()는 Sample 또는 Sample 리스트를 받습니다 — {type(s).__name__}를 받았습니다."
                )
        self._queue.extend(samples)

    def flush(
        self, workers: int = 4, strict: bool = False, verbose: bool = True,
        batch_size: int = 256, item_log: bool = False,
    ) -> list[IngestResult]:
        """큐를 서버에 적재한다. 2단계 — ① payload 준비(병렬), ② batch ingest(청크).

        진행 표시(`verbose=True`):
        - **Preparing** 바 — payload 준비 진행.
        - **Ingesting** 바 — 실제 적재 진행. postfix로 `ok`/`fail` 누계 + 현재 항목(id/파일명).
        - `item_log=True`면 항목마다 한 줄씩(`✓ <sample_id>  <파일명>` / `✗ <파일명>: <error>`)
          바를 깨지 않고 출력한다(대량 적재 시엔 로그가 많아지니 필요할 때만).
        """
        queue = self._queue[:]
        self._queue.clear()

        results: list[IngestResult] = []
        prepared: list[tuple] = []  # (sample, payload)

        # Phase 1: build payloads in parallel.
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {pool.submit(self._prepare_payload, s): s for s in queue}
            for future in tqdm(
                as_completed(futures), total=len(futures),
                desc="Preparing", disable=not verbose,
            ):
                s = futures[future]
                try:
                    prepared.append((s, future.result()))
                except Exception as e:
                    results.append(IngestResult(ok=False, sample=s, error=str(e)))
                    if item_log:
                        tqdm.write(f"  FAIL {_sample_label(s)}: prepare 실패: {e}")

        # Phase 2: batch-ingest prepared payloads in chunks — **청크를 병렬 POST**.
        # 서버 get_or_create_dataset/version이 ON CONFLICT DO NOTHING이라 동시 ingest가 안전.
        # (직렬 POST는 건당 tx의 DB 왕복 지연이 그대로 곱해져 대량 적재의 병목이었다.)
        ok_n = fail_n = 0
        bar = tqdm(total=len(prepared), desc="Ingesting", disable=not verbose)

        def _record(r: IngestResult) -> None:  # 메인 스레드에서만 호출 → 락 불필요
            nonlocal ok_n, fail_n
            results.append(r)
            if r.ok:
                ok_n += 1
                if item_log:
                    tqdm.write(f"  OK {r.sample_id}  {_sample_label(r.sample)}")
            else:
                fail_n += 1
                if item_log:
                    tqdm.write(f"  FAIL {_sample_label(r.sample)}: {r.error}")
            bar.set_postfix(ok=ok_n, fail=fail_n, cur=_sample_label(r.sample), refresh=False)
            bar.update(1)

        def _ingest_chunk(chunk: list) -> list[IngestResult]:  # 워커 스레드: 네트워크만
            payloads = [p for (_, p) in chunk]
            try:
                resp = self._client.ingest_batch(payloads)
                by_index = {r["index"]: r for r in resp.get("results", [])}
            except Exception as e:
                # whole-request failure → every item in this chunk failed
                return [IngestResult(ok=False, sample=s, error=str(e)) for (s, _) in chunk]
            out: list[IngestResult] = []
            # chunk의 각 항목을 반드시 1개 결과로 매핑 (len(results) == len(prepared) 보장).
            for pos, (s, _) in enumerate(chunk):
                item = by_index.get(pos)
                if item is None:
                    out.append(IngestResult(ok=False, sample=s, error="batch 응답에 해당 item 결과 없음"))
                elif item.get("error"):
                    out.append(IngestResult(ok=False, sample=s, error=item["error"]))
                else:
                    out.append(IngestResult(ok=True, sample=s, sample_id=item.get("sample_id")))
            return out

        chunks = [prepared[i:i + batch_size] for i in range(0, len(prepared), batch_size)]
        if chunks:
            with ThreadPoolExecutor(max_workers=workers) as pool:
                for future in as_completed([pool.submit(_ingest_chunk, c) for c in chunks]):
                    for r in future.result():  # 메인 스레드에서 집계 → thread-safe
                        _record(r)

        bar.close()
        if verbose:
            tqdm.write(f"[flush] {ok_n} ok, {fail_n} fail (총 {len(results)})")

        if strict:
            failures = [r for r in results if not r.ok]
            if failures:
                raise NexusBatchError(failures)
        return results

    def delete(
        self, *, confirm: "str | bool | None" = None,
        delete_cas: "bool | None" = None, verbose: bool = True,
    ) -> dict:
        """이 **version 하나**를 hard-delete한다. **삭제 후 남은 버전이 0개면 dataset도 함께 삭제.**

        이 version의 override instances·sample 링크·**이 version에만 있던 sample**(+instances/
        assets)·미참조 CAS object를 제거한다. 다른 version/dataset과 공유된 sample은 보존,
        sealed 스냅샷 샤드는 GC 안 함.

        **sealed 버전은 삭제할 수 없다**(영구 보존 대상 — 예외 없음, 이 버전이 dataset의 마지막
        버전이라 dataset까지 같이 지워지는 경우도 포함). `NexusError(status_code=409)`.

        - `confirm`: `"<버전 문자열>"` 또는 `True`(=`self._version`). **`None`(기본)이면 대화형으로
          확인**(비대화형이면 에러 — 실수로 삭제 방지).
        - `delete_cas`: `True`/`False`, 또는 `None`이면 대화형 확인(비대화형이면 False=CAS 보존).
        반환: `{dataset_id, version, samples_deleted, cas_objects_deleted, dataset_deleted}`.
        """
        if confirm is True:
            ver = self._version
        elif isinstance(confirm, str) and confirm:
            ver = confirm
        elif confirm is None:
            ans = _prompt(
                f"version '{self._version}' 을 삭제합니다"
                f"(마지막 버전이면 dataset도 함께 삭제). 진행할까요? [y/N]: "
            )
            if ans is None:  # 진짜 비대화형(입력 불가) — 실수 삭제 방지
                raise ValueError(
                    "delete()는 confirm=<버전 문자열> 또는 confirm=True 가 필요합니다(비대화형)"
                )
            if ans.strip().lower() not in ("y", "yes"):
                if verbose:
                    tqdm.write("[delete] 취소됨")
                return {"cancelled": True}
            ver = self._version
        else:
            raise ValueError("confirm은 <버전 문자열> / True / None 이어야 합니다")

        dc = _resolve_delete_cas(delete_cas, f"version '{self._version}'")
        with _spinner(f"[delete] version '{self._version}' 삭제 중", disable=not verbose):
            out = self._client.delete_version(self._dataset_id, self._version, ver, delete_cas=dc)
        if verbose:
            extra = " (+dataset 삭제)" if out.get("dataset_deleted") else ""
            tqdm.write(
                f"[delete] version '{self._version}' 삭제 완료{extra} - "
                f"samples={out.get('samples_deleted')}, "
                f"cas={out.get('cas_objects_deleted')}"
            )
        return out

    def seal(self, *, if_sealed: str = "error") -> dict:
        """이 버전을 **seal**(불변 스냅샷)한다 — 단방향.

        seal 시 서버가 annotation을 NDJSON 샤드로 CAS에 박제하고 manifest hash를 기록한다.
        이후 이 버전엔 ingest/patch/add가 막히고(409), `to_df()`가 읽을 수 있게 된다.

        - `if_sealed="error"`(기본): 이미 sealed면 서버 409를 그대로 전파.
        - `if_sealed="ignore"`: 이미 sealed면 현재 버전 상태를 반환(멱등, 노트북 재실행에 편리).

        반환: sealed DatasetVersion dict.
        """
        import requests

        try:
            return self._client.seal(self._dataset_id, self._version)
        except NexusError as e:
            if if_sealed == "ignore" and e.status_code == 409:
                return self._client.get_version(self._dataset_id, self._version)
            raise

    def to_df(
        self,
        groups: "list[str] | None" = None,
        *,
        path: "str | Path | None" = None,
        format: "str | None" = None,
        chunksize: "int | None" = None,
    ) -> "pd.DataFrame":
        """sealed 버전의 GT annotation 스냅샷(NDJSON)을 그대로 DataFrame으로 로드한다.

        각 행 = NDJSON 한 줄 = ``{sample_id, meta, <group_key>: [instances...], ...}``.
        이미지 경로 등 부가정보는 ``meta``(특히 ``meta.filename`` = 이미지 URL)에 담겨 있다.

        - ``groups=None``: 모든 group_key를 그대로 싣는다(NDJSON 원형).
        - ``groups=[...]``: 지정한 group_key만 싣는다(+ ``sample_id``, ``meta``).
        - ``path=``: 주면 결과를 파일로도 저장한다. ``format`` 생략 시 확장자로 추론
          (``csv`` / ``json`` / ``jsonl``·``ndjson`` / ``parquet``). DataFrame은 그대로 반환.
        - ``chunksize=N``: DataFrame **하나** 대신 ``≤N`` 행 DataFrame들의 **이터레이터**를 반환한다
          (샤드 단위로 지연 다운로드 → 메모리 ≈ 한 청크). 대규모 데이터셋용.
          (``pandas.read_csv(chunksize=)`` 와 동일한 관용구. ``path``와 함께 쓸 수 없다.)
        - **sealed 버전 필요** — annotation 스냅샷은 seal 시 생성된다(없으면 ``NexusError``).
        """
        try:
            import pandas as pd
        except ImportError:
            raise ImportError(
                "pandas is required for to_df(). "
                "Install with: pip install 'nexus-sdk[pandas]'"
            )
        import requests as _req

        manifest = self._client.get_manifest(self._dataset_id, self._version)
        snapshot = manifest.get("annotation_snapshot")
        if not snapshot or not snapshot.get("cas_url"):
            raise NexusError(
                "to_df()는 sealed 버전이 필요합니다 — annotation 스냅샷이 없습니다. "
                "ds.seal() 후 다시 시도하세요."
            )
        shard_manifest = _req.get(snapshot["cas_url"], timeout=30).json()

        if chunksize is not None:
            if chunksize <= 0:
                raise ValueError("chunksize는 양의 정수여야 합니다.")
            if path is not None:
                raise ValueError(
                    "chunksize와 path는 함께 쓸 수 없습니다 — 청크를 순회하며 직접 저장하세요."
                )
            return self._iter_df_chunks(shard_manifest, groups, chunksize)

        df = pd.DataFrame(list(self._stream_gt(shard_manifest, groups)))
        if path is not None:
            _write_dataframe(df, path, format)
        return df

    def _stream_gt(self, shard_manifest: dict, groups: "list[str] | None"):
        """샤드를 하나씩 다운로드하며 NDJSON 행(dict)을 yield한다. 메모리 = 샤드 1개."""
        import requests as _req

        for shard in shard_manifest.get("shards", []):
            r = _req.get(shard["url"], timeout=120)
            r.raise_for_status()
            for line in r.text.splitlines():
                line = line.strip()
                if not line:
                    continue
                obj = json.loads(line)
                if groups is not None:
                    obj = {
                        "sample_id": obj.get("sample_id"),
                        "meta": obj.get("meta"),
                        **{g: obj.get(g) for g in groups},
                    }
                yield obj

    def _iter_df_chunks(self, shard_manifest: dict, groups, chunksize: int):
        import pandas as pd

        batch: list[dict] = []
        for obj in self._stream_gt(shard_manifest, groups):
            batch.append(obj)
            if len(batch) >= chunksize:
                yield pd.DataFrame(batch)
                batch = []
        if batch:
            yield pd.DataFrame(batch)

    def _prepare_payload(self, sample: Sample) -> dict:
        ann_spec = self._resolve_annotation(sample._annotation_ref)

        if sample._image_ref is not None:
            image_ref = sample._image_ref
        else:
            ann_src = str(sample._annotation_ref)
            ann_data = ann_spec.get("annotation_data") or {}
            meta = ann_data.get("meta")
            filename = (meta or {}).get("filename")
            if not filename:
                raise NexusCasError(
                    f"[{ann_src}] image 미지정 + annotation meta.filename 없음 — "
                    "Sample(image=ref) 또는 meta.filename(CAS URL)을 지정하세요."
                )
            image_ref = _parse_ref(filename)
            if not isinstance(image_ref, CasRef):
                raise NexusCasError(
                    f"[{ann_src}] meta.filename은 CAS URL이어야 합니다 (s3://·http(s)://). "
                    "로컬 경로는 nx.upload 후 ref를 쓰세요."
                )

        image_spec = self._resolve_asset(image_ref)
        ann_spec = self._ensure_meta(ann_spec, image_ref, image_spec)

        payload: dict = {
            "dataset": self._name,
            "version": self._version,
            "split": sample.split,
            "tags": sample.tags or None,
            "image": image_spec,
            "annotation": ann_spec,
        }
        if sample._asset_refs:
            payload["assets"] = {
                role: self._resolve_asset(ref) for role, ref in sample._asset_refs.items()
            }
        return payload

    def _resolve_asset(self, ref: CasRef) -> dict:
        """CAS ref → ingest asset spec. 리치 CasRef(업로드 출력)는 신뢰, bare는 HEAD."""
        if ref.hash_hex is not None and ref.size is not None and ref.content_type is not None:
            return {
                "bucket": ref.bucket,
                "key": ref.key,
                "size": ref.size,
                "content_type": ref.content_type,
                "logical_name": ref.key.split("/")[-1],
                "hash_hex": ref.hash_hex,
            }
        info = self._cas.head(ref.bucket, ref.key)
        if info is None:
            raise NexusCasError(
                f"CAS object 없음: bucket='{ref.bucket}', key='{ref.key}' — "
                "nx.upload로 먼저 올렸는지 확인하세요."
            )
        return {
            "bucket": ref.bucket,
            "key": ref.key,
            "size": info["size"],
            "content_type": info["content_type"],
            "logical_name": ref.key.split("/")[-1],
            "hash_hex": info.get("hash_hex"),
        }

    def _resolve_annotation(self, ref: "dict | FileRef | None") -> dict:
        """Annotation을 inline JSON dict로 변환. CAS에 업로드하지 않음."""
        if ref is None:
            return {"annotation_data": None}
        if isinstance(ref, dict):
            return {"annotation_data": ref}
        if isinstance(ref, CasRef):
            import requests as _req
            url = f"{self._cas._base}/{ref.bucket}/{ref.key}"
            r = _req.get(url, timeout=30)
            r.raise_for_status()
            return {"annotation_data": r.json()}
        path = Path(ref)
        return {"annotation_data": json.loads(path.read_bytes())}

    def _ensure_meta(self, ann_spec: dict, image_ref: "FileRef", image_spec: dict) -> dict:
        """annotation의 meta 처리. 사용자 입력을 신뢰하고 관여하지 않는 것이 원칙이다.

        - meta가 있으면(값이 None이 아니면) **그대로 신뢰** — 어떤 필드도 수정하지 않는다.
        - meta가 없으면 최소 meta만 생성한다: `filename`=실제 CAS URL, `format_version`="1.0.0",
          `width`/`height`는 `CasRef`에 업로드 시점에 담아둔 dims가 있으면 사용(이미지를 다시
          읽지 않음), 없으면(bare ref 등) 0. (조회 시 image_url/thumbnail_url이 별도로 제공된다.)
        """
        ann_data: dict = ann_spec.get("annotation_data") or {}
        if ann_data.get("meta") is not None:
            return ann_spec  # 사용자가 준 meta를 그대로 사용
        w = image_ref.width if isinstance(image_ref, CasRef) else None
        h = image_ref.height if isinstance(image_ref, CasRef) else None
        ann_data = dict(ann_data)
        ann_data["meta"] = {
            "format_version": "1.0.0",
            "filename": f"{self._cas._base}/{image_spec['bucket']}/{image_spec['key']}",
            "width": w if w is not None else 0,
            "height": h if h is not None else 0,
        }
        return {"annotation_data": ann_data}

    def __enter__(self) -> "Dataset":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        if exc_type is None:
            self.flush()


class Subset:
    """서브셋 = 저장된 explorer 필터(뷰). ``ds.create_subset()``/``ds.list_subsets()``가 반환.

    version(스냅샷)과 직교하는 슬라이스 축. 재현성은 seal이 담당 — sealed version 위 필터는
    결정적이라 ``to_df()``(sealed 전용)가 재현 export가 된다.
    """

    def __init__(self, ds: "Dataset", d: dict) -> None:
        self._ds = ds
        self._client = ds._client
        self._raw = d
        self.subset_id: str = d["subset_id"]
        self.name: str = d["name"]
        self.version: str = d["version"]
        self.filter: dict = d.get("filter_json") or {}

    def __repr__(self) -> str:
        return f"Subset(name={self.name!r}, version={self.version!r}, id={self.subset_id})"

    def samples(
        self, *, include_annotations: "bool | None" = None,
        page_size: int = 1000, max_samples: "int | None" = None,
    ) -> list[dict]:
        """서브셋 필터를 resolve해 샘플을 반환(커서 자동 페이지네이션). explorer와 동일 형식."""
        out: list[dict] = []
        cursor = None
        while True:
            page = self._client.subset_samples(
                self.subset_id, cursor=cursor, limit=page_size,
                include_annotations=include_annotations,
            )
            out.extend(page)
            if len(page) < page_size or (max_samples and len(out) >= max_samples):
                break
            cursor = page[-1]["sample_id"]
        return out[:max_samples] if max_samples else out

    def update(self, *, name: "str | None" = None, filter: "dict | None" = None) -> "Subset":
        """이름/필터 수정(제공한 것만)."""
        self._raw = self._client.update_subset(self.subset_id, name=name, filter=filter)
        self.name = self._raw["name"]
        self.filter = self._raw.get("filter_json") or {}
        return self

    def delete(self) -> None:
        """서브셋 삭제(뷰만 삭제 — 샘플/데이터 무관)."""
        self._client.delete_subset(self.subset_id)

    def to_version(self, version: str) -> "Dataset":
        """서브셋을 **새 버전으로 물질화**(뷰 → 재현 스냅샷). 필터를 resolve한 샘플만 담은
        새 버전을 만들고(필터링된 fork, 라벨은 서브셋 version에서 복제), 그 버전을 가리키는
        Dataset 핸들을 반환한다 — 이어서 patch/추가/seal 가능. 0개 resolve면 에러."""
        ver = self._client.materialize_subset(self.subset_id, version)
        return Dataset(
            self._client, self._ds._cas, self._ds._dataset_id, self._ds._name,
            ver["version"],
        )

    def to_df(self, groups: "list[str] | None" = None):
        """서브셋을 DataFrame으로 (**재현 export**). **sealed version 필요**(재현 정책).

        서브셋 샘플만 resolve해 DataFrame을 만든다 — 버전 전체 NDJSON 샤드를 받지 않는다(Phase 2
        최적화). sealed 버전은 live resolve == 박제 스냅샷이라 결과 동일. `ds.to_df`와 같은 shape
        (`sample_id`/`meta`/`<group_key>`)로 맞춘다.
        """
        import pandas as pd

        ver = self._client.get_version(self._ds._dataset_id, self.version)
        if not ver or ver.get("status") != "sealed":
            raise NexusError(
                f"subset.to_df()는 sealed version에서만 가능합니다(재현 export). "
                f"'{self.version}'를 seal 후 사용하세요."
            )
        rows = self.samples(include_annotations=True)   # 서브셋 샘플만 (평탄 GT)
        df = pd.DataFrame(rows)
        # ds.to_df와 동일 shape: 스냅샷 컬럼(sample_id, meta, <group_key>)만 — 프론트/코어 필드 제거.
        drop = {"split", "tags", "created_at", "image_url", "thumbnail_url"}
        df = df[[c for c in df.columns if c not in drop]]
        if groups is not None:
            keep = ["sample_id", "meta", *groups]
            df = df[[c for c in keep if c in df.columns]]
        return df.reset_index(drop=True)
