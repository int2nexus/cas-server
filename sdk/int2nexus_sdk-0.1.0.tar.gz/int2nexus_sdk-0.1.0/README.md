# int2nexus-sdk

Python SDK for uploading ML training data to a nexus-server instance. (배포명 `int2nexus-sdk`, import는 `import nexus`.)

## Installation

공개 인덱스(PEP 503)에서 설치:

```bash
pip install --extra-index-url https://int2nexus.github.io/cas-server/sdk/simple/ int2nexus-sdk
```

- 배포명은 `int2nexus-sdk`지만 **import는 `import nexus`** 다. (PyPI의 동명 `nexus-sdk`와 충돌을 피하려 배포명을 네임스페이스화했다.)
- `--extra-index-url`(≠ `--index-url`): `int2nexus-sdk`는 위 인덱스에서, 의존성은 PyPI에서 받습니다.
- 버전 고정: `int2nexus-sdk==0.0.1`.
- 개발 설치(소스): `pip install -e ./sdk`.

## Quick Start

### Environment Variables

```bash
export NEXUS_URL=http://localhost:8090
export NEXUS_EMAIL=user@example.com
export NEXUS_PASSWORD=secret
export CAS_URL=http://localhost:8080
export CAS_KEY_ID=mykey
export CAS_SECRET=mysecret
```

### Upload

Ingest is **2-phase**: first upload the image bytes to CAS (`nx.upload`), then register the
returned refs as samples (`nx.Sample` + `flush`).

```python
import nexus as nx

nx.connect()

# Phase 1 — data plane: upload local files to CAS (parallel, idempotent, +WebP thumbnail)
refs = nx.upload([img1, img2], bucket="kitti", prefix="images")   # {path: CasRef}

# Phase 2 — catalog: register the refs as samples
with nx.Dataset.load_or_create("kitti-mini", version="v1", tags=["3d_detection"]) as ds:
    for img_path, ann_path in pairs:
        ds.add(nx.Sample(
            image=refs[img_path],   # CAS ref (not a local path)
            annotation=ann_path,    # local JSON path / dict / URL
            split="train",
        ))
# flush() called automatically on __exit__
```

### Manual flush

```python
refs = nx.upload([img for img, _ in pairs], bucket="kitti", prefix="images")

ds = nx.Dataset.load_or_create("kitti-mini", version="v1")
ds.add([nx.Sample(image=refs[img], annotation=ann) for img, ann in pairs])

results = ds.flush(workers=8, strict=False)
failures = [r for r in results if not r.ok]
```

### Explicit connection

```python
nx.connect(
    nexus_url="http://localhost:8090",
    email="user@example.com",
    password="secret",
    cas_url="http://localhost:8080",
    cas_key_id="mykey",
    cas_secret="mysecret",
)
```

### Fork a version

```python
ds = nx.Dataset.load_or_create("kitti-mini", version="v1.1", fork_from="v1.0")
```

### Link existing samples (without ingest)

```python
ds.link_samples(["0192f0a1-...", "0192f0a1-..."])
```

### Convert sealed version to DataFrame

```python
import nexus as nx

nx.connect()
ds = nx.Dataset.load_or_create("kitti-mini", version="v1")

# all samples
df = ds.to_df()

# train split only
df_train = ds.to_df(split="train")

# only samples that have a 'sedan' instance
df_sedan = ds.to_df(label="sedan")

# include instances column (downloads annotation NDJSON snapshot)
df_full = ds.to_df(labels=True)
# df_full["labels"] → list of instance dicts per row
```

## API Reference

### `nexus.connect()`

Authenticates against nexus-server and initializes the module-level client. Must be called before using `Dataset` unless all environment variables are set (in which case the first API call triggers auto-connect).

### `nexus.upload(paths, bucket, prefix="", *, workers=8, verbose=True, strict=False)`

Uploads local files to CAS and returns `{path: CasRef}`, mapping each input path to its
`CasRef` (which carries `bucket` / `key` / `hash_hex` / `size` / `content_type`). This is
**phase 1** of ingest — pass the returned refs to `nx.Sample(image=...)`.

```python
refs = nx.upload(
    ["data/img001.png", "data/img002.png"],
    bucket="kitti",
    prefix="images",   # CAS key = "{prefix}/{filename}"
    workers=8,         # parallel uploads
)
ref = refs["data/img001.png"]   # CasRef(bucket="kitti", key="images/img001.png", ...)
```

- Uploads in parallel; idempotent — already-present objects (same key + content) are skipped.
- Generates a WebP 256px thumbnail alongside each image (best-effort).
- Re-using the same key with **different** content is a per-file failure (collision).
- Transient network/5xx errors are retried with backoff at the transport layer. Per-file failures are **isolated** (one bad file doesn't abort the batch) — only successes are returned. `strict=True` raises `NexusCasError` if any file failed; default `strict=False` warns. Re-running `nx.upload` with the same paths resumes (already-uploaded files are skipped).

### `nexus.Sample`

```python
nx.Sample(
    image=ref,                       # CAS ref ONLY: a CasRef (from nx.upload) or s3://·http(s):// URL
    annotation="data/ann001.json",  # local JSON path / dict (inline GT) / URL
    assets={"depth": depth_ref},     # optional extra assets, {role: ref} — same rules as image
    split="train",                  # optional
    tags=["rainy", "night"],        # optional
)
```

`image` and every value in `assets` accept **CAS refs only** — a `CasRef` returned by
`nx.upload`, or an `s3://bucket/key` / `http(s)://…` URL. **Local file paths raise `ValueError`**
— upload them with `nx.upload` first. For URL refs the SDK uses a CAS HEAD to retrieve metadata.
`"image"` is a reserved key in `assets` (raises `ValueError`) — use the `image=` parameter instead.
`annotation` still accepts a local JSON path, a dict (inline GT), or a URL.

### `nexus.Dataset.load_or_create(name, version, ...)`

Finds an existing dataset+version by name or creates it. Idempotent.

```python
nx.Dataset.load_or_create(
    name: str,
    version: str,
    tags: list[str] | None = None,       # dataset tags, applied on create
    description: str | None = None,
    fork_from: str | None = None,        # version to fork from on create
)
```

### `Dataset.link_samples(sample_ids)`

Links already-ingested samples to this version without re-ingesting them.

### `Dataset.flush(workers=4, strict=False, verbose=True, batch_size=256)`

Prepares the registration payloads from the queued samples' refs (no upload — uploads happen
earlier in `nx.upload`), then sends them to the server's `/ingest/batch` endpoint in chunks of
`batch_size`. Returns `list[IngestResult]`.

- `strict=True` raises `NexusBatchError` on first failure; `error.failures` contains the failed results.
- `strict=False` (default) records failures in results and continues.

### `Dataset.to_df(split=None, label=None, labels=False, workers=4)`

Downloads manifest metadata and pages through the paginated `/manifest/samples` endpoint, returning a `pandas.DataFrame`. Requires a **sealed** version (raises `NexusError` on draft).

| Column | Description |
|--------|-------------|
| `sample_id` | UUID v7 string |
| `split` | `train` / `val` / `test` / `None` |
| `image_cas_url` | Direct CAS URL for the image |
| `image_hash_hex` | BLAKE3 hash |
| `image_size` | bytes |
| `labels` | `list[dict]` of instances (only when `labels=True`) |

### `nexus.IngestResult`

```python
@dataclass
class IngestResult:
    ok: bool
    sample: Sample | None
    sample_id: str | None  # set on success
    error: str | None      # set on failure
```

## Error Handling

| Exception | Trigger |
|---|---|
| `NexusAuthError` | Login failure or token expired |
| `NexusCasError` | CAS upload/HEAD failure |
| `NexusIngestError` | Server ingest failure (4xx/5xx) |
| `NexusBatchError` | `strict=True` and one or more samples failed |

## Development

```bash
pip install -e "./sdk[dev]"
pytest sdk/tests/ -v
```
