import pytest
from nexus.client import NexusClient
from nexus._types import NexusAuthError, NexusIngestError, NexusError

NEXUS = "http://nexus-test"


@pytest.fixture
def logged_in(requests_mock):
    requests_mock.post(f"{NEXUS}/api/v1/auth/login",
                       json={"token": "tok123", "user_id": 1, "email": "u@x.com"})
    return NexusClient(NEXUS, "u@x.com", "pass")


def test_login_stores_token(requests_mock):
    requests_mock.post(f"{NEXUS}/api/v1/auth/login",
                       json={"token": "mytoken", "user_id": 1, "email": "u@x.com"})
    client = NexusClient(NEXUS, "u@x.com", "pass")
    assert client._token == "mytoken"
    assert client._session.headers["Authorization"] == "Bearer mytoken"


def test_login_failure_raises_auth_error(requests_mock):
    requests_mock.post(f"{NEXUS}/api/v1/auth/login", status_code=401,
                       json={"error": "invalid credentials"})
    with pytest.raises(NexusAuthError):
        NexusClient(NEXUS, "u@x.com", "wrong")


def test_list_datasets(logged_in, requests_mock):
    requests_mock.get(f"{NEXUS}/datasets",
                      json=[{"dataset_id": "d1", "name": "kitti"}])
    result = logged_in.list_datasets()
    assert result[0]["name"] == "kitti"


def test_create_dataset(logged_in, requests_mock):
    requests_mock.post(f"{NEXUS}/datasets",
                       json={"dataset_id": "d2", "name": "new-ds"}, status_code=201)
    result = logged_in.create_dataset("new-ds", tags=["detection"])
    assert result["dataset_id"] == "d2"


def test_create_dataset_coerces_str_tag_to_list(logged_in, requests_mock):
    # tags="x" 문자열을 넘기면 ["x"] 배열로 변환해 보낸다 (서버는 배열을 기대).
    requests_mock.post(f"{NEXUS}/datasets",
                       json={"dataset_id": "d3", "name": "ds"}, status_code=201)
    logged_in.create_dataset("ds", tags="tutorial")
    assert requests_mock.last_request.json()["tags"] == ["tutorial"]


def test_get_version_returns_none_on_404(logged_in, requests_mock):
    requests_mock.get(f"{NEXUS}/datasets/d1/versions/v1", status_code=404)
    assert logged_in.get_version("d1", "v1") is None


def test_get_version_returns_dict_when_found(logged_in, requests_mock):
    requests_mock.get(f"{NEXUS}/datasets/d1/versions/v1",
                      json={"dataset_version_id": "dv1", "version": "v1"})
    result = logged_in.get_version("d1", "v1")
    assert result["version"] == "v1"


def test_ingest_raises_on_http_error(logged_in, requests_mock):
    requests_mock.post(f"{NEXUS}/ingest", status_code=400,
                       json={"error": "bad request"})
    with pytest.raises(NexusIngestError):
        logged_in.ingest({"dataset": "x", "version": "v1", "image": {}, "annotation": {}})


def test_ingest_returns_response(logged_in, requests_mock):
    requests_mock.post(f"{NEXUS}/ingest", status_code=201,
                       json={"sample_id": "s1", "dataset_id": "d1", "version": "v1"})
    result = logged_in.ingest({"dataset": "kitti", "version": "v1"})
    assert result["sample_id"] == "s1"


def test_list_sample_ids_by_label_keyset_pages(logged_in, requests_mock):
    # limit는 client 내부에서 1000으로 고정. 첫 페이지는 1000개(가득) → 계속,
    # 둘째 페이지는 1000개 미만 → 종료. sample_id는 DESC 총순서이므로 페이지의
    # 마지막 row가 다음 cursor가 된다.
    limit = 1000
    # DESC 순서를 모사: 첫 페이지 id는 큰 값, 둘째 페이지 id는 작은 값.
    page1 = [{"sample_id": f"s{9000 - i}"} for i in range(limit)]
    page2 = [{"sample_id": f"s{500 - i}"} for i in range(3)]
    seen_cursors: list[str | None] = []
    bodies: list[dict] = []

    def responder(request, context):
        body = request.json()  # POST explorer body
        bodies.append(body)
        cursor = body.get("cursor")
        seen_cursors.append(cursor)
        context.status_code = 200
        return page1 if cursor is None else page2

    requests_mock.post(
        f"{NEXUS}/datasets/d1/versions/v1/samples/explorer", json=responder
    )

    ids = logged_in.list_sample_ids_by_label("d1", "v1", "car")

    # 두 번 요청: 첫 요청은 cursor 없음, 둘째 요청은 page1의 마지막 sample_id를 cursor로.
    assert seen_cursors == [None, page1[-1]["sample_id"]]
    # label은 annotation 매처로 전달, 경량 조회(include_annotations=False).
    assert bodies[0]["annotation"] == [{"label": "car"}]
    assert bodies[0]["include_annotations"] is False
    # 결과는 두 페이지 id의 합집합.
    expected = {s["sample_id"] for s in page1} | {s["sample_id"] for s in page2}
    assert ids == expected


def test_get_sample(logged_in, requests_mock):
    requests_mock.get(
        f"{NEXUS}/datasets/d1/versions/v1/samples/s1",
        json={
            "sample_id": "s1", "split": "train", "tags": [],
            "meta": {"filename": "img"},
            "road_obj_ma": [{"id": "b", "label": "sedan"}],
        },
    )
    out = logged_in.get_sample("d1", "v1", "s1")
    assert out["sample_id"] == "s1"
    assert out["road_obj_ma"][0]["label"] == "sedan"


def test_get_sample_404_raises(logged_in, requests_mock):
    requests_mock.get(f"{NEXUS}/datasets/d1/versions/v1/samples/nope",
                      status_code=404, json={"error": "not found"})
    with pytest.raises(NexusError):
        logged_in.get_sample("d1", "v1", "nope")


def test_list_datasets_with_filters(logged_in, requests_mock):
    requests_mock.get(f"{NEXUS}/datasets", json=[])
    logged_in.list_datasets(name="kit", tags=["a", "b"], sort="name", order="asc")
    q = requests_mock.last_request.qs
    assert q["name"] == ["kit"]
    assert q["tags"] == ["a,b"]
    assert q["sort"] == ["name"]
    assert q["order"] == ["asc"]


def test_list_versions(logged_in, requests_mock):
    requests_mock.get(f"{NEXUS}/datasets/d1/versions",
                      json=[{"version": "v1"}, {"version": "v2"}])
    vers = logged_in.list_versions("d1")
    assert [v["version"] for v in vers] == ["v1", "v2"]


def test_remove_sample_ids(logged_in, requests_mock):
    requests_mock.delete(f"{NEXUS}/datasets/d1/versions/v1/samples", json={"removed": 2})
    out = logged_in.remove_sample_ids("d1", "v1", ["s1", "s2"])
    assert out["removed"] == 2
    assert requests_mock.last_request.json() == {"sample_ids": ["s1", "s2"]}


def test_default_timeout_set_and_sent(requests_mock):
    requests_mock.post(f"{NEXUS}/api/v1/auth/login", json={"token": "t"})
    c = NexusClient(NEXUS, "u@x.com", "pass")
    assert c._timeout == (10.0, 120.0)              # 기본 (connect, read)
    requests_mock.get(f"{NEXUS}/datasets", json=[])
    c.list_datasets()
    assert requests_mock.last_request.timeout == (10.0, 120.0)


def test_custom_timeout(requests_mock):
    requests_mock.post(f"{NEXUS}/api/v1/auth/login", json={"token": "t"})
    c = NexusClient(NEXUS, "u@x.com", "pass", timeout=5)
    assert c._timeout == 5
