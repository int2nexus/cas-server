# int2nexus-sdk

Python SDK for uploading ML training data to a nexus-server instance. (배포명 `int2nexus-sdk`, import는 `import nexus`.)

## Installation

공개 인덱스(PEP 503)에서 설치:

```bash
pip install --extra-index-url https://int2nexus.github.io/cas-server/sdk/simple/ int2nexus-sdk
```

- 배포명은 `int2nexus-sdk`지만 **import는 `import nexus`** 다. (PyPI의 동명 `nexus-sdk`와 충돌을 피하려 배포명을 네임스페이스화했다.)
- `--extra-index-url`(≠ `--index-url`): `int2nexus-sdk`는 위 인덱스에서, 의존성은 PyPI에서 받습니다.
- 버전 고정: `int2nexus-sdk==0.1.1`.
- 개발 설치(소스): `pip install -e ./sdk`.

## Quick Start

### 설정 파일 (권장)

`~/.int2nexus/settings.json`에 한 번 적어두면 `nx.connect()` 한 줄로 접속된다. 스크립트에 자격증명을 적지 않아도 된다.

```json
{
  "nexus_url": "http://localhost:8090",
  "email": "user@example.com",
  "password": "secret",
  "cas_url": "http://localhost:8080",
  "cas_key_id": "mykey",
  "cas_secret": "mysecret"
}
```

```bash
mkdir -p ~/.int2nexus
$EDITOR ~/.int2nexus/settings.json
chmod 600 ~/.int2nexus/settings.json     # 비밀번호·CAS secret이 들어 있다
```

- **비밀번호와 CAS secret이 평문으로 저장된다.** POSIX에서는 권한이 느슨하면 SDK가 경고한다. **Windows에서는 `chmod`가 사실상 무의미**하므로 검사하지 않는다 — 파일 위치와 접근 권한은 사용자 책임이다.
- 경로를 바꾸려면 `NEXUS_SETTINGS=/path/to/settings.json` 또는 `nx.connect(settings_path=...)`.
- `cas_key_id`/`cas_secret`/`verify`는 선택. 모르는 키는 경고한다(오타 탐지).

### 값의 우선순위

**인자 > 환경변수 > 설정 파일.** 코드에 명시한 값이 항상 이기고, CI는 환경변수로 로컬 파일을 덮을 수 있다.

```bash
export NEXUS_URL=http://localhost:8090
export NEXUS_EMAIL=user@example.com
export NEXUS_PASSWORD=secret
export CAS_URL=http://localhost:8080
export CAS_KEY_ID=mykey
export CAS_SECRET=mysecret
export NEXUS_VERIFY=true          # 선택 — false 또는 CA 번들 경로
```

### 사내 프록시 · TLS 인증서 (`verify`)

사내 보안 장비가 TLS를 검사하면 `nx.connect()`가 SSL 인증서 에러로 죽는다. 세 가지 방법이 있고, **위쪽이 안전하다.**

```python
# 1) 사내 루트 CA를 신뢰 — 검증을 유지한 채 해결(권장)
nx.connect(verify="/path/to/corp-root-ca.pem")

# 2) 환경변수 — SDK 수정/재배포 없이 오늘 바로 쓸 수 있다(requests 기본 동작)
#    export REQUESTS_CA_BUNDLE=/path/to/corp-root-ca.pem

# 3) 검증 끄기 — 최후의 수단
nx.connect(verify=False)
```

설정 파일에 적어두면 매번 넘기지 않아도 된다:

```json
{ "verify": "C:/certs/corp-root-ca.pem" }
```

- `verify`는 **nexus와 CAS 양쪽 세션**에 적용된다. `nx.upload()`는 CAS로 직접 PUT하므로 한쪽만 고치면 업로드에서 같은 에러가 다시 난다.
- CAS를 `http://`로 접속한다면 `verify`는 아무 일도 하지 않는다(TLS가 없으므로).
- `verify=False`는 **그 연결의 중간자 공격 탐지를 포기하는 것**이다. 접속 시 한 번 경고가 뜨고, 이후 요청마다 나오는 urllib3 경고는 억제된다.

### Upload

Ingest is **2-phase**: first upload the image bytes to CAS (`nx.upload`), then register the
returned refs as samples (`nx.Sample` + `flush`).

```python
import nexus as nx

nx.connect()

# Phase 1 — data plane: upload local files to CAS (parallel, idempotent, +WebP thumbnail)
refs = nx.upload([img1, img2], bucket="kitti", prefix="images")   # {path: CasRef}

# Phase 2 — catalog: register the refs as samples
with nx.Dataset.load_or_create("kitti-mini", version="v1", tags=["3d_detection"]) as ds:
    for img_path, ann_path in pairs:
        ds.add(nx.Sample(
            image=refs[img_path],   # CAS ref (not a local path)
            annotation=ann_path,    # local JSON path / dict / URL
            split="train",
        ))
# flush() called automatically on __exit__
```

### Manual flush

```python
refs = nx.upload([img for img, _ in pairs], bucket="kitti", prefix="images")

ds = nx.Dataset.load_or_create("kitti-mini", version="v1")
ds.add([nx.Sample(image=refs[img], annotation=ann) for img, ann in pairs])

results = ds.flush(workers=8, strict=False)
failures = [r for r in results if not r.ok]
```

### Explicit connection

```python
nx.connect(
    nexus_url="http://localhost:8090",
    email="user@example.com",
    password="secret",
    cas_url="http://localhost:8080",
    cas_key_id="mykey",
    cas_secret="mysecret",
    verify=True,          # 선택 — False 또는 CA 번들 경로
)
```

설정이 부족하면 **무엇이 빠졌고 어디에 넣으면 되는지**를 담은 `NexusError`가 난다(예전에는 `KeyError`였다).

### Fork a version

```python
ds = nx.Dataset.load_or_create("kitti-mini", version="v1.1", fork_from="v1.0")
```

### Link existing samples (without ingest)

```python
ds.link_samples(["0192f0a1-...", "0192f0a1-..."])
```

### Convert sealed version to DataFrame

```python
import nexus as nx

nx.connect()
ds = nx.Dataset.load_or_create("kitti-mini", version="v1")

# all samples
df = ds.to_df()

# train split only
df_train = ds.to_df(split="train")

# only samples that have a 'sedan' instance
df_sedan = ds.to_df(label="sedan")

# include instances column (downloads annotation NDJSON snapshot)
df_full = ds.to_df(labels=True)
# df_full["labels"] → list of instance dicts per row
```

## API Reference

### `nexus.connect(...)`

Authenticates against nexus-server and initializes the module-level client. 설정이 인자·환경변수·설정 파일(`~/.int2nexus/settings.json`) 중 어디에든 갖춰져 있으면 첫 API 호출이 자동으로 접속하므로, 명시적으로 부르지 않아도 된다.

```python
nx.connect(
    nexus_url=None, email=None, password=None,          # 없으면 환경변수 → 설정 파일 순으로 해소
    cas_url=None, cas_key_id=None, cas_secret=None,
    timeout=(10.0, 120.0),                              # (connect, read)
    verify=None,                                        # True(기본) | False | CA 번들 경로
    settings_path=None,                                 # 설정 파일 경로 직접 지정
)
```

### `nexus.upload(paths, bucket, prefix="", *, workers=8, verbose=True, strict=False)`

Uploads local files to CAS and returns `{path: CasRef}`, mapping each input path to its
`CasRef` (which carries `bucket` / `key` / `hash_hex` / `size` / `content_type`). This is
**phase 1** of ingest — pass the returned refs to `nx.Sample(image=...)`.

```python
refs = nx.upload(
    ["data/img001.png", "data/img002.png"],
    bucket="kitti",
    prefix="images",   # CAS key = "{prefix}/{filename}"
    workers=8,         # parallel uploads
)
ref = refs["data/img001.png"]   # CasRef(bucket="kitti", key="images/img001.png", ...)
```

- Uploads in parallel; idempotent — already-present objects (same key + content) are skipped.
- Generates a WebP 256px thumbnail alongside each image (best-effort).
- Re-using the same key with **different** content is a per-file failure (collision).
- Transient network/5xx errors are retried with backoff at the transport layer. Per-file failures are **isolated** (one bad file doesn't abort the batch) — only successes are returned. `strict=True` raises `NexusCasError` if any file failed; default `strict=False` warns. Re-running `nx.upload` with the same paths resumes (already-uploaded files are skipped).

### `nexus.Sample`

```python
nx.Sample(
    image=ref,                       # CAS ref ONLY: a CasRef (from nx.upload) or s3://·http(s):// URL
    annotation="data/ann001.json",  # local JSON path / dict (inline GT) / URL
    assets={"depth": depth_ref},     # optional extra assets, {role: ref} — same rules as image
    split="train",                  # optional
    tags=["rainy", "night"],        # optional
)
```

`image` and every value in `assets` accept **CAS refs only** — a `CasRef` returned by
`nx.upload`, or an `s3://bucket/key` / `http(s)://…` URL. **Local file paths raise `ValueError`**
— upload them with `nx.upload` first. For URL refs the SDK uses a CAS HEAD to retrieve metadata.
`"image"` is a reserved key in `assets` (raises `ValueError`) — use the `image=` parameter instead.
`annotation` still accepts a local JSON path, a dict (inline GT), or a URL.

### `nexus.Dataset.load_or_create(name, version, ...)`

Finds an existing dataset+version by name or creates it. Idempotent.

```python
nx.Dataset.load_or_create(
    name: str,
    version: str,
    tags: list[str] | None = None,       # dataset tags, applied on create
    description: str | None = None,
    fork_from: str | None = None,        # version to fork from on create
)
```

### `Dataset.link_samples(sample_ids)`

Links already-ingested samples to this version without re-ingesting them.

### `Dataset.flush(workers=4, strict=False, verbose=True, batch_size=256)`

Prepares the registration payloads from the queued samples' refs (no upload — uploads happen
earlier in `nx.upload`), then sends them to the server's `/ingest/batch` endpoint in chunks of
`batch_size`. Returns `list[IngestResult]`.

- `strict=True` raises `NexusBatchError` on first failure; `error.failures` contains the failed results.
- `strict=False` (default) records failures in results and continues.

### `Dataset.to_df(split=None, label=None, labels=False, workers=4)`

Downloads manifest metadata and pages through the paginated `/manifest/samples` endpoint, returning a `pandas.DataFrame`. Requires a **sealed** version (raises `NexusError` on draft).

| Column | Description |
|--------|-------------|
| `sample_id` | UUID v7 string |
| `split` | `train` / `val` / `test` / `None` |
| `image_cas_url` | Direct CAS URL for the image |
| `image_hash_hex` | BLAKE3 hash |
| `image_size` | bytes |
| `labels` | `list[dict]` of instances (only when `labels=True`) |

### `nexus.IngestResult`

```python
@dataclass
class IngestResult:
    ok: bool
    sample: Sample | None
    sample_id: str | None  # set on success
    error: str | None      # set on failure
```

## Error Handling

| Exception | Trigger |
|---|---|
| `NexusAuthError` | Login failure or token expired |
| `NexusCasError` | CAS upload/HEAD failure |
| `NexusIngestError` | Server ingest failure (4xx/5xx) |
| `NexusBatchError` | `strict=True` and one or more samples failed |

## Development

```bash
pip install -e "./sdk[dev]"
pytest sdk/tests/ -v
```
