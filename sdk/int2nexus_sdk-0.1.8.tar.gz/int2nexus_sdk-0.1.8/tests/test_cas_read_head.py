from unittest.mock import MagicMock


class _Resp:
    """requests.Response 대역. stream=True + iter_content + close만 흉내낸다."""

    def __init__(self, status, headers, body):
        self.status_code = status
        self.headers = headers
        self.text = ""
        self._body = body
        self.closed = False
        self.read_bytes = 0
        # iter_content 제너레이터가 range를 다 돌고 자연스럽게 끝났는지 여부.
        # break로 중간에 버려지면 이 줄까지 실행되지 않는다 — F3 회귀(early break) 검증용.
        self.exhausted = False

    @property
    def ok(self):
        return self.status_code < 400

    def iter_content(self, n):
        for i in range(0, len(self._body), n):
            piece = self._body[i:i + n]
            self.read_bytes += len(piece)
            yield piece
        self.exhausted = True

    def close(self):
        self.closed = True


def _cas(resp):
    from nexus.cas import CasClient
    c = CasClient("http://cas:8080", key_id="k", secret="s")
    c._session = MagicMock()
    c._session.get.return_value = resp
    return c


def test_read_head_range_supported_206():
    resp = _Resp(206,
                 {"content-range": "bytes 0-63/500000",
                  "x-cas-hash": "abc123",
                  "content-type": "image/png"},
                 b"X" * 64)
    c = _cas(resp)

    got = c.read_head("incabin", "a.png", 64)

    assert got["data"] == b"X" * 64
    assert got["size"] == 500000        # Content-Range의 전체 크기
    assert got["hash_hex"] == "abc123"
    assert got["content_type"] == "image/png"
    assert resp.closed
    # Range 헤더를 보냈고, 서명 헤더도 함께 갔다.
    sent = c._session.get.call_args[1]["headers"]
    assert sent["Range"] == "bytes=0-63"
    assert "Authorization" in sent and "x-amz-date" in sent


def test_read_head_range_ignored_200_stops_early():
    # Range를 무시하고 200으로 전체를 보내는 CAS에서도 예산만큼만 읽고 끊는다.
    body = b"Y" * 500000
    resp = _Resp(200, {"content-length": "500000", "content-type": "image/png"}, body)
    c = _cas(resp)

    got = c.read_head("incabin", "a.png", 64)

    assert got["data"] == b"Y" * 64
    assert got["size"] == 500000
    assert got["hash_hex"] is None
    assert resp.closed
    assert resp.read_bytes < 500000     # 전체를 다 읽지 않았다


def test_read_head_returns_none_on_404():
    c = _cas(_Resp(404, {}, b""))
    assert c.read_head("incabin", "missing.png", 64) is None


def test_read_head_raises_on_500():
    import pytest
    from nexus._types import NexusCasError
    c = _cas(_Resp(500, {}, b""))
    with pytest.raises(NexusCasError):
        c.read_head("incabin", "a.png", 64)


def test_read_head_falls_back_to_etag_when_no_cas_hash():
    # head()는 x-cas-hash가 없으면 ETag로 폴백한다(따옴표 벗기고) — read_head도 같아야
    # flush가 리치 ref로 HEAD 왕복을 건너뛴다. x-cas-hash가 아예 없는 배치를 흉내낸다.
    resp = _Resp(206,
                 {"content-range": "bytes 0-63/500000",
                  "ETag": '"abc123"',
                  "content-type": "image/png"},
                 b"X" * 64)
    c = _cas(resp)

    got = c.read_head("incabin", "a.png", 64)

    assert got["hash_hex"] == "abc123"


def test_read_head_hash_hex_none_when_neither_header_present():
    resp = _Resp(206, {"content-range": "bytes 0-63/500000"}, b"X" * 64)
    c = _cas(resp)

    got = c.read_head("incabin", "a.png", 64)

    assert got["hash_hex"] is None


def test_read_head_exact_size_206_drains_stream_fully():
    # 바디가 정확히 max_bytes일 때 `>`(>=가 아님) 덕분에 제너레이터가 자연 종료까지
    # 돌아간다 — early break로 끊으면 다 받은 응답을 미완성으로 취급해 keep-alive
    # 연결을 불필요하게 버리게 된다(F3).
    resp = _Resp(206, {"content-range": "bytes 0-63/64"}, b"Z" * 64)
    c = _cas(resp)

    got = c.read_head("incabin", "a.png", 64)

    assert got["data"] == b"Z" * 64
    assert resp.exhausted is True
    assert resp.closed


def test_read_head_content_encoding_hides_compressed_content_length():
    # requests가 기본으로 Accept-Encoding: gzip을 보내므로 CAS가 압축 응답을 줄 수 있다.
    # 그 상태의 Content-Length는 압축 후 바이트 수라 객체의 실제 크기가 아니므로,
    # size를 모른다고(None) 보고해야 한다 — 잘못된 값을 CasRef.size → sample_assets에
    # 흘려보내면 안 된다(F4).
    body = b"Y" * 500000
    resp = _Resp(200,
                 {"content-length": "500000", "content-encoding": "gzip",
                  "content-type": "image/png"},
                 body)
    c = _cas(resp)

    got = c.read_head("incabin", "a.png", 64)

    assert got["size"] is None
    assert got["data"] == b"Y" * 64  # 헤더 파싱용 데이터 자체는 여전히 정상 반환
