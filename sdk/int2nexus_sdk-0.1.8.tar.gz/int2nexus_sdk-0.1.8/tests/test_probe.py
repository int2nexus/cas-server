import struct
import zlib
import pytest
from unittest.mock import MagicMock


def _png_head(w, h, n=64):
    """온전한 PNG의 앞 n바이트 — range GET 응답을 모사한다.

    시그니처+IHDR만 잘라 붙인 조각은 Pillow가 열지 못한다(IDAT 마커까지 진행해야 한다).
    """
    def chunk(name, d):
        crc = zlib.crc32(name + d) & 0xFFFFFFFF
        return struct.pack(">I", len(d)) + name + d + struct.pack(">I", crc)
    sig = b"\x89PNG\r\n\x1a\n"
    ihdr = chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
    row = b"\x00" + b"\x80\x80\x80" * w
    idat = chunk(b"IDAT", zlib.compress(row * h))
    return (sig + ihdr + idat + chunk(b"IEND", b""))[:n]


def _fake_cas(responses):
    """responses: {key: dict | None | Exception} — read_head 결과를 key로 흉내낸다."""
    cas = MagicMock()

    def _read_head(bucket, key, max_bytes):
        r = responses[key]
        if isinstance(r, Exception):
            raise r
        return r
    cas.read_head.side_effect = _read_head
    return cas


def _ok(w, h, **kw):
    d = {"data": _png_head(w, h), "hash_hex": None, "size": None, "content_type": None}
    d.update(kw)
    return d


def test_probe_fills_dims_and_preserves_order():
    from nexus.probe import probe
    from nexus.sample import CasRef

    cas = _fake_cas({"a.png": _ok(100, 50), "b.png": _ok(200, 80), "c.png": _ok(300, 90)})
    refs = [CasRef("incabin", k) for k in ("a.png", "b.png", "c.png")]

    out = probe(refs, workers=3, verbose=False, cas=cas)

    assert [r.key for r in out] == ["a.png", "b.png", "c.png"]
    assert [(r.width, r.height) for r in out] == [(100, 50), (200, 80), (300, 90)]


def test_probe_accepts_url_strings():
    from nexus.probe import probe

    cas = _fake_cas({"images/a.png": _ok(640, 480)})
    out = probe(["http://cas:8080/incabin/images/a.png"], verbose=False, cas=cas)

    assert out[0].bucket == "incabin" and out[0].key == "images/a.png"
    assert out[0].width == 640 and out[0].height == 480


def test_probe_rejects_local_path():
    from nexus.probe import probe

    with pytest.raises(ValueError, match="CAS 참조"):
        probe(["C:/data/img/a.png"], verbose=False, cas=MagicMock())


def test_probe_isolates_failure_and_keeps_slot():
    # 가운데 하나가 실패해도 리스트가 짧아지지 않는다 — 샘플이 조용히 누락되면 안 된다.
    from nexus.probe import probe
    from nexus.sample import CasRef

    cas = _fake_cas({"a.png": _ok(100, 50), "gone.png": None, "c.png": _ok(300, 90)})
    refs = [CasRef("incabin", k) for k in ("a.png", "gone.png", "c.png")]

    with pytest.warns(RuntimeWarning, match="gone.png"):
        out = probe(refs, workers=1, verbose=False, cas=cas)

    assert len(out) == 3
    assert out[1].key == "gone.png"
    assert out[1].width is None and out[1].height is None
    assert out[0].width == 100 and out[2].width == 300


def test_probe_strict_raises_on_any_failure():
    from nexus.probe import probe
    from nexus.sample import CasRef
    from nexus._types import NexusCasError

    cas = _fake_cas({"gone.png": None})
    with pytest.raises(NexusCasError):
        probe([CasRef("incabin", "gone.png")], verbose=False, strict=True, cas=cas)


def test_probe_reports_unparseable_header():
    from nexus.probe import probe
    from nexus.sample import CasRef

    cas = _fake_cas({"a.txt": {"data": b"not an image", "hash_hex": None,
                               "size": None, "content_type": None}})
    with pytest.warns(RuntimeWarning, match="헤더"):
        out = probe([CasRef("incabin", "a.txt")], verbose=False, cas=cas)
    assert out[0].width is None


def test_probe_skips_refs_that_already_have_dims():
    from nexus.probe import probe
    from nexus.sample import CasRef

    cas = _fake_cas({"b.png": _ok(200, 80)})
    refs = [CasRef("incabin", "a.png", width=10, height=20), CasRef("incabin", "b.png")]

    out = probe(refs, verbose=False, cas=cas)

    assert cas.read_head.call_count == 1          # a.png는 네트워크를 타지 않았다
    assert (out[0].width, out[0].height) == (10, 20)
    assert (out[1].width, out[1].height) == (200, 80)


def test_probe_enriches_ref_so_flush_can_skip_head():
    # 응답 헤더에 hash/size/content_type이 다 있으면 리치 ref가 되어 flush가 HEAD를 건너뛴다.
    from nexus.probe import probe
    from nexus.sample import CasRef

    cas = _fake_cas({"a.png": _ok(640, 480, hash_hex="abc", size=12345,
                                  content_type="image/png")})
    out = probe([CasRef("incabin", "a.png")], verbose=False, cas=cas)

    r = out[0]
    assert (r.hash_hex, r.size, r.content_type) == ("abc", 12345, "image/png")


def test_probe_passes_max_header_bytes_through():
    from nexus.probe import probe
    from nexus.sample import CasRef

    cas = _fake_cas({"a.png": _ok(1, 1)})
    probe([CasRef("incabin", "a.png")], verbose=False, max_header_bytes=4096, cas=cas)

    assert cas.read_head.call_args[0][2] == 4096


def test_probe_rejects_non_positive_max_header_bytes():
    # max_header_bytes=0이면 read_head가 "Range: bytes=0--1"이라는 잘못된 헤더를 만든다
    # (max_bytes - 1 == -1). CAS까지 보내서 알기보다 호출 시점에 바로 막는다.
    from nexus.probe import probe
    from nexus.sample import CasRef

    with pytest.raises(ValueError, match="max_header_bytes"):
        probe([CasRef("incabin", "a.png")], verbose=False, max_header_bytes=0, cas=MagicMock())


def test_probe_accepts_upload_result_mapping():
    # nx.upload(...)는 {local_path: CasRef}를 돌려준다. dict를 그대로 반복하면 키(로컬 경로
    # 문자열)가 나와 "CAS 참조가 아니다"로 거부되므로, probe가 Mapping이면 .values()를
    # 취해 업로드 결과를 그대로 이어붙이는 자연스러운 호출을 받아줘야 한다(F6).
    from nexus.probe import probe
    from nexus.sample import CasRef

    upload_result = {
        "local/a.png": CasRef("incabin", "images/a.png"),
        "local/b.png": CasRef("incabin", "images/b.png"),
    }
    cas = _fake_cas({"images/a.png": _ok(100, 50), "images/b.png": _ok(200, 80)})

    out = probe(upload_result, workers=2, verbose=False, cas=cas)

    assert {r.key for r in out} == {"images/a.png", "images/b.png"}
    assert {(r.width, r.height) for r in out} == {(100, 50), (200, 80)}


def test_probe_error_count_matches_duplicate_failing_keys():
    # 같은 key를 두 번 넘겨 둘 다 실패하면 실패 건수는 2여야 한다. bucket/key 문자열로
    # errors dict를 키잡으면 겹쳐써져 1개로 보고된다(F5 회귀).
    from nexus.probe import probe
    from nexus.sample import CasRef

    cas = _fake_cas({"gone.png": None})
    refs = [CasRef("incabin", "gone.png"), CasRef("incabin", "gone.png")]

    with pytest.warns(RuntimeWarning, match=r"2개 객체"):
        probe(refs, workers=1, verbose=False, cas=cas)


def test_public_api_exports():
    import nexus as nx
    from nexus.imageinfo import ImageInfo

    assert callable(nx.probe)
    assert callable(nx.image_info)
    assert "probe" in nx.__all__ and "image_info" in nx.__all__
    assert "ImageInfo" in nx.__all__
    # __all__에 이름만 있고 실제 바인딩이 빠지는 걸 잡는다 — 문자열 검사만으로는
    # __init__.py의 import 줄에서 ImageInfo를 지워도(바인딩 없음, NameError) __all__ 목록
    # 문자열만 남아 있으면 이 assert가 통과해버린다.
    assert nx.ImageInfo is ImageInfo
