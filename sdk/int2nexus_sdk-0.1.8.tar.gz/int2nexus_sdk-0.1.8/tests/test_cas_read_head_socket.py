"""`read_head`을 진짜 소켓 위에서 검증한다.

`test_cas_read_head.py`는 `requests.Response`를 손으로 흉내낸 `_Resp`로 돈다 —
`headers`가 평범한 소문자 dict이고 `iter_content`가 평범한 제너레이터라, 저자가
`requests`를 어떻게 이해했는지를 고정할 뿐 실제 `requests`(대소문자 섞인 헤더를
`CaseInsensitiveDict`로 담고, 실제 소켓 스트림에서 `iter_content`가 청크를 뽑는)를
검증하지 못한다(F2). 여기서는 `http.server.HTTPServer`를 임의 포트에 띄우고 진짜
`CasClient`로 두드려, Range를 지키는 서버(206)와 무시하는 서버(200)가 같은 결과를
내는지 확인한다.
"""
from __future__ import annotations

import http.server
import threading
from contextlib import contextmanager

import pytest

from nexus.cas import CasClient

# 200으로 전체를 돌려주면 명백히 낭비다 싶을 만큼 크게, max_bytes는 그보다 훨씬 작게.
_BODY_SIZE = 512 * 1024
_BODY = bytes(i % 256 for i in range(_BODY_SIZE))
_MAX_BYTES = 64
_ETAG = '"deadbeef-real-socket"'
_CONTENT_TYPE = "image/png"


class _RangeHonoringHandler(http.server.BaseHTTPRequestHandler):
    """Range를 지켜 206 + Content-Range로 앞부분만 돌려준다."""

    def do_GET(self):  # noqa: N802 (http.server 관례)
        rng = self.headers.get("Range")
        start, end = 0, len(_BODY) - 1
        if rng and rng.startswith("bytes="):
            start_s, _, end_s = rng[len("bytes="):].partition("-")
            start = int(start_s) if start_s else 0
            end = min(int(end_s), len(_BODY) - 1) if end_s else len(_BODY) - 1
        chunk = _BODY[start:end + 1]
        self.send_response(206)
        # 대소문자를 실제 서버들이 흔히 쓰는 모양대로 섞어 보낸다 — 평문 소문자 dict가
        # 아니라 requests의 CaseInsensitiveDict가 실제로 동작해야 read_head가 값을 찾는다.
        self.send_header("Content-Range", f"bytes {start}-{end}/{len(_BODY)}")
        self.send_header("Content-Length", str(len(chunk)))
        self.send_header("Content-Type", _CONTENT_TYPE)
        self.send_header("ETag", _ETAG)
        self.end_headers()
        self.wfile.write(chunk)

    def log_message(self, format, *args):  # noqa: A002 - 테스트 출력 오염 방지
        pass


class _RangeIgnoringHandler(http.server.BaseHTTPRequestHandler):
    """Range 헤더를 무시하고 200으로 전체 바디를 돌려준다."""

    def do_GET(self):  # noqa: N802
        self.send_response(200)
        self.send_header("Content-Length", str(len(_BODY)))
        self.send_header("Content-Type", _CONTENT_TYPE)
        self.send_header("ETag", _ETAG)
        self.end_headers()
        self.wfile.write(_BODY)

    def log_message(self, format, *args):  # noqa: A002
        pass


@contextmanager
def _run_server(handler_cls):
    """`handler_cls`를 임의 포트(127.0.0.1:0)에 띄우고 base_url을 내준다.

    finally에서 shutdown + server_close + thread.join으로 정리한다 — 스레드가 새면
    이후 테스트의 pytest 출력이 지저분해지고(ResourceWarning 등) CI에서 불안정해진다.
    """
    server = http.server.HTTPServer(("127.0.0.1", 0), handler_cls)
    port = server.server_address[1]
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield f"http://127.0.0.1:{port}"
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)
        assert not thread.is_alive(), "test HTTP server thread leaked"


@pytest.fixture
def range_honoring_server():
    with _run_server(_RangeHonoringHandler) as base_url:
        yield base_url


@pytest.fixture
def range_ignoring_server():
    with _run_server(_RangeIgnoringHandler) as base_url:
        yield base_url


def test_read_head_206_honored_over_real_socket(range_honoring_server):
    c = CasClient(range_honoring_server, key_id="k", secret="s")

    got = c.read_head("bucket", "key", _MAX_BYTES)

    assert got is not None
    assert got["data"] == _BODY[:_MAX_BYTES]
    assert got["size"] == _BODY_SIZE
    assert got["hash_hex"] == "deadbeef-real-socket"  # ETag 폴백(따옴표 벗김)
    assert got["content_type"] == _CONTENT_TYPE


def test_read_head_200_ignored_range_over_real_socket(range_ignoring_server):
    c = CasClient(range_ignoring_server, key_id="k", secret="s")

    got = c.read_head("bucket", "key", _MAX_BYTES)

    assert got is not None
    assert got["data"] == _BODY[:_MAX_BYTES]
    assert got["size"] == _BODY_SIZE
    assert got["hash_hex"] == "deadbeef-real-socket"
    assert got["content_type"] == _CONTENT_TYPE


def test_read_head_206_and_200_agree_over_real_socket(
    range_honoring_server, range_ignoring_server
):
    # 핵심 불변식: CAS가 Range를 지키든 무시하든 read_head의 결과는 같아야 한다 —
    # 그래야 probe/flush가 CAS의 Range 지원 여부를 몰라도 된다.
    c206 = CasClient(range_honoring_server, key_id="k", secret="s")
    c200 = CasClient(range_ignoring_server, key_id="k", secret="s")

    got206 = c206.read_head("bucket", "key", _MAX_BYTES)
    got200 = c200.read_head("bucket", "key", _MAX_BYTES)

    assert got206["data"] == got200["data"] == _BODY[:_MAX_BYTES]
    assert got206["size"] == got200["size"] == _BODY_SIZE
