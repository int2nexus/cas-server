import struct
import zlib


def _png(w, h):
    """온전한 PNG bytes."""
    def chunk(name, d):
        crc = zlib.crc32(name + d) & 0xFFFFFFFF
        return struct.pack(">I", len(d)) + name + d + struct.pack(">I", crc)
    sig = b"\x89PNG\r\n\x1a\n"
    ihdr = chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))  # 8bit truecolor
    row = b"\x00" + b"\x80\x80\x80" * w
    idat = chunk(b"IDAT", zlib.compress(row * h))
    return sig + ihdr + idat + chunk(b"IEND", b"")


def _png_head(w, h, n=64):
    """PNG 앞 n바이트 — range GET으로 앞부분만 받았을 때를 모사한다.

    Pillow는 IHDR 값만 읽고 끝내는 게 아니라 IDAT 청크 마커까지 진행해야 파일을 연다.
    그래서 시그니처+IHDR만 잘라 붙인 조각은 열리지 않는다 — 실제 파일을 자른 형태여야 한다.
    """
    return _png(w, h)[:n]


def test_image_info_reads_truncated_png_head():
    from nexus.imageinfo import image_info

    info = image_info(_png_head(1920, 1080, 64))   # 전체 파일의 앞 64바이트뿐
    assert info is not None
    assert info.width == 1920 and info.height == 1080
    assert info.mime == "image/png"
    assert info.channels == 3      # truecolor RGB


def test_image_info_reads_full_png():
    from nexus.imageinfo import image_info

    info = image_info(_png(40, 30))
    assert (info.width, info.height) == (40, 30)


def test_image_info_returns_none_for_non_image():
    from nexus.imageinfo import image_info

    assert image_info(b"not an image at all") is None
    assert image_info(b"") is None


def test_image_info_returns_none_when_too_little_data():
    from nexus.imageinfo import image_info

    assert image_info(b"\x89PNG\r\n\x1a\n") is None        # 시그니처만
    assert image_info(_png_head(1920, 1080, 20)) is None   # IHDR도 다 못 읽음
