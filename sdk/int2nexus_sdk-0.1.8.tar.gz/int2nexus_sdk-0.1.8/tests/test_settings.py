import json

import pytest

import nexus
from nexus import settings
from nexus._types import NexusError


def _reset():
    nexus._client = None
    nexus._cas = None


def _write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data), encoding="utf-8")
    return path


FULL = {
    "nexus_url": "http://file-nexus",
    "email": "file@x.com",
    "password": "filepass",
    "cas_url": "http://file-cas",
    "cas_key_id": "file-kid",
    "cas_secret": "file-sec",
}


# ── 우선순위: 인자 > 환경변수 > 파일 ──────────────────────────────────────────

def test_settings_file_alone_is_enough(tmp_path, monkeypatch, requests_mock):
    """설정 파일만 있으면 nx.connect() 한 줄로 접속된다 — 이 기능의 목적."""
    _reset()
    p = _write(tmp_path / "settings.json", FULL)
    monkeypatch.setenv("NEXUS_SETTINGS", str(p))
    requests_mock.post("http://file-nexus/api/v1/auth/login", json={"token": "ftok"})

    client = nexus.connect()

    assert client._token == "ftok"
    assert nexus._cas._base == "http://file-cas"
    assert nexus._cas._key_id == "file-kid"


def test_env_beats_file(tmp_path, monkeypatch, requests_mock):
    _reset()
    p = _write(tmp_path / "settings.json", FULL)
    monkeypatch.setenv("NEXUS_SETTINGS", str(p))
    monkeypatch.setenv("NEXUS_URL", "http://env-nexus")
    requests_mock.post("http://env-nexus/api/v1/auth/login", json={"token": "etok"})

    client = nexus.connect()

    assert client._token == "etok"
    # 나머지 값은 여전히 파일에서 온다.
    assert nexus._cas._base == "http://file-cas"


def test_explicit_arg_beats_env_and_file(tmp_path, monkeypatch, requests_mock):
    """명시 인자가 항상 이긴다 — '분명히 넘겼는데 파일이 이기는' 사고를 막는 규칙."""
    _reset()
    p = _write(tmp_path / "settings.json", FULL)
    monkeypatch.setenv("NEXUS_SETTINGS", str(p))
    monkeypatch.setenv("NEXUS_URL", "http://env-nexus")
    requests_mock.post("http://arg-nexus/api/v1/auth/login", json={"token": "atok"})

    client = nexus.connect(nexus_url="http://arg-nexus")

    assert client._token == "atok"


def test_settings_path_argument_overrides_env(tmp_path, monkeypatch, requests_mock):
    _reset()
    used = _write(tmp_path / "used.json", FULL)
    ignored = _write(tmp_path / "ignored.json", {**FULL, "nexus_url": "http://ignored"})
    monkeypatch.setenv("NEXUS_SETTINGS", str(ignored))
    requests_mock.post("http://file-nexus/api/v1/auth/login", json={"token": "utok"})

    client = nexus.connect(settings_path=str(used))

    assert client._token == "utok"


# ── 에러·경고 ───────────────────────────────────────────────────────────────

def test_missing_values_raise_actionable_error(tmp_path, monkeypatch):
    """예전엔 KeyError가 났다. 무엇이 빠졌고 어디에 넣는지 알려줘야 한다."""
    _reset()
    monkeypatch.setenv("NEXUS_SETTINGS", str(tmp_path / "absent.json"))

    with pytest.raises(NexusError) as exc:
        nexus.connect()

    msg = str(exc.value)
    assert "nexus_url" in msg and "email" in msg and "password" in msg and "cas_url" in msg
    assert "NEXUS_URL" in msg  # 환경변수 이름
    assert "absent.json" in msg  # 설정 파일 경로


def test_partial_settings_report_only_missing(tmp_path, monkeypatch):
    _reset()
    p = _write(tmp_path / "settings.json", {"nexus_url": "http://n", "email": "e@x.com"})
    monkeypatch.setenv("NEXUS_SETTINGS", str(p))

    with pytest.raises(NexusError) as exc:
        nexus.connect()

    msg = str(exc.value)
    assert "password" in msg and "cas_url" in msg
    # 이미 있는 값은 '부족' 목록의 첫 줄에 나오면 안 된다.
    assert "nexus_url" not in msg.splitlines()[0]


def test_malformed_json_raises_with_path(tmp_path, monkeypatch):
    """조용히 무시하면 오타 하나로 '설정이 안 먹는다'가 되고 원인을 못 찾는다."""
    _reset()
    p = tmp_path / "settings.json"
    p.write_text('{"nexus_url": "http://n",}', encoding="utf-8")
    monkeypatch.setenv("NEXUS_SETTINGS", str(p))

    with pytest.raises(NexusError) as exc:
        nexus.connect()

    assert str(p) in str(exc.value)


def test_non_object_top_level_raises(tmp_path, monkeypatch):
    _reset()
    p = tmp_path / "settings.json"
    p.write_text('["not", "an", "object"]', encoding="utf-8")
    monkeypatch.setenv("NEXUS_SETTINGS", str(p))

    with pytest.raises(NexusError):
        nexus.connect()


def test_unknown_key_warns(tmp_path, monkeypatch):
    """`nexus_uri` 같은 오타를 잡아준다."""
    p = _write(tmp_path / "settings.json", {**FULL, "nexus_uri": "http://typo"})
    monkeypatch.setenv("NEXUS_SETTINGS", str(p))

    with pytest.warns(UserWarning, match="nexus_uri"):
        settings.load_file()


def test_absent_file_is_not_an_error(tmp_path):
    assert settings.load_file(tmp_path / "nope.json") == {}


# ── verify ──────────────────────────────────────────────────────────────────

def test_verify_defaults_to_true(requests_mock):
    _reset()
    requests_mock.post("http://n/api/v1/auth/login", json={"token": "t"})
    nexus.connect(
        nexus_url="http://n", email="e", password="p", cas_url="http://c"
    )
    assert nexus._client._session.verify is True
    assert nexus._cas._session.verify is True


def test_verify_false_applies_to_both_sessions(requests_mock):
    """CAS는 별도 세션이다 — nexus만 고치면 업로드에서 같은 에러가 다시 난다."""
    _reset()
    requests_mock.post("http://n/api/v1/auth/login", json={"token": "t"})
    with pytest.warns(UserWarning, match="중간자"):
        nexus.connect(
            nexus_url="http://n", email="e", password="p", cas_url="http://c",
            verify=False,
        )
    assert nexus._client._session.verify is False
    assert nexus._cas._session.verify is False


def test_verify_accepts_ca_bundle_path(tmp_path, requests_mock):
    """검증을 끄는 대신 사내 루트 CA를 신뢰하는 안전한 경로."""
    _reset()
    ca = tmp_path / "corp-ca.pem"
    ca.write_text("dummy", encoding="utf-8")
    requests_mock.post("http://n/api/v1/auth/login", json={"token": "t"})

    nexus.connect(
        nexus_url="http://n", email="e", password="p", cas_url="http://c",
        verify=str(ca),
    )

    assert nexus._client._session.verify == str(ca)
    assert nexus._cas._session.verify == str(ca)


def test_verify_from_settings_file(tmp_path, monkeypatch, requests_mock):
    """사내 사용자는 CA 경로를 한 번 적어두고 nx.connect() 한 줄로 끝난다."""
    _reset()
    p = _write(tmp_path / "settings.json", {**FULL, "verify": "C:/certs/corp.pem"})
    monkeypatch.setenv("NEXUS_SETTINGS", str(p))
    requests_mock.post("http://file-nexus/api/v1/auth/login", json={"token": "t"})

    nexus.connect()

    assert nexus._client._session.verify == "C:/certs/corp.pem"
    assert nexus._cas._session.verify == "C:/certs/corp.pem"


@pytest.mark.parametrize(
    "raw,expected",
    [
        ("false", False), ("FALSE", False), ("0", False), ("no", False), ("off", False),
        ("true", True), ("1", True), ("yes", True), ("on", True),
        ("/etc/ssl/corp.pem", "/etc/ssl/corp.pem"),
        ("", None), (None, None), (True, True), (False, False),
    ],
)
def test_parse_verify(raw, expected):
    assert settings.parse_verify(raw) == expected


def test_verify_env_var(monkeypatch, requests_mock):
    _reset()
    monkeypatch.setenv("NEXUS_VERIFY", "false")
    requests_mock.post("http://n/api/v1/auth/login", json={"token": "t"})
    with pytest.warns(UserWarning):
        nexus.connect(
            nexus_url="http://n", email="e", password="p", cas_url="http://c"
        )
    assert nexus._client._session.verify is False


def test_explicit_verify_true_beats_env_false(monkeypatch, requests_mock):
    """인자가 환경변수를 이긴다 — verify도 같은 규칙을 따른다."""
    _reset()
    monkeypatch.setenv("NEXUS_VERIFY", "false")
    requests_mock.post("http://n/api/v1/auth/login", json={"token": "t"})

    nexus.connect(
        nexus_url="http://n", email="e", password="p", cas_url="http://c",
        verify=True,
    )

    assert nexus._client._session.verify is True
