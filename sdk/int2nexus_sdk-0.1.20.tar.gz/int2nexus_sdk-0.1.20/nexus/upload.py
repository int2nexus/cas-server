from __future__ import annotations
import warnings
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from tqdm import tqdm

from nexus._types import NexusCasError
from nexus.cas import CasClient
from nexus.imageinfo import image_info
from nexus.sample import CasRef

THUMBNAIL_MAX_EDGE = 256
THUMBNAIL_QUALITY = 80


def _make_thumbnail(image_bytes: bytes) -> "bytes | None":
    """원본 이미지 bytes → longest-edge 256 WebP bytes. 디코딩 실패 시 None."""
    try:
        from PIL import Image
    except ImportError:
        raise ImportError("pillow is required for thumbnails: pip install pillow")
    import io
    try:
        img = Image.open(io.BytesIO(image_bytes)).convert("RGB")
        img.thumbnail((THUMBNAIL_MAX_EDGE, THUMBNAIL_MAX_EDGE))
        buf = io.BytesIO()
        img.save(buf, format="WEBP", quality=THUMBNAIL_QUALITY)
        return buf.getvalue()
    except Exception as exc:
        warnings.warn(f"thumbnail generation failed: {exc}", RuntimeWarning, stacklevel=2)
        return None


def upload(
    paths,
    bucket: str,
    prefix: str = "",
    *,
    workers: int = 8,
    verbose: bool = True,
    strict: bool = False,
    overwrite: bool = False,
    client=None,
    cas=None,
) -> "dict[str, CasRef]":
    """로컬 파일들을 CAS에 직접 업로드하고 {경로: 리치 CasRef} 를 반환한다.

    각 파일: key={prefix}/{filename}, blake3 hash·size·content_type 계산, HEAD-skip(동일 hash)
    /충돌(다른 hash) 검사 후 PUT, WebP 256px 썸네일을 thumb/<key>에 함께 업로드(best-effort).

    같은 key에 **다른 내용**이 이미 있으면 기본은 충돌 에러다. `overwrite=True`면 대신 그
    key를 덮어쓴다 — 썸네일도 새 내용으로 함께 덮어쓴다(안 그러면 옛 이미지의 썸네일이
    새 이미지에 그대로 남는다). 같은 내용이면 overwrite 여부와 무관하게 PUT을 건너뛴다
    (이미 맞는 상태라 다시 쓸 이유가 없다).

    일시적 네트워크/5xx 오류는 CAS 클라이언트가 전송 계층에서 재시도한다. 재시도 후에도
    실패한 파일은 **건당 격리**되어 배치 전체를 중단시키지 않는다 — 성공분만 반환한다.
    `strict=True`면 실패가 하나라도 있으면 `NexusCasError`를 던진다(기본 False는 경고만).
    같은 paths로 다시 호출하면 이미 올라간 건 HEAD-skip되어 실패분만 재시도(resume)된다.
    """
    import nexus as _nx
    _client = client
    _cas = cas
    if _client is None or _cas is None:
        if _nx._client is None:
            _nx._auto_connect()
        _client = _client or _nx._client
        _cas = _cas or _nx._cas

    _client.ensure_bucket(bucket)
    prefix = prefix.strip("/") if prefix else ""

    def _one(path) -> "tuple[str, CasRef]":
        p = Path(path)
        data = p.read_bytes()
        hash_hex = CasClient.hash_bytes(data)
        key = f"{prefix}/{p.name}" if prefix else p.name
        content_type = CasClient.content_type(p)

        existing = _cas.head(bucket, key)
        content_changed = existing is None
        if existing is None:
            _cas.put(bucket, key, data, content_type)
        elif existing.get("hash_hex") and existing["hash_hex"] != hash_hex:
            if not overwrite:
                raise NexusCasError(
                    f"CAS key 충돌: '{bucket}/{key}'에 다른 내용이 이미 존재합니다 "
                    f"(기존 {existing['hash_hex'][:12]} != 신규 {hash_hex[:12]}). "
                    "prefix·파일명을 바꾸거나 overwrite=True로 덮어쓰세요."
                )
            _cas.put(bucket, key, data, content_type)
            content_changed = True

        info = image_info(data)
        thumb = _make_thumbnail(data)
        if thumb is not None:
            try:
                thumb_key = f"thumb/{key}"
                # 내용을 덮어썼으면 썸네일도 무조건 다시 쓴다 — 안 그러면 옛 이미지의
                # 썸네일이 새 이미지에 그대로 남는다. 내용이 그대로면(HEAD-skip) 기존과
                # 동일하게 없을 때만 쓴다.
                if content_changed or _cas.head(bucket, thumb_key) is None:
                    _cas.put(bucket, thumb_key, thumb, "image/webp")
            except Exception as exc:
                warnings.warn(f"thumbnail upload failed: {exc}", RuntimeWarning, stacklevel=2)

        return str(path), CasRef(
            bucket=bucket, key=key, hash_hex=hash_hex,
            size=len(data), content_type=content_type,
            width=info.width if info else None,
            height=info.height if info else None,
        )

    refs: dict[str, CasRef] = {}
    errors: dict[str, Exception] = {}
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(_one, p): p for p in paths}
        for f in tqdm(as_completed(futures), total=len(futures),
                      desc="Uploading", disable=not verbose):
            try:
                k, ref = f.result()
                refs[k] = ref
            except Exception as exc:   # 건당 격리: 한 파일 실패가 배치를 죽이지 않음
                errors[str(futures[f])] = exc

    if errors:
        shown = ", ".join(list(errors)[:5])
        more = f" 외 {len(errors) - 5}건" if len(errors) > 5 else ""
        first_err = next(iter(errors.values()))
        msg = (
            f"{len(errors)}개 파일 업로드 실패(재시도 후): {shown}{more}. "
            f"첫 에러: {first_err}. "
            "같은 paths로 nx.upload를 다시 호출하면 성공분은 건너뛰고 실패분만 재시도합니다."
        )
        if strict:
            raise NexusCasError(msg)
        warnings.warn(msg, RuntimeWarning, stacklevel=2)
    return refs
