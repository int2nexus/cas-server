from __future__ import annotations
import uuid
from .labels import Label, _is_number, _require

COMMON_KEYS = ("id", "label", "track_id", "confidence")


class Instance:
    def __init__(self, id, label, components: dict, track_id=None, confidence=None,
                 extras: dict | None = None):
        # id 가 없거나 빈 문자열이면 UUID v4(하이픈 형식, GT spec)를 붙인다. 서버는 id 없이 적재된
        # 행을 빈 문자열로 돌려주는데, 그대로 두면 그런 행끼리 구분되지 않아 id 로 행을 가르는
        # merge·add_labels·CVAT 왕복이 틀어진다. 채운 id 는 로드 기준에 포함되므로, 그 그룹을
        # 고쳐 저장할 때만 서버에 기록된다.
        self.id = id if (id is not None and id != "") else str(uuid.uuid4())
        self.label = label
        self.track_id = track_id
        self.confidence = confidence
        self.components: dict = components
        # 공통 키도 아니고 dict도 아닌 나머지 키(예: "occluded": true) — component로 오인해
        # Label.validate()에 걸리지 않도록 verbatim 보존만 한다(검증 대상 아님).
        self.extras: dict = extras if extras is not None else {}

    @classmethod
    def from_row(cls, row: dict) -> "Instance":
        comps = {}
        extras = {}
        for k, v in row.items():
            if k in COMMON_KEYS:
                continue
            if isinstance(v, dict):
                comps[k] = Label.from_dict(v)
            else:
                extras[k] = v
        return cls(id=row.get("id"), label=row.get("label"), components=comps,
                   track_id=row.get("track_id"), confidence=row.get("confidence"),
                   extras=extras)

    def to_dict(self) -> dict:
        out = {"id": self.id}
        if self.label is not None:
            out["label"] = self.label
        if self.track_id is not None:
            out["track_id"] = self.track_id
        if self.confidence is not None:
            out["confidence"] = self.confidence
        for name, lab in self.components.items():
            self._require_label(name, lab)
            out[name] = lab.to_dict()
        out.update(self.extras)
        return out

    def get_component(self, name):
        return self.components.get(name)

    def set_component(self, name, label):
        self.components[name] = label
        # to_dict()가 extras를 components 뒤에 덮어쓰므로, 같은 이름의 여분 키가
        # 남아 있으면 방금 설정한 component를 가려버린다.
        self.extras.pop(name, None)

    def remove_component(self, name):
        self.components.pop(name, None)

    def validate(self) -> None:
        _require(isinstance(self.label, str), f"instance {self.id}: label must be a string")
        if self.confidence is not None:
            _require(_is_number(self.confidence), f"instance {self.id}: confidence must be a number")
        if self.track_id is not None:
            _require(isinstance(self.track_id, int) and not isinstance(self.track_id, bool),
                      f"instance {self.id}: track_id must be an int")
        for name, lab in self.components.items():
            self._require_label(name, lab)
            lab.validate()

    def _require_label(self, name, lab) -> None:
        # component 자리에는 단수 Label 만 — 그룹·컨테이너를 넣는 중첩은 금지다.
        # save() 는 검증보다 먼저 to_dict() 로 diff 를 만들므로 거기서도 부른다
        # (안 그러면 검증 에러가 아니라 AttributeError 로 죽는다).
        _require(isinstance(lab, Label),
                 f"instance {self.id}: component '{name}' must be a Label, "
                 f"got {type(lab).__name__}")
