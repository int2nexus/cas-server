from __future__ import annotations
from .instance import Instance
from ._types import NexusValidationError


class LabelGroup:
    def __init__(self, instances: list):
        self.instances = instances

    @classmethod
    def from_list(cls, rows: list) -> "LabelGroup":
        return cls([Instance.from_row(r) for r in rows])

    def to_list(self) -> list:
        self._require_instances()
        return [i.to_dict() for i in self.instances]

    def validate(self) -> None:
        self._require_instances()
        for i in self.instances:
            i.validate()
        # GT spec 4 장: 모든 객체의 id 는 그룹 안에서 유일해야 한다. 중복이면 id 로 행을 가르는
        # merge·add_labels·CVAT 왕복이 그중 한 행만 다룬다. save() 는 보내는 그룹만 검증하므로
        # 중복이 있는 레거시 그룹도 열고 읽을 수 있고, 고쳐 저장할 때만 정리를 요구한다.
        dups = self.duplicate_ids()
        if dups:
            shown = ", ".join(map(str, dups[:5])) + (" …" if len(dups) > 5 else "")
            raise NexusValidationError(f"duplicate instance ids in group: {shown}")

    def _require_instances(self) -> None:
        # 그룹 행 자리에는 Instance 만 — Label 을 바로 넣으면 행에 id·label 이 없어 서버가
        # 그 행을 버리고(missing_label), dict 를 넣으면 AttributeError 로 죽는다.
        for i in self.instances:
            if not isinstance(i, Instance):
                raise NexusValidationError(
                    f"group rows must be Instance objects, got {type(i).__name__} — "
                    "Label 은 nx.Instance(id, label, components={...}) 로 감싸 넣으십시오")

    def duplicate_ids(self) -> list:
        """이 그룹 안에서 두 번 이상 나오는 id(정렬)."""
        seen, dup = set(), set()
        for i in self.instances:
            if isinstance(i, Instance):
                (dup if i.id in seen else seen).add(i.id)
        return sorted(dup, key=str)

    def __getitem__(self, idx): return self.instances[idx]
    def __len__(self): return len(self.instances)
    def add(self, inst): self.instances.append(inst)
    def remove(self, inst): self.instances.remove(inst)


class LabelContainer(LabelGroup):
    """각 원소는 단일 component이고 모두 같은 타입이다."""

    @property
    def labels(self) -> list:
        return [next(iter(i.components.values())) for i in self.instances]

    @property
    def element_type(self) -> str | None:
        for i in self.instances:
            for lab in i.components.values():
                return lab.type
        return None

    def validate(self) -> None:
        super().validate()
        et = None
        for i in self.instances:
            if len(i.components) != 1:
                raise NexusValidationError(
                    f"container instance {i.id}: expected exactly 1 component, got {len(i.components)}")
            t = next(iter(i.components.values())).type
            if et is None:
                et = t
            elif t != et:
                raise NexusValidationError(
                    f"container has mixed component types: {et} vs {t}")


class RawGroup:
    """미선언 그룹. 원본을 손대지 않고 그대로 왕복한다."""
    def __init__(self, raw):
        self.raw = raw

    def to_raw(self):
        return self.raw

    def validate(self) -> None:
        pass
