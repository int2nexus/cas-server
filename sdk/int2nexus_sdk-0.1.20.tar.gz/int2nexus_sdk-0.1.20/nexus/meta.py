from __future__ import annotations
from ._types import NexusValidationError


class Meta:
    """lenient meta. 알려진 키·미지 키 모두 verbatim 보존."""

    def __init__(self, data):
        self._data = data

    @classmethod
    def from_dict(cls, d) -> "Meta":
        return cls(d)

    def to_dict(self):
        return self._data

    def __getitem__(self, k):
        return self._data[k]

    def __setitem__(self, k, v):
        self._data[k] = v

    def __delitem__(self, k):
        del self._data[k]

    def get(self, k, default=None):
        return self._data.get(k, default) if isinstance(self._data, dict) else default

    def validate(self) -> None:
        if not isinstance(self._data, dict):
            raise NexusValidationError("meta must be a JSON object")
