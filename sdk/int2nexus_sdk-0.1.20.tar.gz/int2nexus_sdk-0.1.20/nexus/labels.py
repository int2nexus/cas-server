from __future__ import annotations
from ._types import NexusValidationError

LABEL_REGISTRY: dict[str, "type[Label]"] = {}


def _is_number(v) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _require(cond: bool, msg: str) -> None:
    if not cond:
        raise NexusValidationError(msg)


def _num_list(v) -> bool:
    return isinstance(v, list) and all(_is_number(x) for x in v)


def _int_list(v) -> bool:
    return isinstance(v, list) and all(isinstance(x, int) and not isinstance(x, bool) for x in v)


class Label:
    """component 1개. 내부 dict를 verbatim 보존한다."""

    def __init__(self, data: dict):
        self._data = data

    @property
    def type(self) -> str:
        return self._data.get("type")

    def to_dict(self) -> dict:
        return self._data

    def validate(self) -> None:
        _require(isinstance(self._data, dict), "component must be an object")
        _require(isinstance(self._data.get("type"), str), "component missing 'type'")

    @classmethod
    def from_dict(cls, d: dict) -> "Label":
        t = d.get("type") if isinstance(d, dict) else None
        sub = LABEL_REGISTRY.get(t)
        return sub(d) if sub else Label(d)


class _Typed(Label):
    """_data 필드를 속성으로 노출하는 베이스.

    두 가지로 만든다: `Detection({...})`(wire dict 를 그대로 — 로드 경로) 또는
    `Detection(rect=[...], label=...)`(키워드 — 새로 만들 때). 키워드 쪽은 `type`을
    클래스가 채우고, 클래스가 아는 필드(`_FIELDS`)만 받는다 — 오타(`rct=`)가 저장 때가
    아니라 그 자리에서 `TypeError`로 드러난다. 값이 `None`인 키워드는 빼고 만든다(wire
    spec 이 명시적 null 을 금지한다). 목록에 없는 필드를 담아야 하면 dict 형태를 쓴다."""
    _TYPE: str = ""
    _FIELDS: tuple = ()

    def __init__(self, data: dict | None = None, **fields):
        if data is not None:
            if fields:
                raise TypeError(f"{type(self).__name__}() takes a dict or keywords, not both")
            super().__init__(data)
            return
        unknown = sorted(set(fields) - set(self._FIELDS))
        if unknown:
            raise TypeError(
                f"{type(self).__name__}() got unexpected field(s) {', '.join(unknown)} "
                f"(allowed: {', '.join(self._FIELDS)})")
        d = {"type": self._TYPE}
        d.update({k: v for k, v in fields.items() if v is not None})
        self._complete(d)
        super().__init__(d)

    def _complete(self, d: dict) -> None:
        """키워드 생성 때 유도 가능한 필드를 채운다(기본은 없음)."""

    def validate(self) -> None:
        super().validate()
        # 클래스와 wire type 이 어긋나면(Detection 인데 "polygon") 이 클래스의 규칙으로
        # 검사한 것이 서버에 나가는 타입과 무관해진다.
        _require(self._data.get("type") == self._TYPE,
                 f"{type(self).__name__} must have type '{self._TYPE}', "
                 f"got '{self._data.get('type')}'")

    def _get(self, k):
        return self._data.get(k)
    def _set(self, k, v):
        self._data[k] = v


class Detection(_Typed):
    _TYPE = "bounding_box"
    _FIELDS = ("rect", "label", "confidence", "rotation")

    @property
    def rect(self): return self._get("rect")
    @rect.setter
    def rect(self, v): self._set("rect", v)
    @property
    def label(self): return self._get("label")
    @label.setter
    def label(self, v): self._set("label", v)
    @property
    def confidence(self): return self._get("confidence")
    @confidence.setter
    def confidence(self, v): self._set("confidence", v)
    @property
    def rotation(self): return self._get("rotation")

    def validate(self) -> None:
        super().validate()
        r = self._get("rect")
        _require(isinstance(r, list) and len(r) == 4 and all(_is_number(x) for x in r),
                 "bounding_box.rect must be 4 numbers")
        if self._get("label") is not None:
            _require(isinstance(self._get("label"), str), "label must be a string")
        if self._get("confidence") is not None:
            _require(_is_number(self._get("confidence")), "confidence must be a number")


class Classification(_Typed):
    _TYPE = "classification"
    _FIELDS = ("label", "confidence")

    @property
    def label(self): return self._get("label")
    @label.setter
    def label(self, v): self._set("label", v)
    @property
    def confidence(self): return self._get("confidence")

    def validate(self) -> None:
        super().validate()
        _require(isinstance(self._get("label"), str) and self._get("label") != "",
                 "classification.label must be a non-empty string")
        if self._get("confidence") is not None:
            _require(_is_number(self._get("confidence")), "confidence must be a number")


class Keypoint2D(_Typed):
    _TYPE = "keypoint_2d"
    _FIELDS = ("x", "y", "visibility", "num_keypoints", "label", "confidence")
    _AXES = ("x", "y")

    def _complete(self, d: dict) -> None:
        # num_keypoints 는 x 의 길이에서 나온다 — 따로 적게 하면 외울 규칙이 하나 는다.
        if "num_keypoints" not in d and isinstance(d.get("x"), list):
            d["num_keypoints"] = len(d["x"])

    @property
    def num_keypoints(self):
        return self._get("num_keypoints")

    @property
    def x(self):
        return self._get("x")

    @x.setter
    def x(self, v):
        self._set("x", v)

    @property
    def y(self):
        return self._get("y")

    @y.setter
    def y(self, v):
        self._set("y", v)

    @property
    def visibility(self):
        return self._get("visibility")

    @visibility.setter
    def visibility(self, v):
        self._set("visibility", v)

    @property
    def label(self):
        return self._get("label")

    @property
    def confidence(self):
        return self._get("confidence")

    def validate(self) -> None:
        super().validate()
        # num_keypoints 는 선택 필드다(서버 README 의 keypoint_3d 예시에 없고, 서버도 없으면
        # len(x) 를 쓴다) — 있으면 정수이고 배열 길이와 같아야 하며, 없으면 축 배열끼리 같으면 된다.
        n = self._get("num_keypoints")
        if n is not None:
            _require(isinstance(n, int) and not isinstance(n, bool), "num_keypoints must be an int")
        for ax in self._AXES:
            _require(_num_list(self._get(ax)), f"{ax} must be a list of numbers")
        if n is None:
            n = len(self._get(self._AXES[0]))
            what = f"len({self._AXES[0]})"
        else:
            what = "num_keypoints"
        for ax in self._AXES:
            _require(len(self._get(ax)) == n, f"len({ax}) must equal {what}")
        # visibility 는 선택 필드다(서버 README 의 keypoint_3d 예시에 없다) — 있을 때만 본다.
        if self._get("visibility") is not None:
            _require(_int_list(self._get("visibility")), "visibility must be a list of ints")
            _require(len(self._get("visibility")) == n, f"len(visibility) must equal {what}")
        if self._get("label") is not None:
            _require(isinstance(self._get("label"), str), "label must be a string")
        if self._get("confidence") is not None:
            _require(_is_number(self._get("confidence")), "confidence must be a number")


class Keypoint3D(Keypoint2D):
    _TYPE = "keypoint_3d"
    _FIELDS = ("x", "y", "z", "visibility", "num_keypoints", "label", "confidence")
    _AXES = ("x", "y", "z")

    @property
    def z(self):
        return self._get("z")

    @z.setter
    def z(self, v):
        self._set("z", v)


class ScalarValue(_Typed):
    _TYPE = "value"
    _FIELDS = ("value",)

    @property
    def value(self):
        return self._get("value")

    @value.setter
    def value(self, v):
        self._set("value", v)

    def validate(self) -> None:
        super().validate()
        _require(_is_number(self._get("value")), "value must be a number")


class VectorValue(_Typed):
    _TYPE = "values"
    _FIELDS = ("values", "dim")

    @property
    def values(self):
        return self._get("values")

    @values.setter
    def values(self, v):
        self._set("values", v)

    def validate(self) -> None:
        super().validate()
        _require(_num_list(self._get("values")), "values must be a list of numbers")
        if self._get("dim") is not None:
            _require(isinstance(self._get("dim"), int) and not isinstance(self._get("dim"), bool),
                     "dim must be an int")


class Cuboid3D(_Typed):
    _TYPE = "cuboid_3d"
    _FIELDS = ("center", "dimensions", "rotation")

    @property
    def center(self):
        return self._get("center")

    @property
    def dimensions(self):
        return self._get("dimensions")

    @property
    def rotation(self):
        return self._get("rotation")

    def validate(self) -> None:
        super().validate()
        _require(isinstance(self._get("center"), list) and len(self._get("center")) == 3
                 and _num_list(self._get("center")), "center must be 3 numbers")
        _require(isinstance(self._get("dimensions"), list) and len(self._get("dimensions")) == 3
                 and _num_list(self._get("dimensions")), "dimensions must be 3 numbers")
        # rotation 은 선택 필드다(서버 README 의 cuboid_3d 예시에 없다) — 있을 때만 본다.
        if self._get("rotation") is not None:
            _require(isinstance(self._get("rotation"), list) and len(self._get("rotation")) == 9
                     and _num_list(self._get("rotation")), "rotation must be 9 numbers")


class Polygon(_Typed):
    _TYPE = "polygon"
    _FIELDS = ("points",)
    _MIN_POINTS = 3

    @property
    def points(self):
        return self._get("points")

    @points.setter
    def points(self, v):
        self._set("points", v)

    def validate(self) -> None:
        super().validate()
        p = self._get("points")
        _require(_num_list(p) and len(p) % 2 == 0 and len(p) >= self._MIN_POINTS * 2,
                 f"points must be a flat number list of >= {self._MIN_POINTS} points")


class Polyline(Polygon):
    _TYPE = "polyline"
    _FIELDS = ("points", "closed")
    _MIN_POINTS = 2

    @property
    def closed(self):
        return self._get("closed")

    @closed.setter
    def closed(self, v):
        self._set("closed", v)


for _cls in (Detection, Classification, Keypoint2D, Keypoint3D, ScalarValue, VectorValue,
             Cuboid3D, Polygon, Polyline):
    LABEL_REGISTRY[_cls._TYPE] = _cls
