from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class CasRef:
    bucket: str
    key: str
    hash_hex: str | None = None
    size: int | None = None
    content_type: str | None = None
    width: int | None = None
    height: int | None = None


FileRef = Path | CasRef


def _parse_ref(src: str | Path) -> FileRef:
    # URL 의 %XX 는 풀어서 원래 key 로 쓴다. 안 풀면 CAS 서명이 한 번 더 인코딩해(%20 → %2520)
    # 엉뚱한 객체를 찾는다(SDK 0.1.16 부터 서명 경로를 인코딩하므로). 서버가 key 에 '%' 를
    # 금지하므로(`validate_key`) 경로의 %XX 는 항상 인코딩이라 풀어도 모호하지 않다.
    #
    # http(s) 도 `urlparse` 를 쓰지 않고 문자열을 직접 나눈다(0.1.18). `urlparse` 는 '#' 뒤를
    # fragment, '?' 뒤를 query 로 떼어내 key 를 잘랐는데, CAS 는 그런 문자가 든 key 를 허용해서
    # 잘린 key 는 없는 객체를 가리켰다. 호스트 뒤 경로 전체가 bucket/key 다 — 서명 쪽
    # `_uri_encode_path` 가 '#' '?' 를 %23 %3F 로 인코딩하므로 그대로 남겨도 맞는다.
    from urllib.parse import unquote
    s = str(src)
    if s.startswith("s3://"):
        without_scheme = s[5:]
        bucket, _, key = without_scheme.partition("/")
        return CasRef(bucket=bucket, key=unquote(key))
    if s.startswith("http://") or s.startswith("https://"):
        _host, _, path = s.split("://", 1)[1].partition("/")
        # 호스트 뒤 '//' 는 한 번으로 본다(urlparse 시절과 같게) — CAS_URL 이 '/' 로 끝날 때 생긴다.
        bucket, _, key = path.lstrip("/").partition("/")
        return CasRef(bucket=bucket, key=unquote(key))
    return Path(s)


def _coerce_cas_ref(v: "CasRef | str | Path", what: str) -> CasRef:
    if isinstance(v, CasRef):
        return v
    ref = _parse_ref(v)  # str → CasRef(url) 또는 Path(로컬)
    if isinstance(ref, CasRef):
        return ref
    raise ValueError(
        f"{what}는 CAS 참조여야 합니다 (CasRef 또는 s3://·http(s):// URL). "
        f"로컬 경로는 받지 않습니다 — nx.upload(...)로 먼저 CAS에 올린 뒤 반환된 ref를 넘기세요."
    )


@dataclass
class Sample:
    """등록할 학습 단위. 이미지/asset은 **CAS에 이미 있는 ref**만 받는다.

    - `image`: `CasRef`(nx.upload 반환) 또는 `s3://`·`http(s)://` URL. 로컬 경로는
      받지 않는다 — `nx.upload(...)`로 먼저 CAS에 올린 뒤 반환된 ref를 넘길 것.
    - `assets`: image 외 추가 asset(예: depth map). `{role: ref}` 형태, ref는 image와 동일한
      규칙(CAS ref 전용). `"image"` 키는 예약되어 있어 쓸 수 없다(image= 파라미터를 쓸 것).
    - `annotation`: GT는 nexus DB에 인라인 저장되므로 로컬 JSON 경로 / dict / URL 모두 허용
      (이미지와 달리 CAS 업로드 대상이 아니라 그대로 읽어 전송한다).
    """
    image: "CasRef | str | None" = None
    annotation: "str | Path | dict | None" = None
    assets: "dict[str, CasRef | str] | None" = None
    split: str | None = None
    tags: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        if self.image is None and self.annotation is None:
            raise ValueError("Sample requires at least image or annotation")
        # 문자열 하나를 넘기면 단일 원소 리스트로 자동 변환 (서버는 배열을 기대).
        if isinstance(self.tags, str):
            self.tags = [self.tags]
        # 아래 세 속성은 접근할 때마다 현재 필드에서 계산하므로, 생성자와 같은 검증이 여기서 한 번 돈다
        # (잘못된 image·assets 는 예전처럼 생성 시점에 같은 ValueError 로 드러난다).
        self._image_ref, self._asset_refs, self._annotation_ref
        # 멱등 키와 재전송 본문(스펙 §4-3). `(dataset 이름, version)` 마다 따로 둔다 — 같은 Sample 을 두 버전에 넣으면
        # 버전마다 다른 샘플이 생겨야 한다. 성공하면 flush 가 지운다.
        self._idempotency_keys: dict[tuple[str, str], str] = {}
        self._pending_payloads: dict[tuple[str, str], dict] = {}

    # image·assets·annotation 에서 파생되는 ref 는 저장하지 않고 읽을 때마다 현재 필드로 계산한다. 생성 때 한 번
    # 풀어 저장하면 `s.image = new` 나 `s.assets[role] = ref` 가 flush 에 반영되지 않고 옛 값이 조용히 나갔다.
    # 로컬 경로를 뒤늦게 대입하면 읽는 시점(flush 의 준비 단계)에 ValueError 로 그 샘플만 실패한다.
    @property
    def _image_ref(self) -> "CasRef | None":
        return _coerce_cas_ref(self.image, "Sample.image") if self.image is not None else None

    @property
    def _asset_refs(self) -> "dict[str, CasRef]":
        if self.assets and "image" in self.assets:
            raise ValueError(
                "Sample.assets에 'image' 키는 예약되어 있습니다 — Sample(image=..)를 쓰세요"
            )
        return {
            role: _coerce_cas_ref(v, f"Sample.assets[{role!r}]")
            for role, v in (self.assets or {}).items()
        }

    @property
    def _annotation_ref(self) -> "FileRef | dict | None":
        # dict(인라인 GT)은 그대로(같은 객체), 그 외(경로/URL)는 _parse_ref
        if isinstance(self.annotation, dict):
            return self.annotation
        if self.annotation is not None:
            return _parse_ref(self.annotation)
        return None

    # 복제본은 새 샘플이다. 기본 복사는 위 두 dict 를 공유하거나(얕은 복사) 키·본문을 그대로 베껴서(깊은 복사)
    # 「템플릿 Sample 을 복제해 image 만 바꿔 N 개 add」 하면 전부 같은 키로 나가 첫 건만 생기고 나머지는 409 가 된다.
    # 그래서 멱등 상태는 비워서 만든다. 나머지 필드는 평소대로 복사한다(ref 는 필드에서 계산되어 따로 옮길 것이 없다).
    def __copy__(self) -> "Sample":
        new = object.__new__(type(self))
        new.__dict__.update(self.__dict__)
        new._idempotency_keys = {}
        new._pending_payloads = {}
        return new

    def __deepcopy__(self, memo: dict) -> "Sample":
        import copy

        new = object.__new__(type(self))
        memo[id(self)] = new
        for k, v in self.__dict__.items():
            if k in ("_idempotency_keys", "_pending_payloads"):
                continue
            new.__dict__[k] = copy.deepcopy(v, memo)
        new._idempotency_keys = {}
        new._pending_payloads = {}
        return new
