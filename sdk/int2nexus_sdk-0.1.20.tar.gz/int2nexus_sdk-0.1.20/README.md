# int2nexus-sdk

Python SDK for uploading ML training data to a nexus-server instance. (배포명 `int2nexus-sdk`, import는 `import nexus`.)

## Installation

공개 인덱스(PEP 503)에서 설치:

```bash
pip install --extra-index-url https://int2nexus.github.io/cas-server/sdk/simple/ int2nexus-sdk
```

- 배포명은 `int2nexus-sdk`지만 **import는 `import nexus`** 다. (PyPI의 동명 `nexus-sdk`와 충돌을 피하려 배포명을 네임스페이스화했다.)
- `--extra-index-url`(≠ `--index-url`): `int2nexus-sdk`는 위 인덱스에서, 의존성은 PyPI에서 받습니다.
- 버전 고정: `int2nexus-sdk==0.1.3`.
- 개발 설치(소스): `pip install -e ./sdk`.

## Quick Start

### 설정 파일 (권장)

`~/.int2nexus/settings.json`에 한 번 적어두면 `nx.connect()` 한 줄로 접속된다. 스크립트에 자격증명을 적지 않아도 된다.

```json
{
  "nexus_url": "http://localhost:8090",
  "email": "user@example.com",
  "password": "secret",
  "cas_url": "http://localhost:8080",
  "cas_key_id": "mykey",
  "cas_secret": "mysecret"
}
```

```bash
mkdir -p ~/.int2nexus
$EDITOR ~/.int2nexus/settings.json
chmod 600 ~/.int2nexus/settings.json     # 비밀번호·CAS secret이 들어 있다
```

- **비밀번호와 CAS secret이 평문으로 저장된다.** POSIX에서는 권한이 느슨하면 SDK가 경고한다. **Windows에서는 `chmod`가 사실상 무의미**하므로 검사하지 않는다 — 파일 위치와 접근 권한은 사용자 책임이다.
- 경로를 바꾸려면 `NEXUS_SETTINGS=/path/to/settings.json` 또는 `nx.connect(settings_path=...)`.
- `cas_key_id`/`cas_secret`/`verify`는 선택. 모르는 키는 경고한다(오타 탐지).

### 워크로드는 로봇 토큰으로 (0.1.10+)

사람이 없는 환경(적재 잡, 스케줄러, CI)에서는 로그인할 수 없다. 관리자가 만든 **로봇 계정**의 장수명 토큰을 그대로 제시한다 — `email`/`password`는 필요 없다.

```python
nx.connect(robot_token="nxr_...")     # 또는 NEXUS_ROBOT_TOKEN 환경변수
```

**서버 부재를 기다린다 (0.1.19+).** `nx.connect(retry_timeout=120)`(기본 120초, 환경변수 `NEXUS_RETRY_TIMEOUT`, 설정 파일 키 `retry_timeout`, `0` 이면 끔) — cas-server·nexus-server 교체 중의 연결 실패·502·503·504 를 첫 실패부터 이 시간까지 기다렸다 다시 보낸다. 자세한 것은 `CHANGELOG.md`.

**설정 파일에 저장하지 않는다.** 배포가 sealed-secret에서 환경변수로 주입하는 값이지 이 라이브러리가 관리할 것이 아니다.

갱신도 재로그인도 없다 — `401`은 그대로 올라온다(폐기·만료·계정 정지 중 무엇이든 관리자가 조작해야 풀린다). 로봇은 **삭제를 못 한다**(적재·수정·seal은 된다). 자세한 것은 `usage.md` §19.

### CAS 임시 자격증명 — STS (0.1.12+)

cas 에 STS(`auth.oidc.issuers`)가 켜져 있으면 장수명 CAS 키 대신 OIDC 토큰으로 임시 자격증명을
받아 쓸 수 있다. **명시 인자로만 켜진다** — AWS 환경변수(`AWS_WEB_IDENTITY_TOKEN_FILE` 등)는 읽지
않으므로 같은 프로세스의 다른 저장소 키와 섞이지 않는다.

```python
import nexus as nx

# 쿠버네티스 projected 토큰 — 갱신할 때마다 파일을 다시 읽는다
nx.connect(nexus_url="http://nexus-server", robot_token="nxr_...", cas_url="http://cas-server",
           cas_sts=nx.CasSts(token_file="/var/run/secrets/tokens/cas"))

# 토큰을 코드가 가져오는 경우(예: Keycloak) — 갱신할 때마다 다시 호출된다
nx.connect(nexus_url="http://nexus-server", robot_token="nxr_...", cas_url="http://cas-server",
           cas_sts=nx.CasSts(token_provider=get_access_token, duration_seconds=3600))
```

- **토큰의 남은 수명은 900초 이상이어야 한다**(cas 발급 하한). projected 토큰은 `expirationSeconds`
  7200 이상을, Keycloak 은 realm 액세스 토큰 수명(기본 300초)을 올린다.
- 남은 수명이 600초 이하가 되면 새로 받는다. 갱신이 실패해도 기존 자격증명이 60초 넘게 남아
  있으면 경고만 내고 계속 쓴다.
- `cas_key_id`/`cas_secret` 인자와 함께 주면 `ValueError`. 환경변수·설정 파일의 정적 키는 경고와
  함께 무시하고, nexus 자동 발급을 부르지 않으며 설정 파일에 쓰지 않는다.
- 접속 시점에 한 번 받는다 — 토큰 파일·매핑이 틀리면 `nx.connect` 가 곧바로 `NexusCasError` 로
  실패한다(cas 에 닿지 않으면 재시도 뒤 실패한다).

| STS 코드 | 뜻 |
|---|---|
| `ExpiredToken` | 토큰이 만료됐거나 남은 수명이 900초 미만 |
| `InvalidIdentityToken` | 서명·`iss`·`aud` 가 cas 설정과 맞지 않음 |
| `AccessDenied` | `(issuer, subject)` 매핑이 없거나 템플릿 키가 폐기·만료 |
| `IDPCommunicationError` | cas 가 IdP 의 JWKS 를 가져오지 못함 |
| `ValidationError` | STS 요청 형식이 맞지 않음(`duration_seconds` 범위 등) |
| STS 가 켜져 있지 않음 | cas 의 `auth.oidc.issuers` 가 비어 있음 |

STS 호출이 느려도(타임아웃 15초 × 최대 4회) **남은 수명이 60초를 넘는 자격증명이 있으면 워커는 기다리지 않고
그것을 쓴다.** 기다리는 것은 자격증명이 없거나 60초 이하로 남았을 때뿐이다.
STS 모드는 CAS 데이터 요청의 **리다이렉트를 따라가지 않는다**(세션 토큰이 다른 호스트로 가지 않게) —
`cas_url` 은 리다이렉트 없는 주소(`http`→`https` 전환 포함)로 지정한다.
`urllib`·이미지 라이브러리로 `https://…` 를 직접 여는 코드에는 적용되지 않는다.

### 값의 우선순위

**인자 > 환경변수 > 설정 파일.** 코드에 명시한 값이 항상 이기고, CI는 환경변수로 로컬 파일을 덮을 수 있다.

```bash
export NEXUS_URL=http://localhost:8090
export NEXUS_EMAIL=user@example.com
export NEXUS_PASSWORD=secret
export CAS_URL=http://localhost:8080
export CAS_KEY_ID=mykey
export CAS_SECRET=mysecret
export NEXUS_VERIFY=true          # 선택 — false 또는 CA 번들 경로
```

### 사내 프록시 · TLS 인증서 (`verify`)

사내 보안 장비가 TLS를 검사하면 `nx.connect()`가 SSL 인증서 에러로 죽는다. 세 가지 방법이 있고, **위쪽이 안전하다.**

```python
# 1) 사내 루트 CA를 신뢰 — 검증을 유지한 채 해결(권장)
nx.connect(verify="/path/to/corp-root-ca.pem")

# 2) 환경변수 — SDK 수정/재배포 없이 오늘 바로 쓸 수 있다(requests 기본 동작)
#    export REQUESTS_CA_BUNDLE=/path/to/corp-root-ca.pem

# 3) 검증 끄기 — 최후의 수단
nx.connect(verify=False)
```

설정 파일에 적어두면 매번 넘기지 않아도 된다:

```json
{ "verify": "C:/certs/corp-root-ca.pem" }
```

- `verify`는 **nexus와 CAS 양쪽 세션**에 적용된다. `nx.upload()`는 CAS로 직접 PUT하므로 한쪽만 고치면 업로드에서 같은 에러가 다시 난다.
- CAS를 `http://`로 접속한다면 `verify`는 아무 일도 하지 않는다(TLS가 없으므로).
- `verify=False`는 **그 연결의 중간자 공격 탐지를 포기하는 것**이다. 접속 시 한 번 경고가 뜨고, 이후 요청마다 나오는 urllib3 경고는 억제된다.

### Upload

Ingest is **2-phase**: first upload the image bytes to CAS (`nx.upload`), then register the
returned refs as samples (`nx.Sample` + `flush`).

```python
import nexus as nx

nx.connect()

# Phase 1 — data plane: upload local files to CAS (parallel, idempotent, +WebP thumbnail)
refs = nx.upload([img1, img2], bucket="kitti", prefix="images")   # {path: CasRef}

# Phase 2 — catalog: register the refs as samples
with nx.Dataset.load_or_create("kitti-mini", version="v1", tags=["3d_detection"]) as ds:
    for img_path, ann_path in pairs:
        ds.add(nx.Sample(
            image=refs[img_path],   # CAS ref (not a local path)
            annotation=ann_path,    # local JSON path / dict / URL
            split="train",
        ))
# flush() called automatically on __exit__
```

### Manual flush

```python
refs = nx.upload([img for img, _ in pairs], bucket="kitti", prefix="images")

ds = nx.Dataset.load_or_create("kitti-mini", version="v1")
ds.add([nx.Sample(image=refs[img], annotation=ann) for img, ann in pairs])

results = ds.flush(workers=4, strict=False)
failures = [r for r in results if not r.ok]
```

**`flush(workers=)` 의 상한은 한 사람이 아니라 동시에 적재하는 전원의 합에 걸린다.**
서버 기본값에서 그 합이 4다 — 다섯 명이 각자 `workers=8` 로 돌리면 상한의 10배다. 넘치면
서버가 `429` + `Retry-After` 로 돌려주고 SDK 가 물러났다 다시 오므로 적재가 실패하지는
않지만, 그만큼 느려진다. 처리량을 올리려면 서버의 `database.max_connections` 를 함께
올려야 한다(`nexus-server` README 「적재 동시 실행 상한」).

`nx.upload(workers=)` 는 다르다 — 그쪽은 CAS 로 직접 가므로 이 상한과 무관하다.

### Explicit connection

```python
nx.connect(
    nexus_url="http://localhost:8090",
    email="user@example.com",
    password="secret",
    cas_url="http://localhost:8080",
    cas_key_id="mykey",
    cas_secret="mysecret",
    verify=True,          # 선택 — False 또는 CA 번들 경로
)
```

설정이 부족하면 **무엇이 빠졌고 어디에 넣으면 되는지**를 담은 `NexusError`가 난다(예전에는 `KeyError`였다).

### 계정 관리

```python
client = nx.connect()

# 비밀번호 변경 — 현재 비밀번호를 재확인한다
client.change_password("old-pass", "new-pass-123")

# 소유한 dataset을 다른 계정으로 넘긴다 (서버 0.1.6+)
client.transfer_dataset_owner("0198f3c1-6b2a-77e1-9a40-3d5c9f0e1b22", "new-owner@int2.us")

# 계정 삭제 (되돌릴 수 없다). 소유한 dataset이 남아 있으면 409로 거부된다.
result = client.delete_account("new-pass-123")
# {"deleted_user_id": 7, "released_datasets": 0, "warning": "…"}
```

- 비밀번호를 바꿔도 **이미 발급된 토큰은 만료(최대 24시간)까지 유효**하다. 변경은 새 로그인부터 적용된다.
- `~/.int2nexus/settings.json`에 비밀번호를 적어두었다면 **그 파일도 함께 고쳐야 한다.**
- **서버 `0.1.6`부터 소유한 dataset이 남아 있으면 `delete_account`가 `NexusError(status_code=409)`로 거부된다** —
  `transfer_dataset_owner`로 전부 넘긴 뒤 다시 부른다. 그래서 성공했을 때 `released_datasets`는 항상 0이다.
  구버전 서버(`0.1.5` 이하)는 그대로 지우며, 그때 `released_datasets`가 0이 아니면 그 dataset들은 주인이
  없어져 **누구나 수정·삭제할 수 있는 상태**가 된다.
- 비밀번호를 잊어 로그인조차 못 하는 계정은 본인이 처리할 수 없다 — 운영자가 DB에서 재설정해야 한다.

### annotation 1건 고치기

이미 등록된 샘플의 GT를 받아 고치고 그대로 돌려보낸다. draft 버전에서만 가능하다(sealed는 409).

```python
ds = nx.Dataset.load_or_create("kitti-mini", version="v1")

ann = ds.get_annotation(sample_id)              # 코어 필드 없이 annotation 만
ann["det"].append({"id": "o9", "label": "person",
                   "bounding_box": {"type": "bounding_box", "rect": [0.5, 0.5, 0.1, 0.2]}})

report = ds.save_annotation(sample_id, ann)     # 통째 교체 + 서버 보고서
if report.get("skipped"):
    raise RuntimeError(f"{report['skipped']}건이 저장되지 않았습니다: {report['skipped_reasons']}")
```

- **저장은 병합이 아니라 통째 교체다.** 다른 그룹이 남아 있는 채로 어떤 그룹만 빼고 저장하면 그 그룹은 삭제된다 — 반드시 `get_annotation()`이 준 것을 고쳐서 쓸 것.
- **nexus-server `0.1.18` 부터: 그룹을 하나도 안 보내면(마지막 그룹까지 빼서 `meta`만 남거나 dict가 비면) 아무것도 안 바뀐다.** 그룹을 실제로 비우려면 `ann["det"] = []`처럼 빈 배열로 보낼 것 — 그렇게 보낸 그룹이 전부 비었는데 그 샘플에 다른 버전과 공유하는 원본(base)이 있으면 서버가 409를 준다(비우려면 버전에서 unlink). `0.1.16` 이하 서버는 그룹을 하나도 안 보내도 그대로 전부 지웠다.
- `report["skipped"]`가 0이 아니면 그만큼 **원래 있던 인스턴스가 지워진 것**이다. SDK가 `RuntimeWarning`도 함께 낸다.
- 여러 건을 한 번에 고칠 때는 `Dataset.patch_annotations({sample_id: ann, ...})`(같은 `0.1.18` 규칙이 적용된다).

### annotation을 그룹 단위로 부분 저장 — `load_sample()` / `save()` (SDK 0.1.16+)

annotation을 타입 객체로 받아 고치고, **바뀐 것만** 저장한다(위 `get_annotation`/`save_annotation`은 항상 통째 교체).

```python
ds = nx.Dataset.load_or_create("seatbelt", version="v1",
                               group_kinds={"seatbelt_gt": "group"})

s = ds.load_sample(sample_id)
s["seatbelt_gt"][0].get_component("bounding_box").rect = [0.1, 0.1, 0.4, 0.8]
s.meta["width"] = 1280
s.save()          # 검증 후 바뀐 그룹·meta 키만 보낸다
```

- **`save()`는 바뀐 그룹과 바뀐 `meta` 키만 보낸다.** 안 바꾼 그룹·`meta` 키는 서버가 보존하므로, **양쪽 모두 `save()`(서버 `0.1.18` 이상)로 저장할 때는** 두 곳에서 같은 샘플의 **다른** 그룹을 동시에 고쳐도 서로 지우지 않는다. 같은 그룹을 동시에 고치면 나중 저장이 이긴다. 한쪽이 `save_annotation`/`patch_annotations`·CVAT `pull()`(아래)이거나 옛 서버라 `save()`가 통째 교체로 폴백한 경우는 그 저장이 오래된 스냅샷 전체를 쓰므로, 그 사이 `save()`가 쓴 다른 그룹까지 덮어쓴다.
- `meta`의 키를 지우려면 `del s.meta[k]` 또는 `s.meta[k] = None`.
- **부분 저장은 nexus-server `0.1.18` 이상이 필요하다.** 그 이하 서버에서는 `RuntimeWarning`과 함께 통째 교체(`save_annotation`)로 저장한다(이 경우 동시 편집 보호가 없다). `load_sample` 자체는 `0.1.5` 이상이면 된다.
- 그룹 하나를 비우는 저장(`clear_field`·빈 리스트)은 된다. 다만 저장 결과 **그 샘플의 인스턴스가 하나도 남지 않고** 공유 원본(base)이 있으면 서버가 409로 거절한다(비우면 원본이 다시 보이기 때문) — 이 버전에서 그 샘플을 비우려면 버전에서 unlink한다.

**FiftyOne 호환 필드 함수**(`AnnotatedSample`, 제자리 수정 후 `save()`로 저장한다). 필드는 그룹 이름 또는 `"meta"`다.

```python
s.get_field("dets")                       # 없으면 AttributeError(있는 필드 목록 포함)
s.set_field("dets", rows, create=False)   # create=False면 오타로 새 필드가 생기지 않는다
s["meta"] = {"width": 1280}               # s[f] / s[f] = v 도 같다
s.clear_field("dets")                     # None이 아니라 빈 그룹, "meta"는 저장된 키 전부 삭제
inst = nx.Instance(id=None, label="Person",                 # id=None 이면 새 id 를 붙인다
                   components={"bounding_box": nx.Detection(rect=[0.1, 0.2, 0.3, 0.4])})
s.add_labels(inst, label_field="dets")    # Instance / list / {field: ...}
s.merge(other, fields=None, omit_fields=None, merge_lists=True, overwrite=True)
c = s.copy(fields=["dets"])               # 저장되지 않은 deep copy — c.save()는 실패한다
```

- `merge`: `other`는 `AnnotatedSample` 또는 dict(이 샘플의 그룹 종류 선언으로 파싱). `merge_lists=True`면 `Instance.id` 단위로 합친다(같은 id는 `overwrite`일 때만 교체, 새 id는 뒤에 추가). `merge_lists=False`이거나 선언 안 된 그룹(`RawGroup`)은 통째 교체이고 `overwrite=False`면 기존 필드를 건드리지 않는다. `meta`는 키 단위(`overwrite=False`면 없는 키만 채운다). 가져온 값은 전부 복사하므로 두 샘플이 객체를 공유하지 않는다. 실패하면 아무것도 바꾸지 않는다.
- `add_labels`: 같은 id가 대상 필드(또는 같은 배치 안)에 이미 있으면 `ValueError`이고 아무것도 붙지 않는다. 넣은 `Instance`는 복사해서 붙인다. `"meta"`와 선언 안 된 그룹에는 붙일 수 없다(`TypeError`).
- 리스트를 대입하거나 `add_labels`로 새 필드를 만들면 그 필드에 선언된 종류(`"group"`/`"container"`)를 따른다. **선언하지 않은 새 필드는 저장은 되지만 다음 `load_sample`에서 `RawGroup`으로 돌아온다** — 계속 객체로 다룰 필드는 `declare_group_kinds`로 선언한다.
- 제안과의 차이: `Label.id`·component 단위 id는 없다(id는 `Instance`에만 있다). 그룹은 FiftyOne의 `Detections([Detection])` 같은 이름 붙은 컨테이너 클래스가 아니라 `LabelGroup`/`LabelContainer` 두 종류다.
- 그룹 종류 선언·component 타입 등 객체 모델 자체는 `sdk/CHANGELOG.md`의 `0.1.16` 절을 참고.

### CVAT annotation 편집 세션

draft 버전의 샘플을 CVAT으로 보내 사람이 편집하고, 결과를 다시 draft에 당겨온다.
서버에 `[cvat]` 설정이 필요하다(없으면 503).

```python
ds = nx.Dataset.load_or_create("kitti-mini", version="v1")
ids = [r["sample_id"] for r in ds.list_samples(max_samples=50)]

ses = ds.create_annotation_session(ids)   # open 될 때까지 대기 후 반환
print(ses.url)                            # 작업자에게 넘길 CVAT 주소

summary = ses.pull()                      # CVAT → draft 반영 (멱등, 반복 호출 안전)
ses.close()                               # 잠금 해제 (CVAT project는 보존)

nx.annotation_sessions()                  # 전역 — 지금 진행 중인 세션
```

- **생성은 비동기다.** 수백 장이면 CVAT이 이미지를 받는 데만 몇 분 — `wait=False`로 받고
  나중에 `ses.wait_open(timeout=1800)` 해도 된다.
- `pull()`이 돌려주는 `warnings`를 버리지 말 것 — 반영되지 않은 것의 사유가 거기 있다.
- **`pull()`은 통째 교체다** — 세션 시작 이후 `save()`로 이 샘플의 다른 그룹을 고쳤다면 그 변경도 함께 덮어쓴다(위 「그룹 단위로 부분 저장」).
- `delete()`는 CVAT project와 **아직 당겨오지 않은 편집까지** 지운다. `close()`와 다르다.
- 같은 샘플을 두 세션이 잡을 수 없다(409). sealed 버전에는 만들 수 없다(409).

### Fork a version

```python
ds = nx.Dataset.load_or_create("kitti-mini", version="v1.1", fork_from="v1.0")
```

### Link existing samples (without ingest)

```python
ds.link_samples(["0192f0a1-...", "0192f0a1-..."])
```

### Convert sealed version to DataFrame

```python
import nexus as nx

nx.connect()
ds = nx.Dataset.load_or_create("kitti-mini", version="v1")

# all samples
df = ds.to_df()

# train split only
df_train = ds.to_df(split="train")

# only samples that have a 'sedan' instance
df_sedan = ds.to_df(label="sedan")

# include instances column (downloads annotation NDJSON snapshot)
df_full = ds.to_df(labels=True)
# df_full["labels"] → list of instance dicts per row
```

## API Reference

### `nexus.connect(...)`

Authenticates against nexus-server and initializes the module-level client. 설정이 인자·환경변수·설정 파일(`~/.int2nexus/settings.json`) 중 어디에든 갖춰져 있으면 첫 API 호출이 자동으로 접속하므로, 명시적으로 부르지 않아도 된다.

```python
nx.connect(
    nexus_url=None, email=None, password=None,          # 없으면 환경변수 → 설정 파일 순으로 해소
    cas_url=None, cas_key_id=None, cas_secret=None,
    timeout=(10.0, 120.0),                              # (connect, read)
    verify=None,                                        # True(기본) | False | CA 번들 경로
    settings_path=None,                                 # 설정 파일 경로 직접 지정
)
```

- `cas_sts` — `nx.CasSts(token_file=… | token_provider=…, duration_seconds=3600)`. CAS 임시 자격증명(STS) 모드(0.1.12+). 위 「CAS 임시 자격증명 — STS」 참조

### `nexus.upload(paths, bucket, prefix="", *, workers=8, verbose=True, strict=False, overwrite=False)`

Uploads local files to CAS and returns `{path: CasRef}`, mapping each input path to its
`CasRef` (which carries `bucket` / `key` / `hash_hex` / `size` / `content_type`). This is
**phase 1** of ingest — pass the returned refs to `nx.Sample(image=...)`.

```python
refs = nx.upload(
    ["data/img001.png", "data/img002.png"],
    bucket="kitti",
    prefix="images",   # CAS key = "{prefix}/{filename}"
    workers=8,         # parallel uploads
)
ref = refs["data/img001.png"]   # CasRef(bucket="kitti", key="images/img001.png", ...)
```

- Uploads in parallel; idempotent — already-present objects (same key + content) are skipped.
- Generates a WebP 256px thumbnail alongside each image (best-effort).
- Re-using the same key with **different** content is a per-file failure (collision) by default. Pass `overwrite=True` to replace it instead — the thumbnail is regenerated too, so a stale thumbnail from the old content never lingers. Same content is always skipped regardless of `overwrite`.
- Transient network/5xx errors are retried with backoff at the transport layer. Per-file failures are **isolated** (one bad file doesn't abort the batch) — only successes are returned. `strict=True` raises `NexusCasError` if any file failed; default `strict=False` warns. Re-running `nx.upload` with the same paths resumes (already-uploaded files are skipped).

### `nexus.probe(refs, *, workers=8, verbose=True, strict=False, max_header_bytes=65536)`

이미지를 다른 경로로 이미 CAS에 올렸고 로컬 사본이 없다면, `nx.upload` 없이 CAS 좌표만으로
샘플을 만들 수 있다. 다만 그대로 등록하면 `meta`에 `width`/`height`가 빠진다 — CAS는
객체의 픽셀 크기를 헤더로 알려주지 않기 때문이다.

`nx.probe`는 각 객체의 **앞부분 64KB만** 받아 이미지 헤더를 파싱해 크기를 채운다.

```python
import nexus as nx
from nexus import CasRef

nx.connect()

refs = [CasRef(bucket="incabin", key=f"lg_dataset/{name}") for name in names]
refs = nx.probe(refs, workers=8)          # 앞부분만 range GET

ds = nx.load_or_create("lg_dataset", version="v1")
ds.add([nx.Sample(r) for r in refs])
ds.flush()
```

- 입력은 `CasRef` 또는 `s3://`·`http(s)://` URL 문자열의 리스트, **또는 `nx.upload`가
  돌려주는 `{path: CasRef}` 그대로**다(`Sample.image`와 같은 CAS 참조 규칙 + dict는
  `.values()`로 풀어서 받는다 — dict를 직접 for로 돌리면 키인 로컬 경로 문자열이 나와
  거부되므로, 업로드 결과를 그대로 이어붙이려면 이 형태로 넘긴다).
- 반환은 **입력 순서를 보존한 리스트**다. 실패한 객체도 자리를 지키며 크기만 비어 있다.
- 이미 크기가 채워진 ref는 네트워크를 타지 않는다. 같은 리스트로 다시 호출해 실패분만
  재시도해도 된다.
- CAS가 Range 요청을 지원하지 않아도 동작한다 — 앞부분만 읽고 연결을 끊는다.
- `max_header_bytes`(기본 64KB): 객체 앞부분에서 받아올 바이트 수. 헤더가 유난히 뒤에
  있는 포맷(예: 특정 TIFF)이거나 "이미지 헤더를 읽지 못했습니다" 경고가 뜨면 이 값을
  올려본다. 1 미만은 `ValueError` — Range 헤더가 애초에 성립하지 않는다.
- `strict`(기본 `False`): `False`면 실패를 `RuntimeWarning`으로 모아 경고하고 계속
  진행한다(실패한 항목은 원본 ref 그대로, width/height는 `None`). `True`면 하나라도
  실패했을 때 `NexusCasError`를 던진다 — 크기 누락을 절대 허용하지 않는 파이프라인에.

크기를 못 구하면 `meta`에 `width`/`height` 키를 **넣지 않는다**. 0을 적으면 크기 facet의
range가 `min:0`으로 오염되고, CVAT 세션이 그 값으로 정규화 좌표를 계산해 좌표가 망가진다.
키가 없으면 집계에서 조용히 제외되고, CVAT 세션 생성은 명확한 에러로 거부된다.

**로컬 파일이 있다면 network를 탈 이유가 없다.** 같은 파서를 직접 부르면 된다.

```python
info = nx.image_info(path.read_bytes())   # width/height/mime/channels, 헤더만 읽음
ref = CasRef(bucket="incabin", key=key, width=info.width, height=info.height)
```

### 이미 적재된 샘플의 크기 보정 — `ds.backfill_dims()`

`nx.probe`가 생기기 전에 등록된 샘플은 `meta.width`/`meta.height`가 `0`으로 들어가 있다.
`0`은 크기 facet의 range를 `min:0`으로 오염시키고, CVAT에서는 세션 검증을 통과한 뒤
export 단계에서 해당 인스턴스가 조용히 빠지게 만든다.

```python
ds = nx.load_or_create("lg_dataset", version="v1")

report = ds.backfill_dims(dry_run=True)   # 대상 규모와 실제 측정 가능 건수 확인
report = ds.backfill_dims(workers=8)      # 적용
print(report)   # {'scanned': 12000, 'targeted': 840, 'measured': 838, 'unchanged': 0,
                #  'applied': 838, 'corrected': 0, 'rejected': [...], 'changes': [...]}
```

- 대상은 `meta.width`/`height` 중 **적어도 한 축이** 없거나, `null`이거나, 0 이하인 샘플이다. 두 축 모두 0보다 큰 값이 있는 샘플은 건드리지 않는다.
- `dry_run=True`도 **실제로 측정까지** 한다. 쓰기만 건너뛴다.
- image asset이 없거나 헤더를 읽지 못한 샘플은 건너뛰고 `measured`에서 빠진다.
- 서버는 **축(width/height) 단위로** 기록된 값을 절대 덮어쓰지 않는다 — 한쪽 축만 기록되어 있어도 그 축은 그대로 두고 반대쪽만 채운다. 값이 존재하지만 숫자가 아니면(문자열·bool 등) fail-closed로 "기록됨" 취급해 역시 손대지 않는다. 채울 축이 하나도 없는 샘플을 보내면 `rejected`에 사유와 함께 담겨 돌아온다.
- sealed 버전의 샘플도 보정된다 — 애초에 그 `0`은 측정된 값이 아니라 SDK가 지어낸 자리표시자였다. 다만 seal은 그 시점의 `meta` 사본을 스냅샷에 기록하므로, 보정한 값은 API 조회에는 보이지만 이미 seal된 버전의 `to_df()`에는 반영되지 않는다(학습 입력까지 고치려면 fork 후 다시 seal).

#### 잘못 적재된 값 고치기 — `overwrite=True` (0.1.10+)

`0`이나 빈칸이 아니라 **처음부터 틀린 값**이 들어간 경우가 있다. ingest 때 넘긴 `ann.json`의
`meta.width/height`가 실제 이미지와 달랐던 경우다. 이런 값은 서버가 "기록됨"으로 보므로
위의 채우기 모드로는 닿지 않는다.

```python
report = ds.backfill_dims(overwrite=True, dry_run=True)   # 무엇이 어떻게 바뀌는지 먼저 본다
#   018f...a1: 1280x720 -> 1920x1080
#   018f...b7: 1280x720 -> 1920x1080
#   ... 외 312건
report = ds.backfill_dims(overwrite=True)                 # 적용
```

- **`image_url`이 있는 전량을 probe한다.** "이미 기록됨" 스킵이 빠지기 때문이다. 기본 모드보다 훨씬 오래 걸린다.
- 그렇게 잰 뒤 **실측값이 기록값과 다른 건만** 보낸다. 같은 값이었던 건수는 `unchanged`에 담긴다.
- `corrected`는 적용된 것 중 **기존 값을 덮은** 건수다. `applied - corrected`가 빈칸을 채운 건수다.
- **안전장치는 `dry_run`이다.** 이 모드에도 sealed 게이트는 없다(같은 이유 — 얼려야 할 것은 측정된 값이지 잘못 선언된 값이 아니다). 변경 목록이 전부 같은 비율로 어긋나 있으면 `ann.json` 쪽의 일관된 실수이고, 제각각이면 probe가 엉뚱한 객체를 재고 있다는 신호다. 쓰기 전에 반드시 본다.
- 헤더를 읽지 못한 샘플은 이 모드에서도 보내지 않는다 — 흘려보내면 멀쩡한 값을 측정 실패값으로 덮게 된다.

### `nexus.Sample`

```python
nx.Sample(
    image=ref,                       # CAS ref ONLY: a CasRef (from nx.upload) or s3://·http(s):// URL
    annotation="data/ann001.json",  # local JSON path / dict (inline GT) / URL
    assets={"depth": depth_ref},     # optional extra assets, {role: ref} — same rules as image
    split="train",                  # optional
    tags=["rainy", "night"],        # optional
)
```

`image` and every value in `assets` accept **CAS refs only** — a `CasRef` returned by
`nx.upload`, or an `s3://bucket/key` / `http(s)://…` URL. **Local file paths raise `ValueError`**
— upload them with `nx.upload` first. For URL refs the SDK uses a CAS HEAD to retrieve metadata.
`"image"` is a reserved key in `assets` (raises `ValueError`) — use the `image=` parameter instead.
`annotation` still accepts a local JSON path, a dict (inline GT), or a URL.

### `nexus.Dataset.load_or_create(name, version, ...)`

Finds an existing dataset+version by name or creates it. Idempotent.

```python
nx.Dataset.load_or_create(
    name: str,
    version: str,
    tags: list[str] | None = None,       # dataset tags, applied on create
    description: str | None = None,
    fork_from: str | None = None,        # version to fork from on create
)
```

### `nexus.Dataset.open(dataset_id, version, *, client=None, cas=None)`

Opens an **existing** dataset version by id (0.1.18). It never creates anything: if the dataset
or the version does not exist it raises `NexusError` with `status_code=404`. Use it in readers
(e.g. `to_df()` workers) that already know the id. The handle itself is not restricted —
write permission is still decided by the server's role check. Without both `client` and `cas` it
uses the connection made by `nx.connect()` (auto-connecting if needed). If only one is given, the
other is taken from an existing `nx.connect()` connection only — never auto-connected — and
`ValueError` is raised if there is none.

```python
ds = nx.Dataset.open(dataset_id, "v1")
df = ds.to_df()
```

### `nexus.cas_client()`

Returns the `CasClient` of the current `nx.connect()` connection (auto-connecting if needed,
0.1.18). Use it instead of the private module global `nexus._cas`. `nx.CasClient` and
`nx.NexusClient` are part of the public API, so a `CasClient` can also be built directly and
passed as `Dataset.open(..., cas=)`.

### `Dataset.link_samples(sample_ids)`

Links already-ingested samples to this version without re-ingesting them.

### `Dataset.flush(workers=4, strict=False, verbose=True, batch_size=256)`

Prepares the registration payloads from the queued samples' refs (no upload — uploads happen
earlier in `nx.upload`), then sends them to the server's `/ingest/batch` endpoint in chunks of
`batch_size`. Returns `list[IngestResult]`.

- **Results come back in input order** (0.1.18; earlier versions returned them in completion order,
  with prepare failures first). Each result's `index` is its position in the queue at flush time.
- **A CAS 401/403 while preparing (CAS HEAD) raises `NexusCasError` before anything is ingested**
  (0.1.18). It is a CAS credential/policy problem, not a nexus role problem; fix it and flush the same
  samples again.
- **Replayed items (0.1.19, nexus-server 0.1.20+).** `flush` sends an `idempotency_key` per item; when the server returns an existing result for a re-sent item, `IngestResult.replayed` is `True`, it counts as success, and the summary line shows `replayed N`.
- **Re-sending failed samples (0.1.19).** `flush` does not put failed samples back in the queue. Add them back yourself: `ds.add([r.sample for r in results if not r.ok])`. The SAME `Sample` objects carry the idempotency key and the remembered payload; building new `Sample` objects means new keys and can duplicate. This state lives in process memory and is lost on restart. Copies made with `copy.copy`/`copy.deepcopy`/`dataclasses.replace` start fresh (no key). Do not rename the dataset with `ds.update(name=...)` between an ambiguous failure and the re-send: keys are kept per (dataset name, version), so the renamed handle sends a new key instead of the remembered payload, and an item that was already committed is silently duplicated. Re-send before renaming. With `ingest.verify_assets=true` on the server, new items still fail during a cas-server replacement (the server's own CAS HEAD has no retry; the item fails with 502, which the SDK treats as a definitive item error); only already-committed keys replay without CAS.
- `strict=True` raises `NexusBatchError` on first failure; `error.failures` contains the failed results.
- `strict=False` (default) records failures in results and continues.
- **Permission failures (401/403) always raise `NexusError`, regardless of `strict`.** They mean the
  account cannot write to this dataset at all, so every item fails for the same reason — swallowing
  them would let a CI job ingest nothing and still exit 0. `Dataset.patch_annotations` behaves the same.
- **`429`(서버가 적재 자리를 못 준 것)는 실패로 세지 않는다.** SDK 가 `Retry-After` 를
  존중해 최대 8회 물러났다 다시 온다(지수 백오프 + 지터). 그래도 안 되면 그때서야 `429`
  가 올라온다. `workers` 의 의미는 위 「Manual flush」 를 볼 것. 이 429 는 nexus 요청에만 해당하고 부재 시간
  (`retry_timeout`)을 먹지 않는다. CAS 요청의 429·503 대기(서버 `Retry-After` 포함, 예산에 맞춰 자르지 않는다)는
  `retry_timeout` 을 먹고, CAS 500 은 예산 전체 동안 다시 보낸다.

### `Dataset.get_annotation(sample_id)` / `Dataset.save_annotation(sample_id, annotation)`

이 버전에서 그 샘플의 annotation만 가져와(`{"meta": {...}, "<group_key>": [...], ...}`) 고친 뒤
그대로 되돌려 저장하는 왕복 한 쌍. `get_annotation`은 `get_sample`과 달리 코어 필드
(`sample_id`/`split`/…)를 섞지 않으므로 골라낼 필요가 없다.

- **`save_annotation`은 이 버전의 annotation을 통째로 교체한다** — 다른 그룹이 남아 있는 채로
  어떤 그룹만 빼고 저장하면 그 그룹은 삭제된다. sealed 버전이면 `NexusError(status_code=409)`.
- **nexus-server `0.1.18` 부터**: 그룹을 하나도 안 보내면(meta만 남거나 dict가 비면) 아무것도
  안 바뀐다 — 비우려면 그 그룹을 `[]`로 보낼 것. 그렇게 보낸 그룹이 전부 비었는데 그 샘플에
  다른 버전과 공유하는 원본(base)이 있으면 서버가 409를 준다(unlink 안내). `0.1.16` 이하
  서버는 그룹을 하나도 안 보내도 전부 지웠다.
- 반환은 서버 보고서다: `{"instances": n, "skipped": n, "skipped_reasons": {"missing_label": n,
  "not_an_object": n, "group_not_an_array": n}}`. `skipped`가 0이 아니면 형식이 어긋난 원소가
  버려진 것이고, 교체는 병합이 아니므로 **그만큼 기존 인스턴스가 지워졌다** — SDK가
  `RuntimeWarning`도 함께 낸다.
- 구버전 서버(nexus-server 0.1.3 이하)는 빈 본문을 주므로 `{}`가 반환되고 경고도 없다.
  `{}`는 "유실 없음"이 아니라 "서버가 알려주지 않음"이다 — `report.get("skipped")`로 읽을 것.
- 여러 건은 `Dataset.patch_annotations({sample_id: annotation, ...})`. 같은 경고를 내지만
  건별 보고서는 주지 않는다(단일은 `None`, 배치는 `list[IngestResult]`).

### `Dataset.transfer_owner(email)` / `NexusClient.transfer_dataset_owner(dataset_id, email)`

이 dataset의 소유권을 다른 계정으로 넘긴다(`PUT /api/v1/datasets/{dataset_id}/owner`).
**현재 소유자만** 부를 수 있고, 갱신된 dataset dict를 돌려준다. **SDK 0.1.6+, 서버 0.1.6+.**

- 넘긴 뒤에는 이 계정이 그 dataset을 **지울 수 없다** — `NexusError(status_code=403)`.
  수정·적재는 역할이 가르므로 `editor` 이상이면 계속 된다(서버 0.1.7+).
  되돌리려면 새 소유자가 다시 넘겨주거나 운영자(superuser)가 지정해야 한다.
- **주인이 없는(`owner_user_id`가 `None`) dataset에는 쓸 수 없다** — `403`. 주인 없는 것을 인수하는
  것은 운영자(superuser)의 관리 조작이다.
- **자기 자신에게 넘기면** `400`. `email`로 가입된 계정이 없거나 dataset이 없으면 `404`.
- 소유권은 dataset 단위다 — 핸들이 어느 버전을 가리키든 그 dataset의 모든 버전이 함께 넘어간다.

### `Dataset.to_df(split=None, label=None, labels=False, workers=4)`

Downloads manifest metadata and pages through the paginated `/manifest/samples` endpoint, returning a `pandas.DataFrame`. Requires a **sealed** version (raises `NexusError` on draft).

| Column | Description |
|--------|-------------|
| `sample_id` | UUID v7 string |
| `split` | `train` / `val` / `test` / `None` |
| `image_cas_url` | Direct CAS URL for the image |
| `image_hash_hex` | BLAKE3 hash |
| `image_size` | bytes |
| `labels` | `list[dict]` of instances (only when `labels=True`) |

### `nexus.IngestResult`

```python
@dataclass
class IngestResult:
    ok: bool
    sample: Sample | None
    sample_id: str | None  # set on success
    error: str | None      # set on failure
    status_code: int | None  # HTTP status of the failure, if any (CAS errors too, 0.1.18)
    index: int | None      # position in the input (0.1.18); result lists follow this order
```

## Error Handling

| Exception | Trigger |
|---|---|
| `NexusAuthError` | Login failure or token expired |
| `NexusCasError` | CAS upload/HEAD failure |
| `NexusIngestError` | Server ingest failure (4xx/5xx) |
| `NexusBatchError` | `strict=True` and one or more samples failed |

## Development

```bash
pip install -e "./sdk[dev]"
pytest sdk/tests/ -v
```
