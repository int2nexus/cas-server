import pytest
from nexus.meta import Meta
from nexus._types import NexusValidationError


def test_meta_preserves_all_keys_including_unknown():
    d = {"width": 1280, "height": 992, "META_Project": "ICMU", "intrinsic": {"fx": 0.0}}
    m = Meta.from_dict(d)
    assert m["width"] == 1280
    assert m["META_Project"] == "ICMU"
    assert m.to_dict() == d


def test_meta_setitem_roundtrips():
    m = Meta.from_dict({"width": 1})
    m["width"] = 1280
    assert m.to_dict()["width"] == 1280


def test_meta_validate_requires_object():
    Meta.from_dict({"width": 1}).validate()
    with pytest.raises(NexusValidationError):
        Meta([1, 2]).validate()
    with pytest.raises(NexusValidationError):
        Meta("x").validate()
