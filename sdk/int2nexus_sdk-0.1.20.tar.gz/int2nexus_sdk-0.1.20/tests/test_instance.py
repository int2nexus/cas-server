import pytest
from nexus.instance import Instance
from nexus.labels import Label
from nexus._types import NexusValidationError


def test_from_row_splits_common_keys_and_components():
    row = {"id": "abc", "label": "Unknown", "confidence": 1.0,
           "bounding_box": {"type": "bounding_box", "rect": [0, 0, 1, 1]}}
    inst = Instance.from_row(row)
    assert inst.id == "abc"
    assert inst.label == "Unknown"
    assert isinstance(inst.get_component("bounding_box"), Label)
    assert inst.to_dict() == row  # round-trip


def test_from_row_multi_component_merged():
    row = {"id": "x", "label": "Person",
           "body": {"type": "keypoint_2d", "num_keypoints": 1, "x": [0], "y": [0], "visibility": [1]},
           "cls": {"type": "classification", "label": "a"}}
    inst = Instance.from_row(row)
    assert set(inst.components.keys()) == {"body", "cls"}
    assert inst.to_dict() == row


def test_validate_requires_label():
    inst = Instance.from_row({"id": "x", "bounding_box": {"type": "bounding_box", "rect": [0, 0, 1, 1]}})
    with pytest.raises(NexusValidationError):
        inst.validate()


def test_validate_allows_empty_string_label():
    inst = Instance(id="x", label="", components={})
    inst.validate()  # 서버가 이미 ""를 허용하므로 로드된 샘플이 save()에서 막히면 안 됨


def test_new_instance_gets_default_id():
    inst = Instance(id=None, label="a", components={})
    assert isinstance(inst.id, str) and inst.id


def test_validate_rejects_non_numeric_confidence():
    inst = Instance(id="x", label="a", components={}, confidence="0.9")
    with pytest.raises(NexusValidationError):
        inst.validate()


def test_validate_rejects_non_int_track_id():
    inst = Instance(id="x", label="a", components={}, track_id="x")
    with pytest.raises(NexusValidationError):
        inst.validate()


def test_validate_rejects_bool_track_id():
    inst = Instance(id="x", label="a", components={}, track_id=True)
    with pytest.raises(NexusValidationError):
        inst.validate()


def test_validate_allows_zero_confidence_and_track_id():
    inst = Instance(id="x", label="a", components={}, confidence=0, track_id=0)
    inst.validate()  # 0 은 유효한 값 — falsy 라고 거부하면 안 됨


def test_from_row_keeps_non_dict_extra_keys_out_of_components():
    # "occluded": true 는 dict가 아니므로 component로 오인되면 안 된다 — component가 되면
    # Label.validate()가 "component must be an object"로 거부해 이 그룹의 save()를 막는다.
    row = {"id": "x", "label": "car", "occluded": True,
           "bounding_box": {"type": "bounding_box", "rect": [0, 0, 1, 1]}}
    inst = Instance.from_row(row)
    assert set(inst.components.keys()) == {"bounding_box"}
    assert inst.extras == {"occluded": True}
    inst.validate()  # extras 는 검증 대상이 아니다


def test_extras_round_trip_verbatim():
    row = {"id": "x", "label": "car", "occluded": True, "score": 0.9, "note": None}
    inst = Instance.from_row(row)
    assert inst.to_dict() == row


def test_set_component_overrides_same_name_extra():
    # "occluded": True 가 from_row에서 extra로 들어간 뒤 set_component("occluded", ...)로
    # component가 되면, to_dict()가 extras를 components 뒤에 덮어써서 component를 가리면 안 된다.
    row = {"id": "x", "label": "car", "occluded": True}
    inst = Instance.from_row(row)
    inst.set_component("occluded", Label({"type": "classification", "label": "yes"}))
    assert inst.to_dict()["occluded"] == {"type": "classification", "label": "yes"}


@pytest.mark.parametrize("bad", ["container", "group", "dict", "str"])
def test_non_label_component_is_a_validation_error(bad):
    from nexus.group import LabelContainer, LabelGroup
    value = {"container": LabelContainer([]), "group": LabelGroup([]),
             "dict": {"type": "bounding_box", "rect": [0, 0, 1, 1]}, "str": "x"}[bad]
    inst = Instance(id="a", label="car", components={})
    inst.set_component("bounding_box", value)
    with pytest.raises(NexusValidationError):
        inst.validate()
    with pytest.raises(NexusValidationError):
        inst.to_dict()


# ---------------------------------------------------------------------------
# 빈 id 도 "없음" — 하이픈 형식 UUID v4 를 채운다
# ---------------------------------------------------------------------------

import re  # noqa: E402

_UUID4 = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$")


@pytest.mark.parametrize("given", [None, ""])
def test_missing_or_empty_id_gets_hyphenated_uuid4(given):
    assert _UUID4.match(Instance(id=given, label="a", components={}).id)


def test_from_row_fills_empty_and_absent_ids():
    assert _UUID4.match(Instance.from_row({"id": "", "label": "a"}).id)
    assert _UUID4.match(Instance.from_row({"label": "a"}).id)


def test_existing_id_is_kept_verbatim():
    assert Instance.from_row({"id": "65f0c0ffee0000000000abcd", "label": "a"}).id == "65f0c0ffee0000000000abcd"


def test_generated_ids_are_distinct():
    ids = {Instance(id="", label="a", components={}).id for _ in range(200)}
    assert len(ids) == 200
