import copy
import json
import pathlib
import warnings
import pytest
from nexus.annotated import AnnotatedSample
from nexus._types import NexusError, NexusValidationError

FIX = pathlib.Path(__file__).parent / "fixtures" / "annotation_sample.json"
KINDS = {"raw_dets": "container", "raw_kps": "container", "merged": "group"}
# some_undeclared_group is not declared -> RawGroup


def _load():
    return json.loads(FIX.read_text(encoding="utf-8"))


def test_roundtrip_is_semantically_identical():
    d = _load()
    # deepcopy 로 넘겨 s 가 d 와 객체를 공유하지 않게 한다 — 공유하면
    # to_dict() 가 d 자체를 도로 내놓아도 통과해 왕복 계약을 검증하지 못한다.
    s = AnnotatedSample.from_dict(copy.deepcopy(d), KINDS)
    assert s.to_dict() == d  # dict comparison is order-agnostic


def test_group_kinds_resolved():
    from nexus.group import LabelGroup, LabelContainer, RawGroup
    s = AnnotatedSample.from_dict(_load(), KINDS)
    assert isinstance(s.get_group("raw_dets"), LabelContainer)
    assert isinstance(s.get_group("merged"), LabelGroup)
    assert isinstance(s.get_group("some_undeclared_group"), RawGroup)


def test_meta_preserved():
    s = AnnotatedSample.from_dict(_load(), KINDS)
    assert s.meta["META_Project"] == "DUMMY"
    assert s.meta["width"] == 1280


def test_roundtrip_without_meta_preserves_absence():
    d_without_meta = {
        "raw_dets": [
            {"id": "aaaa0000", "label": "car", "confidence": 1.0,
             "bounding_box": {"type": "bounding_box", "rect": [0.55, 0.10, 0.45, 1.05]}}
        ]
    }
    s = AnnotatedSample.from_dict(d_without_meta, KINDS)
    result = s.to_dict()
    assert result == d_without_meta
    assert "meta" not in result


def test_meta_added_to_absent_sample_is_output():
    d_without_meta = {
        "raw_dets": [
            {"id": "aaaa0000", "label": "car", "confidence": 1.0,
             "bounding_box": {"type": "bounding_box", "rect": [0.55, 0.10, 0.45, 1.05]}}
        ]
    }
    s = AnnotatedSample.from_dict(d_without_meta, KINDS)
    s.meta["width"] = 10
    result = s.to_dict()
    assert "meta" in result
    assert result["meta"]["width"] == 10


class _FakeDataset:
    def __init__(self, merge_status=None):
        self.saved = None          # save_annotation(통째 교체) 기록 — 기존 테스트 호환
        self.merged = []           # merge_annotation(PATCH) 기록
        self.merge_status = merge_status
        self.unsupported = False

    def save_annotation(self, sample_id, ann):
        self.saved = (sample_id, copy.deepcopy(ann))
        return {"instances": 1, "skipped": 0, "skipped_reasons": {}}

    def merge_annotation(self, sample_id, patch):
        if self.merge_status is not None:
            err = NexusError("method not allowed")
            err.status_code = self.merge_status
            raise err
        self.merged.append((sample_id, copy.deepcopy(patch)))
        return {"instances": 0, "skipped": 0, "skipped_reasons": {}}

    def _partial_annotations_unsupported(self):
        return self.unsupported

    def _mark_partial_annotations_unsupported(self):
        self.unsupported = True


def _loaded(ds):
    return AnnotatedSample.from_dict(copy.deepcopy(_load()), KINDS, sample_id="s1", dataset=ds)


def test_save_sends_only_edited_group_and_server_keeps_the_rest():
    ds = _FakeDataset()
    s = _loaded(ds)
    # 한 그룹만 편집
    s.get_group("merged")[0].get_component("bounding_box").rect = [0.1, 0.1, 0.2, 0.2]
    s.save()
    assert ds.saved is None, "부분 저장이어야 하는데 통째 교체가 나갔다"
    (sid, patch), = ds.merged
    assert sid == "s1"
    # 미편집 그룹·RawGroup·meta 는 보내지 않는다(서버가 보존)
    assert set(patch) == {"merged"}
    assert patch["merged"][0]["bounding_box"]["rect"] == [0.1, 0.1, 0.2, 0.2]


def test_save_validates_and_raises_on_bad_meta():
    d = _load(); d["meta"] = [1, 2]  # 객체 아님
    ds = _FakeDataset()
    s = AnnotatedSample.from_dict(d, KINDS, sample_id="s1", dataset=ds)
    # Meta 는 dict 전용 mutator 만 갖지만, 리스트 meta 가 "편집됐다"는 것을 보이려면
    # 기준과 달라지기만 하면 된다 — 내부 데이터를 직접 바꿔 diff 가 다르게 만든다.
    s.meta._data = [1, 2, 3]
    with pytest.raises(NexusValidationError):
        s.save()


def test_bad_meta_loaded_unchanged_does_not_block_group_save():
    d = _load(); d["meta"] = [1, 2]  # 객체 아님
    ds = _FakeDataset()
    s = AnnotatedSample.from_dict(d, KINDS, sample_id="s1", dataset=ds)
    s.get_group("merged")[0].get_component("bounding_box").rect = [0.1, 0.1, 0.2, 0.2]
    s.save()  # meta 를 건드리지 않았으므로 raise 하지 않는다
    (_, patch), = ds.merged
    assert set(patch) == {"merged"}


def test_load_does_not_validate():
    d = _load(); d["raw_kps"][0]["keypoint_2d"]["x"] = [0.1]  # 길이 불일치지만 로드는 통과
    AnnotatedSample.from_dict(d, KINDS)  # no raise


def test_save_does_not_validate_an_untouched_group_even_if_it_is_broken():
    # save()는 이번에 보낼 그룹만 검증한다 — 안 건드린 raw_kps의 keypoint 길이 불일치가
    # merged 그룹 저장을 막으면 안 된다.
    d = _load()
    d["raw_kps"][0]["keypoint_2d"]["x"] = [0.1]  # num_keypoints(3)와 길이가 안 맞음
    ds = _FakeDataset()
    s = AnnotatedSample.from_dict(d, KINDS, sample_id="s1", dataset=ds)
    s.get_group("merged")[0].get_component("bounding_box").rect = [0.1, 0.1, 0.2, 0.2]
    s.save()  # raise하면 안 된다
    (_, patch), = ds.merged
    assert set(patch) == {"merged"}


def test_occluded_style_extra_field_round_trips_and_group_edit_still_saves():
    # "occluded": true 처럼 component가 아닌 스칼라 추가 필드는 verbatim 왕복되고,
    # 같은 인스턴스의 component 편집·저장을 막지 않는다(component로 오인되면 Label.validate가
    # "component must be an object"로 거부해 이 그룹 전체의 save()가 막혔을 것이다).
    d = _load()
    d["merged"][0]["occluded"] = True
    ds = _FakeDataset()
    s = AnnotatedSample.from_dict(copy.deepcopy(d), KINDS, sample_id="s1", dataset=ds)
    assert s.to_dict() == d, "occluded가 verbatim 왕복돼야 한다"
    s.get_group("merged")[0].get_component("bounding_box").rect = [0.1, 0.1, 0.2, 0.2]
    s.save()
    (_, patch), = ds.merged
    assert set(patch) == {"merged"}
    assert patch["merged"][0]["occluded"] is True
    assert patch["merged"][0]["bounding_box"]["rect"] == [0.1, 0.1, 0.2, 0.2]


def test_save_sends_only_changed_group():
    ds = _FakeDataset()
    s = _loaded(ds)
    s.get_group("merged")[0].get_component("bounding_box").rect = [0.1, 0.1, 0.2, 0.2]
    s.save()
    assert ds.saved is None, "부분 저장이어야 하는데 통째 교체가 나갔다"
    (_, patch), = ds.merged
    assert set(patch) == {"merged"}
    assert patch["merged"][0]["bounding_box"]["rect"] == [0.1, 0.1, 0.2, 0.2]


def test_unchanged_sample_sends_nothing():
    ds = _FakeDataset()
    rep = _loaded(ds).save()
    assert ds.merged == [] and ds.saved is None
    assert rep["instances"] == 0 and rep["skipped"] == 0


def test_rows_without_id_are_not_resent_when_unchanged():
    # from_row 가 id 없는 행에 uuid4 를 채운다 — 원본과 비교하면 매번 바뀐 것으로 보인다.
    ds = _FakeDataset()
    ann = {"g": [{"label": "car", "bounding_box": {"type": "bounding_box", "rect": [0, 0, 1, 1]}}],
           "meta": {}}
    s = AnnotatedSample.from_dict(ann, {"g": "container"}, sample_id="s1", dataset=ds)
    s.save()
    assert ds.merged == []


def test_removed_group_is_sent_as_empty_list():
    ds = _FakeDataset()
    s = _loaded(ds)
    del s.groups["raw_kps"]
    s.save()
    (_, patch), = ds.merged
    assert patch == {"raw_kps": []}


def test_meta_diff_sends_changed_and_deleted_keys():
    ds = _FakeDataset()
    s = _loaded(ds)
    s.meta["width"] = 1920
    s.meta["META_Project"] = None       # 삭제
    del s.meta["channels"]              # 삭제
    s.meta["new_key"] = "x"
    s.save()
    (_, patch), = ds.merged
    assert set(patch) == {"meta"}
    assert patch["meta"] == {"width": 1920, "META_Project": None, "channels": None, "new_key": "x"}


def test_second_save_sends_only_increment():
    ds = _FakeDataset()
    s = _loaded(ds)
    s.meta["width"] = 1
    s.save()
    s.meta["height"] = 2
    s.save()
    assert [p for _, p in ds.merged] == [{"meta": {"width": 1}}, {"meta": {"height": 2}}]


def test_null_meta_sample_can_save_groups_and_add_meta():
    ds = _FakeDataset()
    ann = {"g": [{"id": "a", "label": "c", "bounding_box": {"type": "bounding_box", "rect": [0, 0, 1, 1]}}],
           "meta": None}
    s = AnnotatedSample.from_dict(ann, {"g": "container"}, sample_id="s1", dataset=ds)
    assert s.to_dict()["meta"] is None, "변경이 없으면 null 을 그대로 왕복한다"
    s.get_group("g")[0].get_component("bounding_box").rect = [0, 0, 2, 2]
    s.save()
    s.meta["w"] = 1
    s.save()
    assert [set(p) for _, p in ds.merged] == [{"g"}, {"meta"}]
    assert ds.merged[1][1]["meta"] == {"w": 1}


def test_405_falls_back_to_full_put_once_with_warning():
    ds = _FakeDataset(merge_status=405)
    s = _loaded(ds)
    s.meta["width"] = 1
    s.meta["META_Project"] = None
    with pytest.warns(RuntimeWarning):
        s.save()
    sid, full = ds.saved
    assert sid == "s1" and "merged" in full and "raw_dets" in full
    assert full["meta"]["width"] == 1
    assert "META_Project" not in full["meta"], "삭제 표식은 PUT 에서 null 이 아니라 키를 빼야 한다"
    assert ds.unsupported is True
    # 두 번째는 PATCH 를 시도하지 않고 경고 없이 바로 통째 교체
    ds.saved = None
    s.meta["width"] = 2
    with warnings.catch_warnings():
        warnings.simplefilter("error")
        s.save()
    assert ds.saved is not None


def test_other_errors_do_not_fall_back():
    ds = _FakeDataset(merge_status=409)
    s = _loaded(ds)
    s.meta["width"] = 1
    with pytest.raises(NexusError):
        s.save()
    assert ds.saved is None


def test_sample_without_baseline_sends_everything():
    ds = _FakeDataset()
    base = AnnotatedSample.from_dict(copy.deepcopy(_load()), KINDS)
    s = AnnotatedSample("s1", base.meta, base.groups, dataset=ds)   # from_dict 를 거치지 않음
    s.save()
    (_, patch), = ds.merged
    assert set(patch) == set(_load()) , "기준이 없으면 모든 그룹과 meta 를 보낸다"
