import pytest
from nexus.dataset import Dataset
from nexus.annotated import AnnotatedSample
from nexus._types import NexusValidationError


class _FakeClient:
    def __init__(self, ann):
        self._ann = ann
        self.saved = None
        self.merged = None

    def get_sample_annotations(self, dataset_id, version, sample_id):
        return self._ann

    def patch_annotations(self, dataset_id, version, sample_id, ann):
        self.saved = ann
        return {"skipped": 0}

    def merge_sample_annotations(self, dataset_id, version, sample_id, annotation_data):
        self.merged = (dataset_id, version, sample_id, annotation_data)
        return {"instances": 1, "skipped": 0, "skipped_reasons": {}}


def _ds(ann):
    # 기존 생성자에 맞춰 최소 구성. dataset_id/version/name/client 를 직접 세팅.
    ds = Dataset.__new__(Dataset)
    ds._client = _FakeClient(ann)
    ds._dataset_id = "d1"
    ds._version = "v1"
    ds._name = "n"
    ds._group_kinds = {}
    return ds


def test_declare_group_kinds_rejects_bad_value():
    ds = _ds({})
    with pytest.raises((ValueError, NexusValidationError)):
        ds.declare_group_kinds({"g": "not_a_kind"})


def test_load_sample_returns_annotatedsample_with_kinds():
    ann = {"g": [{"id": "a", "label": "c",
                  "bounding_box": {"type": "bounding_box", "rect": [0, 0, 1, 1]}}],
           "meta": {"width": 1}}
    ds = _ds(ann)
    ds.declare_group_kinds({"g": "container"})
    s = ds.load_sample("s1")
    assert isinstance(s, AnnotatedSample)
    from nexus.group import LabelContainer
    assert isinstance(s.get_group("g"), LabelContainer)


def test_load_sample_save_roundtrips_through_client():
    ann = {"g": [{"id": "a", "label": "c",
                  "bounding_box": {"type": "bounding_box", "rect": [0, 0, 1, 1]}}],
           "meta": {"width": 1}}
    ds = _ds(ann)
    ds.declare_group_kinds({"g": "container"})
    s = ds.load_sample("s1")
    s.get_group("g")[0].get_component("bounding_box").rect = [0, 0, 2, 2]
    s.save()
    dataset_id, version, sample_id, patch = ds._client.merged
    assert (dataset_id, version, sample_id) == ("d1", "v1", "s1")
    assert set(patch) == {"g"}
    assert patch["g"][0]["id"] == "a"
    assert ds._client.saved is None, "부분 저장이어야 하는데 통째 교체가 나갔다"


def test_merge_annotation_sends_patch_and_returns_report():
    ann = {"g": [], "meta": {}}
    ds = _ds(ann)
    calls = []

    def merge(dataset_id, version, sample_id, annotation_data):
        calls.append((dataset_id, version, sample_id, annotation_data))
        return {"instances": 1, "skipped": 0, "skipped_reasons": {}}

    ds._client.merge_sample_annotations = merge
    rep = ds.merge_annotation("s1", {"g": [{"id": "a", "label": "c"}]})
    assert rep["instances"] == 1
    assert calls == [("d1", "v1", "s1", {"g": [{"id": "a", "label": "c"}]})]


def test_partial_unsupported_flag_is_shared_on_client():
    ds = _ds({"meta": {}})
    assert ds._partial_annotations_unsupported() is False
    ds._mark_partial_annotations_unsupported()
    assert ds._partial_annotations_unsupported() is True
    assert getattr(ds._client, "_no_partial_annotations") is True
