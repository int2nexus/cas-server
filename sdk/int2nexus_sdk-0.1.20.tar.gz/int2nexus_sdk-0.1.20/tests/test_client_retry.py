"""`NexusClient._send` 의 부재 재시도(스펙 §4-2)."""

import pytest
import requests
from urllib3.exceptions import MaxRetryError, NewConnectionError, ProtocolError

import nexus._retry as _retry
from nexus._types import NexusError
from nexus.client import NexusClient

NEXUS = "http://nexus-test"
FROM_NEXUS = {"X-Request-Id": "r1"}


def refused():
    return requests.exceptions.ConnectionError(
        MaxRetryError(None, "http://x/", reason=NewConnectionError(None, "refused"))
    )


def reset():
    return requests.exceptions.ConnectionError(ProtocolError("Connection aborted.", ConnectionResetError()))


class FakeClock:
    def __init__(self):
        self.t = 0.0

    def now(self):
        return self.t

    def sleep(self, s):
        self.t += s


@pytest.fixture
def clock(monkeypatch):
    c = FakeClock()
    monkeypatch.setattr(_retry, "_now", c.now)
    monkeypatch.setattr("nexus.client.time.sleep", c.sleep)
    return c


def client(requests_mock, *, idempotency=False, retry_timeout=None):
    headers = {"X-Nexus-Idempotency": "1"} if idempotency else {}
    requests_mock.post(f"{NEXUS}/api/v1/auth/login", json={"token": "tok"}, headers=headers)
    return NexusClient(NEXUS, "u@x.com", "pw", retry_timeout=retry_timeout)


def test_learns_idempotency_from_login_response(requests_mock, clock):
    assert client(requests_mock, idempotency=True)._ingest_idempotency
    assert not client(requests_mock)._ingest_idempotency


def test_connect_refused_is_retried_even_for_unsafe_post(requests_mock, clock):
    c = client(requests_mock)
    m = requests_mock.post(f"{NEXUS}/datasets/d1/versions/v1/seal", [{"exc": refused()}, {"json": {"status": "sealed"}}])
    assert c._post("/datasets/d1/versions/v1/seal").json()["status"] == "sealed"
    assert m.call_count == 2


def test_reset_after_send_is_not_retried_for_unsafe_post(requests_mock, clock):
    c = client(requests_mock)
    m = requests_mock.post(f"{NEXUS}/datasets/d1/versions/v1/seal", [{"exc": reset()}, {"json": {}}])
    with pytest.raises(requests.exceptions.ConnectionError):
        c._post("/datasets/d1/versions/v1/seal")
    assert m.call_count == 1


def test_reset_after_send_is_retried_for_get(requests_mock, clock):
    c = client(requests_mock)
    m = requests_mock.get(f"{NEXUS}/datasets", [{"exc": reset()}, {"json": []}])
    assert c._get("/datasets").json() == []
    assert m.call_count == 2


def test_nexus_own_503_is_not_retried(requests_mock, clock):
    c = client(requests_mock)
    m = requests_mock.get(
        f"{NEXUS}/annotation-sessions/s1",
        [{"status_code": 503, "json": {"error": "CVAT"}, "headers": FROM_NEXUS}, {"json": {}}],
    )
    with pytest.raises(NexusError) as e:
        c._get("/annotation-sessions/s1")
    assert e.value.status_code == 503
    assert m.call_count == 1


def test_proxy_503_is_retried_for_get(requests_mock, clock):
    c = client(requests_mock)
    m = requests_mock.get(f"{NEXUS}/datasets", [{"status_code": 503, "text": "<html>"}, {"json": []}])
    assert c._get("/datasets").json() == []
    assert m.call_count == 2


def test_nexus_502_is_retried_for_bucket_ensure(requests_mock, clock):
    c = client(requests_mock)
    m = requests_mock.post(
        f"{NEXUS}/api/v1/buckets/ensure",
        [{"status_code": 502, "json": {"error": "cas error"}, "headers": FROM_NEXUS}, {"json": {}}],
    )
    c.ensure_bucket("b")
    assert m.call_count == 2


def test_owner_put_is_not_retried_after_send(requests_mock, clock):
    c = client(requests_mock)
    m = requests_mock.put(f"{NEXUS}/api/v1/datasets/d1/owner", [{"exc": reset()}, {"json": {}}])
    with pytest.raises(requests.exceptions.ConnectionError):
        c._put("/api/v1/datasets/d1/owner", json={"email": "x@y"})
    assert m.call_count == 1


def test_batch_not_retried_until_server_advertises(requests_mock, clock):
    c = client(requests_mock, idempotency=False)
    m = requests_mock.post(f"{NEXUS}/ingest/batch", [{"exc": reset()}, {"json": {"results": []}}])
    with pytest.raises(requests.exceptions.ConnectionError):
        c.ingest_batch([{"idempotency_key": "k"}])
    assert m.call_count == 1


def test_batch_retried_when_advertised_and_every_item_keyed(requests_mock, clock):
    c = client(requests_mock, idempotency=True)
    m = requests_mock.post(f"{NEXUS}/ingest/batch", [{"exc": reset()}, {"json": {"results": []}}])
    assert c.ingest_batch([{"idempotency_key": "k1"}, {"idempotency_key": "k2"}]) == {"results": []}
    assert m.call_count == 2


def test_batch_not_retried_when_an_item_lacks_key(requests_mock, clock):
    c = client(requests_mock, idempotency=True)
    m = requests_mock.post(f"{NEXUS}/ingest/batch", [{"exc": reset()}, {"json": {"results": []}}])
    with pytest.raises(requests.exceptions.ConnectionError):
        c.ingest_batch([{"idempotency_key": "k1"}, {}])
    assert m.call_count == 1


def test_gives_up_after_budget(requests_mock, clock):
    c = client(requests_mock, retry_timeout=10)
    m = requests_mock.get(f"{NEXUS}/datasets", exc=refused())
    with pytest.raises(requests.exceptions.ConnectionError):
        c._get("/datasets")
    assert m.call_count >= 3
    assert clock.t <= 10.0 + 1e-9


def test_retry_timeout_zero_disables(requests_mock, clock):
    c = client(requests_mock, retry_timeout=0)
    m = requests_mock.get(f"{NEXUS}/datasets", exc=refused())
    with pytest.raises(requests.exceptions.ConnectionError):
        c._get("/datasets")
    assert m.call_count == 1


def test_429_does_not_consume_absence_budget(requests_mock, clock):
    # 429 백오프로 시계가 1 초 넘게 흘러도, 그 뒤의 첫 부재 실패는 예산 전부(1 초)를 받는다.
    c = client(requests_mock, retry_timeout=1)
    m = requests_mock.get(
        f"{NEXUS}/datasets",
        [
            {"status_code": 429, "headers": {"Retry-After": "5"}, "json": {"error": "busy"}},
            {"exc": refused()},
            {"json": []},
        ],
    )
    assert c._get("/datasets").json() == []
    assert m.call_count == 3
    assert clock.t > 1.0


def test_429_after_first_failure_does_not_consume_budget(requests_mock, clock):
    c = client(requests_mock, retry_timeout=1)
    m = requests_mock.get(
        f"{NEXUS}/datasets",
        [
            {"exc": refused()},
            {"status_code": 429, "headers": {"Retry-After": "5"}, "json": {"error": "busy"}},
            {"exc": refused()},
            {"json": []},
        ],
    )
    assert c._get("/datasets").json() == []
    assert m.call_count == 4
    assert clock.t > 5


def test_relogin_connection_error_goes_to_retry_loop(requests_mock, clock):
    c = client(requests_mock)
    requests_mock.post(f"{NEXUS}/api/v1/auth/login", [{"exc": refused()}, {"json": {"token": "t2"}}])
    m = requests_mock.get(f"{NEXUS}/datasets", [{"status_code": 401, "json": {"error": "unauthorized"}}, {"json": []}])
    assert c._get("/datasets").json() == []
    assert m.call_count == 2
