"""flush 의 멱등 키와 재전송 본문(스펙 §4-3)."""

import json
from unittest.mock import MagicMock

import pytest
import requests

from nexus._types import NexusError, NexusIngestError
from nexus.dataset import Dataset
from nexus.sample import CasRef, Sample


def sample():
    ref = CasRef("kitti", "images/a.png", hash_hex="h", size=10, content_type="image/png")
    ann = {"meta": {"format_version": "1.0.0", "filename": "http://cas/kitti/images/a.png", "width": 4, "height": 4}}
    return Sample(image=ref, annotation=ann)


def ds(client, version="v1"):
    return Dataset(client, MagicMock(), "d1", "kitti", version)


def ok(replayed=False):
    item = {"index": 0, "sample_id": "s1", "dataset_id": "d1"}
    if replayed:
        item["replayed"] = True
    return {"results": [item]}


def sent(client):
    return client.ingest_batch.call_args[0][0][0]


def test_key_is_per_version_and_stable_within_version():
    c = MagicMock()
    s = sample()
    k1 = ds(c, "v1")._prepare_payload(s)["idempotency_key"]
    k2 = ds(c, "v2")._prepare_payload(s)["idempotency_key"]
    assert k1 != k2
    assert ds(c, "v1")._prepare_payload(s)["idempotency_key"] == k1


def test_ambiguous_failure_resends_same_bytes_even_if_annotation_mutated():
    c = MagicMock()
    d = ds(c)
    s = sample()
    c.ingest_batch.side_effect = requests.exceptions.ConnectionError("reset")
    d.add(s)
    assert not d.flush(verbose=False)[0].ok
    first = json.dumps(sent(c), sort_keys=True)

    s.annotation["meta"]["width"] = 999  # 붙은 본문은 처음 보낸 것의 깊은 복사라 영향이 없어야 한다
    c.ingest_batch.side_effect = None
    c.ingest_batch.return_value = ok(replayed=True)
    d.add(s)
    res = d.flush(verbose=False)
    assert json.dumps(sent(c), sort_keys=True) == first
    assert res[0].ok and res[0].replayed
    assert s._pending_payloads == {} and s._idempotency_keys == {}


def _with_state(s):
    s._idempotency_keys[("kitti", "v1")] = "k"
    s._pending_payloads[("kitti", "v1")] = {"idempotency_key": "k"}
    return s


def test_copy_does_not_inherit_idempotency_state():
    import copy

    s = _with_state(sample())
    for c2 in (copy.copy(s), copy.deepcopy(s)):
        assert c2._idempotency_keys == {} and c2._pending_payloads == {}
        assert c2._image_ref == s._image_ref
    # 원본의 상태는 그대로이고, 복사본의 상태를 건드려도 원본에 닿지 않는다.
    assert s._idempotency_keys == {("kitti", "v1"): "k"}
    copy.copy(s)._idempotency_keys[("a", "b")] = "x"
    assert ("a", "b") not in s._idempotency_keys


def test_flush_of_shallow_copies_sends_distinct_keys():
    import copy

    c = MagicMock()
    d = ds(c)
    tpl = sample()
    copies = []
    for i in range(3):
        s = copy.copy(tpl)
        s.image = CasRef("kitti", f"images/{i}.png", hash_hex="h", size=10, content_type="image/png")
        copies.append(s)
    c.ingest_batch.return_value = {
        "results": [{"index": i, "sample_id": f"s{i}", "dataset_id": "d1"} for i in range(3)]
    }
    d.add(copies)
    d.flush(verbose=False)
    items = c.ingest_batch.call_args[0][0]
    assert len({p["idempotency_key"] for p in items}) == 3
    # image 만 다시 대입한 복제본이 템플릿의 이미지가 아니라 자기 이미지를 보낸다.
    assert sorted(p["image"]["key"] for p in items) == [f"images/{i}.png" for i in range(3)]


def _rich(key):
    return CasRef("kitti", key, hash_hex="h", size=10, content_type="image/png")


def test_reassigned_image_is_what_prepare_sends():
    c = MagicMock()
    s = sample()
    s.image = _rich("images/new.png")
    assert ds(c)._prepare_payload(s)["image"]["key"] == "images/new.png"


def test_in_place_assets_mutation_is_sent():
    c = MagicMock()
    s = Sample(image=_rich("images/a.png"), annotation={"meta": {"width": 4, "height": 4}}, assets={})
    # assets={} 로 만들어도 그 dict 가 그대로 필드에 남아 이후 그 자리 변경이 보여야 한다.
    s.assets["depth"] = _rich("depth/a.png")
    assert ds(c)._prepare_payload(s)["assets"]["depth"]["key"] == "depth/a.png"


def test_reassigned_annotation_is_what_prepare_sends():
    c = MagicMock()
    s = sample()
    s.annotation = {"meta": {"format_version": "1.0.0", "width": 7, "height": 7}}
    assert ds(c)._prepare_payload(s)["annotation"]["annotation_data"]["meta"]["width"] == 7


def test_local_path_assigned_after_construction_fails_prepare_not_silently_old_image():
    c = MagicMock()
    d = ds(c)
    s = sample()
    s.image = "C:/tmp/local.png"
    d.add(s)
    res = d.flush(verbose=False)
    assert not res[0].ok
    c.ingest_batch.assert_not_called()


def test_definitive_failure_keeps_key_but_not_payload():
    c = MagicMock()
    d = ds(c)
    s = sample()
    c.ingest_batch.side_effect = NexusIngestError("bad", status_code=422)
    d.add(s)
    d.flush(verbose=False)
    assert s._pending_payloads == {}
    assert ("kitti", "v1") in s._idempotency_keys


def test_success_clears_key_so_readding_makes_a_new_sample():
    c = MagicMock()
    d = ds(c)
    s = sample()
    c.ingest_batch.return_value = ok()
    d.add(s)
    d.flush(verbose=False)
    k1 = sent(c)["idempotency_key"]
    d.add(s)
    d.flush(verbose=False)
    assert sent(c)["idempotency_key"] != k1


def test_item_error_drops_payload_keeps_key():
    c = MagicMock()
    d = ds(c)
    s = sample()
    s._pending_payloads[("kitti", "v1")] = {"idempotency_key": "k", "dataset": "kitti"}
    s._idempotency_keys[("kitti", "v1")] = "k"
    c.ingest_batch.return_value = {"results": [{"index": 0, "error": "bad", "status": 400}]}
    d.add(s)
    d.flush(verbose=False)
    assert s._pending_payloads == {}
    assert s._idempotency_keys == {("kitti", "v1"): "k"}


def test_summary_counts_replayed(capsys):
    c = MagicMock()
    d = ds(c)
    c.ingest_batch.return_value = ok(replayed=True)
    d.add(sample())
    d.flush(verbose=True)
    assert "replayed 1" in capsys.readouterr().out


def _refused():
    from urllib3.exceptions import MaxRetryError, NewConnectionError

    return requests.exceptions.ConnectionError(
        MaxRetryError(None, "http://x/", reason=NewConnectionError(None, "refused"))
    )


def test_budget_ending_on_connect_phase_failure_still_keeps_payload():
    # 같은 요청의 앞선 시도가 보낸 뒤 끊겼을 수 있다 — 마지막 예외만 보고 본문을 버리면 다음 flush 가 409 를 낸다.
    c = MagicMock()
    d = ds(c)
    s = sample()
    c.ingest_batch.side_effect = _refused()
    d.add(s)
    d.flush(verbose=False)
    assert s._pending_payloads[("kitti", "v1")] == sent(c)


def test_whole_chunk_422_clears_existing_payload_keeps_key():
    c = MagicMock()
    d = ds(c)
    s = sample()
    s._pending_payloads[("kitti", "v1")] = {"idempotency_key": "k", "dataset": "kitti"}
    s._idempotency_keys[("kitti", "v1")] = "k"
    c.ingest_batch.side_effect = NexusIngestError("bad", status_code=422)
    d.add(s)
    d.flush(verbose=False)
    assert s._pending_payloads == {}
    assert s._idempotency_keys == {("kitti", "v1"): "k"}


def test_whole_chunk_401_keeps_existing_payload():
    c = MagicMock()
    d = ds(c)
    s = sample()
    pending = {"idempotency_key": "k", "dataset": "kitti"}
    s._pending_payloads[("kitti", "v1")] = pending
    s._idempotency_keys[("kitti", "v1")] = "k"
    c.ingest_batch.side_effect = NexusIngestError("unauthorized", status_code=401)
    d.add(s)
    with pytest.raises(NexusError):  # 전량 401 은 flush 가 「다시 connect()」 로 올린다
        d.flush(verbose=False)
    assert s._pending_payloads == {("kitti", "v1"): pending}


def test_missing_item_result_keeps_payload():
    c = MagicMock()
    d = ds(c)
    s = sample()
    c.ingest_batch.return_value = {"results": []}
    d.add(s)
    d.flush(verbose=False)
    assert s._pending_payloads[("kitti", "v1")] == sent(c)
