"""`nexus._retry` — 서버 부재 재시도 판정(스펙 §4-1, §4-2)."""

import math

import pytest
import requests
from urllib3.exceptions import MaxRetryError, NewConnectionError, ProtocolError

from nexus import _retry


def refused():
    return requests.exceptions.ConnectionError(
        MaxRetryError(None, "http://x/", reason=NewConnectionError(None, "refused"))
    )


def reset():
    return requests.exceptions.ConnectionError(ProtocolError("Connection aborted.", ConnectionResetError()))


class Clock:
    def __init__(self):
        self.t = 0.0

    def __call__(self):
        return self.t


def test_resolve_timeout_default_env_and_explicit(monkeypatch):
    assert _retry.resolve_timeout(None) == 120.0
    monkeypatch.setenv("NEXUS_RETRY_TIMEOUT", "30")
    assert _retry.resolve_timeout(None) == 30.0
    assert _retry.resolve_timeout(5) == 5.0
    assert _retry.resolve_timeout("0") == 0.0


@pytest.mark.parametrize("bad", ["abc", -1, True, math.nan, math.inf])
def test_resolve_timeout_rejects(bad):
    with pytest.raises(ValueError, match="retry_timeout"):
        _retry.resolve_timeout(bad)


def test_backoff_grows_to_cap():
    assert [_retry.backoff_delay(a, rand=lambda: 1.0) for a in range(7)] == [0.5, 1.0, 2.0, 4.0, 8.0, 8.0, 8.0]


def test_deadline_counts_from_first_failure_and_clamps():
    clock = Clock()
    clock.t = 1000.0  # 요청 시작이 아니라 첫 실패부터 잰다
    d = _retry.Deadline(10.0, clock=clock)
    assert d.next_delay(rand=lambda: 1.0) == 0.5
    clock.t += 9.8
    assert d.next_delay(rand=lambda: 1.0) == pytest.approx(0.2)
    clock.t += 0.2
    assert d.next_delay(rand=lambda: 1.0) is None


def test_deadline_credit():
    clock = Clock()
    d = _retry.Deadline(10.0, clock=clock)
    d.credit(5.0)  # 첫 실패 전에는 아무 일도 하지 않는다
    assert d.next_delay(rand=lambda: 1.0) == 0.5
    clock.t += 5.0
    d.credit(5.0)  # 예산이 정확히 그만큼 늘어난다
    clock.t += 9.5
    assert d.next_delay(rand=lambda: 1.0) == pytest.approx(0.5)
    clock.t += 0.5
    assert d.next_delay(rand=lambda: 1.0) is None


def test_deadline_zero_is_disabled():
    assert _retry.Deadline(0.0, clock=Clock()).next_delay() is None


def test_connect_phase_detection():
    assert _retry.is_connect_phase(refused())
    assert _retry.is_connect_phase(requests.exceptions.ConnectTimeout())
    assert not _retry.is_connect_phase(reset())
    assert not _retry.is_connect_phase(requests.exceptions.ReadTimeout())


@pytest.mark.parametrize(
    "method,path,idem,expected",
    [
        ("GET", "/datasets", False, True),
        ("HEAD", "/x", False, True),
        ("PUT", "/datasets/d1/versions/v%2F1/samples/s1/annotations", False, True),
        ("PUT", "/subsets/s1", False, True),
        ("PUT", "/datasets/d1/favorite", False, True),
        ("PUT", "/api/v1/datasets/d1/owner", False, False),
        ("POST", "/api/v1/buckets/ensure", False, True),
        ("POST", "/datasets/d1/versions/v1/samples/explorer", False, True),
        ("POST", "/datasets/d1/versions/v1/samples/explorer/count", False, True),
        ("POST", "/datasets/d1/versions/v1/facets/counts", False, True),
        ("POST", "/datasets/d1/versions/v1/seal", False, False),
        ("POST", "/ingest/batch", False, False),
        ("POST", "/ingest/batch", True, True),
        ("POST", "/ingest", True, True),
        ("DELETE", "/datasets/d1", False, False),
        ("PATCH", "/datasets/d1", False, False),
    ],
)
def test_is_safe(method, path, idem, expected):
    assert _retry.is_safe(method, path, ingest_idempotent=idem) is expected


def test_should_retry_table():
    seal = ("POST", "/datasets/d1/versions/v1/seal")
    get = ("GET", "/datasets")
    assert _retry.should_retry(*seal, exc=refused())
    assert not _retry.should_retry(*seal, exc=reset())
    assert _retry.should_retry(*get, exc=reset())
    assert _retry.should_retry(*get, exc=requests.exceptions.ReadTimeout())
    assert _retry.should_retry(*get, status=502, from_nexus=True)
    assert _retry.should_retry(*get, status=503, from_nexus=False)
    assert not _retry.should_retry(*get, status=503, from_nexus=True)
    assert not _retry.should_retry(*get, status=504, from_nexus=True)
    assert not _retry.should_retry(*seal, status=502, from_nexus=False)
    assert not _retry.should_retry(*get, status=500)
    assert not _retry.should_retry(*get, exc=ValueError("x"))
    # TLS·인증서 문제는 서버 부재가 아니다 — 기다려도 풀리지 않는다.
    assert not _retry.should_retry(*get, exc=requests.exceptions.SSLError())
    # 응답 본문을 읽던 중 끊김은 서버가 처리했을 수 있다 — 안전한 요청만 다시 보낸다.
    chunked = requests.exceptions.ChunkedEncodingError("broken")
    assert _retry.should_retry(*get, exc=chunked)
    assert not _retry.should_retry(*seal, exc=chunked)


def test_keeps_pending_payload():
    class E(Exception):
        def __init__(self, code):
            self.status_code = code

    assert _retry.keeps_pending_payload(reset())
    # 마지막 시도가 연결 단계여도 앞선 시도가 보낸 뒤 끊겼을 수 있다.
    assert _retry.keeps_pending_payload(refused())
    assert _retry.keeps_pending_payload(E(None))
    assert _retry.keeps_pending_payload(E(502))
    assert _retry.keeps_pending_payload(E(401))
    assert _retry.keeps_pending_payload(E(403))
    assert _retry.keeps_pending_payload(E(429))
    assert not _retry.keeps_pending_payload(E(400))
    assert not _retry.keeps_pending_payload(E(422))
