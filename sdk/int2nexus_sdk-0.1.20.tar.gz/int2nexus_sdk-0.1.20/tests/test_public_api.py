"""Test that annotation object layer symbols are exposed at package top level."""
import nexus as nx


def test_public_symbols_exposed():
    """Verify that all annotation object layer symbols are exported from nexus package."""
    for name in [
        "AnnotatedSample",
        "LabelGroup",
        "LabelContainer",
        "RawGroup",
        "Instance",
        "Meta",
        "Label",
        "Detection",
        "Keypoint2D",
        "Keypoint3D",
        "Classification",
        "ScalarValue",
        "VectorValue",
        "Cuboid3D",
        "Polygon",
        "Polyline",
        "NexusValidationError",
    ]:
        assert hasattr(nx, name), f"nexus.{name} not exported"


def test_client_classes_and_cas_accessor_are_public():
    """`nx.Dataset(client, cas, ...)` 를 직접 만들 수 있도록 두 클라이언트 클래스와 접속된
    CAS 클라이언트 접근자를 공개 목록에 올린다(0.1.18)."""
    for name in ["CasClient", "NexusClient", "cas_client"]:
        assert name in nx.__all__, f"{name} not in nexus.__all__"
        assert hasattr(nx, name)
