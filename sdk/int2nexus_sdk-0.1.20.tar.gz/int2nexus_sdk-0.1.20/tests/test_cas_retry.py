"""CAS 전송 재시도(`DeadlineRetry`)와 STS 부재 예산(스펙 §4-4)."""

import pytest
from urllib3.exceptions import MaxRetryError, NewConnectionError

import nexus._retry as _retry
from nexus.cas import CasClient, DeadlineRetry, _build_session
from nexus.sts import CasSts, StsCredentials
from nexus._types import NexusCasError

from .sts_helpers import CAS, STS_URL, FakeClock, sts_ok


def deadline_retry(timeout=10):
    return DeadlineRetry(total=None, connect=None, read=None, status=None, retry_timeout=timeout)


def fail(r):
    return r.increment(method="PUT", url="/b/k", error=NewConnectionError(None, "refused"))


def test_template_instance_never_starts_the_clock(monkeypatch):
    t = [0.0]
    monkeypatch.setattr(_retry, "_now", lambda: t[0])
    template = deadline_retry(10)
    t[0] = 1000.0  # 세션을 오래 쓴 뒤의 첫 실패
    nxt = fail(template)
    assert template.first_failure_at is None
    assert nxt.first_failure_at == 1000.0
    assert nxt.retry_timeout == 10
    assert not nxt.is_exhausted()


def test_exhausts_only_after_timeout_from_first_failure(monkeypatch):
    t = [0.0]
    monkeypatch.setattr(_retry, "_now", lambda: t[0])
    r1 = fail(deadline_retry(10))
    t[0] = 5.0
    r2 = fail(r1)
    assert r2.first_failure_at == 0.0
    t[0] = 10.5
    with pytest.raises(MaxRetryError):
        fail(r2)


def test_non_absence_error_exhausts_after_three_retries_with_time_left(monkeypatch):
    # TLS 오류처럼 연결·읽기가 아닌 실패는 부재가 아니다 — 예산이 남아 있어도 3 회 뒤 소진된다(실측: 34 회·124.8 초).
    from urllib3.exceptions import SSLError

    monkeypatch.setattr(_retry, "_now", lambda: 0.0)
    r = _build_session(retry_timeout=120).get_adapter("http://x").max_retries
    for _ in range(3):
        r = r.increment(method="GET", url="/b/k", error=SSLError("bad cert"))
    assert not r.is_exhausted()
    with pytest.raises(MaxRetryError):
        r.increment(method="GET", url="/b/k", error=SSLError("bad cert"))


def test_connect_failures_are_not_counted_by_other(monkeypatch):
    monkeypatch.setattr(_retry, "_now", lambda: 0.0)
    r = _build_session(retry_timeout=120).get_adapter("http://x").max_retries
    for _ in range(10):
        r = fail(r)
    assert not r.is_exhausted()


def test_backoff_never_exceeds_remaining_budget(monkeypatch):
    t = [0.0]
    monkeypatch.setattr(_retry, "_now", lambda: t[0])
    monkeypatch.setattr(_retry, "backoff_delay", lambda n, rand=None: 8.0)
    r = fail(deadline_retry(10))
    t[0] = 9.8
    r = fail(r)
    assert r.get_backoff_time() == pytest.approx(0.2)
    t[0] = 10.0
    assert r.get_backoff_time() == 0.0
    t[0] = 1.0
    assert r.get_backoff_time() == 8.0


def test_session_uses_deadline_retry_or_legacy():
    assert isinstance(_build_session(retry_timeout=120).get_adapter("http://x").max_retries, DeadlineRetry)
    legacy = _build_session(retry_timeout=0).get_adapter("http://x").max_retries
    assert not isinstance(legacy, DeadlineRetry)
    assert legacy.total == 3


def test_direct_casclient_reads_env(monkeypatch):
    # 도입처 업로더처럼 CasClient 를 직접 만들어도 같은 상한을 받는다(스펙 §4-1).
    monkeypatch.setenv("NEXUS_RETRY_TIMEOUT", "7")
    c = CasClient("http://cas")
    assert c._retry_timeout == 7.0
    assert c._session.get_adapter("http://cas").max_retries.retry_timeout == 7.0


def _sts(tmp_path, clock, retry_timeout):
    f = tmp_path / "token"
    f.write_text("tok-web-1", encoding="utf-8")

    def sleep(s):
        clock.t += s

    return StsCredentials(CAS, CasSts(token_file=str(f)), clock=clock, sleep=sleep, retry_timeout=retry_timeout)


def test_sts_waits_through_absence_when_no_usable_cache(tmp_path, requests_mock):
    clock = FakeClock()
    m = requests_mock.post(STS_URL, [{"status_code": 503}] * 8 + [{"text": sts_ok(clock.t + 3600)}])
    creds = _sts(tmp_path, clock, retry_timeout=120).current()
    assert creds.key_id == "CASS-1"
    assert m.call_count == 9


def test_sts_keeps_legacy_attempts_when_cache_is_usable(tmp_path, requests_mock):
    clock = FakeClock()
    requests_mock.post(STS_URL, [{"text": sts_ok(clock.t + 500)}] + [{"status_code": 503}] * 20)
    p = _sts(tmp_path, clock, retry_timeout=120)
    first = p.current()  # 남은 수명 500 초 — 갱신 창(600) 안이지만 60 초보다 길다
    clock.t += 31  # MIN_REFRESH_INTERVAL_SECS 를 넘겨 갱신을 시도하게 한다
    with pytest.warns(UserWarning):
        again = p.current()
    assert again is first
    assert requests_mock.call_count == 1 + 4  # 캐시가 쓸 만하면 종전처럼 4 회만


def test_sts_zero_budget_is_legacy(tmp_path, requests_mock):
    clock = FakeClock()
    requests_mock.post(STS_URL, [{"status_code": 503}] * 10)
    with pytest.raises(NexusCasError):
        _sts(tmp_path, clock, retry_timeout=0).current()
    assert requests_mock.call_count == 4
