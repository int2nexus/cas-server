"""`nx.connect(retry_timeout=)` · NEXUS_RETRY_TIMEOUT · 설정 파일 키(스펙 §4-1)."""

import json

import pytest

import nexus


def _reset():
    nexus._client = None
    nexus._cas = None


def _connect(**kw):
    return nexus.connect(nexus_url="http://nexus", email="u@x.com", password="pass",
                         cas_url="http://cas", cas_key_id="kid", cas_secret="sec", **kw)


@pytest.fixture
def login(requests_mock):
    return requests_mock.post("http://nexus/api/v1/auth/login", json={"token": "tok"})


def test_argument_reaches_both_clients(login):
    _reset()
    client = _connect(retry_timeout=5)
    assert client._retry_timeout == 5.0
    assert nexus.cas_client()._retry_timeout == 5.0


def test_env_var(monkeypatch, login):
    _reset()
    monkeypatch.setenv("NEXUS_RETRY_TIMEOUT", "9")
    _connect()
    assert nexus._client._retry_timeout == 9.0
    assert nexus.cas_client()._retry_timeout == 9.0


def test_settings_file_key(monkeypatch, tmp_path, login):
    _reset()
    path = tmp_path / "settings.json"
    path.write_text(json.dumps({"retry_timeout": 11}), encoding="utf-8")
    _connect(settings_path=str(path))
    assert nexus._client._retry_timeout == 11.0


def test_argument_beats_env(monkeypatch, login):
    _reset()
    monkeypatch.setenv("NEXUS_RETRY_TIMEOUT", "9")
    _connect(retry_timeout=0)
    assert nexus._client._retry_timeout == 0.0


def test_invalid_env_fails_before_login(monkeypatch, login):
    _reset()
    monkeypatch.setenv("NEXUS_RETRY_TIMEOUT", "abc")
    with pytest.raises(ValueError, match="retry_timeout"):
        _connect()
    assert login.call_count == 0
