import pytest
from nexus.labels import (
    Label, LABEL_REGISTRY, Detection, Classification, Keypoint2D, Keypoint3D,
    ScalarValue, VectorValue, Cuboid3D, Polygon, Polyline
)
from nexus._types import NexusValidationError


def test_generic_label_roundtrips_unknown_type():
    d = {"type": "brand_new_thing", "foo": [1, 2], "bar": "x"}
    lab = Label.from_dict(d)
    assert isinstance(lab, Label)
    assert lab.type == "brand_new_thing"
    assert lab.to_dict() == d


def test_generic_label_validate_requires_dict_with_type():
    Label.from_dict({"type": "x"}).validate()  # ok
    with pytest.raises(NexusValidationError):
        Label({"no_type": 1}).validate()
    with pytest.raises(NexusValidationError):
        Label([1, 2, 3]).validate()
    with pytest.raises(NexusValidationError):
        Label("x").validate()


def test_registry_dispatch_uses_type_field():
    # 서브클래스 등록 전에는 generic 으로 떨어진다
    assert Label.from_dict({"type": "bounding_box", "rect": [0, 0, 1, 1]}).type == "bounding_box"


def test_detection_roundtrip_and_int_rect_ok():
    d = {"type": "bounding_box", "rect": [0, 0, 1, 1], "label": "car", "confidence": 0.9}
    det = Label.from_dict(d)
    assert isinstance(det, Detection)
    assert det.rect == [0, 0, 1, 1]
    det.validate()  # int 좌표 허용
    assert det.to_dict() == d


def test_detection_out_of_range_rect_passes_validate():
    Detection({"type": "bounding_box", "rect": [0.5, 0.5, 1.6, 1.2]}).validate()  # range 검사 없음


def test_detection_rect_must_be_four_numbers():
    with pytest.raises(NexusValidationError):
        Detection({"type": "bounding_box", "rect": [0, 0, 1]}).validate()
    with pytest.raises(NexusValidationError):
        Detection({"type": "bounding_box", "rect": "x"}).validate()


def test_classification_label_must_be_str():
    Classification({"type": "classification", "label": "Driver"}).validate()
    with pytest.raises(NexusValidationError):
        Classification({"type": "classification", "label": 4}).validate()


def _kp2d(n=2):
    return {"type": "keypoint_2d", "num_keypoints": n,
            "x": [0.1] * n, "y": [0.2] * n, "visibility": [2] * n}


def test_keypoint2d_roundtrip_and_visibility_2_ok():
    d = _kp2d(3); d["visibility"] = [0, 2, 2]
    kp = Keypoint2D(d); kp.validate()  # visibility 0/2 허용(range 검사 없음)
    assert kp.to_dict() == d


def test_keypoint2d_length_mismatch_fails():
    d = _kp2d(3); d["x"] = [0.1, 0.1]  # len 2 != num 3
    with pytest.raises(NexusValidationError):
        Keypoint2D(d).validate()


def test_keypoint2d_num_must_be_int():
    d = _kp2d(2); d["num_keypoints"] = "2"
    with pytest.raises(NexusValidationError):
        Keypoint2D(d).validate()


def test_keypoint3d_requires_z_consistent():
    d = {"type": "keypoint_3d", "num_keypoints": 2,
         "x": [0, 0], "y": [0, 0], "z": [0, 0], "visibility": [1, 1]}
    Keypoint3D(d).validate()
    d["z"] = [0]  # 길이 불일치
    with pytest.raises(NexusValidationError):
        Keypoint3D(d).validate()


def test_scalar_and_vector_value():
    ScalarValue({"type": "value", "value": 3.5}).validate()
    with pytest.raises(NexusValidationError):
        ScalarValue({"type": "value", "value": "x"}).validate()
    VectorValue({"type": "values", "values": [1, 2, 3]}).validate()
    with pytest.raises(NexusValidationError):
        VectorValue({"type": "values", "values": "x"}).validate()


def test_cuboid3d():
    Cuboid3D({"type": "cuboid_3d", "center": [0, 0, 0], "dimensions": [1, 1, 1],
              "rotation": [1, 0, 0, 0, 1, 0, 0, 0, 1]}).validate()
    with pytest.raises(NexusValidationError):
        Cuboid3D({"type": "cuboid_3d", "center": [0, 0], "dimensions": [1, 1, 1],
                  "rotation": [1, 0, 0, 0, 1, 0, 0, 0, 1]}).validate()


def test_polygon_polyline():
    Polygon({"type": "polygon", "points": [0, 0, 1, 0, 1, 1]}).validate()  # 3점=6값
    with pytest.raises(NexusValidationError):
        Polygon({"type": "polygon", "points": [0, 0, 1, 0]}).validate()  # 2점
    Polyline({"type": "polyline", "points": [0, 0, 1, 1]}).validate()  # 2점=4값
    with pytest.raises(NexusValidationError):
        Polyline({"type": "polyline", "points": [0, 0]}).validate()  # 1점


def test_polyline_closed_property_roundtrip():
    d = {"type": "polyline", "points": [0, 0, 1, 1], "closed": True}
    pline = Polyline(d)
    assert pline.closed is True
    assert pline.to_dict() == d


def test_polyline_closed_property_access():
    pline = Polyline({"type": "polyline", "points": [0, 0, 1, 1], "closed": False})
    assert pline.closed is False
    pline.closed = True
    assert pline.closed is True


# ---------------------------------------------------------------------------
# 키워드 생성자 · 클래스와 type 일치
# ---------------------------------------------------------------------------

from nexus.labels import (  # noqa: E402
    LABEL_REGISTRY, Detection, Classification, Keypoint2D, Keypoint3D, ScalarValue,
    VectorValue, Cuboid3D, Polygon, Polyline,
)


def test_keyword_constructor_fills_type_and_validates():
    d = Detection(rect=[0.1, 0.2, 0.3, 0.4], label="Person", confidence=0.9)
    assert d.to_dict() == {"type": "bounding_box", "rect": [0.1, 0.2, 0.3, 0.4],
                           "label": "Person", "confidence": 0.9}
    d.validate()


def test_keyword_constructor_drops_none_fields():
    assert Detection(rect=[0, 0, 1, 1], label=None).to_dict() == {"type": "bounding_box", "rect": [0, 0, 1, 1]}


def test_keyword_constructor_rejects_unknown_field():
    with pytest.raises(TypeError, match="rct"):
        Detection(rct=[0, 0, 1, 1])


def test_dict_and_keywords_together_rejected():
    with pytest.raises(TypeError):
        Detection({"type": "bounding_box", "rect": [0, 0, 1, 1]}, label="x")


def test_keypoint_keyword_derives_num_keypoints():
    k = Keypoint2D(x=[0.1, 0.2], y=[0.3, 0.4], visibility=[2, 1])
    assert k.num_keypoints == 2
    k.validate()


def test_keypoint_explicit_num_keypoints_is_kept_and_checked():
    k = Keypoint2D(x=[0.1], y=[0.3], visibility=[2], num_keypoints=2)
    with pytest.raises(NexusValidationError):
        k.validate()


@pytest.mark.parametrize("label", [
    Detection(rect=[0, 0, 1, 1]),
    Classification(label="Belted"),
    Keypoint2D(x=[0.0], y=[0.0], visibility=[1]),
    Keypoint3D(x=[0.0], y=[0.0], z=[0.0], visibility=[1]),
    ScalarValue(value=1.5),
    VectorValue(values=[1.0, 2.0], dim=2),
    Cuboid3D(center=[0, 0, 0], dimensions=[1, 1, 1], rotation=[1, 0, 0, 0, 1, 0, 0, 0, 1]),
    Polygon(points=[0, 0, 1, 0, 1, 1]),
    Polyline(points=[0, 0, 1, 1], closed=False),
])
def test_all_nine_types_build_by_keyword_and_round_trip(label):
    label.validate()
    again = Label.from_dict(label.to_dict())
    assert type(again) is type(label)
    assert LABEL_REGISTRY[label.type] is type(label)


def test_class_type_mismatch_is_a_validation_error():
    with pytest.raises(NexusValidationError, match="bounding_box"):
        Detection({"type": "polygon", "rect": [0, 0, 1, 1]}).validate()


def test_subclass_type_mismatch_is_caught():
    # Polyline 은 Polygon 을, Keypoint3D 는 Keypoint2D 를 상속한다 — 부모 type 을 들고 있어도 안 된다.
    with pytest.raises(NexusValidationError):
        Polyline({"type": "polygon", "points": [0, 0, 1, 1]}).validate()
    with pytest.raises(NexusValidationError):
        Keypoint3D({"type": "keypoint_2d", "x": [0], "y": [0], "z": [0], "visibility": [1],
                    "num_keypoints": 1}).validate()


# ---------------------------------------------------------------------------
# 선택 필드는 있을 때만 검사 — 서버 README 의 cuboid_3d·keypoint_3d 예시 모양
# ---------------------------------------------------------------------------

def test_cuboid3d_without_rotation_is_valid():
    Cuboid3D({"type": "cuboid_3d", "center": [2.5, -1.0, 15.0], "dimensions": [4.5, 1.8, 1.5]}).validate()
    Cuboid3D(center=[0, 0, 0], dimensions=[1, 1, 1]).validate()


def test_cuboid3d_rotation_checked_when_present():
    with pytest.raises(NexusValidationError):
        Cuboid3D(center=[0, 0, 0], dimensions=[1, 1, 1], rotation=[1, 0, 0]).validate()


def test_keypoints_without_visibility_are_valid():
    Keypoint3D({"type": "keypoint_3d", "num_keypoints": 2,
                "x": [0.1, 0.2], "y": [0.3, 0.4], "z": [1.0, 2.0]}).validate()
    Keypoint2D(x=[0.1], y=[0.2]).validate()


def test_keypoint_visibility_checked_when_present():
    with pytest.raises(NexusValidationError):
        Keypoint2D(x=[0.1, 0.2], y=[0.3, 0.4], visibility=[1]).validate()      # 길이
    with pytest.raises(NexusValidationError):
        Keypoint2D(x=[0.1], y=[0.2], visibility=[0.5]).validate()              # 정수 아님


def test_center_and_dimensions_stay_required():
    with pytest.raises(NexusValidationError):
        Cuboid3D({"type": "cuboid_3d", "center": [0, 0, 0]}).validate()


# ---------------------------------------------------------------------------
# num_keypoints 도 있을 때만 — 없으면 축 배열 길이끼리만 맞으면 된다
# ---------------------------------------------------------------------------

def test_keypoint_without_num_keypoints_is_valid_when_axes_agree():
    Keypoint3D({"type": "keypoint_3d", "x": [1, 2], "y": [1, 2], "z": [1, 2]}).validate()
    Keypoint2D({"type": "keypoint_2d", "x": [1], "y": [1], "visibility": [2]}).validate()


def test_keypoint_without_num_keypoints_rejects_mismatched_axes():
    with pytest.raises(NexusValidationError):
        Keypoint3D({"type": "keypoint_3d", "x": [1, 2], "y": [1], "z": [1, 2]}).validate()
    with pytest.raises(NexusValidationError):
        Keypoint2D({"type": "keypoint_2d", "x": [1, 2], "y": [1, 2], "visibility": [2]}).validate()


def test_keypoint_num_keypoints_checked_when_present():
    with pytest.raises(NexusValidationError):
        Keypoint2D({"type": "keypoint_2d", "num_keypoints": "2", "x": [1, 2], "y": [1, 2]}).validate()
    with pytest.raises(NexusValidationError):
        Keypoint2D({"type": "keypoint_2d", "num_keypoints": 3, "x": [1, 2], "y": [1, 2]}).validate()
