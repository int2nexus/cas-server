from pathlib import Path
import pytest
from nexus.cas import CasClient
from nexus._types import NexusCasError

CAS = "http://cas-test"


@pytest.fixture
def client():
    return CasClient(CAS, key_id="kid", secret="sec")


def test_head_returns_metadata(requests_mock, client):
    requests_mock.head(f"{CAS}/bucket/images/img.png",
                       headers={"ETag": '"abc123"', "content-length": "2048",
                                "content-type": "image/png"})
    result = client.head("bucket", "images/img.png")
    assert result["hash_hex"] == "abc123"
    assert result["size"] == 2048
    assert result["content_type"] == "image/png"


def test_head_returns_none_on_404(requests_mock, client):
    requests_mock.head(f"{CAS}/bucket/key", status_code=404)
    assert client.head("bucket", "key") is None


def test_head_raises_on_server_error(requests_mock, client):
    requests_mock.head(f"{CAS}/bucket/key", status_code=500)
    with pytest.raises(NexusCasError):
        client.head("bucket", "key")


def test_put_sends_data(requests_mock, client):
    requests_mock.put(f"{CAS}/bucket/key", status_code=200)
    client.put("bucket", "key", b"hello-data", "image/png")
    assert requests_mock.last_request.body == b"hello-data"
    assert requests_mock.last_request.headers["Content-Type"] == "image/png"


def test_put_raises_on_failure(requests_mock, client):
    requests_mock.put(f"{CAS}/bucket/key", status_code=403)
    with pytest.raises(NexusCasError):
        client.put("bucket", "key", b"data", "image/png")


def test_cas_get_returns_content(requests_mock):
    from nexus.cas import CasClient
    requests_mock.get("http://cas/b/k.png", content=b"hello")
    cas = CasClient("http://cas")
    assert cas.get("b", "k.png") == b"hello"


def test_cas_get_raises_on_error(requests_mock):
    import pytest
    from nexus.cas import CasClient
    from nexus._types import NexusCasError
    requests_mock.get("http://cas/b/missing", status_code=404)
    cas = CasClient("http://cas")
    with pytest.raises(NexusCasError) as ei:
        cas.get("b", "missing")
    # 호출부(to_df)가 404와 403을 다르게 안내하려면 상태 코드가 속성으로 있어야 한다.
    assert ei.value.status_code == 404


def test_cas_get_passes_timeout(requests_mock):
    requests_mock.get("http://cas/b/k", content=b"x")
    cas = CasClient("http://cas")
    cas.get("b", "k", timeout=7)
    assert requests_mock.last_request.timeout == 7


def test_session_has_retry_adapter(client):
    from requests.adapters import HTTPAdapter
    adapter = client._session.get_adapter("http://cas-test/b/k")
    assert isinstance(adapter, HTTPAdapter)
    retry = adapter.max_retries
    assert retry.total == 3
    assert "PUT" in retry.allowed_methods
    assert 503 in retry.status_forcelist


def test_session_reused_across_calls(requests_mock, client):
    # 같은 클라이언트의 모든 요청이 동일 Session을 쓴다(keep-alive 재사용).
    requests_mock.head(f"{CAS}/b/k", headers={"ETag": '"h"', "content-length": "1"})
    s1 = client._session
    client.head("b", "k")
    assert client._session is s1


def test_canonical_request_exact_bytes():
    # 줄바꿈/공백이 서버 cas_client.rs::sigv4_auth와 바이트 동일해야 한다.
    from nexus.cas import _canonical_request
    cr = _canonical_request("PUT", "/data/k.png", "localhost:8080", "abc123", "20260101T000000Z")
    expected = (
        "PUT\n"
        "/data/k.png\n"
        "\n"
        "host:localhost:8080\n"
        "x-amz-content-sha256:abc123\n"
        "x-amz-date:20260101T000000Z\n"
        "\n"
        "host;x-amz-content-sha256;x-amz-date\n"
        "abc123"
    )
    assert cr == expected


def test_signed_headers_structure_and_payload_hash():
    from nexus.cas import CasClient, _sha256_hex
    c = CasClient("http://localhost:8080", key_id="rootkey", secret="rootsecret")
    h = c._signed_headers("PUT", "/data/k.png", b"hello")
    assert h["x-amz-content-sha256"] == _sha256_hex(b"hello")
    assert "T" in h["x-amz-date"] and h["x-amz-date"].endswith("Z")
    assert h["Authorization"].startswith("AWS4-HMAC-SHA256 Credential=rootkey/")
    assert "SignedHeaders=host;x-amz-content-sha256;x-amz-date" in h["Authorization"]
    assert "/s3/aws4_request," in h["Authorization"]


def test_signed_headers_empty_without_creds():
    from nexus.cas import CasClient
    c = CasClient("http://localhost:8080")
    assert c._signed_headers("PUT", "/b/k", b"x") == {}


def test_default_region_is_cas_default():
    # CAS 서버가 region "cas-default"로 고정 검증하므로 SDK 기본값도 이에 맞춘다.
    from nexus.cas import CasClient
    c = CasClient("http://localhost:8080", key_id="k", secret="s")
    assert c._region == "cas-default"
    assert "/cas-default/s3/aws4_request" in c._signed_headers("PUT", "/b/k", b"x")["Authorization"]


def test_host_keeps_port():
    from nexus.cas import CasClient
    assert CasClient("http://localhost:8080")._host() == "localhost:8080"
    assert CasClient("https://cas.example.com")._host() == "cas.example.com"


def test_put_sends_sigv4_headers(requests_mock):
    from nexus.cas import CasClient, _sha256_hex
    requests_mock.put("http://cas-test/data/k.png", status_code=200)
    c = CasClient("http://cas-test", key_id="rootkey", secret="rootsecret")
    c.put("data", "k.png", b"hello", "image/png")
    req = requests_mock.last_request
    assert req.headers["x-amz-content-sha256"] == _sha256_hex(b"hello")
    assert req.headers["Authorization"].startswith("AWS4-HMAC-SHA256 Credential=rootkey/")
    assert req.headers["Content-Type"] == "image/png"


def test_hash_bytes_is_deterministic():
    data = b"test-data-for-hashing"
    assert CasClient.hash_bytes(data) == CasClient.hash_bytes(data)
    assert len(CasClient.hash_bytes(data)) == 64  # blake3: 32 bytes = 64 hex chars


def test_hash_bytes_differs_for_different_data():
    assert CasClient.hash_bytes(b"aaa") != CasClient.hash_bytes(b"bbb")


def test_content_type_image_png():
    assert CasClient.content_type(Path("photo.png")) == "image/png"


def test_content_type_unknown_defaults_to_octet_stream():
    assert CasClient.content_type(Path("file.xyz123")) == "application/octet-stream"


def test_no_auth_header_when_credentials_empty(requests_mock):
    c = CasClient(CAS, key_id="", secret="")
    requests_mock.head(f"{CAS}/b/k",
                       headers={"ETag": '"h"', "content-length": "0"})
    c.head("b", "k")
    assert "Authorization" not in requests_mock.last_request.headers


def test_cas_head_prefers_x_cas_hash_over_etag(requests_mock):
    from nexus.cas import CasClient
    requests_mock.head(
        "http://cas/b/k",
        headers={"ETag": '"md5deadbeef"', "x-cas-hash": "blake3abc", "content-length": "5"},
    )
    cas = CasClient("http://cas")
    assert cas.head("b", "k")["hash_hex"] == "blake3abc"


# ── 403 의 두 얼굴 ────────────────────────────────────────────────────────────
#
# cas 는 정책 거부를 `AccessDenied`, 폐기·만료된 키를 `InvalidAccessKeyId` 로 낸다
# (cas `src/error.rs`). 전에는 둘을 구분하지 못해 "클라이언트당 한 번" 이라는 예산으로
# 눌렀는데, 자격증명에 만료가 붙으면서 오래 도는 프로세스가 두 번째 만료에서 죽는다.

_ACCESS_DENIED = (
    '<?xml version="1.0"?><Error><Code>AccessDenied</Code>'
    "<Message>denied</Message></Error>"
)
_BAD_KEY = (
    '<?xml version="1.0"?><Error><Code>InvalidAccessKeyId</Code>'
    "<Message>The AWS Access Key Id you provided does not exist in our records.</Message>"
    "</Error>"
)


def _client_with_reissue(calls):
    """403 마다 새 자격증명을 주는 클라이언트. `calls` 에 호출 횟수가 쌓인다."""

    def on_forbidden():
        calls.append(1)
        return (f"kid-{len(calls)}", f"sec-{len(calls)}")

    return CasClient(CAS, key_id="kid", secret="sec", on_forbidden=on_forbidden)


def test_policy_denial_does_not_reissue(requests_mock):
    """`AccessDenied` 는 자격증명을 새로 받아도 절대 풀리지 않는다.

    여기서 재발급이 일어나면 파일 500 개를 올리는 `viewer` 하나가 자격증명을 그만큼
    찍어내고, 상한 정리가 남의 자격증명을 그만큼 폐기한다.
    """
    calls = []
    c = _client_with_reissue(calls)
    requests_mock.put(f"{CAS}/b/k", status_code=403, text=_ACCESS_DENIED)

    with pytest.raises(NexusCasError) as e:
        c.put("b", "k", b"d", "image/png")

    assert calls == [], "정책 거부에 재발급이 났다"
    assert "정책이 이 동작을 거부" in str(e.value)


def test_expired_key_reissues(requests_mock):
    """`InvalidAccessKeyId` 는 재발급이 실제로 푸는 경우다 — 만료가 여기로 온다."""
    calls = []
    c = _client_with_reissue(calls)
    requests_mock.put(
        f"{CAS}/b/k",
        [
            {"status_code": 403, "text": _BAD_KEY},
            {"status_code": 200},
        ],
    )

    c.put("b", "k", b"d", "image/png")

    assert calls == [1], f"재발급이 한 번 나야 한다: {calls}"


def test_reissue_is_rate_limited_not_budgeted(requests_mock, monkeypatch):
    """간격 안에서는 한 번만, 간격이 지나면 **또 된다**.

    예산이었을 때는 두 번째가 영영 불가능했다. 자격증명이 24 시간마다 만료되는 지금은
    그 성질이 곧 "하루 넘게 도는 잡은 죽는다" 다.
    """
    import nexus.cas as cas_mod

    now = [1000.0]
    monkeypatch.setattr(cas_mod.time, "monotonic", lambda: now[0])

    calls = []
    c = _client_with_reissue(calls)
    requests_mock.put(f"{CAS}/b/k", status_code=403, text=_BAD_KEY)

    # ① 첫 403 — 재발급 한 번.
    with pytest.raises(NexusCasError):
        c.put("b", "k", b"d", "image/png")
    assert calls == [1]

    # ② 간격 안의 두 번째 — 재발급 없음.
    with pytest.raises(NexusCasError):
        c.put("b", "k", b"d", "image/png")
    assert calls == [1], "간격 안에서 또 발급했다"

    # ③ 간격이 지나면 다시 된다.
    now[0] += cas_mod._REISSUE_MIN_INTERVAL_SECS + 1
    with pytest.raises(NexusCasError):
        c.put("b", "k", b"d", "image/png")
    assert len(calls) == 2, f"간격이 지났는데 재발급이 없다: {calls}"


def test_head_403_without_body_still_reissues(requests_mock):
    """HEAD 응답에는 본문이 없어 에러 코드를 읽을 수 없다.

    모르는 것을 정책 거부로 넘겨짚으면 만료된 자격증명이 영영 갱신되지 않는다.
    `head` 는 `GetObject` 만 필요하고 그 권한은 모든 역할에 있으므로, 이 경로의 403 은
    사실상 자격증명 문제뿐이다.
    """
    calls = []
    c = _client_with_reissue(calls)
    requests_mock.head(
        f"{CAS}/b/k",
        [
            {"status_code": 403},
            {"status_code": 200, "headers": {"x-cas-hash": "h", "content-length": "1"}},
        ],
    )

    assert c.head("b", "k") is not None
    assert calls == [1], f"본문 없는 403 에 재발급이 나지 않았다: {calls}"
