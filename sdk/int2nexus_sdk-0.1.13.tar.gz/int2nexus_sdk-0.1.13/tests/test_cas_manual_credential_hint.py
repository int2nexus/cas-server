"""인자·환경변수로 준 자격증명(재발급 콜백이 없는 경로)의 403 힌트.

**탈출구는 그대로다** — 그 경로에는 콜백을 걸지 않는다(운영자가 관리하는 값을 403 한
번에 nexus 자동 발급으로 바꿔치기하지 않기 위해서다). 고친 것은 **힌트뿐**이다.

종전 힌트는 「폐기되었거나 정책이 거부했다」로만 말해 **만료를 가리키지 않았다.**
마이그레이션 021 이후 CAS 자격증명은 요청자 토큰의 만료를 물려받으므로 "그쪽은 운영자가
관리하는 **영구** 자격증명일 수 있다"는 전제가 더는 항상 참이 아니다 — 그 경로의 키도
시간이 지나면 죽는다. cas 는 그 구분을 S3 에러 코드로 이미 주고 있다.
"""

import pytest

from nexus.cas import CasClient
from nexus._types import NexusCasError

CAS = "http://cas-manual"

_ACCESS_DENIED = (
    '<?xml version="1.0"?><Error><Code>AccessDenied</Code>'
    "<Message>denied</Message></Error>"
)
_BAD_KEY = (
    '<?xml version="1.0"?><Error><Code>InvalidAccessKeyId</Code>'
    "<Message>The AWS Access Key Id you provided does not exist in our records.</Message>"
    "</Error>"
)


@pytest.fixture
def manual():
    """`on_forbidden` 이 없는 클라이언트 — 인자·환경변수로 자격증명을 준 경우."""
    return CasClient(CAS, key_id="kid", secret="sec")


def test_bad_key_hint_points_at_expiry_not_at_policy(requests_mock, manual):
    """`InvalidAccessKeyId` 는 자격증명이 죽었다는 뜻이다 — 만료를 짚어야 한다."""
    requests_mock.put(f"{CAS}/b/k", status_code=403, text=_BAD_KEY)

    with pytest.raises(NexusCasError) as e:
        manual.put("b", "k", b"d", "image/png")

    msg = str(e.value)
    assert "만료" in msg, f"만료를 가리키지 않는다: {msg}"
    # 사용자가 할 일: 새 값을 넣거나 SDK 에 맡긴다. 역할 승격이 아니다.
    assert "nx.connect()" in msg
    assert "역할" not in msg, f"정책 거부 이야기가 섞였다: {msg}"


def test_policy_denial_hint_is_the_same_without_a_callback(requests_mock, manual):
    """`AccessDenied` 판정은 콜백 유무와 무관하다 — 정책은 자격증명을 바꿔도 그대로다."""
    requests_mock.put(f"{CAS}/b/k", status_code=403, text=_ACCESS_DENIED)

    with pytest.raises(NexusCasError) as e:
        manual.put("b", "k", b"d", "image/png")

    assert "정책이 이 동작을 거부" in str(e.value)


def test_unknown_code_keeps_the_both_causes_hint(requests_mock, manual):
    """코드를 못 읽으면(본문 없는 HEAD 403 등) 넘겨짚지 않고 둘 다 짚는다."""
    requests_mock.head(f"{CAS}/b/k", status_code=403)

    with pytest.raises(NexusCasError) as e:
        manual.head("b", "k")

    msg = str(e.value)
    assert "폐기" in msg and "정책" in msg
