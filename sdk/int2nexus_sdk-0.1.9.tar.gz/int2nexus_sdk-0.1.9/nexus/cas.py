from __future__ import annotations
import hashlib
import hmac
import mimetypes
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable
import blake3
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from nexus._types import NexusCasError

# 대량 적재용: 일시적 5xx/네트워크 끊김을 전송 계층에서 백오프 재시도.
# PUT은 key당 내용이 고정(content-addressed)이라 재시도 안전.
_RETRY = Retry(
    total=3,
    backoff_factor=0.5,
    status_forcelist=(429, 500, 502, 503, 504),
    allowed_methods=frozenset(["HEAD", "GET", "PUT"]),
    respect_retry_after_header=True,
    raise_on_status=False,
)

_EMPTY_SHA256 = hashlib.sha256(b"").hexdigest()

# 403을 받았을 때 자격증명을 다시 발급받을 수 있는 횟수. **요청당이 아니라 클라이언트당이다.**
#
# nexus가 붙이는 정책에서 403은 예외가 아니라 **정상 응답**이다 — `viewer` 자격증명에는
# `PutObject`가 아예 없고, 모든 역할이 `annotations/`·`manifests/` 접두사에 deny를 달고
# 나온다. 예산이 요청당이면 그런 호출마다 새 자격증명이 하나씩 발급되고(상한에 닿은
# 뒤에는 발급마다 가장 오래된 것이 폐기까지 된다), 파일 500개를 올리는 `viewer` 하나가
# 자격증명 1000개를 찍어내며 cas 관리 호출 수천 번을 유발한다. 정책 거부는 자격증명을
# 새로 받아도 절대 풀리지 않으므로 그 재시도는 전부 헛돈다.
_REISSUE_BUDGET = 1

# 예산을 다 쓰고도 403이면 자격증명이 낡은 것이 아니라 **정책이 막은 것**이다.
_POLICY_DENIED_HINT = (
    "새 자격증명으로 다시 시도했는데도 403입니다 — 자격증명이 폐기된 것이 아니라 "
    "정책이 이 동작을 거부한 것입니다. `viewer` 역할에는 쓰기(PutObject) 권한이 없고, "
    "`annotations/`·`manifests/` 접두사는 어떤 역할에서도 쓸 수 없습니다(seal 산출물). "
    "역할이 방금 바뀌었다면 `nx.connect()`로 다시 접속하세요"
)

# 재발급 경로가 아예 없는 경우(수동으로 지정한 자격증명 등).
_FORBIDDEN_HINT = (
    "403은 자격증명이 폐기되었거나 정책이 이 동작을 거부했다는 뜻입니다 — "
    "`viewer` 역할에는 쓰기(PutObject) 권한이 없고, `annotations/`·`manifests/` "
    "접두사는 어떤 역할에서도 쓸 수 없습니다"
)


def _build_session(
    pool_maxsize: int = 32, verify: "bool | str" = True
) -> requests.Session:
    session = requests.Session()
    adapter = HTTPAdapter(
        max_retries=_RETRY,
        pool_connections=pool_maxsize,
        pool_maxsize=pool_maxsize,
    )
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    # CAS는 nexus와 별개 세션이고 `nx.upload`가 파일 바이트를 여기로 직접 PUT한다 —
    # 사내 TLS 검사 장비가 nexus를 가로챈다면 CAS도 대개 같으므로 같은 설정을 받는다.
    # CAS를 http로 접속하면 이 값은 아무 일도 하지 않는다(무해).
    session.verify = verify
    return session


def _sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _hmac(key: bytes, data: bytes) -> bytes:
    return hmac.new(key, data, hashlib.sha256).digest()


def _signing_key(secret: str, date: str, region: str) -> bytes:
    k_date = _hmac(("AWS4" + secret).encode(), date.encode())
    k_region = _hmac(k_date, region.encode())
    k_service = _hmac(k_region, b"s3")
    return _hmac(k_service, b"aws4_request")


def _canonical_request(
    method: str, path: str, host: str, payload_hash: str, amz_date: str
) -> str:
    """SigV4 canonical request. 서버 cas_client.rs::sigv4_auth와 **바이트 동일**해야 한다.

    SignedHeaders = host;x-amz-content-sha256;x-amz-date (고정), CanonicalQueryString 비어 있음.
    줄바꿈/공백 한 글자라도 다르면 서명 불일치 → 절대 변형 금지.
    """
    return (
        f"{method}\n"
        f"{path}\n"
        f"\n"  # CanonicalQueryString (비어 있음)
        f"host:{host}\n"
        f"x-amz-content-sha256:{payload_hash}\n"
        f"x-amz-date:{amz_date}\n"
        f"\n"  # canonical headers 종료 빈 줄
        f"host;x-amz-content-sha256;x-amz-date\n"
        f"{payload_hash}"
    )


def _total_size(resp) -> "int | None":
    """응답에서 객체의 **전체** 크기를 얻는다. 206이면 Content-Range, 200이면 Content-Length.

    200 분기는 `content-encoding` 헤더가 있으면 None을 돌려준다 — `requests`가 기본으로
    보내는 `Accept-Encoding: gzip, deflate` 때문에 CAS가 압축 응답을 줄 수 있는데, 그러면
    Content-Length는 압축 후 바이트 수라 원본 객체 크기가 아니다. 이 값이 `CasRef.size`를
    거쳐 서버 `sample_assets`에 그대로 박히므로 모르는 채로 두는 편이 낫다(206의
    Content-Range는 항상 실제 전체 크기라 영향 없음).
    """
    cr = resp.headers.get("content-range", "") or ""
    if "/" in cr:
        total = cr.rsplit("/", 1)[1].strip()
        if total.isdigit():
            return int(total)
    if resp.status_code == 200 and not resp.headers.get("content-encoding"):
        cl = resp.headers.get("content-length")
        if cl and str(cl).isdigit():
            return int(cl)
    return None


class CasClient:
    def __init__(
        self,
        cas_url: str,
        key_id: str = "",
        secret: str = "",
        region: str = "cas-default",
        verify: "bool | str" = True,
        on_forbidden: "Callable[[], tuple[str, str]] | None" = None,
    ) -> None:
        self._base = cas_url.rstrip("/")
        self._key_id = key_id
        self._secret = secret
        self._region = region
        # 커넥션 재사용(keep-alive) + 재시도를 위해 클라이언트당 Session 하나.
        self._session = _build_session(verify=verify)
        # 403(자격증명이 그 사이 폐기됨)을 받았을 때 한 번 불러 (key_id, secret)을 새로
        # 받아오는 콜백. None이면(수동으로 지정한 영구 자격증명 등) 재시도하지 않는다 —
        # `_retry_with_fresh_credentials` 참조.
        self._on_forbidden = on_forbidden
        # `upload.py`가 ThreadPoolExecutor로 하나의 CasClient를 여러 워커가 공유한다.
        # 락이 없으면 동시에 403을 맞은 워커 수만큼 `on_forbidden`이 불려 자격증명이
        # 그만큼 발급되고, 한 워커가 새 key_id를 읽는 사이 다른 워커가 secret을 덮어써
        # "key_id는 새 것, secret은 옛 것"처럼 서로 안 맞는 조합을 읽을 수도 있다 —
        # `client.py`의 `_auth_lock`과 같은 문제, 같은 해법이다.
        self._forbidden_lock = threading.Lock()
        # 남은 재발급 횟수 — **이 클라이언트가 사는 동안 통틀어서**다(`_REISSUE_BUDGET`).
        # 성공했다고 되돌리지 않는다: `upload`는 파일마다 HEAD(성공) → PUT(정책 거부 403)를
        # 반복하므로, 성공에 예산을 되돌리면 파일 수만큼 재발급이 나는 원래 문제로 돌아간다.
        self._reissues_left = _REISSUE_BUDGET if on_forbidden is not None else 0

    def _host(self) -> str:
        # 스킴만 제거, 포트는 유지 (서버 sigv4_auth와 동일).
        return self._base.removeprefix("http://").removeprefix("https://")

    def _signed_headers(self, method: str, path: str, body: bytes) -> dict:
        """SigV4 Authorization/x-amz-date/x-amz-content-sha256 헤더. 자격증명 없으면 {}.

        서버 cas_client.rs::sigv4_auth 그대로 (host;x-amz-content-sha256;x-amz-date 서명).
        """
        if not (self._key_id and self._secret):
            return {}
        now = datetime.now(timezone.utc)
        date = now.strftime("%Y%m%d")
        amz_date = now.strftime("%Y%m%dT%H%M%SZ")
        payload_hash = _sha256_hex(body)

        canonical_request = _canonical_request(
            method, path, self._host(), payload_hash, amz_date
        )
        credential_scope = f"{date}/{self._region}/s3/aws4_request"
        string_to_sign = (
            f"AWS4-HMAC-SHA256\n"
            f"{amz_date}\n"
            f"{credential_scope}\n"
            f"{_sha256_hex(canonical_request.encode())}"
        )
        signature = _hmac(
            _signing_key(self._secret, date, self._region),
            string_to_sign.encode(),
        ).hex()
        auth = (
            f"AWS4-HMAC-SHA256 Credential={self._key_id}/{credential_scope}, "
            f"SignedHeaders=host;x-amz-content-sha256;x-amz-date, "
            f"Signature={signature}"
        )
        return {
            "Authorization": auth,
            "x-amz-date": amz_date,
            "x-amz-content-sha256": payload_hash,
        }

    def _retry_with_fresh_credentials(self, failed_key_id: str, failed_secret: str) -> bool:
        """403을 받았을 때 `on_forbidden`으로 자격증명을 **한 번** 갈아 끼운다.

        **"한 번"은 요청당이 아니라 클라이언트당이다**(`_REISSUE_BUDGET`). 이미 한 번
        갈아 끼웠는데 또 403이라는 것은 자격증명이 낡아서가 아니라 **정책이 그 동작을
        거부한다**는 뜻이고, 그 상태에서 자격증명을 더 발급해봐야 아무것도 달라지지
        않는다 — 이 설계에서 403은 흔한 정상 응답이라(`viewer`의 쓰기, `annotations/`·
        `manifests/` 접두사) 요청당 예산이면 호출 하나마다 자격증명이 하나씩 생긴다.
        예산이 바닥나면 `False`를 돌려주고, 호출부는 원래의 403을 실패로 올린다.
        (역할이 실제로 바뀌어 새 자격증명이 필요하다면 `nx.connect()`가 새 `CasClient`를
        만들면서 예산도 새로 시작한다.)

        콜백이 없으면(수동으로 지정한 영구 자격증명 등) 재시도하지 않고 `False`를
        돌려준다 — 호출부는 원래의 403 응답을 그대로 실패 처리한다.

        `failed_key_id`/`failed_secret`은 403을 받은 그 요청이 서명에 실제로 쓴 값이다.
        여러 스레드가 이 `CasClient`를 공유할 수 있어(`upload.py`의 `ThreadPoolExecutor`),
        락을 잡은 뒤 "그 사이 다른 스레드가 이미 갈아 끼웠는지"를 먼저 본다 — 현재
        값이 실패한 값과 다르면 이미 누군가 갱신한 것이므로 그 결과를 그대로 쓰고
        `on_forbidden`을 또 부르지 않는다. 안 그러면 동시에 403을 맞은 워커 수만큼
        자격증명이 발급되고, 그사이 값을 읽는 스레드는 "key_id는 새 것, secret은 옛
        것"처럼 서로 안 맞는 조합을 볼 수도 있다.

        콜백이 예외를 던지면 **여기서 잡지 않고 그대로 전파한다.** 예를 들어 재발급
        자체가 409(cas 운영자가 이 사용자의 자격증명을 직접 폐기해 되살릴 수 없음)면,
        그 사실을 삼키고 조용히 넘어가는 것은 운영자의 조치를 nexus가 무효화하는
        셈이라 절대 안 된다 — 서버 메시지를 그대로 올려 호출부가 보게 한다.
        """
        if self._on_forbidden is None:
            return False
        with self._forbidden_lock:
            if (self._key_id, self._secret) != (failed_key_id, failed_secret):
                # 다른 스레드가 이미 갈아 끼웠다 — 그 결과로 한 번 더 시도하는 것은
                # 새 자격증명을 만들지 않으므로 예산과 무관하다.
                return True
            if self._reissues_left <= 0:
                return False
            self._reissues_left -= 1
            self._key_id, self._secret = self._on_forbidden()
            return True

    def _forbidden_hint(self, status_code: int) -> str:
        """403 에러 메시지 뒤에 붙일 설명. 403이 아니면 빈 문자열.

        "자격증명이 깨졌다"와 "정책이 막았다"는 사용자가 할 일이 전혀 다르다 — 앞은
        재접속, 뒤는 역할 승격이나 다른 접두사 선택이다. 상태 코드만으로는 구별되지
        않으므로 클라이언트가 아는 것(재발급을 이미 써봤는가)을 메시지에 싣는다.
        """
        if status_code != 403:
            return ""
        if self._on_forbidden is not None and self._reissues_left <= 0:
            return f" — {_POLICY_DENIED_HINT}"
        return f" — {_FORBIDDEN_HINT}"

    def head(self, bucket: str, key: str) -> dict | None:
        path = f"/{bucket}/{key}"

        def _request():
            return self._session.head(
                f"{self._base}{path}", headers=self._signed_headers("HEAD", path, b"")
            )

        used = (self._key_id, self._secret)
        r = _request()
        if r.status_code == 403 and self._retry_with_fresh_credentials(*used):
            r = _request()
        if r.status_code == 404:
            return None
        if not r.ok:
            raise NexusCasError(
                f"CAS HEAD failed ({r.status_code}): {bucket}/{key} — {r.text[:300]}"
                f"{self._forbidden_hint(r.status_code)}"
            )
        etag = r.headers.get("ETag", r.headers.get("etag", "")).strip('"')
        hash_hex = r.headers.get("x-cas-hash", "") or etag
        size_str = r.headers.get("content-length", "")
        return {
            "hash_hex": hash_hex,
            "size": int(size_str) if size_str else None,
            "content_type": r.headers.get("content-type"),
        }

    def read_head(self, bucket: str, key: str, max_bytes: int) -> "dict | None":
        """객체 앞부분 `max_bytes`만 받아 bytes와 응답 헤더 정보를 돌려준다. 404면 None.

        **Range를 지원하지 않는 CAS에서도 동작한다.** 206이면 요청한 만큼만 오고, 서버가
        Range를 무시하고 200으로 전체를 보내면 예산만큼 읽고 연결을 닫는다 — 전송은 거기서
        끊긴다. 그래서 CAS의 Range 지원 여부를 사전에 알 필요가 없다.

        Range 헤더는 SigV4 SignedHeaders(host;x-amz-content-sha256;x-amz-date)에 없으므로
        서명에 영향을 주지 않는다(`_canonical_request` 참조).

        `iter_content`로 읽는다 — `raw.read`는 Content-Encoding 디코딩을 건너뛰어 압축
        전송이 걸리면 깨진 바이트를 돌려준다. 첫 청크가 예산보다 작게 올 수 있으므로
        예산에 닿거나 스트림이 끝날 때까지 누적한다.

        `hash_hex`는 `head()`와 같은 규칙 — `x-cas-hash`가 없으면 `ETag`로 폴백한다(CAS가
        GET에는 ETag만 주는 배치가 있다). 여기서 빠지면 리치 ref가 안 되어 `flush`가 매
        샘플마다 HEAD를 한 번씩 더 보내고, 이 기능이 노리는 왕복 절감이 조용히 사라진다.

        403이면 `_retry_with_fresh_credentials`로 한 번 재시도한다(`head`/`get`/`put`과 동일).
        """
        path = f"/{bucket}/{key}"

        def _request():
            headers = self._signed_headers("GET", path, b"")
            headers["Range"] = f"bytes=0-{max_bytes - 1}"
            return self._session.get(f"{self._base}{path}", headers=headers, stream=True)

        used = (self._key_id, self._secret)
        r = _request()
        if r.status_code == 403 and self._retry_with_fresh_credentials(*used):
            r.close()
            r = _request()
        try:
            if r.status_code == 404:
                return None
            if not r.ok:
                raise NexusCasError(
                    f"CAS GET(range) failed ({r.status_code}): {bucket}/{key} — {r.text[:300]}"
                    f"{self._forbidden_hint(r.status_code)}"
                )
            buf = bytearray()
            for chunk in r.iter_content(8192):
                buf.extend(chunk)
                # `>`이지 `>=`가 아니다: 206 응답의 바디가 정확히 max_bytes였을 때 `>=`면
                # 마지막 청크를 받은 그 반복에서 바로 break해 스트림이 다 온 것처럼 보이지만
                # 실제로는 서버가 아직 EOF를 보내지 않았을 수 있다 — 그 상태에서 close()하면
                # 다 받은 응답을 미완성으로 취급해 재사용 가능한 keep-alive 연결을 끊게 된다.
                # buf[:max_bytes] 슬라이스가 최대 한 청크(8192B)의 초과분은 어차피 잘라내므로
                # 200 응답(전체를 다 보내는 경우)은 여전히 한 청크 여유로 일찍 멈춘다.
                if len(buf) > max_bytes:
                    break
            etag = r.headers.get("ETag", r.headers.get("etag", "")).strip('"')
            hash_hex = r.headers.get("x-cas-hash", "") or etag
            return {
                "data": bytes(buf[:max_bytes]),
                "hash_hex": hash_hex or None,
                "size": _total_size(r),
                "content_type": r.headers.get("content-type"),
            }
        finally:
            r.close()

    def put(
        self,
        bucket: str,
        key: str,
        data: bytes,
        content_type: str = "application/octet-stream",
    ) -> None:
        path = f"/{bucket}/{key}"

        def _request():
            headers = self._signed_headers("PUT", path, data)
            headers["Content-Type"] = content_type  # 서명 대상 아님(SignedHeaders에 미포함)
            return self._session.put(f"{self._base}{path}", data=data, headers=headers)

        used = (self._key_id, self._secret)
        r = _request()
        if r.status_code == 403 and self._retry_with_fresh_credentials(*used):
            r = _request()
        if not r.ok:
            raise NexusCasError(
                f"CAS PUT failed ({r.status_code}): {bucket}/{key} — {r.text[:300]}"
                f"{self._forbidden_hint(r.status_code)}"
            )

    def get(self, bucket: str, key: str) -> bytes:
        path = f"/{bucket}/{key}"

        def _request():
            return self._session.get(
                f"{self._base}{path}", headers=self._signed_headers("GET", path, b"")
            )

        used = (self._key_id, self._secret)
        r = _request()
        if r.status_code == 403 and self._retry_with_fresh_credentials(*used):
            r = _request()
        if not r.ok:
            raise NexusCasError(
                f"CAS GET failed ({r.status_code}): {bucket}/{key} — {r.text[:300]}"
                f"{self._forbidden_hint(r.status_code)}"
            )
        return r.content

    @staticmethod
    def hash_bytes(data: bytes) -> str:
        return blake3.blake3(data).hexdigest()

    @staticmethod
    def content_type(path: Path) -> str:
        ct, _ = mimetypes.guess_type(str(path))
        return ct or "application/octet-stream"
