import pytest
from nexus._types import (
    IngestResult,
    NexusAuthError,
    NexusBatchError,
    NexusCasError,
    NexusError,
    NexusIngestError,
)


def test_all_errors_inherit_nexus_error():
    assert issubclass(NexusAuthError, NexusError)
    assert issubclass(NexusCasError, NexusError)
    assert issubclass(NexusIngestError, NexusError)
    assert issubclass(NexusBatchError, NexusError)


def test_batch_error_stores_failures():
    dummy = IngestResult(ok=False, sample=None, error="fail")
    err = NexusBatchError([dummy])
    assert err.failures == [dummy]
    assert "1 sample" in str(err)


def test_ingest_result_defaults():
    r = IngestResult(ok=True, sample=None)
    assert r.sample_id is None
    assert r.error is None


def test_casref_rich_fields():
    from nexus.sample import CasRef
    bare = CasRef("b", "k")
    assert bare.hash_hex is None and bare.size is None and bare.content_type is None
    rich = CasRef("b", "k", hash_hex="abc", size=10, content_type="image/png")
    assert rich.hash_hex == "abc" and rich.size == 10 and rich.content_type == "image/png"
