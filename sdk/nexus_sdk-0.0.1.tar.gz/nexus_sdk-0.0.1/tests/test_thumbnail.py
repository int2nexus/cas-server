import io
from PIL import Image
from nexus.upload import _make_thumbnail


def _png(w, h):
    import struct, zlib
    def chunk(name, d):
        crc = zlib.crc32(name + d) & 0xFFFFFFFF
        return struct.pack(">I", len(d)) + name + d + struct.pack(">I", crc)
    sig = b"\x89PNG\r\n\x1a\n"
    ihdr = chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))  # color type 2 = RGB
    row = b"\x00" + b"\x80\x80\x80" * w
    idat = chunk(b"IDAT", zlib.compress(row * h))
    iend = chunk(b"IEND", b"")
    return sig + ihdr + idat + iend


def test_make_thumbnail_resizes_large_image_to_webp():
    out = _make_thumbnail(_png(800, 600))
    assert out is not None
    img = Image.open(io.BytesIO(out))
    assert img.format == "WEBP"
    assert max(img.size) == 256
    assert img.size == (256, 192)   # 비율 유지


def test_make_thumbnail_does_not_upscale_small_image():
    img = Image.open(io.BytesIO(_make_thumbnail(_png(100, 80))))
    assert img.size == (100, 80)


def _png_gray(w, h):
    import struct, zlib
    def chunk(name, d):
        crc = zlib.crc32(name + d) & 0xFFFFFFFF
        return struct.pack(">I", len(d)) + name + d + struct.pack(">I", crc)
    sig = b"\x89PNG\r\n\x1a\n"
    ihdr = chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 0, 0, 0, 0))  # color type 0 = grayscale
    row = b"\x00" + b"\x80" * w
    idat = chunk(b"IDAT", zlib.compress(row * h))
    iend = chunk(b"IEND", b"")
    return sig + ihdr + idat + iend


def test_make_thumbnail_converts_non_rgb_to_rgb_webp():
    out = _make_thumbnail(_png_gray(300, 300))   # grayscale 입력
    assert out is not None
    img = Image.open(io.BytesIO(out))
    assert img.format == "WEBP"
    assert img.mode == "RGB"        # convert("RGB") 경로 검증
    assert max(img.size) == 256


def test_make_thumbnail_returns_none_on_undecodable_bytes(recwarn):
    assert _make_thumbnail(b"not an image") is None
    assert any("thumbnail generation failed" in str(w.message) for w in recwarn)
