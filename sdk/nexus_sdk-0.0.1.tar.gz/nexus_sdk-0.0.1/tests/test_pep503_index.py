import hashlib
import sys
from pathlib import Path

# repo-root/scripts 를 import 경로에 추가 (이 파일: sdk/tests/test_*.py)
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "scripts"))
from gen_pep503_index import generate_index, normalize_name


def test_normalize_name():
    assert normalize_name("nexus_sdk") == "nexus-sdk"
    assert normalize_name("Nexus.SDK") == "nexus-sdk"
    assert normalize_name("a__b--c") == "a-b-c"


def test_generate_index(tmp_path):
    whl = tmp_path / "nexus_sdk-0.0.1-py3-none-any.whl"
    whl.write_bytes(b"wheel-bytes")
    sdist = tmp_path / "nexus_sdk-0.0.1.tar.gz"
    sdist.write_bytes(b"sdist-bytes")

    out = generate_index(tmp_path)
    assert out == {"nexus-sdk": ["nexus_sdk-0.0.1-py3-none-any.whl", "nexus_sdk-0.0.1.tar.gz"]}

    root = (tmp_path / "simple" / "index.html").read_text(encoding="utf-8")
    assert 'href="nexus-sdk/"' in root

    proj = (tmp_path / "simple" / "nexus-sdk" / "index.html").read_text(encoding="utf-8")
    sha = hashlib.sha256(b"wheel-bytes").hexdigest()
    assert f'href="../../nexus_sdk-0.0.1-py3-none-any.whl#sha256={sha}"' in proj
    assert "nexus_sdk-0.0.1.tar.gz#sha256=" in proj


def test_generate_index_ignores_non_dist(tmp_path):
    (tmp_path / "README.txt").write_text("x", encoding="utf-8")
    (tmp_path / "nexus_sdk-0.0.1-py3-none-any.whl").write_bytes(b"w")
    out = generate_index(tmp_path)
    assert list(out) == ["nexus-sdk"]
