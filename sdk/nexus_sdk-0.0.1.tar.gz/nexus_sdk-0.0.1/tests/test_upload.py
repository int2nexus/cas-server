from unittest.mock import MagicMock
import pytest


def _png(w, h):
    import struct, zlib
    def chunk(name, d):
        crc = zlib.crc32(name + d) & 0xFFFFFFFF
        return struct.pack(">I", len(d)) + name + d + struct.pack(">I", crc)
    sig = b"\x89PNG\r\n\x1a\n"
    ihdr = chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
    row = b"\x00" + b"\x80\x80\x80" * w
    idat = chunk(b"IDAT", zlib.compress(row * h))
    iend = chunk(b"IEND", b"")
    return sig + ihdr + idat + iend


def test_upload_puts_image_and_thumbnail_returns_rich_ref(tmp_path):
    from nexus.upload import upload
    from nexus.sample import CasRef
    from nexus.cas import CasClient

    img = tmp_path / "img.png"
    data = _png(400, 300)
    img.write_bytes(data)

    cas = MagicMock(); cas.head.return_value = None
    client = MagicMock()

    refs = upload([str(img)], bucket="kitti", prefix="images",
                  workers=1, verbose=False, client=client, cas=cas)

    client.ensure_bucket.assert_called_once_with("kitti")
    ref = refs[str(img)]
    assert isinstance(ref, CasRef)
    assert ref.bucket == "kitti" and ref.key == "images/img.png"
    assert ref.hash_hex == CasClient.hash_bytes(data)
    assert ref.size == len(data)
    assert ref.content_type == "image/png"
    assert ref.width == 400 and ref.height == 300  # 업로드 시 dims 캐시
    assert cas.put.call_count == 2  # image + thumbnail
    thumb = [c for c in cas.put.call_args_list if c[0][1] == "thumb/images/img.png"]
    assert len(thumb) == 1 and thumb[0][0][3] == "image/webp"


def test_upload_skips_put_when_same_hash_exists(tmp_path):
    from nexus.upload import upload
    from nexus.cas import CasClient
    img = tmp_path / "img.png"; data = _png(10, 10); img.write_bytes(data)
    cas = MagicMock()
    cas.head.return_value = {"hash_hex": CasClient.hash_bytes(data), "size": len(data), "content_type": "image/png"}
    refs = upload([str(img)], bucket="b", prefix="p", workers=1, verbose=False,
                  client=MagicMock(), cas=cas)
    cas.put.assert_not_called()
    assert refs[str(img)].key == "p/img.png"


def test_upload_collision_is_reported_as_failure(tmp_path):
    # 충돌은 건당 격리되어 실패로 보고된다 → strict=True면 raise.
    from nexus.upload import upload
    from nexus._types import NexusCasError
    img = tmp_path / "img.png"; img.write_bytes(_png(10, 10))
    cas = MagicMock()
    cas.head.return_value = {"hash_hex": "different", "size": 1, "content_type": "image/png"}
    with pytest.raises(NexusCasError, match="업로드 실패"):
        upload([str(img)], bucket="b", prefix="p", workers=1, verbose=False,
               strict=True, client=MagicMock(), cas=cas)


def test_upload_isolates_per_file_failure(tmp_path):
    # 한 파일이 실패해도 배치를 죽이지 않고 성공분만 반환 (strict=False는 경고).
    from nexus.upload import upload
    from nexus._types import NexusCasError
    a = tmp_path / "a.png"; a.write_bytes(_png(8, 8))
    b = tmp_path / "b.png"; b.write_bytes(_png(8, 8))
    cas = MagicMock(); cas.head.return_value = None

    def put_side(bucket, key, data, ct):
        if key.endswith("b.png"):
            raise NexusCasError("boom")
    cas.put.side_effect = put_side

    with pytest.warns(RuntimeWarning, match="업로드 실패"):
        refs = upload([str(a), str(b)], bucket="bk", prefix="p", workers=1,
                      verbose=False, client=MagicMock(), cas=cas)
    assert str(a) in refs and str(b) not in refs


def test_upload_strict_raises_on_any_failure(tmp_path):
    from nexus.upload import upload
    from nexus._types import NexusCasError
    a = tmp_path / "a.png"; a.write_bytes(_png(8, 8))
    cas = MagicMock(); cas.head.return_value = None
    cas.put.side_effect = NexusCasError("boom")
    with pytest.raises(NexusCasError, match="업로드 실패"):
        upload([str(a)], bucket="bk", prefix="p", workers=1, verbose=False,
               strict=True, client=MagicMock(), cas=cas)


def test_upload_no_prefix_uses_bare_filename(tmp_path):
    from nexus.upload import upload
    img = tmp_path / "img.png"; img.write_bytes(_png(8, 8))
    cas = MagicMock(); cas.head.return_value = None
    refs = upload([str(img)], bucket="b", workers=1, verbose=False,
                  client=MagicMock(), cas=cas)
    assert refs[str(img)].key == "img.png"
