from pathlib import Path
import pytest
from nexus.cas import CasClient
from nexus._types import NexusCasError

CAS = "http://cas-test"


@pytest.fixture
def client():
    return CasClient(CAS, key_id="kid", secret="sec")


def test_head_returns_metadata(requests_mock, client):
    requests_mock.head(f"{CAS}/bucket/images/img.png",
                       headers={"ETag": '"abc123"', "content-length": "2048",
                                "content-type": "image/png"})
    result = client.head("bucket", "images/img.png")
    assert result["hash_hex"] == "abc123"
    assert result["size"] == 2048
    assert result["content_type"] == "image/png"


def test_head_returns_none_on_404(requests_mock, client):
    requests_mock.head(f"{CAS}/bucket/key", status_code=404)
    assert client.head("bucket", "key") is None


def test_head_raises_on_server_error(requests_mock, client):
    requests_mock.head(f"{CAS}/bucket/key", status_code=500)
    with pytest.raises(NexusCasError):
        client.head("bucket", "key")


def test_put_sends_data(requests_mock, client):
    requests_mock.put(f"{CAS}/bucket/key", status_code=200)
    client.put("bucket", "key", b"hello-data", "image/png")
    assert requests_mock.last_request.body == b"hello-data"
    assert requests_mock.last_request.headers["Content-Type"] == "image/png"


def test_put_raises_on_failure(requests_mock, client):
    requests_mock.put(f"{CAS}/bucket/key", status_code=403)
    with pytest.raises(NexusCasError):
        client.put("bucket", "key", b"data", "image/png")


def test_cas_get_returns_content(requests_mock):
    from nexus.cas import CasClient
    requests_mock.get("http://cas/b/k.png", content=b"hello")
    cas = CasClient("http://cas")
    assert cas.get("b", "k.png") == b"hello"


def test_cas_get_raises_on_error(requests_mock):
    import pytest
    from nexus.cas import CasClient
    from nexus._types import NexusCasError
    requests_mock.get("http://cas/b/missing", status_code=404)
    cas = CasClient("http://cas")
    with pytest.raises(NexusCasError):
        cas.get("b", "missing")


def test_session_has_retry_adapter(client):
    from requests.adapters import HTTPAdapter
    adapter = client._session.get_adapter("http://cas-test/b/k")
    assert isinstance(adapter, HTTPAdapter)
    retry = adapter.max_retries
    assert retry.total == 3
    assert "PUT" in retry.allowed_methods
    assert 503 in retry.status_forcelist


def test_session_reused_across_calls(requests_mock, client):
    # 같은 클라이언트의 모든 요청이 동일 Session을 쓴다(keep-alive 재사용).
    requests_mock.head(f"{CAS}/b/k", headers={"ETag": '"h"', "content-length": "1"})
    s1 = client._session
    client.head("b", "k")
    assert client._session is s1


def test_canonical_request_exact_bytes():
    # 줄바꿈/공백이 서버 cas_client.rs::sigv4_auth와 바이트 동일해야 한다.
    from nexus.cas import _canonical_request
    cr = _canonical_request("PUT", "/data/k.png", "localhost:8080", "abc123", "20260101T000000Z")
    expected = (
        "PUT\n"
        "/data/k.png\n"
        "\n"
        "host:localhost:8080\n"
        "x-amz-content-sha256:abc123\n"
        "x-amz-date:20260101T000000Z\n"
        "\n"
        "host;x-amz-content-sha256;x-amz-date\n"
        "abc123"
    )
    assert cr == expected


def test_signed_headers_structure_and_payload_hash():
    from nexus.cas import CasClient, _sha256_hex
    c = CasClient("http://localhost:8080", key_id="rootkey", secret="rootsecret")
    h = c._signed_headers("PUT", "/data/k.png", b"hello")
    assert h["x-amz-content-sha256"] == _sha256_hex(b"hello")
    assert "T" in h["x-amz-date"] and h["x-amz-date"].endswith("Z")
    assert h["Authorization"].startswith("AWS4-HMAC-SHA256 Credential=rootkey/")
    assert "SignedHeaders=host;x-amz-content-sha256;x-amz-date" in h["Authorization"]
    assert "/s3/aws4_request," in h["Authorization"]


def test_signed_headers_empty_without_creds():
    from nexus.cas import CasClient
    c = CasClient("http://localhost:8080")
    assert c._signed_headers("PUT", "/b/k", b"x") == {}


def test_default_region_is_cas_default():
    # CAS 서버가 region "cas-default"로 고정 검증하므로 SDK 기본값도 이에 맞춘다.
    from nexus.cas import CasClient
    c = CasClient("http://localhost:8080", key_id="k", secret="s")
    assert c._region == "cas-default"
    assert "/cas-default/s3/aws4_request" in c._signed_headers("PUT", "/b/k", b"x")["Authorization"]


def test_host_keeps_port():
    from nexus.cas import CasClient
    assert CasClient("http://localhost:8080")._host() == "localhost:8080"
    assert CasClient("https://cas.example.com")._host() == "cas.example.com"


def test_put_sends_sigv4_headers(requests_mock):
    from nexus.cas import CasClient, _sha256_hex
    requests_mock.put("http://cas-test/data/k.png", status_code=200)
    c = CasClient("http://cas-test", key_id="rootkey", secret="rootsecret")
    c.put("data", "k.png", b"hello", "image/png")
    req = requests_mock.last_request
    assert req.headers["x-amz-content-sha256"] == _sha256_hex(b"hello")
    assert req.headers["Authorization"].startswith("AWS4-HMAC-SHA256 Credential=rootkey/")
    assert req.headers["Content-Type"] == "image/png"


def test_hash_bytes_is_deterministic():
    data = b"test-data-for-hashing"
    assert CasClient.hash_bytes(data) == CasClient.hash_bytes(data)
    assert len(CasClient.hash_bytes(data)) == 64  # blake3: 32 bytes = 64 hex chars


def test_hash_bytes_differs_for_different_data():
    assert CasClient.hash_bytes(b"aaa") != CasClient.hash_bytes(b"bbb")


def test_content_type_image_png():
    assert CasClient.content_type(Path("photo.png")) == "image/png"


def test_content_type_unknown_defaults_to_octet_stream():
    assert CasClient.content_type(Path("file.xyz123")) == "application/octet-stream"


def test_no_auth_header_when_credentials_empty(requests_mock):
    c = CasClient(CAS, key_id="", secret="")
    requests_mock.head(f"{CAS}/b/k",
                       headers={"ETag": '"h"', "content-length": "0"})
    c.head("b", "k")
    assert "Authorization" not in requests_mock.last_request.headers


def test_cas_head_prefers_x_cas_hash_over_etag(requests_mock):
    from nexus.cas import CasClient
    requests_mock.head(
        "http://cas/b/k",
        headers={"ETag": '"md5deadbeef"', "x-cas-hash": "blake3abc", "content-length": "5"},
    )
    cas = CasClient("http://cas")
    assert cas.head("b", "k")["hash_hex"] == "blake3abc"
