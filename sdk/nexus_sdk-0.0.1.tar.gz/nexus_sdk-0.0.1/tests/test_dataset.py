import json

import pytest
from unittest.mock import MagicMock
from nexus.dataset import Dataset
from nexus.sample import Sample, CasRef
from nexus._types import NexusBatchError


def _ds(mock_client, mock_cas):
    return Dataset(mock_client, mock_cas, "d1", "kitti", "v1")


def _rich_sample(split=None):
    """리치 CasRef + meta 포함 annotation → flush 시 HEAD/dims fetch 불필요."""
    ref = CasRef("kitti", "images/a.png", hash_hex="h", size=10, content_type="image/png")
    ann = {"meta": {"format_version": "1.0.0", "filename": "http://cas/kitti/images/a.png",
                    "width": 4, "height": 4}}
    return Sample(image=ref, annotation=ann, split=split)


def _manifest_with_snapshot():
    # /manifest now returns METADATA ONLY (no samples key).
    return {
        "annotation_snapshot": {"cas_url": "http://cas/snap.ndjson", "hash_hex": "abc"},
    }


def _samples_page():
    # samples now come from the paginated /manifest/samples endpoint.
    return {
        "samples": [
            {
                "sample_id": "s1",
                "split": "train",
                "assets": {
                    "image": {"cas_url": "http://cas/img1", "hash_hex": "h1", "size": 10},
                },
            },
        ],
        "next_cursor": None,
    }


def _batch_ok(n=1):
    return {"results": [{"index": i, "sample_id": f"s{i}", "dataset_id": "d1"} for i in range(n)]}


# ── queueing ────────────────────────────────────────────────────────────────

def test_add_queues_sample():
    ds = _ds(MagicMock(), MagicMock())
    s = _rich_sample()
    ds.add(s)
    assert ds._queue == [s]


def test_list_samples_paginates():
    mock_client = MagicMock()
    mock_client.get_manifest_samples.side_effect = [
        {"samples": [{"sample_id": "s1"}, {"sample_id": "s2"}], "next_cursor": "s2"},
        {"samples": [{"sample_id": "s3"}], "next_cursor": None},
    ]
    ds = _ds(mock_client, MagicMock())
    out = ds.list_samples(page_size=2)
    assert [s["sample_id"] for s in out] == ["s1", "s2", "s3"]
    assert mock_client.get_manifest_samples.call_count == 2


def test_list_samples_split_filter_and_max():
    mock_client = MagicMock()
    mock_client.get_manifest_samples.side_effect = [
        {"samples": [
            {"sample_id": "s1", "split": "train"},
            {"sample_id": "s2", "split": "val"},
            {"sample_id": "s3", "split": "train"},
        ], "next_cursor": None},
    ]
    ds = _ds(mock_client, MagicMock())
    assert [s["sample_id"] for s in ds.list_samples(split="train")] == ["s1", "s3"]
    mock_client.get_manifest_samples.side_effect = [
        {"samples": [{"sample_id": "s1"}, {"sample_id": "s2"}], "next_cursor": "s2"},
    ]
    assert len(ds.list_samples(max_samples=1)) == 1   # 상한에서 즉시 중단


def test_add_accepts_list():
    ds = _ds(MagicMock(), MagicMock())
    samples = [_rich_sample() for _ in range(3)]
    ds.add(samples)                      # 리스트도 add로 처리
    assert len(ds._queue) == 3


def test_add_rejects_non_sample_in_list():
    import pytest
    ds = _ds(MagicMock(), MagicMock())
    with pytest.raises(TypeError, match="Sample"):
        ds.add([_rich_sample(), "not-a-sample"])


# ── Sample ref model ──────────────────────────────────────────────────────────

def test_sample_rejects_local_path_image():
    with pytest.raises(ValueError, match="nx.upload"):
        Sample(image="data/local.png", annotation={"meta": {}})


# ── flush: ref resolution ──────────────────────────────────────────────────────

def test_flush_rich_ref_no_head():
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_client = MagicMock(); mock_client.ingest_batch.return_value = _batch_ok(1)
    ds = _ds(mock_client, mock_cas)
    ref = CasRef("kitti", "images/a.png", hash_hex="h", size=10, content_type="image/png")
    ann = {"meta": {"format_version": "1.0.0", "filename": "http://cas/kitti/images/a.png", "width": 4, "height": 4}}
    ds.add(Sample(image=ref, annotation=ann, split="train"))
    ds.flush(workers=1, verbose=False)
    mock_cas.head.assert_not_called()
    payload = mock_client.ingest_batch.call_args[0][0][0]
    assert payload["image"]["hash_hex"] == "h" and payload["image"]["size"] == 10
    assert payload["image"]["key"] == "images/a.png"


def test_flush_bare_ref_heads():
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_cas.head.return_value = {"hash_hex": "h2", "size": 20, "content_type": "image/png"}
    mock_client = MagicMock(); mock_client.ingest_batch.return_value = _batch_ok(1)
    ds = _ds(mock_client, mock_cas)
    ann = {"meta": {"format_version": "1.0.0", "filename": "x", "width": 1, "height": 1}}
    ds.add(Sample(image="s3://kitti/images/b.png", annotation=ann))
    ds.flush(workers=1, verbose=False)
    mock_cas.head.assert_called_once_with("kitti", "images/b.png")
    payload = mock_client.ingest_batch.call_args[0][0][0]
    assert payload["image"]["hash_hex"] == "h2" and payload["image"]["size"] == 20


def test_flush_cas_object_missing_marks_failed():
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_cas.head.return_value = None
    mock_client = MagicMock()
    ds = _ds(mock_client, mock_cas)
    ann = {"meta": {"format_version": "1.0.0", "filename": "x", "width": 1, "height": 1}}
    ds.add(Sample(image="s3://kitti/images/missing.png", annotation=ann))
    results = ds.flush(workers=1, verbose=False)
    assert not results[0].ok
    assert "CAS object 없음" in results[0].error


def test_flush_clears_queue():
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_client = MagicMock(); mock_client.ingest_batch.return_value = _batch_ok(1)
    ds = _ds(mock_client, mock_cas)
    ds.add(_rich_sample())
    ds.flush(workers=1, verbose=False)
    assert ds._queue == []


def test_flush_partial_failure_strict_false():
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_client = MagicMock()
    mock_client.ingest_batch.return_value = {
        "results": [
            {"index": 0, "sample_id": "s0", "dataset_id": "d1"},
            {"index": 1, "error": "server error"},
        ]
    }
    ds = _ds(mock_client, mock_cas)
    ds.add(_rich_sample())
    ds.add(_rich_sample())
    results = ds.flush(workers=1, verbose=False)

    assert len(results) == 2
    assert sum(1 for r in results if r.ok) == 1
    assert sum(1 for r in results if not r.ok) == 1
    assert any("server error" in r.error for r in results if r.error)


def test_flush_strict_true_raises_batch_error():
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_client = MagicMock()
    mock_client.ingest_batch.return_value = {"results": [{"index": 0, "error": "fail"}]}
    ds = _ds(mock_client, mock_cas)
    ds.add(_rich_sample())
    with pytest.raises(NexusBatchError) as exc:
        ds.flush(workers=1, strict=True, verbose=False)
    assert len(exc.value.failures) == 1
    assert not exc.value.failures[0].ok


# ── annotation handling ────────────────────────────────────────────────────────

def test_flush_cas_ref_annotation_fetched_inline(requests_mock):
    mock_cas = MagicMock()
    mock_cas.head.return_value = {"hash_hex": "abc123", "size": 1024, "content_type": "image/png"}
    mock_cas._base = "http://cas"
    mock_client = MagicMock()
    mock_client.ingest_batch.return_value = _batch_ok(1)

    ds = _ds(mock_client, mock_cas)
    ds.add(Sample(image="s3://bucket/img.png", annotation="s3://bucket/ann.json"))

    # annotation은 inline으로 fetch(meta 없음) → 이미지 다운로드 없이 최소 meta 생성
    requests_mock.get("http://cas/bucket/ann.json", json={"objects": []})
    results = ds.flush(workers=1, verbose=False)

    assert results[0].ok
    mock_cas.put.assert_not_called()
    payload = mock_client.ingest_batch.call_args[0][0][0]
    assert payload["image"]["bucket"] == "bucket"
    assert payload["image"]["key"] == "img.png"
    assert payload["image"]["hash_hex"] == "abc123"
    ann_data = payload["annotation"]["annotation_data"]
    assert ann_data["objects"] == []
    assert ann_data["meta"]["format_version"] == "1.0.0"
    assert ann_data["meta"]["filename"] == "http://cas/bucket/img.png"
    assert ann_data["meta"]["width"] == 0
    assert ann_data["meta"]["height"] == 0


def test_process_meta_present_is_trusted_unchanged():
    # meta가 있으면 어떤 필드도 수정하지 않고 사용자 입력을 그대로 신뢰한다.
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_client = MagicMock(); mock_client.ingest_batch.return_value = _batch_ok(1)
    ref = CasRef("kitti", "images/a.png", hash_hex="h", size=10, content_type="image/png")
    ann = {
        "meta": {"format_version": "2.0", "filename": "/data/src/custom.png", "width": 999, "height": 777},
        "scene_gt": [{"id": "s1", "label": "highway"}],
    }
    ds = _ds(mock_client, mock_cas)
    ds.add(Sample(image=ref, annotation=ann))
    ds.flush(workers=1, verbose=False)

    meta = mock_client.ingest_batch.call_args[0][0][0]["annotation"]["annotation_data"]["meta"]
    assert meta == {"format_version": "2.0", "filename": "/data/src/custom.png", "width": 999, "height": 777}
    assert "original_filename" not in meta   # filename 덮어쓰기/보존 안 함


def test_process_uses_ref_dims_when_meta_absent_no_download():
    # meta가 없으면 CasRef에 캐시된 dims를 사용한다(이미지 재다운로드 없음).
    # (requests_mock을 안 걸었는데 통과 = 이미지 다운로드가 일어나지 않았다는 뜻.)
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_client = MagicMock(); mock_client.ingest_batch.return_value = _batch_ok(1)
    ref = CasRef("kitti", "images/a.png", hash_hex="h", size=10,
                 content_type="image/png", width=640, height=480)
    ds = _ds(mock_client, mock_cas)
    ds.add(Sample(image=ref, annotation={"scene_gt": [{"id": "s1", "label": "x"}]}))  # meta 없음
    ds.flush(workers=1, verbose=False)

    ann_data = mock_client.ingest_batch.call_args[0][0][0]["annotation"]["annotation_data"]
    assert ann_data["meta"] == {
        "format_version": "1.0.0",
        "filename": "http://cas/kitti/images/a.png",
        "width": 640,
        "height": 480,
    }
    assert "scene_gt" in ann_data  # 기존 내용 보존


def test_process_meta_dims_zero_when_ref_has_no_dims():
    # bare ref(URL 등, dims 없음) → meta width/height는 0.
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_cas.head.return_value = {"hash_hex": "h", "size": 1, "content_type": "image/png"}
    mock_client = MagicMock(); mock_client.ingest_batch.return_value = _batch_ok(1)
    ds = _ds(mock_client, mock_cas)
    ds.add(Sample(image="s3://kitti/images/a.png", annotation={"scene_gt": []}))  # meta 없음, bare ref
    ds.flush(workers=1, verbose=False)

    meta = mock_client.ingest_batch.call_args[0][0][0]["annotation"]["annotation_data"]["meta"]
    assert meta["width"] == 0 and meta["height"] == 0
    assert meta["filename"] == "http://cas/kitti/images/a.png"


def test_process_builds_minimal_meta_no_annotation_no_download():
    # annotation=None (bare ref) → HEAD만, 이미지 다운로드 없음, meta w/h=0.
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_cas.head.return_value = {"hash_hex": "h", "size": 1, "content_type": "image/png"}
    mock_client = MagicMock(); mock_client.ingest_batch.return_value = _batch_ok(1)

    ds = _ds(mock_client, mock_cas)
    ds.add(Sample(image="s3://kitti/images/d.png"))  # annotation=None
    ds.flush(workers=1, verbose=False)

    meta = mock_client.ingest_batch.call_args[0][0][0]["annotation"]["annotation_data"]["meta"]
    assert meta == {
        "format_version": "1.0.0",
        "filename": "http://cas/kitti/images/d.png",
        "width": 0,
        "height": 0,
    }


def test_flush_annotation_only_derives_image_from_meta(requests_mock):
    """annotation만 있을 때 meta.filename에서 image bucket/key를 파싱해 ingest한다."""
    mock_cas = MagicMock()
    mock_cas._base = "http://cas"
    mock_cas.head.return_value = {"hash_hex": "abc", "size": 1024, "content_type": "image/bmp"}
    mock_client = MagicMock()
    mock_client.ingest_batch.return_value = _batch_ok(1)

    ann = {
        "meta": {
            "format_version": "1.0.0",
            "filename": "http://cas/mybucket/img/foo.bmp",
            "width": 1280,
            "height": 720,
        },
        "objects": [],
    }
    requests_mock.get("http://cas/anns/ann.json", json=ann)

    ds = _ds(mock_client, mock_cas)
    ds.add(Sample(annotation="http://cas/anns/ann.json"))
    results = ds.flush(workers=1, verbose=False)

    assert results[0].ok
    mock_cas.put.assert_not_called()
    payload = mock_client.ingest_batch.call_args[0][0][0]
    assert payload["image"]["bucket"] == "mybucket"
    assert payload["image"]["key"] == "img/foo.bmp"
    ann_data = payload["annotation"]["annotation_data"]
    assert ann_data["meta"]["width"] == 1280
    assert ann_data["objects"] == []


def test_flush_annotation_only_missing_meta_filename_fails(requests_mock):
    """annotation에 meta.filename이 없으면 에러로 처리된다."""
    mock_cas = MagicMock()
    mock_cas._base = "http://cas"
    mock_client = MagicMock()

    requests_mock.get("http://cas/anns/ann.json", json={"objects": []})

    ds = _ds(mock_client, mock_cas)
    ds.add(Sample(annotation="http://cas/anns/ann.json"))
    results = ds.flush(workers=1, verbose=False)

    assert not results[0].ok
    assert "meta.filename" in results[0].error


def test_flush_annotation_only_local_filename_fails(requests_mock):
    """meta.filename이 로컬 경로면 CAS URL 요구 에러."""
    mock_cas = MagicMock()
    mock_cas._base = "http://cas"
    mock_client = MagicMock()
    ann = {"meta": {"format_version": "1.0.0", "filename": "local/foo.png", "width": 1, "height": 1}}
    requests_mock.get("http://cas/anns/ann.json", json=ann)

    ds = _ds(mock_client, mock_cas)
    ds.add(Sample(annotation="http://cas/anns/ann.json"))
    results = ds.flush(workers=1, verbose=False)

    assert not results[0].ok
    assert "meta.filename" in results[0].error


def test_flush_http_url_parses_bucket_key():
    """HTTP CAS URL은 bucket/key로 파싱되고 업로드 없이 ingest된다."""
    mock_cas = MagicMock()
    mock_cas._base = "http://cas"
    mock_cas.head.return_value = {"hash_hex": "abc123", "size": 2048, "content_type": "image/png"}
    mock_client = MagicMock()
    mock_client.ingest_batch.return_value = _batch_ok(1)

    ds = _ds(mock_client, mock_cas)
    ds.add(Sample(image="http://cas/mybucket/path/to/img.png"))
    results = ds.flush(workers=1, verbose=False)

    assert results[0].ok
    mock_cas.put.assert_not_called()
    payload = mock_client.ingest_batch.call_args[0][0][0]
    assert payload["image"]["bucket"] == "mybucket"
    assert payload["image"]["key"] == "path/to/img.png"
    assert payload["image"]["size"] == 2048
    assert payload["image"]["content_type"] == "image/png"


# ── context manager ────────────────────────────────────────────────────────────

def test_context_manager_flushes_on_exit():
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_client = MagicMock(); mock_client.ingest_batch.return_value = _batch_ok(1)

    with Dataset(mock_client, mock_cas, "d1", "kitti", "v1") as ds:
        ds.add(_rich_sample())

    mock_client.ingest_batch.assert_called_once()


def test_context_manager_skips_flush_on_exception():
    mock_client = MagicMock()
    mock_cas = MagicMock()

    try:
        with Dataset(mock_client, mock_cas, "d1", "kitti", "v1") as ds:
            ds.add(_rich_sample())
            raise ValueError("oops")
    except ValueError:
        pass
    mock_client.ingest_batch.assert_not_called()


# ── client / load_or_create ─────────────────────────────────────────────────────

def test_client_ensure_bucket_posts(requests_mock):
    requests_mock.post("http://nexus/api/v1/auth/login",
                       json={"token": "tok", "user_id": 1, "email": "u@x.com"})
    requests_mock.post("http://nexus/api/v1/buckets/ensure", status_code=200)

    from nexus.client import NexusClient
    client = NexusClient("http://nexus", "u@x.com", "pass")
    client.ensure_bucket("kitti")

    assert requests_mock.last_request.method == "POST"
    assert requests_mock.last_request.json() == {"bucket": "kitti"}


def test_load_or_create_finds_existing_dataset_and_version(requests_mock):
    requests_mock.post("http://nexus/api/v1/auth/login",
                       json={"token": "tok", "user_id": 1, "email": "u@x.com"})
    requests_mock.get("http://nexus/datasets",
                      json=[{"dataset_id": "d1", "name": "kitti"}])
    requests_mock.get("http://nexus/datasets/d1/versions/v1",
                      json={"dataset_version_id": "dv1", "version": "v1"})

    from nexus.client import NexusClient
    from nexus.cas import CasClient
    client = NexusClient("http://nexus", "u@x.com", "pass")
    cas = CasClient("http://cas")
    ds = Dataset.load_or_create("kitti", "v1", client=client, cas=cas)
    assert ds._dataset_id == "d1"
    assert ds._version == "v1"


def test_load_or_create_creates_missing_dataset_and_version(requests_mock):
    requests_mock.post("http://nexus/api/v1/auth/login",
                       json={"token": "tok", "user_id": 1, "email": "u@x.com"})
    requests_mock.get("http://nexus/datasets", json=[])
    requests_mock.post("http://nexus/datasets",
                       json={"dataset_id": "d2", "name": "new-ds"}, status_code=201)
    requests_mock.get("http://nexus/datasets/d2/versions/v1", status_code=404)
    requests_mock.post("http://nexus/datasets/d2/versions",
                       json={"dataset_version_id": "dv1", "version": "v1"}, status_code=201)

    from nexus.client import NexusClient
    from nexus.cas import CasClient
    client = NexusClient("http://nexus", "u@x.com", "pass")
    cas = CasClient("http://cas")
    ds = Dataset.load_or_create("new-ds", "v1", client=client, cas=cas)
    assert ds._dataset_id == "d2"
    assert ds._name == "new-ds"


# ── patch_annotations ───────────────────────────────────────────────────────────

def test_patch_annotations_single_delegates_to_client():
    mock_client = MagicMock()
    ds = _ds(mock_client, MagicMock())
    ann = {"meta": {"filename": "img.bmp"}, "scene_gt": [{"id": "a", "label": "car"}]}

    out = ds.patch_annotations("sample-uuid-123", ann)

    assert out is None
    mock_client.patch_annotations.assert_called_once_with("d1", "v1", "sample-uuid-123", ann)


def test_patch_annotations_batch_dict_parallel():
    mock_client = MagicMock()
    ds = _ds(mock_client, MagicMock())
    patches = {"s1": {"meta": {}}, "s2": {"scene_gt": []}}

    results = ds.patch_annotations(patches, workers=2, verbose=False)

    assert {r.sample_id for r in results} == {"s1", "s2"}
    assert all(r.ok for r in results)
    assert mock_client.patch_annotations.call_count == 2
    mock_client.patch_annotations.assert_any_call("d1", "v1", "s1", {"meta": {}})
    mock_client.patch_annotations.assert_any_call("d1", "v1", "s2", {"scene_gt": []})


def test_patch_annotations_batch_isolates_failure():
    mock_client = MagicMock()

    def put(dsid, ver, sid, ann):
        if sid == "bad":
            raise RuntimeError("boom")
    mock_client.patch_annotations.side_effect = put
    ds = _ds(mock_client, MagicMock())

    results = ds.patch_annotations({"ok1": {}, "bad": {}}, workers=1, verbose=False)
    by_id = {r.sample_id: r for r in results}
    assert by_id["ok1"].ok is True
    assert by_id["bad"].ok is False and "boom" in by_id["bad"].error


def test_patch_annotations_batch_strict_raises():
    from nexus._types import NexusBatchError
    import pytest
    mock_client = MagicMock()
    mock_client.patch_annotations.side_effect = RuntimeError("boom")
    ds = _ds(mock_client, MagicMock())
    with pytest.raises(NexusBatchError):
        ds.patch_annotations({"s1": {}}, strict=True, verbose=False)


def test_client_patch_annotations_sends_put(requests_mock):
    requests_mock.post("http://nexus/api/v1/auth/login",
                       json={"token": "tok", "user_id": 1, "email": "u@x.com"})
    requests_mock.put(
        "http://nexus/datasets/d1/versions/v1/samples/s1/annotations",
        status_code=204,
    )

    from nexus.client import NexusClient
    client = NexusClient("http://nexus", "u@x.com", "pass")
    ann = {"meta": {"filename": "img.bmp"}, "scene_gt": [{"id": "a", "label": "car"}]}
    client.patch_annotations("d1", "v1", "s1", ann)

    assert requests_mock.last_request.method == "PUT"
    assert requests_mock.last_request.json() == {"annotation_data": ann}


# ── to_df ─────────────────────────────────────────────────────────────────────

def test_to_df_without_labels_flag_omits_labels(requests_mock):
    mock_client = MagicMock()
    mock_client.get_manifest.return_value = _manifest_with_snapshot()
    mock_client.get_manifest_samples.return_value = _samples_page()

    ds = _ds(mock_client, MagicMock())
    df = ds.to_df()

    assert df.loc[0, "sample_id"] == "s1"
    assert df.loc[0, "labels"] is None


def test_to_df_labels_warns_on_shard_manifest_fetch_failure(requests_mock):
    """shard manifest 다운로드 실패 시 RuntimeWarning을 발생시키고 labels=None을 반환한다."""
    mock_client = MagicMock()
    mock_client.get_manifest.return_value = _manifest_with_snapshot()
    mock_client.get_manifest_samples.return_value = _samples_page()
    requests_mock.get("http://cas/snap.ndjson", status_code=500)

    ds = _ds(mock_client, MagicMock())
    with pytest.warns(RuntimeWarning, match="annotation shard download failed"):
        df = ds.to_df(labels=True)

    assert df.loc[0, "labels"] is None


def test_to_df_labels_warns_on_shard_file_fetch_failure(requests_mock):
    """shard 파일 다운로드 실패 시 RuntimeWarning을 발생시키고 labels=None을 반환한다."""
    mock_client = MagicMock()
    mock_client.get_manifest.return_value = _manifest_with_snapshot()
    mock_client.get_manifest_samples.return_value = _samples_page()

    shard_manifest = {
        "format": "sharded_ndjson", "shard_size": 10000, "total_samples": 1,
        "shards": [{"url": "http://cas/shards/abc.ndjson", "hash_hex": "abc", "count": 1}],
    }
    requests_mock.get("http://cas/snap.ndjson", json=shard_manifest)
    requests_mock.get("http://cas/shards/abc.ndjson", status_code=503)

    ds = _ds(mock_client, MagicMock())
    with pytest.warns(RuntimeWarning, match="annotation shard download failed"):
        df = ds.to_df(labels=True)

    assert df.loc[0, "labels"] is None


def test_to_df_with_labels_flag_parses_ndjson_labels(requests_mock):
    # annotation_snapshot.cas_url → ShardManifest JSON
    # ShardManifest.shards[].url  → NDJSON 샤드 (annotation_data 형식)
    mock_client = MagicMock()
    mock_client.get_manifest.return_value = _manifest_with_snapshot()
    mock_client.get_manifest_samples.return_value = _samples_page()

    shard_manifest = {
        "format": "sharded_ndjson",
        "shard_size": 10000,
        "total_samples": 1,
        "shards": [{"url": "http://cas/shards/abc.ndjson", "hash_hex": "abc", "count": 1}],
    }
    ndjson_line = json.dumps({
        "sample_id": "s1",
        "meta": {"format_version": "1.0.0", "filename": "img.png", "width": 640, "height": 480},
        "road_obj_ma": [
            {
                "id": "i1", "label": "car", "track_id": 1, "confidence": 0.9,
                "bounding_box": {"type": "bounding_box", "rect": [0, 0, 1, 1]},
            }
        ],
    })
    requests_mock.get("http://cas/snap.ndjson", json=shard_manifest)
    requests_mock.get("http://cas/shards/abc.ndjson", text=ndjson_line + "\n")

    ds = _ds(mock_client, MagicMock())
    df = ds.to_df(labels=True)

    row_labels = df.loc[0, "labels"]
    assert "meta" in row_labels
    assert row_labels["meta"]["width"] == 640
    assert row_labels["road_obj_ma"][0]["label"] == "car"
    assert row_labels["road_obj_ma"][0]["bounding_box"]["rect"] == [0, 0, 1, 1]


def test_to_df_pages_through_manifest_samples():
    mock_client = MagicMock()
    mock_client.get_manifest.return_value = {"annotation_snapshot": None}
    mock_client.get_manifest_samples.side_effect = [
        {
            "samples": [{
                "sample_id": "s0", "split": "train",
                "assets": {"image": {"cas_url": "http://cas/0", "hash_hex": "h0", "size": 1}},
            }],
            "next_cursor": "cur1",
        },
        {
            "samples": [{
                "sample_id": "s1", "split": "val",
                "assets": {"image": {"cas_url": "http://cas/1", "hash_hex": "h1", "size": 2}},
            }],
            "next_cursor": None,
        },
    ]

    ds = _ds(mock_client, MagicMock())
    df = ds.to_df()

    assert len(df) == 2
    assert list(df["sample_id"]) == ["s0", "s1"]
    assert mock_client.get_manifest_samples.call_count == 2


def test_to_df_stops_on_non_advancing_cursor():
    """서버가 전진하지 않는 cursor를 계속 줘도 무한 루프하지 않는다."""
    mock_client = MagicMock()
    mock_client.get_manifest.return_value = {"annotation_snapshot": None}
    # 항상 같은 next_cursor "stuck"을 반환 (버그난 서버 시뮬레이션)
    mock_client.get_manifest_samples.return_value = {
        "samples": [{
            "sample_id": "s0", "split": "train",
            "assets": {"image": {"cas_url": "http://cas/0", "hash_hex": "h0", "size": 1}},
        }],
        "next_cursor": "stuck",
    }

    ds = _ds(mock_client, MagicMock())
    df = ds.to_df()

    # 첫 페이지(cursor=None) + cursor="stuck" 한 번 → "stuck" 재등장에서 중단 = 2회 호출
    assert mock_client.get_manifest_samples.call_count == 2
    assert len(df) == 2  # 중복 페이지를 무한 누적하지 않음


def test_client_get_manifest_samples_sends_get(requests_mock):
    requests_mock.post("http://nexus/api/v1/auth/login",
                       json={"token": "tok", "user_id": 1, "email": "u@x.com"})
    page = {"samples": [{"sample_id": "s1"}], "next_cursor": "cur2"}
    requests_mock.get("http://nexus/datasets/d1/versions/v1/manifest/samples", json=page)

    from nexus.client import NexusClient
    client = NexusClient("http://nexus", "u@x.com", "pass")
    out = client.get_manifest_samples("d1", "v1", cursor="cur1", limit=500)

    assert out == page
    assert requests_mock.last_request.method == "GET"
    assert requests_mock.last_request.qs["cursor"] == ["cur1"]
    assert requests_mock.last_request.qs["limit"] == ["500"]


# ── batch ingest endpoint ──────────────────────────────────────────────────────

def test_flush_uses_batch_endpoint():
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_client = MagicMock(); mock_client.ingest_batch.return_value = _batch_ok(3)

    ds = _ds(mock_client, mock_cas)
    for i in range(3):
        ref = CasRef("kitti", f"images/{i}.png", hash_hex="h", size=10, content_type="image/png")
        ann = {"meta": {"format_version": "1.0.0", "filename": f"http://cas/kitti/images/{i}.png",
                        "width": 4, "height": 4}}
        ds.add(Sample(image=ref, annotation=ann))

    results = ds.flush(workers=1, verbose=False)

    assert mock_client.ingest_batch.call_count == 1
    assert len(mock_client.ingest_batch.call_args[0][0]) == 3
    assert len(results) == 3
    assert all(r.ok for r in results)
    mock_cas.head.assert_not_called()


def test_flush_chunks_by_batch_size():
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_client = MagicMock()
    mock_client.ingest_batch.side_effect = [_batch_ok(2), _batch_ok(1)]

    ds = _ds(mock_client, mock_cas)
    for i in range(3):
        ref = CasRef("kitti", f"images/{i}.png", hash_hex="h", size=10, content_type="image/png")
        ann = {"meta": {"format_version": "1.0.0", "filename": f"http://cas/kitti/images/{i}.png",
                        "width": 4, "height": 4}}
        ds.add(Sample(image=ref, annotation=ann))

    results = ds.flush(workers=1, batch_size=2, verbose=False)

    assert mock_client.ingest_batch.call_count == 2
    assert len(results) == 3
    assert all(r.ok for r in results)


def test_flush_maps_results_by_index_out_of_order():
    """서버가 결과를 뒤바뀐 순서로 줘도 index로 올바른 sample에 매핑한다."""
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_client = MagicMock()
    mock_client.ingest_batch.return_value = {"results": [
        {"index": 1, "sample_id": "sid-1"},
        {"index": 0, "sample_id": "sid-0"},
    ]}

    ds = _ds(mock_client, mock_cas)
    for i in range(2):
        ref = CasRef("kitti", f"images/{i}.png", hash_hex="h", size=10, content_type="image/png")
        ann = {"meta": {"format_version": "1.0.0", "filename": f"http://cas/kitti/images/{i}.png",
                        "width": 4, "height": 4}}
        ds.add(Sample(image=ref, annotation=ann))

    results = ds.flush(workers=1, verbose=False)

    assert len(results) == 2
    assert results[0].ok and results[0].sample_id == "sid-0"  # chunk pos 0
    assert results[1].ok and results[1].sample_id == "sid-1"  # chunk pos 1


def test_flush_missing_index_in_response_marks_item_failed():
    """서버 응답에 빠진 index가 있으면 해당 sample은 실패로 기록(드롭 금지)."""
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_client = MagicMock()
    mock_client.ingest_batch.return_value = {"results": [{"index": 0, "sample_id": "sid-0"}]}

    ds = _ds(mock_client, mock_cas)
    for i in range(2):
        ref = CasRef("kitti", f"images/{i}.png", hash_hex="h", size=10, content_type="image/png")
        ann = {"meta": {"format_version": "1.0.0", "filename": f"http://cas/kitti/images/{i}.png",
                        "width": 4, "height": 4}}
        ds.add(Sample(image=ref, annotation=ann))

    results = ds.flush(workers=1, verbose=False)

    assert len(results) == 2  # 누락돼도 drop되지 않음
    assert results[0].ok and results[0].sample_id == "sid-0"
    assert not results[1].ok and results[1].error


def test_client_ingest_batch_posts(requests_mock):
    requests_mock.post("http://nexus/api/v1/auth/login",
                       json={"token": "tok", "user_id": 1, "email": "u@x.com"})
    results = {"results": [{"index": 0, "sample_id": "s0", "dataset_id": "d1"}]}
    requests_mock.post("http://nexus/ingest/batch", json=results)

    from nexus.client import NexusClient
    client = NexusClient("http://nexus", "u@x.com", "pass")
    items = [{"dataset": "kitti", "version": "v1", "image": {}, "annotation": {}}]
    out = client.ingest_batch(items)

    assert requests_mock.last_request.method == "POST"
    assert requests_mock.last_request.json() == {"items": items}
    assert out == results
