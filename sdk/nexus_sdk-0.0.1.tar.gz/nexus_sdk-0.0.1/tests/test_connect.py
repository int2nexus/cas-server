import pytest
import nexus
from nexus._types import NexusAuthError


def _reset():
    nexus._client = None
    nexus._cas = None


def test_connect_explicit_args(requests_mock):
    _reset()
    requests_mock.post("http://nexus/api/v1/auth/login",
                       json={"token": "tok", "user_id": 1, "email": "u@x.com"})
    client = nexus.connect(
        nexus_url="http://nexus",
        email="u@x.com",
        password="pass",
        cas_url="http://cas",
        cas_key_id="kid",
        cas_secret="sec",
    )
    assert client._token == "tok"
    assert nexus._cas is not None


def test_connect_reads_env_vars(monkeypatch, requests_mock):
    _reset()
    monkeypatch.setenv("NEXUS_URL", "http://nexus")
    monkeypatch.setenv("NEXUS_EMAIL", "u@x.com")
    monkeypatch.setenv("NEXUS_PASSWORD", "pass")
    monkeypatch.setenv("CAS_URL", "http://cas")
    monkeypatch.setenv("CAS_KEY_ID", "kid")
    monkeypatch.setenv("CAS_SECRET", "sec")
    requests_mock.post("http://nexus/api/v1/auth/login",
                       json={"token": "envtok", "user_id": 1, "email": "u@x.com"})
    client = nexus.connect()
    assert client._token == "envtok"


def test_public_exports():
    assert hasattr(nexus, "connect")
    assert hasattr(nexus, "upload")
    assert hasattr(nexus, "Dataset")
    assert hasattr(nexus, "Sample")
    assert hasattr(nexus, "CasRef")
    assert hasattr(nexus, "IngestResult")
    assert hasattr(nexus, "NexusError")
    assert hasattr(nexus, "NexusAuthError")
    assert hasattr(nexus, "NexusCasError")
    assert hasattr(nexus, "NexusIngestError")
    assert hasattr(nexus, "NexusBatchError")
