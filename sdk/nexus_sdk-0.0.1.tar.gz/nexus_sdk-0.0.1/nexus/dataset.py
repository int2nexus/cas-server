from __future__ import annotations
import json
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from tqdm import tqdm

from nexus._types import IngestResult, NexusBatchError, NexusCasError
from nexus.cas import CasClient
from nexus.client import NexusClient
from nexus.sample import CasRef, FileRef, Sample, _parse_ref


class Dataset:
    def __init__(
        self,
        client: NexusClient,
        cas: CasClient,
        dataset_id: str,
        name: str,
        version: str,
    ) -> None:
        self._client = client
        self._cas = cas
        self._dataset_id = dataset_id
        self._name = name
        self._version = version
        self._queue: list[Sample] = []

    @classmethod
    def load_or_create(
        cls,
        name: str,
        version: str,
        tags: list[str] | None = None,
        description: str | None = None,
        *,
        fork_from: str | None = None,
        client: NexusClient | None = None,
        cas: CasClient | None = None,
    ) -> "Dataset":
        import nexus as _nx

        _client = client
        _cas = cas

        if _client is None or _cas is None:
            if _nx._client is None:
                _nx._auto_connect()
            _client = _client or _nx._client
            _cas = _cas or _nx._cas

        datasets = _client.list_datasets()
        matched = next((d for d in datasets if d["name"] == name), None)
        if matched:
            dataset_id = matched["dataset_id"]
        else:
            dataset_id = _client.create_dataset(
                name, tags=tags, description=description
            )["dataset_id"]

        if not _client.get_version(dataset_id, version):
            _client.create_version(dataset_id, version, fork_from=fork_from)

        return cls(_client, _cas, dataset_id, name, version)

    def link_samples(self, sample_ids: list[str]) -> None:
        """이미 존재하는 sample_id들을 이 버전에 연결. ingest 없이 참조만 추가."""
        self._client.add_sample_ids(self._dataset_id, self._version, sample_ids)

    def list_samples(
        self,
        *,
        split: str | None = None,
        page_size: int = 1000,
        max_samples: int | None = None,
    ) -> list[dict]:
        """이 dataset/version에 포함된 샘플 목록을 모두 가져온다 (cursor 페이지네이션 자동).

        각 항목은 dict로 `sample_id`/`sample_key`/`split`와 `assets`(`{image: {cas_url, hash_hex,
        size}, ...}`)를 담는다. 프론트 전용 `image_url`/`thumbnail_url`은 포함하지 않는다.
        sealed 여부와 무관하게 동작한다(`to_df`와 달리 draft에서도 조회 가능).

        - `split`: 지정 시 해당 split만 (클라이언트 측 필터).
        - `page_size`: 요청당 페이지 크기. `max_samples`: 최대 수집 개수(상한).
        """
        out: list[dict] = []
        cursor = None
        seen: set = set()
        while True:
            page = self._client.get_manifest_samples(
                self._dataset_id, self._version, cursor=cursor, limit=page_size,
            )
            for s in page.get("samples", []):
                if split is not None and s.get("split") != split:
                    continue
                out.append(s)
                if max_samples is not None and len(out) >= max_samples:
                    return out
            cursor = page.get("next_cursor")
            # 끝(falsy)이거나 서버가 전진하지 않는 cursor를 주면 중단 (무한 루프 방지).
            if not cursor or cursor in seen:
                break
            seen.add(cursor)
        return out

    def patch_annotations(
        self,
        sample_id: "str | dict[str, dict]",
        annotation_data: dict | None = None,
        *,
        workers: int = 8,
        strict: bool = False,
        verbose: bool = True,
    ) -> "None | list[IngestResult]":
        """샘플 annotation을 이 버전 전용으로 교체한다 (CoW — 공유 원본·다른 버전 보존).

        단일/배치를 하나로 처리한다:
        - **단일**: `patch_annotations(sample_id, annotation_data)` → 반환 `None`.
        - **배치**: `patch_annotations({sample_id: annotation_data, ...})` → PUT을 워커로
          **병렬** 처리하고 건당 `IngestResult` 리스트를 반환(`sample_id`/`ok`/`error`).
          (`[(sample_id, annotation_data), ...]` 형태의 시퀀스도 받는다.)

        `strict=True`면 배치 중 실패가 있으면 `NexusBatchError`를 던진다.
        """
        if annotation_data is not None:
            # 단일
            self._client.patch_annotations(
                self._dataset_id, self._version, sample_id, annotation_data
            )
            return None

        # 배치: dict 또는 (sample_id, annotation_data) 시퀀스
        items = list(sample_id.items()) if isinstance(sample_id, dict) else [tuple(x) for x in sample_id]

        def _one(sid: str, ann: dict) -> str:
            self._client.patch_annotations(self._dataset_id, self._version, sid, ann)
            return sid

        results: list[IngestResult] = []
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {pool.submit(_one, sid, ann): sid for sid, ann in items}
            for future in tqdm(
                as_completed(futures), total=len(futures),
                desc="Patching", disable=not verbose,
            ):
                sid = futures[future]
                try:
                    future.result()
                    results.append(IngestResult(ok=True, sample=None, sample_id=sid))
                except Exception as e:
                    results.append(IngestResult(ok=False, sample=None, sample_id=sid, error=str(e)))

        if strict:
            failures = [r for r in results if not r.ok]
            if failures:
                raise NexusBatchError(failures)
        return results

    def add(self, sample: "Sample | list[Sample]") -> None:
        """샘플을 등록 큐에 추가한다. 단일 `Sample` 또는 `Sample` 리스트 모두 받는다."""
        if isinstance(sample, Sample):
            self._queue.append(sample)
            return
        samples = list(sample)  # 리스트/튜플/제너레이터 허용
        for s in samples:
            if not isinstance(s, Sample):
                raise TypeError(
                    f"add()는 Sample 또는 Sample 리스트를 받습니다 — {type(s).__name__}를 받았습니다."
                )
        self._queue.extend(samples)

    def flush(
        self, workers: int = 4, strict: bool = False, verbose: bool = True,
        batch_size: int = 256,
    ) -> list[IngestResult]:
        queue = self._queue[:]
        self._queue.clear()

        results: list[IngestResult] = []
        prepared: list[tuple] = []  # (sample, payload)

        # Phase 1: build payloads in parallel.
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {pool.submit(self._prepare_payload, s): s for s in queue}
            for future in tqdm(
                as_completed(futures), total=len(futures),
                desc="Preparing", disable=not verbose,
            ):
                s = futures[future]
                try:
                    prepared.append((s, future.result()))
                except Exception as e:
                    results.append(IngestResult(ok=False, sample=s, error=str(e)))

        # Phase 2: batch-ingest prepared payloads in chunks.
        for i in range(0, len(prepared), batch_size):
            chunk = prepared[i:i + batch_size]
            payloads = [p for (_, p) in chunk]
            try:
                resp = self._client.ingest_batch(payloads)
                # index → result. position 기반으로 순회하므로 순서/중복/누락에 안전하다.
                by_index = {r["index"]: r for r in resp.get("results", [])}
            except Exception as e:
                # whole-request failure → every item in this chunk failed
                for (s, _) in chunk:
                    results.append(IngestResult(ok=False, sample=s, error=str(e)))
                continue
            # chunk의 각 항목을 반드시 1개 결과로 매핑 (len(results) == len(prepared) 보장).
            for pos, (s, _) in enumerate(chunk):
                item = by_index.get(pos)
                if item is None:
                    results.append(IngestResult(
                        ok=False, sample=s,
                        error="batch 응답에 해당 item 결과 없음",
                    ))
                elif item.get("error"):
                    results.append(IngestResult(ok=False, sample=s, error=item["error"]))
                else:
                    results.append(IngestResult(ok=True, sample=s, sample_id=item.get("sample_id")))

        if strict:
            failures = [r for r in results if not r.ok]
            if failures:
                raise NexusBatchError(failures)
        return results

    def to_df(
        self,
        split: str | None = None,
        label: str | None = None,
        labels: bool = False,
        workers: int = 4,
    ) -> "pd.DataFrame":
        try:
            import pandas as pd
        except ImportError:
            raise ImportError(
                "pandas is required for to_df(). "
                "Install with: pip install 'nexus-sdk[pandas]'"
            )

        manifest = self._client.get_manifest(self._dataset_id, self._version)

        label_ids: set[str] | None = None
        if label:
            label_ids = self._client.list_sample_ids_by_label(
                self._dataset_id, self._version, label
            )

        samples = []
        cursor = None
        seen_cursors: set = set()
        while True:
            page = self._client.get_manifest_samples(
                self._dataset_id, self._version, cursor=cursor, limit=1000,
            )
            samples.extend(page.get("samples", []))
            cursor = page.get("next_cursor")
            # 끝(falsy)이거나, 서버가 전진하지 않는 cursor를 주면 중단 — 무한 루프 방지.
            if not cursor or cursor in seen_cursors:
                break
            seen_cursors.add(cursor)
        if split:
            samples = [s for s in samples if s.get("split") == split]
        if label_ids is not None:
            samples = [s for s in samples if s["sample_id"] in label_ids]

        # labels=True: shard manifest JSON → 샤드별 NDJSON 순차 다운로드
        # annotation_snapshot.cas_url → ShardManifest JSON
        # ShardManifest.shards[].url   → NDJSON 샤드 파일
        # NDJSON 라인 형식: {"sample_id": ..., "meta": {...}, "<group_key>": [...], ...}
        labels_map: dict[str, dict] = {}
        if labels:
            snapshot = manifest.get("annotation_snapshot")
            if snapshot and snapshot.get("cas_url"):
                import requests as _req
                try:
                    shard_manifest = _req.get(snapshot["cas_url"], timeout=30).json()
                    for shard in shard_manifest.get("shards", []):
                        r = _req.get(shard["url"], timeout=120)
                        r.raise_for_status()
                        for line in r.text.splitlines():
                            line = line.strip()
                            if not line:
                                continue
                            obj = json.loads(line)
                            sid = obj["sample_id"]
                            labels_map[sid] = {k: v for k, v in obj.items() if k != "sample_id"}
                except Exception as exc:
                    import warnings
                    warnings.warn(
                        f"annotation shard download failed: {exc}. labels will be None for all rows.",
                        RuntimeWarning,
                        stacklevel=3,
                    )

        rows = []
        for s in samples:
            assets = s.get("assets", {})
            img = assets.get("image", {})
            dep = assets.get("depth_map", {})
            rows.append({
                "sample_id": s["sample_id"],
                "sample_key": s.get("sample_key"),
                "split": s.get("split"),
                "image_cas_url": img.get("cas_url"),
                "image_hash_hex": img.get("hash_hex"),
                "image_size": img.get("size"),
                "depth_cas_url": dep.get("cas_url") if dep else None,
                "labels": labels_map.get(s["sample_id"]) if labels else None,
            })

        return pd.DataFrame(rows)

    def _prepare_payload(self, sample: Sample) -> dict:
        ann_spec = self._resolve_annotation(sample._annotation_ref)

        if sample._image_ref is not None:
            image_ref = sample._image_ref
        else:
            ann_src = str(sample._annotation_ref)
            ann_data = ann_spec.get("annotation_data") or {}
            meta = ann_data.get("meta")
            filename = (meta or {}).get("filename")
            if not filename:
                raise NexusCasError(
                    f"[{ann_src}] image 미지정 + annotation meta.filename 없음 — "
                    "Sample(image=ref) 또는 meta.filename(CAS URL)을 지정하세요."
                )
            image_ref = _parse_ref(filename)
            if not isinstance(image_ref, CasRef):
                raise NexusCasError(
                    f"[{ann_src}] meta.filename은 CAS URL이어야 합니다 (s3://·http(s)://). "
                    "로컬 경로는 nx.upload 후 ref를 쓰세요."
                )

        image_spec = self._resolve_asset(image_ref)
        ann_spec = self._ensure_meta(ann_spec, image_ref, image_spec)

        payload: dict = {
            "dataset": self._name,
            "version": self._version,
            "split": sample.split,
            "tags": sample.tags or None,
            "image": image_spec,
            "annotation": ann_spec,
        }
        if sample._depth_ref is not None:
            payload["depth"] = self._resolve_asset(sample._depth_ref)
        return payload

    def _resolve_asset(self, ref: CasRef) -> dict:
        """CAS ref → ingest asset spec. 리치 CasRef(업로드 출력)는 신뢰, bare는 HEAD."""
        if ref.hash_hex is not None and ref.size is not None and ref.content_type is not None:
            return {
                "bucket": ref.bucket,
                "key": ref.key,
                "size": ref.size,
                "content_type": ref.content_type,
                "logical_name": ref.key.split("/")[-1],
                "hash_hex": ref.hash_hex,
            }
        info = self._cas.head(ref.bucket, ref.key)
        if info is None:
            raise NexusCasError(
                f"CAS object 없음: bucket='{ref.bucket}', key='{ref.key}' — "
                "nx.upload로 먼저 올렸는지 확인하세요."
            )
        return {
            "bucket": ref.bucket,
            "key": ref.key,
            "size": info["size"],
            "content_type": info["content_type"],
            "logical_name": ref.key.split("/")[-1],
            "hash_hex": info.get("hash_hex"),
        }

    def _resolve_annotation(self, ref: "dict | FileRef | None") -> dict:
        """Annotation을 inline JSON dict로 변환. CAS에 업로드하지 않음."""
        if ref is None:
            return {"annotation_data": None}
        if isinstance(ref, dict):
            return {"annotation_data": ref}
        if isinstance(ref, CasRef):
            import requests as _req
            url = f"{self._cas._base}/{ref.bucket}/{ref.key}"
            r = _req.get(url, timeout=30)
            r.raise_for_status()
            return {"annotation_data": r.json()}
        path = Path(ref)
        return {"annotation_data": json.loads(path.read_bytes())}

    def _ensure_meta(self, ann_spec: dict, image_ref: "FileRef", image_spec: dict) -> dict:
        """annotation의 meta 처리. 사용자 입력을 신뢰하고 관여하지 않는 것이 원칙이다.

        - meta가 있으면(값이 None이 아니면) **그대로 신뢰** — 어떤 필드도 수정하지 않는다.
        - meta가 없으면 최소 meta만 생성한다: `filename`=실제 CAS URL, `format_version`="1.0.0",
          `width`/`height`는 `CasRef`에 업로드 시점에 담아둔 dims가 있으면 사용(이미지를 다시
          읽지 않음), 없으면(bare ref 등) 0. (조회 시 image_url/thumbnail_url이 별도로 제공된다.)
        """
        ann_data: dict = ann_spec.get("annotation_data") or {}
        if ann_data.get("meta") is not None:
            return ann_spec  # 사용자가 준 meta를 그대로 사용
        w = image_ref.width if isinstance(image_ref, CasRef) else None
        h = image_ref.height if isinstance(image_ref, CasRef) else None
        ann_data = dict(ann_data)
        ann_data["meta"] = {
            "format_version": "1.0.0",
            "filename": f"{self._cas._base}/{image_spec['bucket']}/{image_spec['key']}",
            "width": w if w is not None else 0,
            "height": h if h is not None else 0,
        }
        return {"annotation_data": ann_data}

    def __enter__(self) -> "Dataset":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        if exc_type is None:
            self.flush()
