"""SDK 0.1.21 FiftyOne interop 메서드 단위 테스트.

설계: docs/superpowers/specs/2026-10-08-sdk-fiftyone-interop-design.md
요청 경로·쿼리·본문은 requests-mock 으로 실제 NexusClient 를 지나 확인한다.
"""
import warnings
from urllib.parse import parse_qs, urlsplit

import pytest

import nexus as nx
from nexus._types import NexusError
from nexus.cas import CasClient
from nexus.client import NexusClient
from nexus.dataset import Dataset

BASE = "http://nexus"
VER = f"{BASE}/datasets/d1/versions/v1"
EXPLORER = f"{VER}/samples/explorer"


def _q(req) -> dict:
    """쿼리스트링을 대소문자 그대로 읽는다(requests-mock 의 `.qs` 는 값을 소문자로 바꾼다)."""
    return {k: v[0] if len(v) == 1 else v for k, v in parse_qs(urlsplit(req.url).query).items()}


@pytest.fixture
def client(requests_mock):
    requests_mock.post(f"{BASE}/api/v1/auth/login",
                       json={"token": "tok", "user_id": 1, "email": "u@x.com"})
    return NexusClient(BASE, "u@x.com", "pass")


@pytest.fixture
def ds(client):
    return Dataset(client, CasClient("http://cas"), "d1", "kitti", "v1")


# ── Task 1: NexusClient 저수준 ────────────────────────────────────────────────

def test_version_stats_gets_stats(client, requests_mock):
    requests_mock.get(f"{VER}/stats", json={"sample_count": 3, "total_size_bytes": 30})
    assert client.version_stats("d1", "v1") == {"sample_count": 3, "total_size_bytes": 30}


def test_facet_values_sends_field_query(client, requests_mock):
    requests_mock.get(f"{VER}/facets", json={"kind": "enum", "field": "meta.Src", "values": []})
    client.facet_values("d1", "v1", "meta.Src")
    assert _q(requests_mock.last_request) == {"field": "meta.Src"}


def test_facet_counts_posts_filter_with_field_query(client, requests_mock):
    requests_mock.post(f"{VER}/facets/counts",
                       json={"field": "tags", "computed": True, "truncated": False, "counts": []})
    client.facet_counts("d1", "v1", "tags", filter={"split": "train"})
    req = requests_mock.last_request
    assert _q(req) == {"field": "tags"}
    assert req.json() == {"split": "train"}


def test_facet_counts_without_filter_sends_empty_object(client, requests_mock):
    requests_mock.post(f"{VER}/facets/counts",
                       json={"field": "tags", "computed": True, "truncated": False, "counts": []})
    client.facet_counts("d1", "v1", "tags")
    assert requests_mock.last_request.json() == {}


def test_histogram_sends_field_query(client, requests_mock):
    requests_mock.get(f"{VER}/histogram",
                      json={"kind": "categorical_histogram", "field": "meta.k", "buckets": []})
    out = client.histogram("d1", "v1", "meta.k")
    assert out["kind"] == "categorical_histogram"
    assert _q(requests_mock.last_request) == {"field": "meta.k"}


def test_version_schema_gets_schema(client, requests_mock):
    requests_mock.get(f"{VER}/schema", json={"meta_schema": {"fields": []}})
    assert client.version_schema("d1", "v1") == {"meta_schema": {"fields": []}}


def test_add_and_remove_dataset_tags(client, requests_mock):
    requests_mock.post(f"{BASE}/datasets/d1/tags", json={"dataset_id": "d1", "tags": ["a", "b"]})
    requests_mock.delete(f"{BASE}/datasets/d1/tags", json={"dataset_id": "d1", "tags": ["b"]})
    assert client.add_dataset_tags("d1", ["a", "b"])["tags"] == ["a", "b"]
    assert requests_mock.last_request.json() == {"tags": ["a", "b"]}
    assert client.remove_dataset_tags("d1", ["a"])["tags"] == ["b"]
    assert requests_mock.last_request.method == "DELETE"
    assert requests_mock.last_request.json() == {"tags": ["a"]}


def test_delete_version_sends_confirm_dataset_name(client, requests_mock):
    requests_mock.delete(f"{VER}", json={"version": "v1"})
    client.delete_version("d1", "v1", "v1", confirm_dataset_name="Kitti Set")
    assert _q(requests_mock.last_request) == {
        "confirm": "v1", "delete_cas": "false", "confirm_dataset_name": "Kitti Set",
    }


def test_delete_version_omits_confirm_dataset_name_by_default(client, requests_mock):
    requests_mock.delete(f"{VER}", json={"version": "v1"})
    client.delete_version("d1", "v1", "v1")
    assert "confirm_dataset_name" not in _q(requests_mock.last_request)


# ── Task 2: 핸들 기본 ─────────────────────────────────────────────────────────

def test_name_property_reflects_handle_and_rename(ds, requests_mock):
    assert ds.name == "kitti"
    requests_mock.patch(f"{BASE}/datasets/d1", json={"dataset_id": "d1", "name": "kitti2"})
    ds.update(name="kitti2")
    assert ds.name == "kitti2"


def test_len_uses_exact_explorer_count_not_stats(ds, requests_mock):
    count = requests_mock.post(f"{EXPLORER}/count", json={"count": 2_000_000, "exact": True})
    stats = requests_mock.get(f"{VER}/stats", json={"sample_count": 1, "total_size_bytes": 0})
    assert len(ds) == 2_000_000
    assert _q(count.last_request) == {"exact": "true"}
    assert count.last_request.json() == {}
    assert not stats.called


def test_bool_is_true_without_calling_server(ds, requests_mock):
    count = requests_mock.post(f"{EXPLORER}/count", json={"count": 0, "exact": True})
    assert bool(ds) is True
    if ds:
        pass
    assert not count.called


def test_tags_is_a_tuple_read_each_time(ds, requests_mock):
    requests_mock.get(f"{BASE}/datasets/d1", [
        {"json": {"dataset_id": "d1", "name": "kitti", "tags": ["a"]}},
        {"json": {"dataset_id": "d1", "name": "kitti", "tags": ["a", "b"]}},
    ])
    first = ds.tags
    assert first == ("a",)
    with pytest.raises(AttributeError):
        first.append("x")
    assert ds.tags == ("a", "b")


def test_tags_on_missing_dataset_raises_404(ds, requests_mock):
    requests_mock.get(f"{BASE}/datasets/d1", status_code=404, json={"error": "not found"})
    with pytest.raises(NexusError) as ei:
        ds.tags
    assert ei.value.status_code == 404


def test_add_tag_and_remove_tag_send_varargs(ds, requests_mock):
    add = requests_mock.post(f"{BASE}/datasets/d1/tags", json={"dataset_id": "d1", "tags": ["a", "b"]})
    rm = requests_mock.delete(f"{BASE}/datasets/d1/tags", json={"dataset_id": "d1", "tags": ["b"]})
    assert ds.add_tag("a", "b") == ("a", "b")
    assert add.last_request.json() == {"tags": ["a", "b"]}
    assert ds.remove_tag("a") == ("b",)
    assert rm.last_request.json() == {"tags": ["a"]}


def test_add_tag_and_remove_tag_reject_empty(ds):
    with pytest.raises(ValueError):
        ds.add_tag()
    with pytest.raises(ValueError):
        ds.remove_tag()


def test_add_tag_rejects_list_argument(ds, requests_mock):
    add = requests_mock.post(f"{BASE}/datasets/d1/tags", json={})
    with pytest.raises(ValueError, match="add_tag"):
        ds.add_tag(["a", "b"])
    with pytest.raises(ValueError):
        ds.add_tag("")
    assert not add.called


def test_get_field_schema_maps_meta_fields(ds, requests_mock):
    requests_mock.get(f"{VER}/schema", json={"meta_schema": {"fields": [
        {"name": "width", "type": "int"},
        {"name": "driver_id", "type": "float", "observed": True},
        {"name": "weather", "type": "string", "observed": True},
    ]}})
    assert ds.get_field_schema() == {
        "meta.width": "int", "meta.driver_id": "float", "meta.weather": "string",
    }


def test_get_field_schema_without_meta_schema_is_empty(ds, requests_mock):
    requests_mock.get(f"{VER}/schema", json={})
    assert ds.get_field_schema() == {}


def test_delete_passes_confirm_dataset_name(ds, requests_mock):
    requests_mock.delete(f"{VER}", json={"version": "v1", "dataset_deleted": False})
    ds.delete(confirm=True, delete_cas=False, verbose=False, confirm_dataset_name="kitti")
    assert _q(requests_mock.last_request)["confirm_dataset_name"] == "kitti"


def test_delete_without_confirm_dataset_name_omits_query(ds, requests_mock):
    requests_mock.delete(f"{VER}", json={"version": "v1", "dataset_deleted": False})
    ds.delete(confirm=True, delete_cas=False, verbose=False)
    assert "confirm_dataset_name" not in _q(requests_mock.last_request)


def test_dataset_exists_requires_exact_name(client, requests_mock):
    requests_mock.get(f"{BASE}/datasets", json=[
        {"dataset_id": "d1", "name": "kitti-2024"},
        {"dataset_id": "d2", "name": "kitti"},
    ])
    assert nx.dataset_exists("kitti", client=client) is True
    assert _q(requests_mock.last_request)["name"] == "kitti"


def test_dataset_exists_rejects_partial_match(client, requests_mock):
    requests_mock.get(f"{BASE}/datasets", json=[{"dataset_id": "d1", "name": "kitti-2024"}])
    assert nx.dataset_exists("kitti", client=client) is False


# ── Task 3: iter_samples / values / distinct ─────────────────────────────────

def _rows(*ids, **extra):
    return [{"sample_id": i, "split": None, "tags": [], "meta": {}, **extra} for i in ids]


def test_iter_samples_is_lazy_and_pages_on_full_page(ds, requests_mock):
    m = requests_mock.post(EXPLORER, [
        {"json": _rows("s5", "s4")},
        {"json": _rows("s3")},
    ])
    it = ds.iter_samples(page_size=2)
    assert m.call_count == 0  # 제너레이터 — 꺼내기 전에는 부르지 않는다
    assert [s.sample_id for s in it] == ["s5", "s4", "s3"]
    assert m.call_count == 2
    first, second = m.request_history
    assert first.json() == {"limit": 2, "include_annotations": True}
    assert second.json() == {"limit": 2, "cursor": "s4", "include_annotations": True}


def test_iter_samples_stops_on_short_page(ds, requests_mock):
    m = requests_mock.post(EXPLORER, json=_rows("s2"))
    assert len(list(ds.iter_samples(page_size=2))) == 1
    assert m.call_count == 1


def test_iter_samples_empty_page_after_exact_full_page(ds, requests_mock):
    m = requests_mock.post(EXPLORER, [{"json": _rows("s2", "s1")}, {"json": []}])
    assert len(list(ds.iter_samples(page_size=2))) == 2
    assert m.call_count == 2


def test_iter_samples_passes_filters(ds, requests_mock):
    m = requests_mock.post(EXPLORER, json=[])
    list(ds.iter_samples(
        split="train", tags=["a"], exclude_tags=["b"], meta={"k": {"type": "enum", "values": ["x"]}},
        group_key="det", label="car", confidence_min=0.5, track_id=3,
        sample_ids=["s1"],
    ))
    assert m.last_request.json() == {
        "limit": 1000, "split": "train", "tags": ["a"], "exclude_tags": ["b"],
        "meta": {"k": {"type": "enum", "values": ["x"]}},
        "annotation": [{"group_key": "det", "label": "car",
                        "confidence": {"min": 0.5, "max": None}, "track_id": 3}],
        "include_annotations": True, "sample_ids": ["s1"],
    }


@pytest.mark.parametrize("bad", [0, 1001, -1, 2.0, "10", True, None])
def test_iter_samples_rejects_bad_page_size(ds, bad):
    with pytest.raises(ValueError):
        next(ds.iter_samples(page_size=bad))


def test_iter_samples_rejects_unknown_filter(ds, requests_mock):
    m = requests_mock.post(EXPLORER, json=[])
    with pytest.raises(TypeError, match="lable"):
        next(ds.iter_samples(lable="car"))
    assert not m.called


def test_samples_still_builds_same_body(ds, requests_mock):
    # 공용 헬퍼로 옮긴 뒤에도 samples() 의 요청 모양은 그대로다.
    m = requests_mock.post(EXPLORER, json=[])
    ds.samples(group_key="det", label="car", split="val")
    assert m.last_request.json() == {
        "limit": 1000, "split": "val",
        "annotation": [{"group_key": "det", "label": "car"}],
        "include_annotations": True,
    }


def test_values_reads_meta_tags_split_and_id(ds, requests_mock):
    m = requests_mock.post(EXPLORER, json=[
        {"sample_id": "s2", "split": "train", "tags": ["a"], "meta": {"driver_id": 7}},
        {"sample_id": "s1", "split": None, "tags": [], "meta": None},
    ])
    assert ds.values("meta.driver_id") == [7, None]
    assert m.last_request.json()["include_annotations"] is False
    assert ds.values("tags") == [["a"], []]
    assert ds.values("split") == ["train", None]
    assert ds.values("sample_id") == ["s2", "s1"]


@pytest.mark.parametrize("bad", ["driver_id", "meta.", "meta", "filepath", "", "det.label"])
def test_values_and_distinct_reject_non_path_fields(ds, bad):
    with pytest.raises(ValueError):
        ds.values(bad)
    with pytest.raises(ValueError):
        ds.distinct(bad)


def test_distinct_meta_uses_categorical_histogram(ds, requests_mock):
    h = requests_mock.get(f"{VER}/histogram", json={
        "kind": "categorical_histogram", "field": "meta.weather",
        "buckets": [{"value": "rain", "count": 5}, {"value": "clear", "count": 9}],
    })
    requests_mock.get(f"{VER}/schema", json={"meta_schema": {"fields": [
        {"name": "weather", "type": "string", "observed": True}]}})
    ex = requests_mock.post(EXPLORER, json=[])
    assert ds.distinct("meta.weather") == ["clear", "rain"]
    assert _q(h.last_request) == {"field": "meta.weather"}
    assert not ex.called


def test_distinct_bool_meta_converts_histogram_strings(ds, requests_mock):
    requests_mock.get(f"{VER}/histogram", json={
        "kind": "categorical_histogram", "field": "meta.night",
        "buckets": [{"value": "true", "count": 1}, {"value": "false", "count": 2}],
    })
    requests_mock.get(f"{VER}/schema", json={"meta_schema": {"fields": [
        {"name": "night", "type": "bool", "observed": True}]}})
    assert ds.distinct("meta.night") == [False, True]


def test_distinct_numeric_histogram_falls_back_to_scan(ds, requests_mock):
    requests_mock.get(f"{VER}/histogram", json={
        "kind": "numeric_histogram", "field": "meta.driver_id", "min": 1, "max": 7, "bins": [],
    })
    requests_mock.post(EXPLORER, json=[
        {"sample_id": "s3", "meta": {"driver_id": 7}},
        {"sample_id": "s2", "meta": {"driver_id": 1}},
        {"sample_id": "s1", "meta": {"driver_id": 7}},
    ])
    assert ds.distinct("meta.driver_id") == [1, 7]


def test_distinct_histogram_400_falls_back_to_scan_and_flattens_arrays(ds, requests_mock):
    requests_mock.get(f"{VER}/histogram", status_code=400, json={"error": "holds arrays"})
    requests_mock.post(EXPLORER, json=[
        {"sample_id": "s2", "meta": {"cams": ["front", "rear"]}},
        {"sample_id": "s1", "meta": {"cams": ["front"]}},
    ])
    assert ds.distinct("meta.cams") == ["front", "rear"]


def test_distinct_unobserved_key_is_empty(ds, requests_mock):
    requests_mock.get(f"{VER}/histogram", status_code=400, json={"error": "unknown meta field"})
    requests_mock.post(EXPLORER, json=_rows("s1"))
    assert ds.distinct("meta.nope") == []


def test_distinct_histogram_other_errors_propagate(ds, requests_mock):
    requests_mock.get(f"{VER}/histogram", status_code=404, json={"error": "no version"})
    with pytest.raises(NexusError) as ei:
        ds.distinct("meta.k")
    assert ei.value.status_code == 404


def test_distinct_scan_rejects_object_values(ds, requests_mock):
    requests_mock.get(f"{VER}/histogram", status_code=400, json={"error": "holds objects"})
    requests_mock.post(EXPLORER, json=[{"sample_id": "s1", "meta": {"calib": {"fx": 1.0}}}])
    with pytest.raises(ValueError, match="meta.calib"):
        ds.distinct("meta.calib")


def test_distinct_tags_scans_and_flattens(ds, requests_mock):
    h = requests_mock.get(f"{VER}/histogram", json={})
    requests_mock.post(EXPLORER, json=[
        {"sample_id": "s2", "tags": ["b", "a"]}, {"sample_id": "s1", "tags": ["a"]},
    ])
    assert ds.distinct("tags") == ["a", "b"]
    assert not h.called


def test_distinct_scan_keeps_one_and_true_apart_and_sorts_mixed_types(ds, requests_mock):
    requests_mock.get(f"{VER}/histogram", status_code=400, json={"error": "mixed"})
    requests_mock.post(EXPLORER, json=[
        {"sample_id": "s4", "meta": {"k": 1}},
        {"sample_id": "s3", "meta": {"k": True}},
        {"sample_id": "s2", "meta": {"k": "a"}},
        {"sample_id": "s1", "meta": {"k": 1}},
    ])
    out = ds.distinct("meta.k")
    assert len(out) == 3
    assert any(v is True for v in out)
    assert any(v == 1 and v is not True for v in out)
    assert "a" in out


# ── Task 4: count_values / set_values ────────────────────────────────────────

def _counts(field, counts, computed=True, truncated=False):
    return {"field": field, "computed": computed, "truncated": truncated,
            "counts": [{"value": v, "count": c} for v, c in counts]}


def test_count_values_returns_dict(ds, requests_mock):
    m = requests_mock.post(f"{VER}/facets/counts",
                           json=_counts("det.label", [("car", 10), ("bus", 2)]))
    assert ds.count_values("det.label") == {"car": 10, "bus": 2}
    assert _q(m.last_request) == {"field": "det.label"}
    assert m.last_request.json() == {}


def test_count_values_truncated_warns_but_returns(ds, requests_mock):
    requests_mock.post(f"{VER}/facets/counts", json=_counts("tags", [("a", 1)], truncated=True))
    with pytest.warns(RuntimeWarning, match="500"):
        out = ds.count_values("tags")
    assert out == {"a": 1}


def test_count_values_not_computed_raises(ds, requests_mock):
    requests_mock.post(f"{VER}/facets/counts", json=_counts("tags", [], computed=False))
    with pytest.raises(NexusError, match="못 셌"):
        ds.count_values("tags")


def test_count_values_server_400_propagates(ds, requests_mock):
    requests_mock.post(f"{VER}/facets/counts", status_code=400, json={"error": "unsupported field"})
    with pytest.raises(NexusError) as ei:
        ds.count_values("meta.width")
    assert ei.value.status_code == 400


def test_count_sample_tags_is_count_values_tags(ds, requests_mock):
    m = requests_mock.post(f"{VER}/facets/counts", json=_counts("tags", [("a", 3)]))
    with warnings.catch_warnings():
        warnings.simplefilter("error")
        assert ds.count_sample_tags() == {"a": 3}
    assert _q(m.last_request) == {"field": "tags"}


def test_set_values_patches_meta_per_sample(ds, requests_mock):
    a = requests_mock.patch(f"{VER}/samples/s1/annotations", json={"skipped": 0})
    b = requests_mock.patch(f"{VER}/samples/s2/annotations", json={"skipped": 0})
    assert ds.set_values("meta.driver_id", {"s1": 7, "s2": None}) == 2
    assert a.last_request.json() == {"annotation_data": {"meta": {"driver_id": 7}}}
    assert b.last_request.json() == {"annotation_data": {"meta": {"driver_id": None}}}


@pytest.mark.parametrize("bad", ["driver_id", "tags", "split", "meta.", "det.label"])
def test_set_values_rejects_non_meta_field(ds, bad):
    with pytest.raises(ValueError):
        ds.set_values(bad, {"s1": 1})


def test_set_values_rejects_non_mapping(ds):
    with pytest.raises(ValueError):
        ds.set_values("meta.k", [1, 2])


def test_set_values_stops_at_first_failure_with_count_and_id(ds, requests_mock):
    requests_mock.patch(f"{VER}/samples/s1/annotations", json={"skipped": 0})
    requests_mock.patch(f"{VER}/samples/s2/annotations", status_code=404, json={"error": "nope"})
    s3 = requests_mock.patch(f"{VER}/samples/s3/annotations", json={"skipped": 0})
    with pytest.raises(NexusError) as ei:
        ds.set_values("meta.k", {"s1": 1, "s2": 2, "s3": 3})
    e = ei.value
    assert e.status_code == 404
    assert e.applied == 1 and e.failed_sample_id == "s2"
    assert "1" in str(e) and "s2" in str(e)
    assert not s3.called


def test_set_values_sealed_stops_at_first_409(ds, requests_mock):
    first = requests_mock.patch(f"{VER}/samples/s1/annotations", status_code=409,
                                json={"error": "version is sealed"})
    s2 = requests_mock.patch(f"{VER}/samples/s2/annotations", json={})
    with pytest.raises(NexusError) as ei:
        ds.set_values("meta.k", {"s1": 1, "s2": 2})
    assert ei.value.status_code == 409 and ei.value.applied == 0
    assert first.called and not s2.called


# ── Task 5: shuffle ──────────────────────────────────────────────────────────

def _explorer_router(all_rows):
    """본문의 sample_ids 로 걸러 서버처럼 sample_id 내림차순으로 돌려주는 가짜 explorer."""
    def cb(request, context):
        body = request.json()
        rows = all_rows
        if body.get("sample_ids"):
            want = set(body["sample_ids"])
            rows = [r for r in rows if r["sample_id"] in want]
        rows = sorted(rows, key=lambda r: r["sample_id"], reverse=True)
        cur = body.get("cursor")
        if cur:
            rows = [r for r in rows if r["sample_id"] < cur]
        return rows[: body["limit"]]
    return cb


def test_shuffle_same_seed_reproduces_and_covers_all(ds, requests_mock):
    rows = _rows(*[f"s{i:02d}" for i in range(10)])
    requests_mock.post(EXPLORER, json=_explorer_router(rows))
    a = [s.sample_id for s in ds.shuffle(seed=7, page_size=3)]
    b = [s.sample_id for s in ds.shuffle(seed=7, page_size=3)]
    assert a == b
    assert sorted(a) == sorted(r["sample_id"] for r in rows)
    assert a != sorted(a, reverse=True)  # 서버 순서 그대로가 아니다


def test_shuffle_keeps_shuffled_order_within_chunk(ds, requests_mock):
    rows = _rows("s1", "s2", "s3", "s4")
    m = requests_mock.post(EXPLORER, json=_explorer_router(rows))
    import random as _random
    expected = sorted((r["sample_id"] for r in rows), reverse=True)
    _random.Random(3).shuffle(expected)
    got = [s.sample_id for s in ds.shuffle(seed=3, page_size=4)]
    assert got == expected
    # id 수집은 annotation 없이, 청크 조회는 sample_ids 로
    assert m.request_history[0].json()["include_annotations"] is False
    assert sorted(m.request_history[-1].json()["sample_ids"]) == sorted(expected)


def test_shuffle_applies_filters_to_collection_and_chunks(ds, requests_mock):
    m = requests_mock.post(EXPLORER, json=_explorer_router(_rows("s1", "s2")))
    list(ds.shuffle(seed=1, split="train"))
    collect, *chunks = m.request_history
    assert collect.json()["split"] == "train" and collect.json()["include_annotations"] is False
    assert chunks and all(
        r.json()["split"] == "train" and r.json()["include_annotations"] is True for r in chunks
    )


def test_shuffle_skips_samples_missing_from_chunk(ds, requests_mock):
    collected = _rows("s1", "s2", "s3")

    def cb(request, context):
        body = request.json()
        if not body.get("sample_ids"):
            return collected
        # 수집 뒤에 s2 가 지워졌다
        return [r for r in collected if r["sample_id"] in body["sample_ids"] and r["sample_id"] != "s2"]

    requests_mock.post(EXPLORER, json=cb)
    got = [s.sample_id for s in ds.shuffle(seed=5)]
    assert sorted(got) == ["s1", "s3"]


def test_shuffle_validates_before_calling(ds, requests_mock):
    m = requests_mock.post(EXPLORER, json=[])
    with pytest.raises(ValueError):
        next(ds.shuffle(page_size=0))
    with pytest.raises(TypeError):
        next(ds.shuffle(lable="car"))
    assert not m.called


def test_shuffle_empty_version_yields_nothing(ds, requests_mock):
    requests_mock.post(EXPLORER, json=[])
    assert list(ds.shuffle(seed=1)) == []


# ── 최종 리뷰 수정 ───────────────────────────────────────────────────────────

def test_distinct_categorical_with_json_text_falls_back_to_scan(ds, requests_mock):
    # 관측 전용 키에 문자열과 배열이 섞이면 서버는 categorical 로 보고 배열을 JSON 텍스트로 준다.
    requests_mock.get(f"{VER}/histogram", json={
        "kind": "categorical_histogram", "field": "meta.cams",
        "buckets": [{"value": '["front", "rear"]', "count": 1}, {"value": "front", "count": 1}],
    })
    requests_mock.get(f"{VER}/schema", json={"meta_schema": {"fields": [
        {"name": "cams", "type": "string", "observed": True}]}})
    requests_mock.post(EXPLORER, json=[
        {"sample_id": "s2", "meta": {"cams": ["front", "rear"]}},
        {"sample_id": "s1", "meta": {"cams": "front"}},
    ])
    assert ds.distinct("meta.cams") == ["front", "rear"]


def test_distinct_true_false_strings_without_bool_schema_scans(ds, requests_mock):
    # 스키마는 dataset 단위(다른 버전에서 문자열을 본 적이 있으면 "string")지만 이 버전은 불리언뿐이다.
    requests_mock.get(f"{VER}/histogram", json={
        "kind": "categorical_histogram", "field": "meta.night",
        "buckets": [{"value": "true", "count": 1}, {"value": "false", "count": 1}],
    })
    requests_mock.get(f"{VER}/schema", json={"meta_schema": {"fields": [
        {"name": "night", "type": "string", "observed": True}]}})
    requests_mock.post(EXPLORER, json=[
        {"sample_id": "s2", "meta": {"night": True}},
        {"sample_id": "s1", "meta": {"night": False}},
    ])
    assert ds.distinct("meta.night") == [False, True]


def test_distinct_scan_sorts_numbers_numerically_and_merges_int_float(ds, requests_mock):
    requests_mock.get(f"{VER}/histogram", json={
        "kind": "numeric_histogram", "field": "meta.score", "min": 1, "max": 2, "bins": [],
    })
    requests_mock.post(EXPLORER, json=[
        {"sample_id": "s4", "meta": {"score": 2}},
        {"sample_id": "s3", "meta": {"score": 1.5}},
        {"sample_id": "s2", "meta": {"score": 1.0}},
        {"sample_id": "s1", "meta": {"score": 1}},
    ])
    assert ds.distinct("meta.score") == [1, 1.5, 2]


def test_set_values_transport_error_keeps_progress(ds, requests_mock):
    import requests as _requests
    requests_mock.patch(f"{VER}/samples/s1/annotations", json={"skipped": 0})
    requests_mock.patch(f"{VER}/samples/s2/annotations", exc=_requests.exceptions.ReadTimeout)
    with pytest.raises(NexusError) as ei:
        ds.set_values("meta.k", {"s1": 1, "s2": 2})
    e = ei.value
    assert e.applied == 1 and e.failed_sample_id == "s2"
    assert "적용됐을 수도" in str(e)
    assert isinstance(e.__cause__, _requests.exceptions.ReadTimeout)


def test_shuffle_fetches_each_chunk_in_one_request(ds, requests_mock):
    # 청크가 서버 상한(1000)과 같아도 다음 페이지를 다시 묻지 않는다.
    rows = _rows(*[f"s{i:04d}" for i in range(1000)])
    m = requests_mock.post(EXPLORER, json=_explorer_router(rows))
    assert len(list(ds.shuffle(seed=1))) == 1000
    chunk_reqs = [r for r in m.request_history if r.json().get("sample_ids")]
    assert len(chunk_reqs) == 1
    assert chunk_reqs[0].json()["limit"] == 1000


def test_shuffle_chunk_request_limit_is_chunk_size(ds, requests_mock):
    m = requests_mock.post(EXPLORER, json=_explorer_router(_rows("s1", "s2", "s3", "s4", "s5")))
    list(ds.shuffle(seed=2, page_size=2))
    limits = [r.json()["limit"] for r in m.request_history if r.json().get("sample_ids")]
    assert limits == [2, 2, 1]


# ── 3차 리뷰 수정 ────────────────────────────────────────────────────────────

def test_distinct_empty_categorical_returns_empty_without_scan(ds, requests_mock):
    # 서버 SQL 이 `IS NOT NULL` 로 거르므로 버킷이 비면 이 버전에 값이 없다는 뜻이다.
    requests_mock.get(f"{VER}/histogram", json={
        "kind": "categorical_histogram", "field": "meta.weather", "buckets": [],
    })
    schema = requests_mock.get(f"{VER}/schema", json={"meta_schema": {"fields": []}})
    ex = requests_mock.post(EXPLORER, json=[])
    assert ds.distinct("meta.weather") == []
    assert not ex.called
    assert not schema.called


def test_shuffle_chunk_requests_include_annotations_by_default(ds, requests_mock):
    m = requests_mock.post(EXPLORER, json=_explorer_router(_rows("s1", "s2")))
    list(ds.shuffle(seed=1))
    collect, *chunks = m.request_history
    assert collect.json()["include_annotations"] is False
    assert chunks and all(r.json()["include_annotations"] is True for r in chunks)


def _merge_failing_on(ds, sid, exc):
    real = ds._client.merge_sample_annotations

    def fake(dataset_id, version, sample_id, annotation_data):
        if sample_id == sid:
            raise exc
        return {}

    ds._client.merge_sample_annotations = fake
    return real


def test_set_values_keeps_nexus_error_subclass(ds):
    from nexus._types import NexusAuthError
    _merge_failing_on(ds, "s2", NexusAuthError("token expired", status_code=401))
    with pytest.raises(NexusAuthError) as ei:
        ds.set_values("meta.k", {"s1": 1, "s2": 2})
    e = ei.value
    assert e.status_code == 401
    assert e.applied == 1 and e.failed_sample_id == "s2"
    assert "s2" in str(e)


def test_set_values_other_exception_carries_progress(ds):
    _merge_failing_on(ds, "s2", OSError("token file unreadable"))
    with pytest.raises(OSError) as ei:
        ds.set_values("meta.k", {"s1": 1, "s2": 2, "s3": 3})
    assert ei.value.applied == 1 and ei.value.failed_sample_id == "s2"


# ── 피드백 반영(2026-10-12): AnnotatedSample 행 변환·태그 저장 ────────────────

def _row(sid="s1", tags=("a",), meta=None, **groups):
    """explorer·get_sample 응답 한 행 — 코어 키 여섯 + meta + 그룹."""
    r = {
        "sample_id": sid, "split": "train", "tags": list(tags),
        "created_at": "2026-10-12T00:00:00Z",
        "image_url": "http://cas/b/x.png", "thumbnail_url": "http://cas/b/thumb/x.png",
        "meta": {"width": 4} if meta is None else meta,
    }
    r.update(groups)
    return r


_REPORT = {"instances": 0, "skipped": 0,
           "skipped_reasons": {"missing_label": 0, "not_an_object": 0, "group_not_an_array": 0}}


def test_from_row_strips_core_keys_and_keeps_tags_split(ds):
    from nexus.annotated import AnnotatedSample
    s = AnnotatedSample.from_row(_row(det=[{"id": "i1", "label": "car"}]), {}, dataset=ds)
    assert s.sample_id == "s1"
    assert s.split == "train"
    assert s.tags == ["a"]
    assert set(s.groups) == {"det"}
    assert s.meta.to_dict() == {"width": 4}
    with pytest.raises(AttributeError):
        s.split = "val"


def test_from_row_types_declared_groups(ds):
    from nexus.annotated import AnnotatedSample
    from nexus.group import LabelContainer
    row = _row(g=[{"id": "a", "label": "c",
                   "bounding_box": {"type": "bounding_box", "rect": [0, 0, 1, 1]}}])
    s = AnnotatedSample.from_row(row, {"g": "container"}, dataset=ds)
    assert isinstance(s.get_group("g"), LabelContainer)


def test_save_tags_only_checks_version_then_adds_and_removes(ds, requests_mock):
    from nexus.annotated import AnnotatedSample
    ver = requests_mock.get(VER, json={"version": "v1", "status": "draft"})
    patch = requests_mock.patch(f"{VER}/samples/s1/annotations", json=_REPORT)
    add = requests_mock.post(f"{BASE}/samples/tags", json=[{"sample_id": "s1"}])
    rm = requests_mock.delete(f"{BASE}/samples/tags", json=[{"sample_id": "s1"}])
    s = AnnotatedSample.from_row(_row(tags=("a", "b")), {}, dataset=ds)
    s.tags.remove("a")
    s.tags.append("c")
    s.save()
    assert ver.called and not patch.called
    assert add.last_request.json() == {"sample_ids": ["s1"], "tags": ["c"]}
    assert rm.last_request.json() == {"sample_ids": ["s1"], "tags": ["a"]}
    before = ver.call_count + add.call_count + rm.call_count
    s.save()  # 기준이 갱신돼 보낼 것이 없다
    assert ver.call_count + add.call_count + rm.call_count == before


def test_save_tag_order_only_is_not_a_change(ds, requests_mock):
    from nexus.annotated import AnnotatedSample
    ver = requests_mock.get(VER, json={"status": "draft"})
    s = AnnotatedSample.from_row(_row(tags=("a", "b")), {}, dataset=ds)
    s.tags.reverse()
    s.save()
    assert not ver.called


def test_save_tags_on_sealed_version_raises_409_before_sending(ds, requests_mock):
    from nexus.annotated import AnnotatedSample
    requests_mock.get(VER, json={"status": "sealed"})
    patch = requests_mock.patch(f"{VER}/samples/s1/annotations", json=_REPORT)
    add = requests_mock.post(f"{BASE}/samples/tags", json=[{"sample_id": "s1"}])
    s = AnnotatedSample.from_row(_row(), {}, dataset=ds)
    s.meta["width"] = 8
    s.tags.append("x")
    with pytest.raises(NexusError) as ei:
        s.save()
    assert ei.value.status_code == 409
    assert not patch.called and not add.called


def test_save_meta_and_tags_patches_first_then_tags(ds, requests_mock):
    from nexus.annotated import AnnotatedSample
    requests_mock.get(VER, json={"status": "draft"})
    requests_mock.patch(f"{VER}/samples/s1/annotations", json=_REPORT)
    requests_mock.post(f"{BASE}/samples/tags", json=[{"sample_id": "s1"}])
    s = AnnotatedSample.from_row(_row(), {}, dataset=ds)
    s.meta["width"] = 8
    s.tags.append("x")
    s.save()
    # 픽스처의 로그인 요청만 빼고 순서대로 본다.
    calls = [(r.method, r.path) for r in requests_mock.request_history
             if not r.path.endswith("/auth/login")]
    assert calls == [
        ("GET", "/datasets/d1/versions/v1"),
        ("PATCH", "/datasets/d1/versions/v1/samples/s1/annotations"),
        ("POST", "/samples/tags"),
    ]


def test_save_without_tag_change_does_not_check_version(ds, requests_mock):
    from nexus.annotated import AnnotatedSample
    ver = requests_mock.get(VER, json={"status": "draft"})
    patch = requests_mock.patch(f"{VER}/samples/s1/annotations", json=_REPORT)
    s = AnnotatedSample.from_row(_row(), {}, dataset=ds)
    s.meta["width"] = 8
    s.save()
    assert patch.last_request.json() == {"annotation_data": {"meta": {"width": 8}}}
    assert not ver.called


def test_save_from_dict_sample_never_checks_version(ds, requests_mock):
    from nexus.annotated import AnnotatedSample
    ver = requests_mock.get(VER, json={"status": "draft"})
    requests_mock.patch(f"{VER}/samples/s1/annotations", json=_REPORT)
    s = AnnotatedSample.from_dict({"meta": {"width": 4}}, {}, sample_id="s1", dataset=ds)
    assert s.tags is None and s.split is None
    s.meta["width"] = 8
    s.save()
    assert not ver.called


def test_save_tag_failure_keeps_meta_baseline(ds, requests_mock):
    from nexus.annotated import AnnotatedSample
    requests_mock.get(VER, json={"status": "draft"})
    patch = requests_mock.patch(f"{VER}/samples/s1/annotations", json=_REPORT)
    add = requests_mock.post(f"{BASE}/samples/tags", [
        {"status_code": 400, "json": {"error": "bad"}},
        {"json": [{"sample_id": "s1"}]},
    ])
    s = AnnotatedSample.from_row(_row(), {}, dataset=ds)
    s.meta["width"] = 8
    s.tags.append("x")
    with pytest.raises(NexusError):
        s.save()
    assert patch.call_count == 1
    s.save()  # meta 는 이미 저장됐다 — 태그만 다시 간다
    assert patch.call_count == 1
    assert add.call_count == 2
    assert add.last_request.json() == {"sample_ids": ["s1"], "tags": ["x"]}


def test_save_rejects_invalid_tags_before_sending(ds, requests_mock):
    from nexus.annotated import AnnotatedSample
    from nexus._types import NexusValidationError
    ver = requests_mock.get(VER, json={"status": "draft"})
    s = AnnotatedSample.from_row(_row(), {}, dataset=ds)
    s.tags = "a"
    with pytest.raises(NexusValidationError):
        s.save()
    s.tags = ["a", ""]
    with pytest.raises(NexusValidationError):
        s.save()
    assert not ver.called


def test_save_dedupes_added_tags(ds, requests_mock):
    from nexus.annotated import AnnotatedSample
    requests_mock.get(VER, json={"status": "draft"})
    add = requests_mock.post(f"{BASE}/samples/tags", json=[{"sample_id": "s1"}])
    s = AnnotatedSample.from_row(_row(tags=()), {}, dataset=ds)
    s.tags.append("x")
    s.tags.append("x")
    s.save()
    assert add.last_request.json() == {"sample_ids": ["s1"], "tags": ["x"]}


def test_load_sample_uses_get_sample_and_carries_tags(ds, requests_mock):
    one = requests_mock.get(f"{VER}/samples/s1", json=_row(tags=("a",), det=[{"id": "i1", "label": "car"}]))
    ann = requests_mock.get(f"{VER}/samples/s1/annotations", json={})
    s = ds.load_sample("s1")
    assert one.called and not ann.called
    assert s.sample_id == "s1" and s.tags == ["a"] and s.split == "train"
    assert set(s.groups) == {"det"}


def test_iter_samples_yields_annotated_samples_with_annotations(ds, requests_mock):
    from nexus.annotated import AnnotatedSample
    m = requests_mock.post(EXPLORER, json=[_row("s2", det=[{"id": "i1", "label": "car"}]), _row("s1")])
    out = list(ds.iter_samples())
    assert all(isinstance(s, AnnotatedSample) for s in out)
    assert [s.sample_id for s in out] == ["s2", "s1"]
    assert "det" in out[0].groups and out[0].tags == ["a"] and out[0].split == "train"
    assert m.last_request.json()["include_annotations"] is True


@pytest.mark.parametrize("value", [True, False])
def test_iter_samples_and_shuffle_reject_include_annotations(ds, requests_mock, value):
    m = requests_mock.post(EXPLORER, json=[])
    with pytest.raises(TypeError, match="include_annotations"):
        next(ds.iter_samples(include_annotations=value))
    with pytest.raises(TypeError, match="include_annotations"):
        next(ds.shuffle(include_annotations=value))
    assert not m.called


def test_iter_samples_sample_save_roundtrip(ds, requests_mock):
    requests_mock.post(EXPLORER, json=[_row("s1")])
    p = requests_mock.patch(f"{VER}/samples/s1/annotations", json=_REPORT)
    s = next(ds.iter_samples())
    s.meta["width"] = 8
    s.save()
    assert p.last_request.json() == {"annotation_data": {"meta": {"width": 8}}}


def test_shuffle_yields_annotated_samples(ds, requests_mock):
    from nexus.annotated import AnnotatedSample
    requests_mock.post(EXPLORER, json=_explorer_router([_row("s1"), _row("s2")]))
    out = list(ds.shuffle(seed=0))
    assert all(isinstance(s, AnnotatedSample) for s in out)
    assert sorted(s.sample_id for s in out) == ["s1", "s2"]


def test_shuffle_types_declared_groups(ds, requests_mock):
    from nexus.group import LabelContainer
    g = [{"id": "a", "label": "c", "bounding_box": {"type": "bounding_box", "rect": [0, 0, 1, 1]}}]
    requests_mock.post(EXPLORER, json=_explorer_router([_row("s1", g=g)]))
    ds.declare_group_kinds({"g": "container"})
    (s,) = list(ds.shuffle(seed=0))
    assert isinstance(s.get_group("g"), LabelContainer)


def test_values_with_filters_passes_them(ds, requests_mock):
    m = requests_mock.post(EXPLORER, json=[{"sample_id": "s1", "meta": {"k": 1}}])
    assert ds.values("meta.k", split="train", tags=["a"]) == [1]
    body = m.last_request.json()
    assert body["split"] == "train" and body["tags"] == ["a"]
    assert body["include_annotations"] is False


def test_values_and_distinct_reject_include_annotations(ds, requests_mock):
    m = requests_mock.post(EXPLORER, json=[])
    with pytest.raises(TypeError, match="include_annotations"):
        ds.values("meta.k", include_annotations=True)
    with pytest.raises(TypeError, match="include_annotations"):
        ds.distinct("meta.k", include_annotations=True)
    assert not m.called


def test_values_rejects_unknown_filter(ds, requests_mock):
    m = requests_mock.post(EXPLORER, json=[])
    with pytest.raises(TypeError, match="lable"):
        ds.values("meta.k", lable="car")
    assert not m.called


def test_distinct_with_filters_skips_histogram(ds, requests_mock):
    h = requests_mock.get(f"{VER}/histogram", json={
        "kind": "categorical_histogram", "field": "meta.w",
        "buckets": [{"value": "rain", "count": 1}, {"value": "clear", "count": 1}],
    })
    m = requests_mock.post(EXPLORER, json=[{"sample_id": "s1", "meta": {"w": "rain"}}])
    assert ds.distinct("meta.w", split="train") == ["rain"]
    assert not h.called
    assert m.last_request.json()["split"] == "train"


def test_refresh_updates_name(ds, requests_mock):
    requests_mock.get(f"{BASE}/datasets/d1", json={"dataset_id": "d1", "name": "dataset1", "tags": []})
    assert ds.refresh() is ds
    assert ds.name == "dataset1"


def test_refresh_missing_dataset_raises_404(ds, requests_mock):
    requests_mock.get(f"{BASE}/datasets/d1", status_code=404, json={"error": "not found"})
    with pytest.raises(NexusError) as ei:
        ds.refresh()
    assert ei.value.status_code == 404


# ── 최종 리뷰 수정: 옛 서버 PUT 폴백 ──────────────────────────────────────────

def test_put_fallback_keeps_groups_hidden_by_core_keys(ds, requests_mock):
    # 샘플 단건 응답은 코어 키(tags)가 같은 이름의 그룹을 가린다. 옛 서버(PATCH 405)의 통째 PUT 이
    # 그 그룹을 빼고 보내면 이 버전의 그 그룹 instance 가 전부 지워진다.
    stored_group = [{"id": "t1", "label": "x"}]
    requests_mock.get(f"{VER}/samples/s1", json=_row(det=[{"id": "i1", "label": "car"}]))
    requests_mock.get(f"{VER}/samples/s1/annotations", json={
        "meta": {"width": 4}, "det": [{"id": "i1", "label": "car"}], "tags": stored_group,
    })
    requests_mock.patch(f"{VER}/samples/s1/annotations", status_code=405, json={"error": "method not allowed"})
    put = requests_mock.put(f"{VER}/samples/s1/annotations", json=_REPORT)
    s = ds.load_sample("s1")
    s.meta["width"] = 8
    with pytest.warns(RuntimeWarning):
        s.save()
    body = put.last_request.json()["annotation_data"]
    assert body["tags"] == stored_group
    assert body["det"] == [{"id": "i1", "label": "car"}]
    assert body["meta"] == {"width": 8}


# ── 미룬 사소한 것 수정 ───────────────────────────────────────────────────────

def test_sealed_result_is_remembered_on_the_handle(ds, requests_mock):
    from nexus.annotated import AnnotatedSample
    ver = requests_mock.get(VER, json={"status": "sealed"})
    for sid in ("s1", "s2"):
        s = AnnotatedSample.from_row(_row(sid), {}, dataset=ds)
        s.tags.append("x")
        with pytest.raises(NexusError) as ei:
            s.save()
        assert ei.value.status_code == 409
    assert ver.call_count == 1  # seal 은 단방향이라 sealed 는 다시 묻지 않는다


def test_draft_result_is_not_remembered(ds, requests_mock):
    from nexus.annotated import AnnotatedSample
    ver = requests_mock.get(VER, json={"status": "draft"})
    requests_mock.post(f"{BASE}/samples/tags", json=[{"sample_id": "s1"}, {"sample_id": "s2"}])
    for sid in ("s1", "s2"):
        s = AnnotatedSample.from_row(_row(sid), {}, dataset=ds)
        s.tags.append("x")
        s.save()
    assert ver.call_count == 2  # draft 는 그 사이 seal 될 수 있다


def test_tag_save_on_deleted_sample_raises_404(ds, requests_mock):
    from nexus.annotated import AnnotatedSample
    requests_mock.get(VER, json={"status": "draft"})
    requests_mock.post(f"{BASE}/samples/tags", json=[])  # 서버는 삭제된 샘플을 결과에서 뺀다
    s = AnnotatedSample.from_row(_row(), {}, dataset=ds)
    s.tags.append("x")
    with pytest.raises(NexusError) as ei:
        s.save()
    assert ei.value.status_code == 404
    assert s._baseline_tags == ["a"]  # 저장되지 않았으니 기준도 그대로


def test_tag_remove_on_deleted_sample_raises_404(ds, requests_mock):
    from nexus.annotated import AnnotatedSample
    requests_mock.get(VER, json={"status": "draft"})
    requests_mock.delete(f"{BASE}/samples/tags", json=[])
    s = AnnotatedSample.from_row(_row(), {}, dataset=ds)
    s.tags.remove("a")
    with pytest.raises(NexusError) as ei:
        s.save()
    assert ei.value.status_code == 404


def test_tags_none_on_row_sample_is_rejected(ds, requests_mock):
    from nexus.annotated import AnnotatedSample
    from nexus._types import NexusValidationError
    ver = requests_mock.get(VER, json={"status": "draft"})
    s = AnnotatedSample.from_row(_row(), {}, dataset=ds)
    s.tags = None
    with pytest.raises(NexusValidationError, match="tags"):
        s.save()
    assert not ver.called


def test_local_tags_match_server_order_after_save(ds, requests_mock):
    from nexus.annotated import AnnotatedSample
    requests_mock.get(VER, json={"status": "draft"})
    requests_mock.post(f"{BASE}/samples/tags", json=[{"sample_id": "s1"}])
    requests_mock.delete(f"{BASE}/samples/tags", json=[{"sample_id": "s1"}])
    s = AnnotatedSample.from_row(_row(tags=("a", "b")), {}, dataset=ds)
    s.tags = ["x", "b", "x", "a", "a"]
    s.tags.remove("b")
    s.save()
    # 서버는 기존 순서를 지키고 새 태그를 뒤에 붙인다(중복 없음).
    assert s.tags == ["a", "x"]


@pytest.mark.parametrize("filters", [{"split": None}, {"tags": []}, {"sample_ids": None, "meta": None}])
def test_distinct_with_only_empty_filters_still_uses_histogram(ds, requests_mock, filters):
    h = requests_mock.get(f"{VER}/histogram", json={
        "kind": "categorical_histogram", "field": "meta.w",
        "buckets": [{"value": "rain", "count": 1}],
    })
    requests_mock.get(f"{VER}/schema", json={"meta_schema": {"fields": []}})
    ex = requests_mock.post(EXPLORER, json=[])
    assert ds.distinct("meta.w", **filters) == ["rain"]
    assert h.called and not ex.called


def test_distinct_zero_confidence_is_a_real_filter(ds, requests_mock):
    h = requests_mock.get(f"{VER}/histogram", json={})
    requests_mock.post(EXPLORER, json=[{"sample_id": "s1", "meta": {"w": "rain"}}])
    assert ds.distinct("meta.w", confidence_min=0) == ["rain"]
    assert not h.called


# ── 성능: 행에서 만든 샘플의 기준 사본(JSON 왕복) ─────────────────────────────

def test_from_row_baseline_is_independent_of_row_and_edits(ds):
    from nexus.annotated import AnnotatedSample
    row = _row(det=[{"id": "i1", "label": "car", "bounding_box": {"x": 1, "y": 2, "w": 3, "h": 4}}])
    s = AnnotatedSample.from_row(row, {"det": "group"}, dataset=ds)
    assert s._baseline == s.to_dict()
    row["meta"]["width"] = 99            # 원본 행을 고쳐도
    s.groups["det"][0].label = "bus"     # 객체를 고쳐도
    assert s._baseline["meta"] == {"width": 4}
    assert s._baseline["det"][0]["label"] == "car"
    assert set(s._diff()) == {"det", "meta"}


def test_local_tags_follow_server_response_order(ds, requests_mock):
    # 서버는 새 태그를 DISTINCT 로 골라 붙여 여러 개면 순서가 입력과 다를 수 있다 — 응답의 tags 를 따른다.
    from nexus.annotated import AnnotatedSample
    requests_mock.get(VER, json={"status": "draft"})
    requests_mock.post(f"{BASE}/samples/tags", json=[{"sample_id": "s1", "tags": ["a", "c", "z", "m"]}])
    s = AnnotatedSample.from_row(_row(tags=("a",)), {}, dataset=ds)
    s.tags += ["z", "m", "c"]
    s.save()
    assert s.tags == ["a", "c", "z", "m"]
    assert s._tag_diff() == ([], [])
