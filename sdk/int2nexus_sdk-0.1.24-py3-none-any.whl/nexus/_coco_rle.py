"""COCO 압축 RLE `counts` 문자열 디코더(pycocotools 의존 없음).

서버 `src/integrations/cvat/mask_rle.rs` 의 런 해석을 그대로 옮긴 것이다 — 문자 범위 48..=111, 이어짐 비트
0x20, 마지막 문자의 부호 비트 0x10, 세 번째 이후 런만 두 칸 앞 런과의 차. 런 한 개는 문자 12 개까지다."""
from __future__ import annotations

_MAX_CHARS_PER_RUN = 12


def decode_counts(counts: str) -> list[int]:
    """압축 문자열을 런 길이 목록으로 푼다. 잘못된 문자·끝나지 않은 문자열은 `ValueError`."""
    if not isinstance(counts, str):
        raise ValueError("counts must be a string")
    s = counts.encode("utf-8")
    cnts: list[int] = []
    p = 0
    while p < len(s):
        x = 0
        k = 0
        more = True
        while more:
            if p >= len(s):
                raise ValueError("mask.rle.counts ends in the middle of a character group")
            ch = s[p]
            if not 48 <= ch <= 111:
                raise ValueError("mask.rle.counts has an out-of-range character")
            if k >= _MAX_CHARS_PER_RUN:
                raise ValueError("mask.rle.counts has a run that is too long")
            c = ch - 48
            x |= (c & 0x1F) << (5 * k)
            more = bool(c & 0x20)
            p += 1
            k += 1
            if not more and c & 0x10:
                x |= -1 << (5 * k)
        if len(cnts) > 2:
            x += cnts[-2]
        cnts.append(x)
    return cnts
