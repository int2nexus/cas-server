"""읽은 행의 지문 — seal 스냅샷 행과 explorer 행(draft `to_df`)이 같은 내용이면 같은 값을 낸다.

pandas 를 쓰지 않는다. 형식은 `"nxfp1:" + blake3 hex` 이고 계산 규칙을 바꾸면 접두를 올린다
(같은 접두의 두 값은 같은 규칙으로 계산한 것이어야 대조가 성립한다).
"""
from __future__ import annotations

import json
from collections.abc import Iterable

import blake3

FINGERPRINT_PREFIX = "nxfp1:"


def _fp_row(row: dict) -> dict:
    """지문용 행 정규화 — `meta` 가 없거나 `None`·`{}` 이면 키를 뺀다(원본은 바꾸지 않는다).

    seal 스냅샷은 meta 가 없으면 키가 없고(`groups` 축약을 거치면 `None`), explorer 는 `{}` 를 준다 —
    둘을 같은 행으로 본다. 그 밖의 키는 그대로다."""
    if "meta" in row and (row["meta"] is None or row["meta"] == {}):
        return {k: v for k, v in row.items() if k != "meta"}
    return row


def _row_bytes(row: dict) -> bytes:
    return json.dumps(
        _fp_row(row), sort_keys=True, separators=(",", ":"), ensure_ascii=False
    ).encode()


def fingerprint_rows(rows: Iterable[dict]) -> str:
    """행들의 지문. 행마다 정규화한 JSON(키 정렬·공백 없음)의 blake3 를 구하고, `sample_id` 순으로
    `"{sample_id}\\t{행 해시}\\n"` 을 이어 다시 blake3 한다 — 행 순서와 키 순서에 무관하다.

    행 해시만 쥐므로 메모리는 행 수 × 약 100 바이트다."""
    digests = [(str(r.get("sample_id")), blake3.blake3(_row_bytes(r)).hexdigest()) for r in rows]
    digests.sort()
    h = blake3.blake3()
    for sid, d in digests:
        h.update(f"{sid}\t{d}\n".encode())
    return FINGERPRINT_PREFIX + h.hexdigest()
