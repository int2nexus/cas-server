"""외부 IdP(OIDC) 토큰으로 nexus 에 직접 인증한다.

설계: `docs/superpowers/specs/2026-09-03-oidc-token-exchange-design.md`(서버 축),
2026-09-17 회신 ② §7 ⑶(SDK 대칭 요청).

서버는 등록된 발급자의 OIDC 토큰을 요청마다 **직접 Bearer 로** 받는다(교환 없이 —
`Credential::Oidc`). 이 모듈이 하는 일은 그 토큰을 **어디서 가져오는가**를 정하고, 만료가
가까우면 다시 가져오는 것뿐이다. `CasSts` 와 대칭이되 훨씬 얇다 — CAS 는 토큰을 STS 로
교환해 임시 자격증명을 받지만 nexus 는 토큰을 그대로 쓴다.

**이 경로에는 로그인도 `refresh` 도, 비밀번호 변경·계정 삭제도 없다**(서버가 OIDC 요청의
`refresh` 를 403 으로 막는다). 회전은 토큰 출처가 진다 — kubelet 이 projected 토큰 파일을
갈아 끼우거나 provider 가 새 토큰을 준다. `robot_token`(정적 베어러)과 갈리는 자리가 그것이다:
로봇 토큰은 갈아 끼우는 주체가 없어 한 번 실으면 끝이지만, 이 토큰은 시간이 지나면 바뀐다.

**토큰 값은 예외 문구·repr 어디에도 싣지 않는다.** 노트북 출력은 공유되기 쉽다.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from nexus._types import NexusAuthError


@dataclass(frozen=True)
class OidcAuth:
    """OIDC 토큰 출처. `token_file` 과 `token_provider` 중 정확히 하나를 준다.

    - `token_file`: kubelet 이 갈아 끼우는 projected ServiceAccount 토큰 파일. 만료가
      가까우면 **다시 읽는다** — kubelet 이 만료 전에 새 토큰으로 덮어써 둔다. 매 요청
      직접 Bearer 로 충분한 축(쿠버네티스)이 여기다.
    - `token_provider`: 호출하면 유효한 토큰을 돌려주는 콜러블(Keycloak 등, 노트북 안에
      갈아 끼우는 주체가 없어 코드가 가져와야 하는 축). 만료가 가까우면 **다시 호출한다**.

    `email`/`password`·`robot_token` 과 함께 줄 수 없다(`connect` 가 막는다). 자격증명
    **출처**를 고르는 축이라 계정 종류와는 다르다 — 사람 계정에 붙은 OIDC 신원이든 로봇
    계정에 붙은 k8s SA 신원이든 이 하나로 인증한다.
    """

    token_file: "str | None" = None
    token_provider: "Callable[[], str] | None" = None

    def __post_init__(self) -> None:
        if (self.token_file is None) == (self.token_provider is None):
            raise ValueError(
                "OidcAuth 는 token_file 과 token_provider 중 정확히 하나를 받습니다"
            )
        if self.token_file is not None and not str(self.token_file).strip():
            raise ValueError("OidcAuth.token_file 이 비어 있습니다")
        if self.token_provider is not None and not callable(self.token_provider):
            raise ValueError("OidcAuth.token_provider 는 호출할 수 있는 값이어야 합니다")

    def __repr__(self) -> str:
        # 출처만 — provider 가 클로저로 토큰을 쥐고 있어도 값은 노출하지 않는다.
        src = (
            f"token_file={self.token_file!r}"
            if self.token_file is not None
            else "token_provider=<callable>"
        )
        return f"OidcAuth({src})"


def read_token(cfg: OidcAuth) -> str:
    """토큰을 **지금** 가져온다. 파일이면 다시 읽고, provider 면 다시 호출한다.

    **에러 문구에 토큰 값을 싣지 않는다.** provider 예외는 종류만 남기고 사슬을 끊는다
    (`from None`) — 문구에 토큰이 들어 있을 수 있고, `__cause__` 로 남기면 노트북 traceback
    이 그대로 찍는다. `sts.read_token` 과 같은 규율이다.
    """
    if cfg.token_file is not None:
        try:
            raw = Path(cfg.token_file).read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError) as e:
            # `UnicodeDecodeError` 는 `OSError` 가 아니라 `ValueError` 라 따로 잡아야 한다 —
            # 안 잡으면 이 예외가 `read_token` 을 그대로 빠져나가고, 호출부(`_oidc_maybe_refetch`·
            # `_relogin`)의 `except NexusAuthError` 가 못 받아 **사용자 요청이 죽는다**.
            # 정상 토큰은 ASCII JWT 라 드물지만 kubelet 중간 쓰기·손상 파일에서 실제로 난다.
            # 문구에는 `e.__class__.__name__` 만 싣는다 — `str(e)` 는 문제 바이트를 노출한다.
            raise NexusAuthError(
                f"OIDC 토큰 파일을 읽지 못했습니다: {cfg.token_file} "
                f"({e.__class__.__name__}) — projected 볼륨의 마운트 경로와 audience 를 "
                "확인하십시오"
            ) from None
        token = raw.strip()
        if not token:
            raise NexusAuthError(f"OIDC 토큰 파일이 비어 있습니다: {cfg.token_file}")
        return token

    try:
        token = cfg.token_provider()  # type: ignore[misc]
    except Exception as e:
        raise NexusAuthError(
            f"OidcAuth.token_provider 가 예외를 던졌습니다 ({e.__class__.__name__})"
        ) from None
    if not isinstance(token, str) or not token.strip():
        raise NexusAuthError(
            "OidcAuth.token_provider 가 빈 값이나 문자열이 아닌 값을 돌려줬습니다"
        )
    return token.strip()
