from __future__ import annotations
import os
import warnings

from nexus._types import (
    IngestResult,
    NexusAuthError,
    NexusBatchError,
    NexusCasError,
    NexusError,
    NexusIngestError,
    NexusSchemaJobPending,
    NexusValidationError,
    NexusVersionJobPending,
)
from nexus import _retry
from nexus import settings as _settings
from nexus._version import __version__
from nexus.cas import CasClient
from nexus.client import NexusClient
from nexus.dataset import AnnotationSession, Dataset
from nexus.imageinfo import ImageInfo, image_info
from nexus.probe import probe
from nexus.sample import CasRef, Sample
from nexus.sts import CasSts
from nexus.oidc import OidcAuth
from nexus.upload import upload, rewrite_thumbnails
from nexus.annotated import AnnotatedSample, SampleSummary
from nexus.group import LabelGroup, LabelContainer, RawGroup
from nexus.instance import Instance
from nexus.meta import Meta
from nexus.labels import (
    Label,
    Detection,
    Keypoint2D,
    Keypoint3D,
    Classification,
    ScalarValue,
    VectorValue,
    Cuboid3D,
    Polygon,
    Polyline,
    Mask,
)

_client: NexusClient | None = None
_cas: CasClient | None = None


def _apply_insecure_tls(verify: "bool | str") -> None:
    """`verify=False`일 때 urllib3의 요청마다 나오는 경고를 억제하고 **한 번만** 우리 경고를 낸다.

    요청마다 나오는 경고는 대량 적재 로그를 뒤덮어 실제 문제를 가린다. 그렇다고 조용히
    넘기면 "이 연결은 중간자 공격을 탐지하지 못한다"는 사실이 어디에도 남지 않으므로,
    접속 시점에 한 번은 반드시 알린다.
    """
    if verify is not False:
        return
    warnings.warn(
        "TLS 인증서 검증이 꺼져 있습니다(verify=False) — 이 연결은 중간자 공격을 탐지하지 "
        "못합니다. 사내 프록시가 원인이라면 검증을 끄는 대신 루트 CA 번들 경로를 주는 쪽을 "
        "권합니다: nx.connect(verify='/path/to/corp-ca.pem') 또는 설정 파일의 \"verify\" 키.",
        stacklevel=3,
    )
    try:  # urllib3 2.x / 1.x 모두 대응
        from urllib3.exceptions import InsecureRequestWarning

        warnings.simplefilter("ignore", InsecureRequestWarning)
    except Exception:  # pragma: no cover - urllib3 내부 구조가 바뀐 경우
        pass


def connect(
    nexus_url: str | None = None,
    email: str | None = None,
    password: str | None = None,
    cas_url: str | None = None,
    cas_key_id: str | None = None,
    cas_secret: str | None = None,
    timeout: "float | tuple[float, float]" = (10.0, 120.0),
    verify: "bool | str | None" = None,
    settings_path: "str | None" = None,
    save_cas_credentials: bool = False,
    robot_token: "str | None" = None,
    cas_sts: "CasSts | None" = None,
    oidc: "OidcAuth | None" = None,
    retry_timeout: "float | None" = None,
) -> NexusClient:
    """nexus/CAS에 접속한다. 인자를 하나도 안 주면 환경변수와 설정 파일에서 해소한다.

    값의 우선순위는 **인자 > 환경변수 > 설정 파일**(`~/.int2nexus/settings.json`,
    `NEXUS_SETTINGS`로 경로 변경 가능). 설정 파일에 다 적어두면 `nx.connect()` 한 줄이면 된다.

    - `retry_timeout`: 서버 부재(연결 실패·502·503·504)를 첫 실패부터 기다리는 초. 기본 120, 환경변수 NEXUS_RETRY_TIMEOUT, 설정 파일 키 retry_timeout. 0 이면 끈다(0.1.19).

    `verify`는 TLS 인증서 검증 —`True`(기본), `False`(검증 끔), 또는 **CA 번들 경로**.
    사내 TLS 검사 장비 때문에 SSL 에러가 난다면 검증을 끄는 대신 사내 루트 CA 경로를 주는
    쪽을 권한다. nexus와 CAS 양쪽 세션에 같은 값이 적용된다.

    **CAS 자격증명은 nexus 가 발급하지 않는다**(0.1.14~). 이전 판은 자격증명이 비어 있으면
    `POST /api/v1/auth/cas-credentials` 로 자동 발급을 받았는데, 그 경로가 걷히면서 없어졌다.
    정적 키는 인자·환경변수(`CAS_KEY_ID`/`CAS_SECRET`)·설정 파일 중 하나로 직접 주고, 스스로
    갱신이 필요하면 아래 STS 모드를 쓴다.

    **자격증명이 없어도 접속 자체는 된다** — 서명 없는 요청은 `CasClient._signed_headers` 가
    그대로 통과시킨다. CAS 가 익명 읽기를 허용하는 배포에서는 그대로 읽히고, 아니면 첫 CAS
    호출이 403 이다. 어느 쪽인지 접속 시점에는 알 수 없으므로 `warnings.warn` 으로 알린다.

    **403 에 자격증명을 갈아 끼우지 않는다.** 갱신할 곳이 없기 때문이다 — 만료·폐기된 정적
    키는 새 값을 주어야 풀리고, 에러 메시지가 그것을 짚는다(`cas.py` 의
    `_MANUAL_CREDENTIAL_DEAD_HINT`). 스스로 갱신하는 것은 STS 모드뿐이다.

    `save_cas_credentials` 인자는 시그니처 호환을 위해 남아 있지만 아무 일도 하지 않는다 —
    켜 두면 경고한다.

    **로봇 토큰**(`robot_token=` 또는 `NEXUS_ROBOT_TOKEN`)을 주면 로그인 경로를 타지 않고
    그 값이 그대로 Bearer 로 실린다. `email`/`password` 는 필요 없다. 관리자가
    `POST /api/v1/admin/robots/{user_id}/tokens` 로 발급한 `nxr_` 로 시작하는 값이고,
    워크로드는 보통 sealed-secret 에서 환경변수로 받는다.

    **로봇 토큰은 설정 파일에 저장하지 않는다.** 그 값은 배포가 주입하는 것이지 이 라이브러리가
    관리할 것이 아니고, 파일에 남기면 sealed-secret 으로 관리하는 의미가 사라진다.

    로봇 토큰에는 갱신도 재로그인도 없다. `401` 은 그대로 올라간다 — 폐기·만료·계정 정지
    중 무엇이든 관리자가 조작해야 풀리고, 재시도해 봐야 같은 값을 다시 보내는 것뿐이다.

    **외부 IdP(OIDC) 토큰으로 nexus 에 인증** 하려면 `oidc=OidcAuth(token_file=...)` 또는
    `OidcAuth(token_provider=...)` 를 준다. 서버가 등록된 발급자의 OIDC 토큰을 요청마다 직접
    Bearer 로 받고(교환 없이), 만료가 가까우면 SDK 가 출처에서 다시 가져온다 — 파일이면
    (kubelet 이 갈아 끼우는 projected SA 토큰) 다시 읽고, provider 면(Keycloak 등) 다시
    부른다. `CasSts` 와 대칭이되 nexus 축의 인증이다(`cas_sts` 는 CAS 축이라 함께 쓸 수 있다).
    **`email`/`password`·`robot_token` 과는 함께 줄 수 없다** — 셋 다 로그인을 대체한다.
    이 경로에는 `refresh`·비밀번호 변경·계정 삭제가 없다(서버가 OIDC 요청에 403). 접속 시점에
    토큰을 한 번 가져오며, 출처가 틀렸으면 여기서 `NexusAuthError` 로 실패한다.

    **CAS 임시 자격증명(STS)** 은 `cas_sts=CasSts(token_file=...)` 또는
    `CasSts(token_provider=...)` 로 켠다(0.1.12+). 그러면 cas 의 `AssumeRoleWithWebIdentity` 로
    임시 자격증명을 받아 쓰고 만료 전에 스스로 갱신한다. **정적 키 경로 전체를 건너뛴다** —
    `cas_key_id`/`cas_secret` 인자와 함께 주면 `ValueError`, 환경변수·설정 파일의 정적 키는 경고를
    내고 무시한다. 접속 시점에 한 번 받아
    토큰 파일·매핑이 틀렸으면 여기서 `NexusCasError` 로 실패한다(cas 에 닿지 않으면 재시도 뒤).
    """
    # bucket은 전역 기본값을 두지 않는다 — nx.upload(paths, bucket=...)에서 호출별로 지정.
    # timeout=(connect, read) — read를 넉넉히(배치 적재가 오래 걸릴 수 있음). 없으면 정체가 무한 hang.
    global _client, _cas

    if cas_sts is not None and (cas_key_id or cas_secret):
        raise ValueError(
            "cas_sts 와 cas_key_id/cas_secret 인자는 함께 줄 수 없습니다 — STS 모드는 CAS 자격증명을 "
            "스스로 받습니다"
        )

    # 인자 > 환경변수. 설정 파일은 보지 않는다 — 로봇 토큰은 배포가 주입하는 값이고,
    # 파일에 남기면 sealed-secret 으로 관리하는 의미가 사라진다.
    resolved_robot_token = robot_token or os.environ.get("NEXUS_ROBOT_TOKEN") or None

    # **OIDC 는 nexus 축의 인증이다.** `cas_sts`(CAS 축)와는 함께 쓸 수 있지만,
    # `robot_token`·`email`/`password` 와는 상호배타다 — 셋 다 로그인을 대체하므로 함께
    # 주면 어느 쪽이 이기는지가 모호하다. `cas_sts` + 정적 키를 막는 것과 같은 규율이다.
    if oidc is not None:
        if resolved_robot_token is not None:
            raise ValueError(
                "oidc 와 robot_token(NEXUS_ROBOT_TOKEN 포함)은 함께 줄 수 없습니다 — "
                "둘 다 로그인을 대체합니다"
            )
        if email is not None or password is not None:
            raise ValueError(
                "oidc 와 email/password 는 함께 줄 수 없습니다 — OIDC 는 로그인 경로를 "
                "타지 않습니다"
            )

    # OIDC 도 로봇 토큰처럼 로그인 경로를 타지 않으므로 email/password 를 필수에서 뺀다.
    require_login = resolved_robot_token is None and oidc is None

    cfg = _settings.resolve(
        path=settings_path,
        require_login=require_login,
        nexus_url=nexus_url,
        email=email,
        password=password,
        cas_url=cas_url,
        cas_key_id=cas_key_id,
        cas_secret=cas_secret,
        verify=verify,
        retry_timeout=retry_timeout,
    )
    # 네트워크 호출 전에 해석한다 — 값이 틀렸으면 로그인도 하기 전에 ValueError 다.
    retry_timeout = _retry.resolve_timeout(cfg["retry_timeout"])
    _apply_insecure_tls(cfg["verify"])

    client = NexusClient(
        cfg["nexus_url"], cfg["email"] or "", cfg["password"] or "",
        timeout=timeout, verify=cfg["verify"],
        robot_token=resolved_robot_token,
        oidc=oidc,
        retry_timeout=retry_timeout,
    )
    _client = client

    # settings.resolve()가 인자·환경변수·설정 파일에서 읽어 채워둔 값(셋 다 없으면
    # CasClient 기본값과 같은 "cas-default"). **0.1.14 부터 이 값을 갈아 끼우는 경로가
    # 없다** — 자동 발급 응답의 region 이 채워 주던 자리였다. 기본 region 이 아닌 배포는
    # 반드시 직접 준다. 틀리면 서명이 맞지 않아 계속 403 이다.
    region = cfg["cas_region"]

    # **STS 분기보다 먼저 본다.** 이 인자는 두 모드 모두에서 아무 일도 하지 않으므로
    # STS 뒤에 두면 STS 사용자만 경고를 못 받는다.
    if save_cas_credentials:
        # 발급이 없어졌으므로 저장할 것도 없다. 인자는 시그니처 호환을 위해 남겨 두되
        # 조용히 무시하지 않는다 — 이 값을 켜 둔 코드는 "자격증명이 파일에 남는다"를
        # 전제하고 있으므로, 그 전제가 깨진 것을 그 자리에서 알려야 한다.
        warnings.warn(
            "save_cas_credentials 는 더 이상 아무 일도 하지 않습니다(0.1.14~) — nexus 가 "
            "CAS 자격증명을 발급하지 않으므로 저장할 값이 생기지 않습니다. 정적 키는 "
            "CAS_KEY_ID/CAS_SECRET 이나 설정 파일로 직접 주십시오.",
            stacklevel=2,
        )

    if cas_sts is not None:
        # **정적 키 분기 전체를 건너뛴다**(지금은 한쪽 키 경고뿐이다). 환경변수나
        # 설정 파일에 키가 있으면 조용히 버리지 않고 알린다 — 0.1.9 이하 설치본은 설정 파일에 자동
        # 발급 키가 깔려 있을 수 있어 매 접속 보일 수 있고, 그것은 의도다.
        if cfg["cas_key_id"] or cfg["cas_secret"]:
            warnings.warn(
                "CAS_KEY_ID/CAS_SECRET(환경변수 또는 설정 파일)을 무시하고 cas_sts 로 받은 임시 "
                "자격증명을 씁니다",
                stacklevel=2,
            )
        cas = CasClient(cfg["cas_url"], region=region, verify=cfg["verify"], sts=cas_sts,
                        retry_timeout=retry_timeout)
        try:
            cas.ensure_credentials()
        except Exception:
            # 실패한 접속이 _client/_cas 중 하나라도 남기면 upload/probe 가 재접속하지 않고
            # 옛 클라이언트로 죽는다(probe는 _cas를 직접 본다) — 둘 다 지운다.
            _client = None
            _cas = None
            raise
        _cas = cas
        return client

    if not cfg["cas_key_id"] or not cfg["cas_secret"]:
        # **nexus 에 발급을 요청하지 않는다**(0.1.14~). 이전 판은 자격증명이 비어 있으면
        # `POST /api/v1/auth/cas-credentials` 로 자동 발급을 받았는데, nexus 가 그 경로를
        # 걷으면서 부를 곳이 없어졌다. 자격증명 없이도 접속 자체는 되고(서명 없는 요청은
        # `CasClient._signed_headers` 가 그대로 통과시킨다), CAS 가 익명 읽기를 허용하지
        # 않는 배포에서는 첫 CAS 호출이 403 이다. 그래서 여기서 조용히 넘어가지 않고
        # 무엇을 해야 하는지 적어 경고한다.
        if cfg["cas_key_id"] or cfg["cas_secret"]:
            # 한쪽만 있으면 어차피 서명에 못 쓴다 — 둘 다 있어야 `_signed_headers` 가
            # 서명한다. 반쪽이 있다는 것은 설정이 끊긴 것이므로 따로 짚는다.
            warnings.warn(
                "CAS_KEY_ID/CAS_SECRET 중 한쪽만 설정되어 있어 그것만으로는 서명할 수 "
                "없습니다 — CAS 요청이 서명 없이 나갑니다.",
                stacklevel=2,
            )
        else:
            warnings.warn(
                "CAS 자격증명이 없어 CAS 요청이 서명 없이 나갑니다. nexus 는 CAS 자격증명을 "
                "발급하지 않습니다(0.1.14~) — CAS 운영자에게 받은 키를 CAS_KEY_ID/CAS_SECRET "
                "으로 주거나, 스스로 갱신하는 STS 모드를 쓰십시오"
                "(`nx.connect(cas_sts=CasSts(token_file=...))`).",
                stacklevel=2,
            )

    _cas = CasClient(
        cfg["cas_url"], cfg["cas_key_id"], cfg["cas_secret"],
        region=region, verify=cfg["verify"], retry_timeout=retry_timeout,
    )
    return client


def _auto_connect() -> NexusClient:
    global _client
    if _client is None:
        connect()
    return _client  # type: ignore[return-value]


def cas_client() -> CasClient:
    """`nx.connect()` 로 접속된 `CasClient` 를 돌려준다(접속 전이면 자동 접속, 0.1.18).

    `nx.Dataset(client, cas, ...)` 을 직접 만들거나 `Dataset.open(..., cas=)` 에 넘길 때 쓴다.
    비공개 전역 `nexus._cas` 를 읽는 대신 이 함수를 쓴다 — 전역의 이름은 약속이 아니다.
    """
    if _client is None:
        _auto_connect()
    if _cas is None:
        raise NexusError("CAS 클라이언트가 없습니다 — nx.connect() 가 실패했거나 끝나지 않았습니다")
    return _cas


def list_datasets(
    *,
    q: str | None = None,
    name: str | None = None,
    description: str | None = None,
    tags: "str | list[str] | None" = None,
    sort: str | None = None,
    order: str | None = None,
    favorite: bool = False,
    mine: bool = False,
    unowned: bool = False,
    limit: int | None = None,
    cursor: str | None = None,
    name_exact: str | None = None,
    client: NexusClient | None = None,
) -> list[dict]:
    """등록된 dataset 목록(dict 리스트).

    각 항목: `dataset_id`/`name`/`description`/`tags`/`created_at`와 **`versions`**(버전 문자열
    목록, 예 `['v0','v1']`), **`is_favorite`**(내 즐겨찾기 여부). 옵션 — `name`/`description`: 부분
    검색(ILIKE), `name_exact`: 이름 정확히 일치(nexus-server `0.1.26` 부터, 그 이하 서버는 무시),
    `tags`: 하나라도 포함(ANY), `sort`: "name"|"created_at"(기본), `order`: "asc"/"desc"(기본
    desc), `favorite`: True면 내 즐겨찾기만, `mine`: 내가 담당인 것만, `unowned`: 담당자가 없는 것만.

    **`limit`을 안 주면 커서를 자동으로 순회해 전체를 모은다**(서버 0.1.7부터 한 응답에
    기본 100개까지만 실린다). `limit`에 숫자를 주면 그 개수만큼 한 페이지만 반환한다.
    """
    c = client or _auto_connect()
    return c.list_datasets(
        q=q, name=name, description=description, tags=tags, sort=sort, order=order,
        favorite=favorite, mine=mine, unowned=unowned, limit=limit, cursor=cursor,
        name_exact=name_exact,
    )


def favorite_groups(*, client: NexusClient | None = None) -> dict:
    """내 즐겨찾기를 웹 사이드바와 같은 그룹 구성으로 돌려준다.

    `{"groups": [{"group_id", "name", "datasets": [...]}], "unassigned": [...]}` — `datasets`·
    `unassigned` 의 항목은 `list_datasets()` 와 같은 dataset dict 이고, 그룹 안 순서는 사이드바와 같다.

    소속·그룹 안 순서는 즐겨찾기 목록(`list_datasets(favorite=True)`)의 각 행이 가진
    `favorite_group_id`·`favorite_position` 으로 정한다(서버 레이아웃과 같은 `position`, `dataset_id` 순).
    그룹 이름·그룹 순서·빈 그룹은 그 앞에 읽은 그룹 구성(`NexusClient.get_favorite_layout`)에서 온다. 그래서
    즐겨찾기 하나가 두 그룹에 나오지 않는다. 그룹 구성을 읽은 뒤에 만든 그룹에 든 dataset 은 맨 뒤의
    `name: None` 그룹으로 담는다(그런 그룹이 여럿이면 그들끼리의 순서는 정해져 있지 않다). 그 사이에 지워진 그룹은 옛
    이름의 빈 그룹으로 남고(안의 즐겨찾기는 서버가 미분류로 옮겨 `unassigned` 에 나온다), 이름을 바꾼 그룹은 옛 이름이다. 즐겨찾기가 1,000 개
    (한 페이지)를 넘으면 목록을 여러 페이지로 읽으므로, 그 사이에 사이드바 순서를 바꾸면 그룹 안 순서가 섞일 수 있고 페이지
    경계의 dataset 이 지워지면 서버 목록이 일찍 끝나 뒤 항목이 빠질 수 있다.
    """
    c = client or _auto_connect()
    layout = c.get_favorite_layout()
    rows = c.list_datasets(favorite=True)

    by_group: dict = {}
    for d in rows:
        by_group.setdefault(d.get("favorite_group_id"), []).append(d)
    for members in by_group.values():
        members.sort(key=lambda d: (d.get("favorite_position") is None, d.get("favorite_position") or 0,
                                    str(d["dataset_id"])))

    groups = [
        {"group_id": g["group_id"], "name": g["name"], "datasets": by_group.pop(g["group_id"], [])}
        for g in layout["groups"]
    ]
    unassigned = by_group.pop(None, [])
    groups += [{"group_id": gid, "name": None, "datasets": members} for gid, members in by_group.items()]
    return {"groups": groups, "unassigned": unassigned}


def dataset_exists(name: str, *, client: NexusClient | None = None) -> bool:
    """그 이름의 dataset 이 있으면 `True`. 이름이 **정확히 같은** 것만 센다
    (`Dataset.load_or_create` 와 같은 조회)."""
    from nexus.dataset import _find_dataset_by_name

    c = client or _auto_connect()
    return _find_dataset_by_name(c, name) is not None


def delete_dataset(
    name: str,
    *,
    confirm_dataset_name: str,
    delete_cas: "bool | None" = None,
    client: NexusClient | None = None,
) -> dict:
    """이름이 `name` 인 dataset 을 버전째 지운다(nexus-server 0.1.26 부터). `confirm_dataset_name` 에 같은
    이름을 한 번 더 적는다 — 서버가 현재 이름과 정확히 같은지 본다(되돌릴 수 없는 삭제의 확인이다).

    - `name` 의 dataset 이 없으면 `NexusError(status_code=404)`.
    - `delete_cas`: `ds.delete()` 와 같다 — `True` 면 미참조 샘플 에셋(이미지·썸네일)도 지우고, `None`(기본)이면
      대화형으로 묻는다(비대화형이면 보존). seal 스냅샷은 서버 0.1.31~ 값과 무관하게 지운다.
    - sealed 버전이 있으면 `role=admin` 만 지운다(아니면 409, 아무것도 지우지 않는다).
    - 도중에 실패했거나 응답을 못 받았으면 다시 부르면 남은 버전부터 지운다(다 지워졌으면 404).
    - 반환: `{dataset_id, versions_deleted, samples_deleted, cas_objects_deleted}`."""
    from nexus.dataset import _find_dataset_by_name, _resolve_delete_cas

    c = client or _auto_connect()
    found = _find_dataset_by_name(c, name)
    if found is None:
        raise NexusError(f"dataset '{name}' 이 없습니다", status_code=404)
    return c.delete_dataset(
        found["dataset_id"],
        confirm_dataset_name=confirm_dataset_name,
        delete_cas=_resolve_delete_cas(delete_cas, f"dataset '{name}'"),
    )


def annotation_session(
    session_id: str, *, client: NexusClient | None = None
) -> "AnnotationSession":
    """`session_id`로 기존 세션을 다시 잡는다.

    세션은 파이썬 프로세스와 무관하게 서버에 남아 있다 — 스크립트를 껐다 켜도, 다른
    사람이 만든 세션이어도 id만 있으면 이어받을 수 있다. 목록에서 고르려면
    :func:`annotation_sessions` 를 쓴다.
    """
    c = client or _auto_connect()
    return AnnotationSession(c, c.get_annotation_session(session_id))


def annotation_sessions(
    *,
    status: "str | None" = None,
    dataset_id: str | None = None,
    mine: bool = False,
    limit: int | None = None,
    client: NexusClient | None = None,
) -> "list[AnnotationSession]":
    """**전역** CVAT 편집 세션 목록 — dataset·버전을 가로질러 "지금 진행 중인 것"을 모은다.

    기본은 진행 중인 것만(`status="active"` = creating+open)이다. 이력까지 보려면 `"all"`,
    특정 상태만 보려면 `"open"`/`"closed"`/`"failed"`. `mine=True`면 내가 만든 것만.

    각 항목은 `dataset_name`/`version`/`sample_count`를 이미 담고 있어 추가 조회 없이
    목록을 그릴 수 있다. 다만 `has_unimported_changes`는 목록에서 항상 `None`이다
    (세션마다 CVAT 호출이 필요해서) — 필요하면 `.refresh()` 후 읽을 것.
    """
    c = client or _auto_connect()
    rows = c.list_annotation_sessions(
        dataset_id=dataset_id, status=status, mine=mine, limit=limit
    )
    return [AnnotationSession(c, r) for r in rows]


def recompute_dataset_schema(
    name: str, *, wait: float = 3600.0, client: NexusClient | None = None
) -> list[dict]:
    """이름이 `name` 인 dataset 의 **모든 버전**에서 스키마를 다시 만든다(nexus-server 0.1.37~).

    재계산 API 는 버전 단위라 이 함수가 버전마다 요청을 보내 줄에 모두 세운 뒤, 합쳐 `wait` 초(기본 3600)까지
    기다린다. 서버는 파드마다 재계산을 하나씩 돌리므로 버전이 많으면 오래 걸린다. 판 올림 전부터 있던 버전
    (`schema_state: "legacy"`)의 섞인 그룹을 걷어 내는 데 쓴다. sealed 버전은 seal 스냅샷으로 계산한다.

    반환은 버전 목록 순서의 `[{"version", "status", "state", "job_id", "result", "error", "code"}]` — `state` 는
    `done`·`failed`·`queued`/`running`(`wait` 안에 안 끝남, 서버에서 계속 돈다)·`rejected`(요청이 4xx 로 거절됨 — 준비 중·실패 버전은 `code="version_preparing"`, 스냅샷 없는 sealed 버전은 `code` 없음, 목록을 읽은 뒤
    지워진 버전은 404)·`gone`(기다리는 동안 버전이 지워져 작업도 함께 지워짐)·`unknown`(요청이 nexus 5xx·재시도를 다 쓴
    429·작업 없는 2xx 로 끝났거나 요청·작업 조회가 다시 보내도 닿지 않아 끝을 모름 — `job_id` 가 있으면 그것으로, 없으면 다시 불러 확인). 버전 하나의 거절·실패는 다른 버전을 멈추지 않는다. 옛 서버·인증·권한 오류(401·403)는
    아직 세운 작업이 하나도 없을 때 올리고(앞 버전들의 거절 줄은 함께 버려진다), 세운 작업이 있으면 그 버전을
    `rejected` 로 남겨 이미 받은 `job_id` 를 지킨다. 기다리는 동안의 오류는 409(작업 실패) 말고는 401·403 도 `unknown` 이다. dataset 이 없으면
    `NexusError(status_code=404)`.

    0.1.37 에서 seal 한 버전은 seal 이 관측을 정확한 값으로 바꿔 두었으므로(`schema_state: "exact"`) 다시 계산해도
    달라지지 않는다 — 판 올림 전부터 있던 버전(`legacy`)과 draft 를 고칠 때 쓴다."""
    import time as _time

    import requests

    from nexus.client import SCHEMA_JOBS_UNSUPPORTED, _check_wait
    from nexus.dataset import _find_dataset_by_name

    _check_wait(wait)
    c = client or _auto_connect()
    found = _find_dataset_by_name(c, name)
    if found is None:
        raise NexusError(f"dataset '{name}' 이 없습니다", status_code=404)
    dataset_id = found["dataset_id"]
    started = _time.monotonic()
    report: list[dict] = []
    for v in c.list_versions(dataset_id):
        row = {
            "version": v.get("version"),
            "status": v.get("status"),
            "state": None,
            "job_id": None,
            "result": None,
            "error": None,
            "code": None,
        }
        try:
            job = c.request_schema_recompute(dataset_id, v["version"])
        except NexusError as e:
            # 옛 서버·인증·권한(401·403)은 모든 버전에 같으므로 아직 세운 작업이 하나도 없으면 올린다. 이미 세운 작업이
            # 있으면(도중에 토큰이 끝나거나 강등됨) 올리면 그 `job_id` 를 잃으므로 그 줄에 남기고 계속한다. 그 밖(목록 뒤
            # 삭제 404, 400, 준비 중 409, 다시 보내도 안 된 5xx)도 그 줄에 남긴다.
            global_failure = e.status_code in (401, 403) or e.code == SCHEMA_JOBS_UNSUPPORTED
            if global_failure and not any(r.get("job_id") for r in report):
                raise
            definite = e.status_code is not None and 400 <= e.status_code < 500 and e.status_code != 429
            if global_failure or definite:
                # 4xx(400·404·409, 게이트웨이의 405·413·422 등)는 확실한 거절이라 작업이 서지 않았다.
                row.update(state="rejected", error=e.server_message or str(e), code=e.code)
            else:
                # 재시도를 다 쓴 429(지나가는 거절 — 다시 부르면 된다), nexus 의 5xx(다시 보내지 않는다), 다시 보내도 안 된
                # 502·503·504, 작업 없는 2xx(`SCHEMA_JOB_MISSING`) — 거절로 적으면 고칠 수 없는 버전처럼 읽힌다.
                row.update(state="unknown", error=e.server_message or str(e), code=e.code)
        except requests.RequestException as e:
            # `retry_timeout` 안에 닿지 못했다. 서버가 작업을 세웠는지 알 수 없다(`job_id` 없음 — 다시 부르면 그 작업이 온다).
            row.update(state="unknown", error=str(e))
        else:
            row.update(state=job.get("state"), job_id=job.get("job_id"))
            row["_job"] = job
        report.append(row)
    for row in report:
        job = row.pop("_job", None)
        if job is None:
            continue
        left = max(0.0, wait - (_time.monotonic() - started))
        try:
            job = c.wait_schema_job(job, wait=left)
        except NexusSchemaJobPending as e:
            job = e.job
        except NexusError as e:
            # 작업 실패는 409 로 온다. 그 밖(조회가 다시 보내도 안 된 5xx, 지워진 작업 404)은 그 작업의 끝을 모르는 것이라
            # 보고 전체를 버리지 않고 `unknown` 으로 남긴다 — `job_id` 로 다시 확인한다.
            if e.status_code == 404:
                # 작업 행은 버전을 ON DELETE CASCADE 로 참조한다 — 기다리는 동안 버전이 지워졌다(다시 확인할 것이 없다).
                row.update(state="gone", error=e.server_message or str(e))
                continue
            failed = e.status_code == 409
            row.update(state="failed" if failed else "unknown", error=(e.server_message if failed else None) or str(e))
            continue
        except requests.RequestException as e:
            row.update(state="unknown", error=str(e))
            continue
        row.update(state=job.get("state"), result=job.get("result"), error=job.get("error"))
    return report


__all__ = [
    "__version__",
    "connect",
    "cas_client",
    "list_datasets",
    "favorite_groups",
    "dataset_exists",
    "delete_dataset",
    "recompute_dataset_schema",
    "annotation_sessions",
    "annotation_session",
    "Dataset",
    "AnnotationSession",
    "NexusClient",
    "CasClient",
    "Sample",
    "CasRef",
    "CasSts",
    "OidcAuth",
    "upload",
    "rewrite_thumbnails",
    "probe",
    "image_info",
    "ImageInfo",
    "IngestResult",
    "NexusError",
    "NexusAuthError",
    "NexusCasError",
    "NexusIngestError",
    "NexusBatchError",
    "AnnotatedSample",
    "SampleSummary",
    "LabelGroup",
    "LabelContainer",
    "RawGroup",
    "Instance",
    "Meta",
    "Label",
    "Detection",
    "Keypoint2D",
    "Keypoint3D",
    "Classification",
    "ScalarValue",
    "VectorValue",
    "Cuboid3D",
    "Polygon",
    "Polyline",
    "Mask",
    "NexusValidationError",
    "NexusVersionJobPending",
    "NexusSchemaJobPending",
]
