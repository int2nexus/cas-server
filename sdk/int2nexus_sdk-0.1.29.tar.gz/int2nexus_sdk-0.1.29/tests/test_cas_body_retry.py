"""`CasClient.get` 이 본문을 받다가 끊긴 응답을 다시 받는지, 실패 문구가 실패 종류를 가르는지 — 진짜 소켓 위에서.

urllib3 의 재시도는 응답 헤더까지만 덮어, 헤더를 받은 뒤 본문이 끊기면 한 번에 실패했다(2026-11-12 스물한째 리포트 5 절).
가짜 서버는 `Content-Length` 를 다 채우지 않고 연결을 닫는다 — requests 는 그것을 `ChunkedEncodingError`(IncompleteRead)로 올린다.
"""
from __future__ import annotations

import http.server
import threading
from contextlib import contextmanager

import pytest
import requests
from urllib3.exceptions import NewConnectionError, ProtocolError, ReadTimeoutError

from nexus import _retry
from nexus.cas import CasClient

_BODY = bytes(i % 251 for i in range(200_000))


def _handler(cut_first: int):
    """처음 `cut_first` 번은 본문 절반만 보내고 끊고, 그 뒤로는 다 보낸다. 받은 GET 수를 `hits` 에 센다."""

    class H(http.server.BaseHTTPRequestHandler):
        hits = 0

        def do_GET(self):  # noqa: N802
            type(self).hits += 1
            self.send_response(200)
            self.send_header("Content-Length", str(len(_BODY)))
            self.send_header("Content-Type", "application/octet-stream")
            self.end_headers()
            if type(self).hits <= cut_first:
                self.wfile.write(_BODY[: len(_BODY) // 2])
                self.wfile.flush()
                self.close_connection = True
                return
            self.wfile.write(_BODY)

        def log_message(self, format, *args):  # noqa: A002
            pass

    return H


@contextmanager
def _serve(handler_cls):
    server = http.server.HTTPServer(("127.0.0.1", 0), handler_cls)
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    try:
        yield f"http://127.0.0.1:{server.server_address[1]}"
    finally:
        server.shutdown()
        server.server_close()
        t.join(timeout=5)


def test_본문_도중_끊기면_다시_받아_전체를_돌려준다(monkeypatch):
    monkeypatch.setattr("nexus.cas.time.sleep", lambda s: None)
    h = _handler(cut_first=2)
    with _serve(h) as url:
        c = CasClient(url, "k", "s", retry_timeout=30)
        assert c.get("b", "big.bin", timeout=5) == _BODY
    assert h.hits == 3


def test_예산이_0_이면_세_번까지만_다시_받는다(monkeypatch):
    monkeypatch.setattr("nexus.cas.time.sleep", lambda s: None)
    h = _handler(cut_first=10)
    with _serve(h) as url:
        c = CasClient(url, "k", "s", retry_timeout=0)
        with pytest.raises(requests.exceptions.ChunkedEncodingError) as ei:
            c.get("b", "big.bin", timeout=5)
    assert h.hits == 4  # 처음 한 번 + 다시 세 번
    assert _retry.is_body_interrupted(ei.value)
    assert "받는 도중 연결이 끊겼습니다" in _retry.describe_failure(ei.value, 5)


def test_실패_문구는_연결_실패와_읽기_시한과_본문_끊김을_가른다():
    conn = requests.exceptions.ConnectionError(
        type("M", (Exception,), {"reason": NewConnectionError(None, "refused")})()
    )
    assert _retry.describe_failure(conn).startswith("연결할 수 없습니다")
    assert not _retry.is_body_interrupted(conn)

    body_timeout = requests.exceptions.ConnectionError(ReadTimeoutError(None, None, "Read timed out."))
    assert _retry.is_body_interrupted(body_timeout)
    assert _retry.describe_failure(body_timeout, 30).startswith("응답이 30 초 넘게 멈춰")

    header_timeout = requests.exceptions.ReadTimeout("Read timed out.")
    assert not _retry.is_body_interrupted(header_timeout)
    assert _retry.describe_failure(header_timeout, 120).startswith("응답이 120 초 넘게 멈춰")

    cut = requests.exceptions.ChunkedEncodingError(ProtocolError("Connection broken: IncompleteRead"))
    assert _retry.is_body_interrupted(cut)
    assert _retry.describe_failure(cut).startswith("받는 도중 연결이 끊겼습니다")

    assert not _retry.is_body_interrupted(requests.exceptions.SSLError("bad cert"))
    assert _retry.describe_failure(requests.exceptions.SSLError("bad cert")).startswith("TLS")
