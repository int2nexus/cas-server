"""버전 스키마 재계산·지정 삭제(nexus-server 0.1.37 `POST .../schema/recompute`, `GET /api/v1/schema-jobs/{id}`,
`DELETE .../schema/{labels|components|meta-fields}`)."""

import pytest

import nexus as nx
from nexus._types import NexusError, NexusSchemaJobPending
from nexus.client import NexusClient
from nexus.dataset import Dataset

NEXUS = "http://nexus-test"
DS = "d1"
VER = f"{NEXUS}/datasets/{DS}/versions/v1"
RECOMPUTE = f"{VER}/schema/recompute"
JOB = f"{NEXUS}/api/v1/schema-jobs/s1"
NEW = {"X-Nexus-Version": "0.1.37"}
RESULT = {"conflicts": [], "replaced": True, "samples": 3}
# 경로가 없는 옛 nexus(0.1.20~0.1.36)의 404 — nexus 고유 헤더는 있고 판 헤더는 없다.
OLD_404 = {"X-Request-Id": "r0", "X-Nexus-Idempotency": "1"}


def job(state, job_id="s1", version="v1", **kw):
    return {"job_id": job_id, "dataset_id": DS, "version": version, "state": state, **kw}


@pytest.fixture
def sleeps(monkeypatch):
    out = []
    monkeypatch.setattr("nexus.client.time.sleep", lambda s: out.append(s))
    return out


@pytest.fixture
def client(requests_mock):
    requests_mock.post(f"{NEXUS}/api/v1/auth/login", json={"token": "tok"})
    return NexusClient(NEXUS, "u@x.com", "pw")


def accepted(requests_mock, url=RECOMPUTE, j=None):
    requests_mock.post(
        url,
        status_code=202,
        headers={"Location": "/api/v1/schema-jobs/s1", **NEW},
        json={"job": j or job("queued")},
    )


def test_recompute_polls_until_done_and_returns_job_with_result(requests_mock, client, sleeps):
    accepted(requests_mock)
    m = requests_mock.get(
        JOB, [{"json": job("queued")}, {"json": job("running")}, {"json": job("done", result=RESULT)}]
    )
    out = client.recompute_schema(DS, "v1")
    assert out["state"] == "done"
    assert out["result"] == RESULT
    assert m.call_count == 3
    assert sleeps == [2.0, 2.0]


def test_recompute_block_false_returns_accepted_job_without_polling(requests_mock, client, sleeps):
    accepted(requests_mock)
    m = requests_mock.get(JOB, json=job("done"))
    out = client.recompute_schema(DS, "v1", block=False)
    assert out == job("queued")
    assert m.call_count == 0


def test_recompute_failed_raises_409_with_job_error(requests_mock, client, sleeps):
    accepted(requests_mock)
    requests_mock.get(JOB, json=job("failed", error="database error"))
    with pytest.raises(NexusError) as e:
        client.recompute_schema(DS, "v1")
    assert e.value.status_code == 409
    assert e.value.server_message == "database error"


def test_recompute_timeout_raises_pending_with_job(requests_mock, client, sleeps):
    accepted(requests_mock)
    requests_mock.get(JOB, json=job("running"))
    with pytest.raises(NexusSchemaJobPending) as e:
        client.recompute_schema(DS, "v1", wait=5)
    assert e.value.job_id == "s1"
    assert e.value.job["state"] == "running"
    assert isinstance(e.value, NexusError)
    assert sum(sleeps) == pytest.approx(5)


def test_recompute_already_done_job_is_returned_without_sleep(requests_mock, client, sleeps):
    # 같은 버전에 막 끝난 작업이 있으면 서버는 그 작업을 준다(살아 있는 작업만 재사용하므로 드물다).
    accepted(requests_mock, j=job("done", result=RESULT))
    requests_mock.get(JOB, json=job("done", result=RESULT))
    assert client.recompute_schema(DS, "v1")["result"] == RESULT
    assert sleeps == []


def test_recompute_rejects_bad_wait(client):
    with pytest.raises(ValueError):
        client.recompute_schema(DS, "v1", wait=float("nan"))


def test_recompute_on_old_server_explains_minimum_version(requests_mock, client):
    # 옛 서버의 매칭 안 된 404 에는 판 헤더가 없다(인증 전에 끝난다).
    requests_mock.post(RECOMPUTE, status_code=404, json={"error": "not found"}, headers=OLD_404)
    with pytest.raises(NexusError) as e:
        client.recompute_schema(DS, "v1")
    assert e.value.status_code == 404
    assert "0.1.37" in str(e.value)
    assert [h.method for h in requests_mock.request_history] == ["POST", "POST"]  # 로그인과 요청뿐, 탐침 없음


def test_rolled_back_server_is_detected_even_if_new_version_was_remembered(requests_mock, client):
    requests_mock.get(VER, json={"version": "v1"}, headers=NEW)
    client.get_version(DS, "v1")
    requests_mock.post(RECOMPUTE, status_code=404, json={"error": "not found"}, headers=OLD_404)
    with pytest.raises(NexusError) as e:
        client.recompute_schema(DS, "v1")
    assert "0.1.37" in str(e.value)


def test_delete_schema_items_on_old_server_explains_minimum_version(requests_mock, client):
    requests_mock.delete(f"{VER}/schema/labels", status_code=404, json={"error": "not found"}, headers=OLD_404)
    with pytest.raises(NexusError) as e:
        client.delete_schema_items(DS, "v1", "labels", [{"group": "gt", "label": "car"}])
    assert "0.1.37" in str(e.value)


def test_failed_job_without_error_has_readable_message(requests_mock, client, sleeps):
    accepted(requests_mock)
    requests_mock.get(JOB, json=job("failed"))
    with pytest.raises(NexusError) as e:
        client.recompute_schema(DS, "v1")
    assert "None" not in str(e.value) and "사유 없음" in str(e.value)
    assert e.value.server_message is None


def test_only_recompute_is_safe_to_resend():
    from nexus._retry import is_safe

    assert is_safe("POST", "/datasets/d1/versions/v1/schema/recompute")
    # 지정 삭제는 다시 보내면 sealed 409·더 작은 수가 올 수 있어 다시 보내지 않는다.
    for kind in ("labels", "components", "meta-fields"):
        assert not is_safe("DELETE", f"/datasets/d1/versions/v1/schema/{kind}")
    assert not is_safe("DELETE", "/datasets/d1/versions/v1")


def test_recompute_404_on_new_server_is_passed_through(requests_mock, client):
    requests_mock.post(RECOMPUTE, status_code=404, json={"error": "version v1 not found"}, headers=NEW)
    probe = requests_mock.get(VER, status_code=404, headers=NEW)
    with pytest.raises(NexusError) as e:
        client.recompute_schema(DS, "v1")
    assert e.value.status_code == 404
    assert "0.1.37" not in str(e.value)
    assert probe.call_count == 0


def test_recompute_encodes_version_segment(requests_mock, client, sleeps):
    url = f"{NEXUS}/datasets/{DS}/versions/a%2Fb%23c/schema/recompute"
    accepted(requests_mock, url=url, j=job("done", result=RESULT))
    requests_mock.get(JOB, json=job("done", result=RESULT))
    client.recompute_schema(DS, "a/b#c")
    assert [h.url for h in requests_mock.request_history if h.method == "POST"][-1] == url


def test_get_schema_job(requests_mock, client):
    requests_mock.get(JOB, json=job("running"))
    assert client.get_schema_job("s1")["state"] == "running"


@pytest.mark.parametrize(
    "kind,path",
    [("labels", "labels"), ("components", "components"), ("meta_fields", "meta-fields")],
)
def test_delete_schema_items_sends_items_and_returns_count(requests_mock, client, kind, path):
    m = requests_mock.delete(f"{VER}/schema/{path}", json={"deleted": 2})
    items = [{"group": "gt", "label": "car"}]
    assert client.delete_schema_items(DS, "v1", kind, items) == 2
    assert m.last_request.json() == {"items": items}


def test_delete_schema_items_rejects_unknown_kind_and_empty_items(client):
    with pytest.raises(ValueError):
        client.delete_schema_items(DS, "v1", "groups", [{"group": "gt"}])
    with pytest.raises(ValueError):
        client.delete_schema_items(DS, "v1", "labels", [])
    with pytest.raises(ValueError):
        client.delete_schema_items(DS, "v1", "labels", (x for x in []))
    with pytest.raises(TypeError):
        client.delete_schema_items(DS, "v1", "labels", {"group": "gt", "label": "car"})


def test_delete_schema_items_accepts_any_iterable(requests_mock, client):
    m = requests_mock.delete(f"{VER}/schema/labels", json={"deleted": 1})
    client.delete_schema_items(DS, "v1", "labels", (i for i in [{"group": "gt", "label": "car"}]))
    assert m.last_request.json() == {"items": [{"group": "gt", "label": "car"}]}


def test_delete_schema_items_on_sealed_propagates_409(requests_mock, client):
    requests_mock.delete(f"{VER}/schema/labels", status_code=409, json={"error": "sealed"})
    with pytest.raises(NexusError) as e:
        client.delete_schema_items(DS, "v1", "labels", [{"group": "gt", "label": "car"}])
    assert e.value.status_code == 409


# ── Dataset 핸들 ─────────────────────────────────────────────────────────────


def test_dataset_methods_use_handle_dataset_and_version(requests_mock, client, sleeps):
    ds = Dataset(client, None, DS, "cars", "v1")
    accepted(requests_mock, j=job("done", result=RESULT))
    requests_mock.get(JOB, json=job("done", result=RESULT))
    assert ds.recompute_schema()["result"] == RESULT
    requests_mock.delete(f"{VER}/schema/components", json={"deleted": 1})
    assert ds.delete_schema_items("components", [{"group": "gt", "name": "bbox"}]) == 1


# ── dataset 의 모든 버전 ─────────────────────────────────────────────────────


def versions(requests_mock, rows):
    requests_mock.get(f"{NEXUS}/datasets", json=[{"dataset_id": DS, "name": "cars"}])
    requests_mock.get(f"{NEXUS}/datasets/{DS}/versions", json=rows)


def test_recompute_dataset_schema_runs_every_version_and_reports_each(requests_mock, client, sleeps):
    versions(
        requests_mock,
        [
            {"dataset_version_id": "a", "version": "v1", "status": "sealed"},
            {"dataset_version_id": "b", "version": "v2", "status": "draft"},
            {"dataset_version_id": "c", "version": "v3", "status": "preparing"},
        ],
    )
    accepted(requests_mock, url=RECOMPUTE, j=job("queued", job_id="s1"))
    requests_mock.post(
        f"{NEXUS}/datasets/{DS}/versions/v2/schema/recompute",
        status_code=202,
        headers=NEW,
        json={"job": job("queued", job_id="s2", version="v2")},
    )
    requests_mock.post(
        f"{NEXUS}/datasets/{DS}/versions/v3/schema/recompute",
        status_code=409,
        headers=NEW,
        json={"error": "버전이 준비 중입니다", "code": "version_preparing"},
    )
    requests_mock.get(JOB, [{"json": job("running")}, {"json": job("done", result=RESULT)}])
    requests_mock.get(
        f"{NEXUS}/api/v1/schema-jobs/s2",
        json=job("failed", job_id="s2", version="v2", error="database error"),
    )
    out = nx.recompute_dataset_schema("cars", client=client)
    by = {r["version"]: r for r in out}
    assert [r["version"] for r in out] == ["v1", "v2", "v3"]
    assert by["v1"]["state"] == "done" and by["v1"]["result"] == RESULT and by["v1"]["job_id"] == "s1"
    assert by["v1"]["status"] == "sealed"
    assert by["v2"]["state"] == "failed" and by["v2"]["error"] == "database error"
    assert by["v3"]["state"] == "rejected" and by["v3"]["job_id"] is None
    assert by["v3"]["code"] == "version_preparing"


def test_recompute_dataset_schema_leaves_unfinished_jobs_in_report(requests_mock, client, sleeps):
    versions(requests_mock, [{"dataset_version_id": "a", "version": "v1", "status": "draft"}])
    accepted(requests_mock)
    requests_mock.get(JOB, json=job("running"))
    out = nx.recompute_dataset_schema("cars", wait=4, client=client)
    assert out == [
        {"version": "v1", "status": "draft", "state": "running", "job_id": "s1", "result": None, "error": None, "code": None}
    ]


def test_recompute_dataset_schema_missing_dataset_is_404(requests_mock, client):
    requests_mock.get(f"{NEXUS}/datasets", json=[])
    with pytest.raises(NexusError) as e:
        nx.recompute_dataset_schema("cars", client=client)
    assert e.value.status_code == 404


def test_recompute_dataset_schema_stops_on_permission_error(requests_mock, client, sleeps):
    versions(requests_mock, [{"dataset_version_id": "a", "version": "v1", "status": "draft"}])
    requests_mock.post(RECOMPUTE, status_code=403, headers=NEW, json={"error": "forbidden"})
    with pytest.raises(NexusError) as e:
        nx.recompute_dataset_schema("cars", client=client)
    assert e.value.status_code == 403


def test_public_names():
    assert "recompute_dataset_schema" in nx.__all__
    assert "NexusSchemaJobPending" in nx.__all__


def test_recompute_dataset_schema_keeps_report_when_a_version_vanishes_or_poll_fails(requests_mock, client, sleeps):
    versions(
        requests_mock,
        [
            {"dataset_version_id": "a", "version": "v1", "status": "draft"},
            {"dataset_version_id": "b", "version": "v2", "status": "draft"},
            {"dataset_version_id": "c", "version": "v3", "status": "draft"},
        ],
    )
    accepted(requests_mock)
    requests_mock.post(
        f"{NEXUS}/datasets/{DS}/versions/v2/schema/recompute",
        status_code=404,
        headers=NEW,
        json={"error": "version v2 not found"},
    )
    requests_mock.post(
        f"{NEXUS}/datasets/{DS}/versions/v3/schema/recompute",
        status_code=202,
        headers=NEW,
        json={"job": job("queued", job_id="s3", version="v3")},
    )
    requests_mock.get(JOB, status_code=404, headers=NEW, json={"error": "schema job s1"})
    requests_mock.get(f"{NEXUS}/api/v1/schema-jobs/s3", json=job("done", job_id="s3", result=RESULT))
    by = {r["version"]: r for r in nx.recompute_dataset_schema("cars", client=client)}
    assert by["v1"]["state"] == "gone" and by["v1"]["job_id"] == "s1"
    assert by["v2"]["state"] == "rejected"
    assert by["v3"]["state"] == "done" and by["v3"]["result"] == RESULT


def test_recompute_dataset_schema_on_old_server_raises_once(requests_mock, client):
    requests_mock.get(f"{NEXUS}/datasets", json=[{"dataset_id": DS, "name": "cars"}])
    requests_mock.get(
        f"{NEXUS}/datasets/{DS}/versions",
        json=[{"version": "v1", "dataset_version_id": "a"}, {"version": "v2", "dataset_version_id": "b"}],
        headers={"X-Nexus-Version": "0.1.36"},
    )
    m = requests_mock.post(RECOMPUTE, status_code=404, json={"error": "not found"}, headers=OLD_404)
    with pytest.raises(NexusError) as e:
        nx.recompute_dataset_schema("cars", client=client)
    assert "0.1.37" in str(e.value)
    assert m.call_count == 1


def test_recompute_dataset_schema_keeps_going_after_5xx_and_network_errors(requests_mock, client, sleeps, monkeypatch):
    import requests as rq

    versions(
        requests_mock,
        [
            {"dataset_version_id": "a", "version": "v1", "status": "draft"},
            {"dataset_version_id": "b", "version": "v2", "status": "draft"},
            {"dataset_version_id": "c", "version": "v3", "status": "draft"},
        ],
    )
    accepted(requests_mock)
    requests_mock.post(
        f"{NEXUS}/datasets/{DS}/versions/v2/schema/recompute",
        status_code=500,
        headers={**NEW, "X-Request-Id": "r1"},
        json={"error": "database error"},
    )
    requests_mock.post(
        f"{NEXUS}/datasets/{DS}/versions/v3/schema/recompute",
        status_code=202,
        headers=NEW,
        json={"job": job("queued", job_id="s3", version="v3")},
    )
    requests_mock.get(JOB, exc=rq.ConnectionError("down"))
    requests_mock.get(f"{NEXUS}/api/v1/schema-jobs/s3", json=job("done", job_id="s3", result=RESULT))
    monkeypatch.setattr(client, "_retry_timeout", 0)
    by = {r["version"]: r for r in nx.recompute_dataset_schema("cars", client=client)}
    assert by["v1"]["state"] == "unknown" and by["v1"]["job_id"] == "s1"
    assert by["v2"]["state"] == "unknown" and by["v2"]["job_id"] is None
    assert by["v3"]["state"] == "done"


def test_recompute_dataset_schema_request_network_error_is_unknown(requests_mock, client, sleeps):
    import requests as rq

    client._retry_timeout = 0
    versions(requests_mock, [{"dataset_version_id": "a", "version": "v1", "status": "draft"}])
    requests_mock.post(RECOMPUTE, exc=rq.ConnectTimeout("no route"))
    out = nx.recompute_dataset_schema("cars", client=client)
    assert out[0]["state"] == "unknown" and out[0]["job_id"] is None


def test_recompute_dataset_schema_on_headerless_old_server_raises(requests_mock, client):
    # 0.1.28 이하는 어떤 응답에도 판 헤더가 없다 — 표지 값으로 옛 서버를 가른다.
    requests_mock.get(f"{NEXUS}/datasets", json=[{"dataset_id": DS, "name": "cars"}])
    requests_mock.get(f"{NEXUS}/datasets/{DS}/versions", json=[{"version": "v1", "dataset_version_id": "a"}])
    requests_mock.post(RECOMPUTE, status_code=404, json={"error": "not found"}, headers=OLD_404)
    with pytest.raises(NexusError) as e:
        nx.recompute_dataset_schema("cars", client=client)
    assert "0.1.37" in str(e.value)


def test_delete_on_old_server_message_reads_naturally(requests_mock, client):
    requests_mock.delete(f"{VER}/schema/labels", status_code=404, json={"error": "not found"}, headers=OLD_404)
    with pytest.raises(NexusError) as e:
        client.delete_schema_items(DS, "v1", "labels", [{"group": "gt", "label": "car"}])
    assert str(e.value).startswith("스키마 지정 삭제: 이 서버에 경로가 없습니다")


def test_recompute_dataset_schema_keeps_queued_job_ids_when_auth_fails_midway(requests_mock, client, sleeps):
    versions(
        requests_mock,
        [
            {"dataset_version_id": "a", "version": "v1", "status": "draft"},
            {"dataset_version_id": "b", "version": "v2", "status": "draft"},
        ],
    )
    accepted(requests_mock)
    requests_mock.post(
        f"{NEXUS}/datasets/{DS}/versions/v2/schema/recompute", status_code=403, headers=NEW, json={"error": "viewer"}
    )
    requests_mock.get(JOB, json=job("done", result=RESULT))
    by = {r["version"]: r for r in nx.recompute_dataset_schema("cars", client=client)}
    assert by["v1"]["state"] == "done" and by["v1"]["job_id"] == "s1"
    assert by["v2"]["state"] == "rejected"


def test_recompute_dataset_schema_failed_without_reason_still_has_error_text(requests_mock, client, sleeps):
    versions(requests_mock, [{"dataset_version_id": "a", "version": "v1", "status": "draft"}])
    accepted(requests_mock)
    requests_mock.get(JOB, json=job("failed"))
    out = nx.recompute_dataset_schema("cars", client=client)
    assert out[0]["state"] == "failed" and "사유 없음" in out[0]["error"]


def test_404_that_never_reached_nexus_is_passed_through(requests_mock, client):
    # 프록시·잘못된 base URL 의 404 에는 nexus 고유 헤더 X-Nexus-Idempotency 가 없다 — 판 안내로 바꾸지 않는다.
    requests_mock.post(RECOMPUTE, status_code=404, text="Not Found")
    with pytest.raises(NexusError) as e:
        client.recompute_schema(DS, "v1")
    assert e.value.status_code == 404 and e.value.code is None
    assert "0.1.37" not in str(e.value)


def test_old_server_error_keeps_server_body_and_sets_code(requests_mock, client):
    from nexus.client import SCHEMA_JOBS_UNSUPPORTED

    requests_mock.post(RECOMPUTE, status_code=404, json={"error": "not found"}, headers=OLD_404)
    with pytest.raises(NexusError) as e:
        client.recompute_schema(DS, "v1")
    assert e.value.code == SCHEMA_JOBS_UNSUPPORTED
    assert e.value.server_message == "not found"


def test_cancelled_job_is_terminal(requests_mock, client, sleeps):
    accepted(requests_mock)
    requests_mock.get(JOB, json=job("cancelled"))
    with pytest.raises(NexusError) as e:
        client.recompute_schema(DS, "v1")
    assert e.value.status_code == 409
    assert sleeps == []


def test_version_deleted_during_wait_is_404(requests_mock, client, sleeps):
    # 작업 행은 버전을 ON DELETE CASCADE 로 참조한다 — 버전이 지워지면 작업 조회가 404 다.
    accepted(requests_mock)
    requests_mock.get(JOB, [{"json": job("running")}, {"status_code": 404, "json": {"error": "schema job s1"}, "headers": NEW}])
    with pytest.raises(NexusError) as e:
        client.recompute_schema(DS, "v1")
    assert e.value.status_code == 404


def test_proxy_404_echoing_request_id_is_not_called_old_server(requests_mock, client):
    # Envoy·Istio 같은 게이트웨이는 X-Request-Id 를 돌려줄 수 있다 — nexus 고유 헤더가 없으면 판 안내로 바꾸지 않는다.
    requests_mock.post(RECOMPUTE, status_code=404, text="no route", headers={"X-Request-Id": "gw"})
    with pytest.raises(NexusError) as e:
        client.recompute_schema(DS, "v1")
    assert e.value.code is None


def test_old_server_non_json_body_keeps_text(requests_mock, client):
    requests_mock.post(RECOMPUTE, status_code=404, text="", headers=OLD_404)
    with pytest.raises(NexusError) as e:
        client.recompute_schema(DS, "v1")
    assert e.value.code == "schema_jobs_unsupported"


def test_wait_budget_counts_from_request_start(requests_mock, client, sleeps, monkeypatch):
    import nexus.client as cm

    clock = [0.0]
    monkeypatch.setattr(cm.time, "monotonic", lambda: clock[0])

    def slow_post(request, context):
        clock[0] += 4.0  # 요청 재전송 대기에 4 초를 썼다
        context.status_code = 202
        context.headers.update(NEW)
        return {"job": job("queued")}

    requests_mock.post(RECOMPUTE, json=slow_post)
    requests_mock.get(JOB, json=job("running"))
    with pytest.raises(NexusSchemaJobPending):
        client.recompute_schema(DS, "v1", wait=5)
    assert sum(sleeps) == pytest.approx(1)


def test_recompute_dataset_schema_other_4xx_is_rejected_not_unknown(requests_mock, client, sleeps):
    versions(requests_mock, [{"dataset_version_id": "a", "version": "v1", "status": "draft"}])
    requests_mock.post(RECOMPUTE, status_code=422, headers=NEW, json={"error": "bad"})
    out = nx.recompute_dataset_schema("cars", client=client)
    assert out[0]["state"] == "rejected" and out[0]["job_id"] is None


def _fake_clock(monkeypatch):
    """단조 시계와 sleep 을 함께 바꿔 끼운다 — sleep 한 만큼 시계가 간다(부재 재시도의 대기도 같은 시계를 본다)."""
    import nexus.client as cm

    clock = [0.0]
    monkeypatch.setattr(cm.time, "monotonic", lambda: clock[0])

    def sleep(s):
        clock[0] += s

    monkeypatch.setattr(cm.time, "sleep", sleep)
    return clock


def test_wait_stops_poll_retries_at_wait_budget_not_retry_timeout(requests_mock, client, monkeypatch):
    # 조회가 계속 닿지 않으면 종전에는 조회 하나가 `retry_timeout`(120 초)까지 다시 보내 `wait` 를 넘겼다.
    import requests as rq

    clock = _fake_clock(monkeypatch)
    accepted(requests_mock)
    requests_mock.get(JOB, exc=rq.ConnectionError("down"))
    with pytest.raises(NexusSchemaJobPending) as e:
        client.recompute_schema(DS, "v1", wait=5)
    assert e.value.job["state"] == "queued"  # 마지막으로 본 작업
    assert clock[0] == pytest.approx(5)


def test_wait_caps_poll_timeout_to_remaining_budget(requests_mock, client, sleeps):
    accepted(requests_mock)
    m = requests_mock.get(JOB, json=job("running"))
    with pytest.raises(NexusSchemaJobPending):
        client.recompute_schema(DS, "v1", wait=5)
    connect, read = m.request_history[0].timeout
    assert connect <= 5 and read <= 5


def test_wait_poll_error_before_budget_is_raised(requests_mock, client, sleeps, monkeypatch):
    import requests as rq

    monkeypatch.setattr(client, "_retry_timeout", 0)
    accepted(requests_mock)
    requests_mock.get(JOB, exc=rq.ConnectionError("down"))
    with pytest.raises(rq.ConnectionError):
        client.recompute_schema(DS, "v1", wait=600)


def test_accepted_response_without_job_is_nexus_error_not_keyerror(requests_mock, client):
    from nexus.client import SCHEMA_JOB_MISSING

    requests_mock.post(RECOMPUTE, status_code=202, headers=NEW, json={"ok": True})
    with pytest.raises(NexusError) as e:
        client.request_schema_recompute(DS, "v1")
    assert e.value.code == SCHEMA_JOB_MISSING and e.value.status_code == 202
    requests_mock.post(RECOMPUTE, status_code=200, text="<html>ok</html>")
    with pytest.raises(NexusError) as e:
        client.request_schema_recompute(DS, "v1")
    assert e.value.code == SCHEMA_JOB_MISSING


def test_recompute_dataset_schema_job_missing_is_unknown_and_keeps_other_versions(requests_mock, client, sleeps):
    versions(
        requests_mock,
        [
            {"dataset_version_id": "a", "version": "v1", "status": "draft"},
            {"dataset_version_id": "b", "version": "v2", "status": "draft"},
        ],
    )
    accepted(requests_mock)
    requests_mock.post(f"{NEXUS}/datasets/{DS}/versions/v2/schema/recompute", status_code=202, headers=NEW, json={})
    requests_mock.get(JOB, json=job("done", result=RESULT))
    by = {r["version"]: r for r in nx.recompute_dataset_schema("cars", client=client)}
    assert by["v1"]["state"] == "done" and by["v1"]["job_id"] == "s1"
    assert by["v2"]["state"] == "unknown" and by["v2"]["code"] == "schema_job_missing"


def test_recompute_dataset_schema_exhausted_429_is_unknown_not_rejected(requests_mock, client, sleeps):
    versions(requests_mock, [{"dataset_version_id": "a", "version": "v1", "status": "draft"}])
    requests_mock.post(RECOMPUTE, status_code=429, headers={**NEW, "Retry-After": "1"}, json={"error": "busy"})
    out = nx.recompute_dataset_schema("cars", client=client)
    assert out[0]["state"] == "unknown" and out[0]["job_id"] is None
    assert out[0]["error"] == "busy"


@pytest.mark.parametrize("timeout", [None, (10.0, None), 30.0])
def test_wait_poll_timeout_works_when_client_timeout_is_unbounded(requests_mock, sleeps, timeout):
    requests_mock.post(f"{NEXUS}/api/v1/auth/login", json={"token": "tok"})
    c = NexusClient(NEXUS, "u@x.com", "pw", timeout=timeout)
    accepted(requests_mock)
    m = requests_mock.get(JOB, json=job("running"))
    with pytest.raises(NexusSchemaJobPending):
        c.recompute_schema(DS, "v1", wait=5)
    t = m.request_history[0].timeout
    assert all(x is not None and x <= 5 for x in (t if isinstance(t, tuple) else (t,)))
