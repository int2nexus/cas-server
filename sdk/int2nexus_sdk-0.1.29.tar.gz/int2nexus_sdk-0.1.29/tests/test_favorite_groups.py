import pytest

import nexus as nx
from nexus.client import NexusClient

NEXUS = "http://nexus-test"
LAYOUT = f"{NEXUS}/api/v1/datasets/favorites/groups"


@pytest.fixture
def logged_in(requests_mock):
    requests_mock.post(f"{NEXUS}/api/v1/auth/login",
                       json={"token": "tok123", "user_id": 1, "email": "u@x.com"})
    return NexusClient(NEXUS, "u@x.com", "pass")


def test_get_favorite_layout_returns_server_body(logged_in, requests_mock):
    body = {"groups": [{"group_id": "g1", "name": "학습", "position": 0,
                        "dataset_ids": ["d1"]}],
            "unassigned": ["d2"]}
    requests_mock.get(LAYOUT, json=body)
    assert logged_in.get_favorite_layout() == body


def ds(dataset_id, name, group=None, pos=0):
    return {"dataset_id": dataset_id, "name": name, "is_favorite": True,
            "favorite_group_id": group, "favorite_position": pos}


def test_favorite_groups_orders_by_favorite_position_from_the_list(logged_in, requests_mock):
    requests_mock.get(LAYOUT, json={
        "groups": [
            {"group_id": "g1", "name": "학습", "position": 0, "dataset_ids": ["d3", "d1"]},
            {"group_id": "g2", "name": "빈 그룹", "position": 1, "dataset_ids": []},
        ],
        "unassigned": ["d2"],
    })
    # 목록 순서는 사이드바 순서와 다르다 — 결과는 favorite_position 순이어야 한다.
    requests_mock.get(f"{NEXUS}/datasets", json=[
        ds("d1", "a", "g1", 1),
        ds("d2", "b", None, 0),
        ds("d3", "c", "g1", 0),
    ])

    out = nx.favorite_groups(client=logged_in)

    assert requests_mock.last_request.qs["favorite"] == ["true"]
    assert [g["name"] for g in out["groups"]] == ["학습", "빈 그룹"]
    assert out["groups"][0]["group_id"] == "g1"
    assert [d["name"] for d in out["groups"][0]["datasets"]] == ["c", "a"]
    assert out["groups"][1]["datasets"] == []
    assert [d["name"] for d in out["unassigned"]] == ["b"]


def test_same_position_breaks_ties_by_dataset_id(logged_in, requests_mock):
    requests_mock.get(LAYOUT, json={"groups": [], "unassigned": ["a", "b"]})
    requests_mock.get(f"{NEXUS}/datasets", json=[ds("b", "B", None, 0), ds("a", "A", None, 0)])
    assert [d["name"] for d in nx.favorite_groups(client=logged_in)["unassigned"]] == ["A", "B"]


def test_membership_comes_from_the_list_not_the_layout(logged_in, requests_mock):
    """두 읽기 사이에 즐겨찾기가 풀리거나(gone), 새로 생기거나(new), 그룹을 옮겼으면(moved) 목록 쪽을 따른다 —
    빠지거나 두 번 나오거나 이름 없는 자리표시가 남지 않는다."""
    requests_mock.get(LAYOUT, json={
        "groups": [{"group_id": "g1", "name": "학습", "position": 0, "dataset_ids": ["gone", "moved"]}],
        "unassigned": [],
    })
    requests_mock.get(f"{NEXUS}/datasets", json=[ds("moved", "m", None, 0), ds("new", "n", None, 1)])

    out = nx.favorite_groups(client=logged_in)

    assert out["groups"][0]["datasets"] == []
    assert [d["name"] for d in out["unassigned"]] == ["m", "n"]
    for d in out["unassigned"]:
        assert "name" in d


def test_group_created_after_layout_read_is_kept_at_the_end(logged_in, requests_mock):
    requests_mock.get(LAYOUT, json={"groups": [{"group_id": "g1", "name": "학습", "position": 0,
                                                "dataset_ids": []}], "unassigned": []})
    requests_mock.get(f"{NEXUS}/datasets", json=[ds("d1", "a", "g9", 0)])
    out = nx.favorite_groups(client=logged_in)
    assert out["groups"][-1] == {"group_id": "g9", "name": None, "datasets": [ds("d1", "a", "g9", 0)]}


def test_favorite_groups_is_public():
    assert "favorite_groups" in nx.__all__
    assert callable(nx.favorite_groups)
