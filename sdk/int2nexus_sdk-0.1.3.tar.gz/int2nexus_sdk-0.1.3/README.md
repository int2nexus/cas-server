# int2nexus-sdk

Python SDK for uploading ML training data to a nexus-server instance. (배포명 `int2nexus-sdk`, import는 `import nexus`.)

## Installation

공개 인덱스(PEP 503)에서 설치:

```bash
pip install --extra-index-url https://int2nexus.github.io/cas-server/sdk/simple/ int2nexus-sdk
```

- 배포명은 `int2nexus-sdk`지만 **import는 `import nexus`** 다. (PyPI의 동명 `nexus-sdk`와 충돌을 피하려 배포명을 네임스페이스화했다.)
- `--extra-index-url`(≠ `--index-url`): `int2nexus-sdk`는 위 인덱스에서, 의존성은 PyPI에서 받습니다.
- 버전 고정: `int2nexus-sdk==0.1.3`.
- 개발 설치(소스): `pip install -e ./sdk`.

## Quick Start

### 설정 파일 (권장)

`~/.int2nexus/settings.json`에 한 번 적어두면 `nx.connect()` 한 줄로 접속된다. 스크립트에 자격증명을 적지 않아도 된다.

```json
{
  "nexus_url": "http://localhost:8090",
  "email": "user@example.com",
  "password": "secret",
  "cas_url": "http://localhost:8080",
  "cas_key_id": "mykey",
  "cas_secret": "mysecret"
}
```

```bash
mkdir -p ~/.int2nexus
$EDITOR ~/.int2nexus/settings.json
chmod 600 ~/.int2nexus/settings.json     # 비밀번호·CAS secret이 들어 있다
```

- **비밀번호와 CAS secret이 평문으로 저장된다.** POSIX에서는 권한이 느슨하면 SDK가 경고한다. **Windows에서는 `chmod`가 사실상 무의미**하므로 검사하지 않는다 — 파일 위치와 접근 권한은 사용자 책임이다.
- 경로를 바꾸려면 `NEXUS_SETTINGS=/path/to/settings.json` 또는 `nx.connect(settings_path=...)`.
- `cas_key_id`/`cas_secret`/`verify`는 선택. 모르는 키는 경고한다(오타 탐지).

### 값의 우선순위

**인자 > 환경변수 > 설정 파일.** 코드에 명시한 값이 항상 이기고, CI는 환경변수로 로컬 파일을 덮을 수 있다.

```bash
export NEXUS_URL=http://localhost:8090
export NEXUS_EMAIL=user@example.com
export NEXUS_PASSWORD=secret
export CAS_URL=http://localhost:8080
export CAS_KEY_ID=mykey
export CAS_SECRET=mysecret
export NEXUS_VERIFY=true          # 선택 — false 또는 CA 번들 경로
```

### 사내 프록시 · TLS 인증서 (`verify`)

사내 보안 장비가 TLS를 검사하면 `nx.connect()`가 SSL 인증서 에러로 죽는다. 세 가지 방법이 있고, **위쪽이 안전하다.**

```python
# 1) 사내 루트 CA를 신뢰 — 검증을 유지한 채 해결(권장)
nx.connect(verify="/path/to/corp-root-ca.pem")

# 2) 환경변수 — SDK 수정/재배포 없이 오늘 바로 쓸 수 있다(requests 기본 동작)
#    export REQUESTS_CA_BUNDLE=/path/to/corp-root-ca.pem

# 3) 검증 끄기 — 최후의 수단
nx.connect(verify=False)
```

설정 파일에 적어두면 매번 넘기지 않아도 된다:

```json
{ "verify": "C:/certs/corp-root-ca.pem" }
```

- `verify`는 **nexus와 CAS 양쪽 세션**에 적용된다. `nx.upload()`는 CAS로 직접 PUT하므로 한쪽만 고치면 업로드에서 같은 에러가 다시 난다.
- CAS를 `http://`로 접속한다면 `verify`는 아무 일도 하지 않는다(TLS가 없으므로).
- `verify=False`는 **그 연결의 중간자 공격 탐지를 포기하는 것**이다. 접속 시 한 번 경고가 뜨고, 이후 요청마다 나오는 urllib3 경고는 억제된다.

### Upload

Ingest is **2-phase**: first upload the image bytes to CAS (`nx.upload`), then register the
returned refs as samples (`nx.Sample` + `flush`).

```python
import nexus as nx

nx.connect()

# Phase 1 — data plane: upload local files to CAS (parallel, idempotent, +WebP thumbnail)
refs = nx.upload([img1, img2], bucket="kitti", prefix="images")   # {path: CasRef}

# Phase 2 — catalog: register the refs as samples
with nx.Dataset.load_or_create("kitti-mini", version="v1", tags=["3d_detection"]) as ds:
    for img_path, ann_path in pairs:
        ds.add(nx.Sample(
            image=refs[img_path],   # CAS ref (not a local path)
            annotation=ann_path,    # local JSON path / dict / URL
            split="train",
        ))
# flush() called automatically on __exit__
```

### Manual flush

```python
refs = nx.upload([img for img, _ in pairs], bucket="kitti", prefix="images")

ds = nx.Dataset.load_or_create("kitti-mini", version="v1")
ds.add([nx.Sample(image=refs[img], annotation=ann) for img, ann in pairs])

results = ds.flush(workers=8, strict=False)
failures = [r for r in results if not r.ok]
```

### Explicit connection

```python
nx.connect(
    nexus_url="http://localhost:8090",
    email="user@example.com",
    password="secret",
    cas_url="http://localhost:8080",
    cas_key_id="mykey",
    cas_secret="mysecret",
    verify=True,          # 선택 — False 또는 CA 번들 경로
)
```

설정이 부족하면 **무엇이 빠졌고 어디에 넣으면 되는지**를 담은 `NexusError`가 난다(예전에는 `KeyError`였다).

### 계정 관리

```python
client = nx.connect()

# 비밀번호 변경 — 현재 비밀번호를 재확인한다
client.change_password("old-pass", "new-pass-123")

# 계정 삭제 (되돌릴 수 없다)
result = client.delete_account("new-pass-123")
# {"deleted_user_id": 7, "released_datasets": 2, "warning": "…"}
```

- 비밀번호를 바꿔도 **이미 발급된 토큰은 만료(최대 24시간)까지 유효**하다. 변경은 새 로그인부터 적용된다.
- `~/.int2nexus/settings.json`에 비밀번호를 적어두었다면 **그 파일도 함께 고쳐야 한다.**
- `released_datasets`가 0이 아니면 그 dataset들은 주인이 없어져 **누구나 수정·삭제할 수 있는 상태**가 된다.
- 비밀번호를 잊어 로그인조차 못 하는 계정은 본인이 처리할 수 없다 — 운영자가 DB에서 재설정해야 한다.

### CVAT annotation 편집 세션

draft 버전의 샘플을 CVAT으로 보내 사람이 편집하고, 결과를 다시 draft에 당겨온다.
서버에 `[cvat]` 설정이 필요하다(없으면 503).

```python
ds = nx.Dataset.load_or_create("kitti-mini", version="v1")
ids = [r["sample_id"] for r in ds.list_samples(max_samples=50)]

ses = ds.create_annotation_session(ids)   # open 될 때까지 대기 후 반환
print(ses.url)                            # 작업자에게 넘길 CVAT 주소

summary = ses.pull()                      # CVAT → draft 반영 (멱등, 반복 호출 안전)
ses.close()                               # 잠금 해제 (CVAT project는 보존)

nx.annotation_sessions()                  # 전역 — 지금 진행 중인 세션
```

- **생성은 비동기다.** 수백 장이면 CVAT이 이미지를 받는 데만 몇 분 — `wait=False`로 받고
  나중에 `ses.wait_open(timeout=1800)` 해도 된다.
- `pull()`이 돌려주는 `warnings`를 버리지 말 것 — 반영되지 않은 것의 사유가 거기 있다.
- `delete()`는 CVAT project와 **아직 당겨오지 않은 편집까지** 지운다. `close()`와 다르다.
- 같은 샘플을 두 세션이 잡을 수 없다(409). sealed 버전에는 만들 수 없다(409).

### Fork a version

```python
ds = nx.Dataset.load_or_create("kitti-mini", version="v1.1", fork_from="v1.0")
```

### Link existing samples (without ingest)

```python
ds.link_samples(["0192f0a1-...", "0192f0a1-..."])
```

### Convert sealed version to DataFrame

```python
import nexus as nx

nx.connect()
ds = nx.Dataset.load_or_create("kitti-mini", version="v1")

# all samples
df = ds.to_df()

# train split only
df_train = ds.to_df(split="train")

# only samples that have a 'sedan' instance
df_sedan = ds.to_df(label="sedan")

# include instances column (downloads annotation NDJSON snapshot)
df_full = ds.to_df(labels=True)
# df_full["labels"] → list of instance dicts per row
```

## API Reference

### `nexus.connect(...)`

Authenticates against nexus-server and initializes the module-level client. 설정이 인자·환경변수·설정 파일(`~/.int2nexus/settings.json`) 중 어디에든 갖춰져 있으면 첫 API 호출이 자동으로 접속하므로, 명시적으로 부르지 않아도 된다.

```python
nx.connect(
    nexus_url=None, email=None, password=None,          # 없으면 환경변수 → 설정 파일 순으로 해소
    cas_url=None, cas_key_id=None, cas_secret=None,
    timeout=(10.0, 120.0),                              # (connect, read)
    verify=None,                                        # True(기본) | False | CA 번들 경로
    settings_path=None,                                 # 설정 파일 경로 직접 지정
)
```

### `nexus.upload(paths, bucket, prefix="", *, workers=8, verbose=True, strict=False)`

Uploads local files to CAS and returns `{path: CasRef}`, mapping each input path to its
`CasRef` (which carries `bucket` / `key` / `hash_hex` / `size` / `content_type`). This is
**phase 1** of ingest — pass the returned refs to `nx.Sample(image=...)`.

```python
refs = nx.upload(
    ["data/img001.png", "data/img002.png"],
    bucket="kitti",
    prefix="images",   # CAS key = "{prefix}/{filename}"
    workers=8,         # parallel uploads
)
ref = refs["data/img001.png"]   # CasRef(bucket="kitti", key="images/img001.png", ...)
```

- Uploads in parallel; idempotent — already-present objects (same key + content) are skipped.
- Generates a WebP 256px thumbnail alongside each image (best-effort).
- Re-using the same key with **different** content is a per-file failure (collision).
- Transient network/5xx errors are retried with backoff at the transport layer. Per-file failures are **isolated** (one bad file doesn't abort the batch) — only successes are returned. `strict=True` raises `NexusCasError` if any file failed; default `strict=False` warns. Re-running `nx.upload` with the same paths resumes (already-uploaded files are skipped).

### `nexus.probe(refs, *, workers=8, verbose=True, strict=False, max_header_bytes=65536)`

이미지를 다른 경로로 이미 CAS에 올렸고 로컬 사본이 없다면, `nx.upload` 없이 CAS 좌표만으로
샘플을 만들 수 있다. 다만 그대로 등록하면 `meta`에 `width`/`height`가 빠진다 — CAS는
객체의 픽셀 크기를 헤더로 알려주지 않기 때문이다.

`nx.probe`는 각 객체의 **앞부분 64KB만** 받아 이미지 헤더를 파싱해 크기를 채운다.

```python
import nexus as nx
from nexus import CasRef

nx.connect()

refs = [CasRef(bucket="incabin", key=f"lg_dataset/{name}") for name in names]
refs = nx.probe(refs, workers=8)          # 앞부분만 range GET

ds = nx.load_or_create("lg_dataset", version="v1")
ds.add([nx.Sample(r) for r in refs])
ds.flush()
```

- 입력은 `CasRef` 또는 `s3://`·`http(s)://` URL 문자열의 리스트, **또는 `nx.upload`가
  돌려주는 `{path: CasRef}` 그대로**다(`Sample.image`와 같은 CAS 참조 규칙 + dict는
  `.values()`로 풀어서 받는다 — dict를 직접 for로 돌리면 키인 로컬 경로 문자열이 나와
  거부되므로, 업로드 결과를 그대로 이어붙이려면 이 형태로 넘긴다).
- 반환은 **입력 순서를 보존한 리스트**다. 실패한 객체도 자리를 지키며 크기만 비어 있다.
- 이미 크기가 채워진 ref는 네트워크를 타지 않는다. 같은 리스트로 다시 호출해 실패분만
  재시도해도 된다.
- CAS가 Range 요청을 지원하지 않아도 동작한다 — 앞부분만 읽고 연결을 끊는다.
- `max_header_bytes`(기본 64KB): 객체 앞부분에서 받아올 바이트 수. 헤더가 유난히 뒤에
  있는 포맷(예: 특정 TIFF)이거나 "이미지 헤더를 읽지 못했습니다" 경고가 뜨면 이 값을
  올려본다. 1 미만은 `ValueError` — Range 헤더가 애초에 성립하지 않는다.
- `strict`(기본 `False`): `False`면 실패를 `RuntimeWarning`으로 모아 경고하고 계속
  진행한다(실패한 항목은 원본 ref 그대로, width/height는 `None`). `True`면 하나라도
  실패했을 때 `NexusCasError`를 던진다 — 크기 누락을 절대 허용하지 않는 파이프라인에.

크기를 못 구하면 `meta`에 `width`/`height` 키를 **넣지 않는다**. 0을 적으면 크기 facet의
range가 `min:0`으로 오염되고, CVAT 세션이 그 값으로 정규화 좌표를 계산해 좌표가 망가진다.
키가 없으면 집계에서 조용히 제외되고, CVAT 세션 생성은 명확한 에러로 거부된다.

**로컬 파일이 있다면 network를 탈 이유가 없다.** 같은 파서를 직접 부르면 된다.

```python
info = nx.image_info(path.read_bytes())   # width/height/mime/channels, 헤더만 읽음
ref = CasRef(bucket="incabin", key=key, width=info.width, height=info.height)
```

### 이미 적재된 샘플의 크기 보정 — `ds.backfill_dims()`

`nx.probe`가 생기기 전에 등록된 샘플은 `meta.width`/`meta.height`가 `0`으로 들어가 있다.
`0`은 크기 facet의 range를 `min:0`으로 오염시키고, CVAT에서는 세션 검증을 통과한 뒤
export 단계에서 해당 인스턴스가 조용히 빠지게 만든다.

```python
ds = nx.load_or_create("lg_dataset", version="v1")

report = ds.backfill_dims(dry_run=True)   # 대상 규모와 실제 측정 가능 건수 확인
report = ds.backfill_dims(workers=8)      # 적용
print(report)   # {'scanned': 12000, 'targeted': 840, 'measured': 838, 'applied': 838, 'rejected': [...]}
```

- 대상은 `meta.width`/`height` 중 **적어도 한 축이** 없거나, `null`이거나, 0 이하인 샘플이다. 두 축 모두 0보다 큰 값이 있는 샘플은 건드리지 않는다.
- `dry_run=True`도 **실제로 측정까지** 한다. 쓰기만 건너뛴다.
- image asset이 없거나 헤더를 읽지 못한 샘플은 건너뛰고 `measured`에서 빠진다.
- 서버는 **축(width/height) 단위로** 기록된 값을 절대 덮어쓰지 않는다 — 한쪽 축만 기록되어 있어도 그 축은 그대로 두고 반대쪽만 채운다. 값이 존재하지만 숫자가 아니면(문자열·bool 등) fail-closed로 "기록됨" 취급해 역시 손대지 않는다. 채울 축이 하나도 없는 샘플을 보내면 `rejected`에 사유와 함께 담겨 돌아온다.
- sealed 버전의 샘플도 보정된다 — `samples.meta`는 seal이 얼리는 대상이 아니고, 애초에 그 `0`은 측정된 값이 아니라 SDK가 지어낸 자리표시자였다.

### `nexus.Sample`

```python
nx.Sample(
    image=ref,                       # CAS ref ONLY: a CasRef (from nx.upload) or s3://·http(s):// URL
    annotation="data/ann001.json",  # local JSON path / dict (inline GT) / URL
    assets={"depth": depth_ref},     # optional extra assets, {role: ref} — same rules as image
    split="train",                  # optional
    tags=["rainy", "night"],        # optional
)
```

`image` and every value in `assets` accept **CAS refs only** — a `CasRef` returned by
`nx.upload`, or an `s3://bucket/key` / `http(s)://…` URL. **Local file paths raise `ValueError`**
— upload them with `nx.upload` first. For URL refs the SDK uses a CAS HEAD to retrieve metadata.
`"image"` is a reserved key in `assets` (raises `ValueError`) — use the `image=` parameter instead.
`annotation` still accepts a local JSON path, a dict (inline GT), or a URL.

### `nexus.Dataset.load_or_create(name, version, ...)`

Finds an existing dataset+version by name or creates it. Idempotent.

```python
nx.Dataset.load_or_create(
    name: str,
    version: str,
    tags: list[str] | None = None,       # dataset tags, applied on create
    description: str | None = None,
    fork_from: str | None = None,        # version to fork from on create
)
```

### `Dataset.link_samples(sample_ids)`

Links already-ingested samples to this version without re-ingesting them.

### `Dataset.flush(workers=4, strict=False, verbose=True, batch_size=256)`

Prepares the registration payloads from the queued samples' refs (no upload — uploads happen
earlier in `nx.upload`), then sends them to the server's `/ingest/batch` endpoint in chunks of
`batch_size`. Returns `list[IngestResult]`.

- `strict=True` raises `NexusBatchError` on first failure; `error.failures` contains the failed results.
- `strict=False` (default) records failures in results and continues.
- **Permission failures (401/403) always raise `NexusError`, regardless of `strict`.** They mean the
  account cannot write to this dataset at all, so every item fails for the same reason — swallowing
  them would let a CI job ingest nothing and still exit 0. `Dataset.patch_annotations` behaves the same.

### `Dataset.to_df(split=None, label=None, labels=False, workers=4)`

Downloads manifest metadata and pages through the paginated `/manifest/samples` endpoint, returning a `pandas.DataFrame`. Requires a **sealed** version (raises `NexusError` on draft).

| Column | Description |
|--------|-------------|
| `sample_id` | UUID v7 string |
| `split` | `train` / `val` / `test` / `None` |
| `image_cas_url` | Direct CAS URL for the image |
| `image_hash_hex` | BLAKE3 hash |
| `image_size` | bytes |
| `labels` | `list[dict]` of instances (only when `labels=True`) |

### `nexus.IngestResult`

```python
@dataclass
class IngestResult:
    ok: bool
    sample: Sample | None
    sample_id: str | None  # set on success
    error: str | None      # set on failure
```

## Error Handling

| Exception | Trigger |
|---|---|
| `NexusAuthError` | Login failure or token expired |
| `NexusCasError` | CAS upload/HEAD failure |
| `NexusIngestError` | Server ingest failure (4xx/5xx) |
| `NexusBatchError` | `strict=True` and one or more samples failed |

## Development

```bash
pip install -e "./sdk[dev]"
pytest sdk/tests/ -v
```
