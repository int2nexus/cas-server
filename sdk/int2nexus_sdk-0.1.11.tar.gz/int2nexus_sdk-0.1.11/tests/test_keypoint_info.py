"""`ds.set_keypoint_info()` — 정적 골격 정의 일괄 설정 래퍼.

래퍼가 지는 책임은 셋뿐이다: 인자를 서버 계약대로 옮기고, `confirm=True`를 실제 개수로
바꾸고, 나머지는 서버에 맡긴다. 모양 검증은 **서버가 한다** — 여기서 한 벌 더 하면 두
규칙이 갈라지는 날 SDK 를 통과한 값이 서버에서 400 이 나거나 그 반대가 된다.
"""

from unittest.mock import MagicMock

from nexus.dataset import Dataset


WHOLE = "BKP_Landmark_Whole_Keypoints"


def _ds(client):
    return Dataset(client, MagicMock(), "d1", "kitti", "v1")


def _info():
    return {WHOLE: {"labels": ["hip", "neck", "head"], "edges": [[0, 1, 2]]}}


def test_passes_dataset_version_and_payload_through():
    client = MagicMock()
    client.set_keypoint_info.return_value = {"updated": 3, "skipped_non_object_meta": 0}

    out = _ds(client).set_keypoint_info(_info())

    client.set_keypoint_info.assert_called_once_with(
        "d1", "v1", _info(), filter=None, confirm=None
    )
    assert out["updated"] == 3


def test_filter_is_forwarded():
    client = MagicMock()
    client.set_keypoint_info.return_value = {"updated": 1, "skipped_non_object_meta": 0}
    flt = {"tags": ["train"]}

    _ds(client).set_keypoint_info(_info(), filter=flt)

    assert client.set_keypoint_info.call_args.kwargs["filter"] == flt


def test_confirm_true_counts_first_and_sends_that_number():
    """`confirm=True`는 개수를 세어 채운다.

    서버 409 메시지에서 숫자를 뽑는 방법도 있지만 그것은 문구가 바뀌는 날 조용히 멈춘다.
    개수 조회는 정식 API 라 그런 식으로 깨지지 않는다.
    """
    client = MagicMock()
    client.count_samples.return_value = (48213, True)
    client.set_keypoint_info.return_value = {"updated": 48213, "skipped_non_object_meta": 0}

    _ds(client).set_keypoint_info(_info(), confirm=True)

    # 상한이 걸린 개수(10,000)를 confirm 으로 보내면 서버가 409 로 되받는다 — exact 여야 한다.
    assert client.count_samples.call_args.kwargs["exact"] is True
    assert client.set_keypoint_info.call_args.kwargs["confirm"] == 48213


def test_confirm_true_counts_the_same_filter_it_writes():
    """개수와 쓰기가 다른 집합을 보면 confirm 이 의미를 잃는다."""
    client = MagicMock()
    client.count_samples.return_value = (12, True)
    client.set_keypoint_info.return_value = {"updated": 12, "skipped_non_object_meta": 0}
    flt = {"split": "train"}

    _ds(client).set_keypoint_info(_info(), filter=flt, confirm=True)

    assert client.count_samples.call_args.args[2] == flt
    assert client.set_keypoint_info.call_args.kwargs["filter"] == flt


def test_an_explicit_number_is_sent_as_is_without_counting():
    """정확한 수를 이미 아는 자동화는 왕복을 한 번 아낀다."""
    client = MagicMock()
    client.set_keypoint_info.return_value = {"updated": 500, "skipped_non_object_meta": 0}

    _ds(client).set_keypoint_info(_info(), confirm=500)

    client.count_samples.assert_not_called()
    assert client.set_keypoint_info.call_args.kwargs["confirm"] == 500


def test_confirm_false_means_no_confirmation_not_a_count_of_zero():
    """`False`가 `0`으로 새어 나가면 서버가 '대상이 0건이 아니다'로 409를 낸다."""
    client = MagicMock()
    client.set_keypoint_info.return_value = {"updated": 1, "skipped_non_object_meta": 0}

    _ds(client).set_keypoint_info(_info(), confirm=False)

    client.count_samples.assert_not_called()
    assert client.set_keypoint_info.call_args.kwargs["confirm"] is None


def test_skipped_non_object_meta_is_returned_untouched():
    """0이 아니면 그 샘플들의 meta가 깨져 있다는 뜻이다 — 삼키면 알 방법이 없다."""
    client = MagicMock()
    client.set_keypoint_info.return_value = {"updated": 9, "skipped_non_object_meta": 2}

    out = _ds(client).set_keypoint_info(_info())

    assert out["skipped_non_object_meta"] == 2


# ── 클라이언트 계층: 실제 HTTP 모양 ─────────────────────────────────────────
#
# 위 테스트들은 클라이언트를 대역으로 두므로 경로·바디·쿼리가 맞는지는 못 본다.
# 여기서 그것만 붙든다.

import pytest
from nexus.client import NexusClient

NEXUS = "http://nexus-test"


@pytest.fixture
def logged_in(requests_mock):
    requests_mock.post(
        f"{NEXUS}/api/v1/auth/login",
        json={"token": "tok", "user_id": 1, "email": "u@x.com"},
    )
    return NexusClient(NEXUS, "u@x.com", "pass")


def test_client_sends_filter_and_keypoint_info_in_the_body(logged_in, requests_mock):
    url = f"{NEXUS}/datasets/d1/versions/v1/samples/keypoint-info"
    requests_mock.patch(url, json={"updated": 3, "skipped_non_object_meta": 0})

    logged_in.set_keypoint_info("d1", "v1", _info(), filter={"split": "train"})

    body = requests_mock.last_request.json()
    assert body == {"filter": {"split": "train"}, "keypoint_info": _info()}
    # confirm 이 없으면 쿼리에 붙지 않는다 — `confirm=` 빈 값은 서버 파싱을 깨뜨린다.
    assert "confirm" not in requests_mock.last_request.qs


def test_client_omits_filter_as_an_empty_object_not_null(logged_in, requests_mock):
    """서버의 `filter`는 `SampleExplorerRequest`라 `null`이면 역직렬화가 실패한다."""
    url = f"{NEXUS}/datasets/d1/versions/v1/samples/keypoint-info"
    requests_mock.patch(url, json={"updated": 1, "skipped_non_object_meta": 0})

    logged_in.set_keypoint_info("d1", "v1", _info())

    assert requests_mock.last_request.json()["filter"] == {}


def test_client_puts_confirm_in_the_query_string(logged_in, requests_mock):
    url = f"{NEXUS}/datasets/d1/versions/v1/samples/keypoint-info"
    requests_mock.patch(url, json={"updated": 42, "skipped_non_object_meta": 0})

    logged_in.set_keypoint_info("d1", "v1", _info(), confirm=42)

    assert requests_mock.last_request.qs["confirm"] == ["42"]


def test_count_samples_returns_the_pair_and_asks_for_exact(logged_in, requests_mock):
    url = f"{NEXUS}/datasets/d1/versions/v1/samples/explorer/count"
    requests_mock.post(url, json={"count": 48213, "exact": True})

    n, exact = logged_in.count_samples("d1", "v1", {"split": "train"}, exact=True)

    assert (n, exact) == (48213, True)
    assert requests_mock.last_request.qs["exact"] == ["true"]
    assert requests_mock.last_request.json() == {"split": "train"}
