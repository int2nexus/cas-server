"""로봇 토큰으로 연결하기.

로봇 토큰은 로그인 경로를 타지 않고 값이 그대로 Bearer 로 실린다. 갱신도 재로그인도
없다 — 서버가 로봇 토큰의 `refresh` 를 403 으로 막고, 401 의 진짜 이유(폐기·만료·계정
정지)를 재로그인 실패로 덮어써서 가리면 안 된다.
"""

import pytest
import requests

from nexus.client import NexusClient
from nexus._types import NexusError


BASE = "http://nx"
TOKEN = "nxr_58WInNMvByZ0QSetTENPeD-irfMymBwG276j7yGLLZE"


def test_robot_token_skips_login(requests_mock):
    requests_mock.get(f"{BASE}/datasets", json=[])

    c = NexusClient(BASE, "", "", robot_token=TOKEN)

    assert not any(
        h.path == "/api/v1/auth/login" for h in requests_mock.request_history
    ), "로봇 토큰인데 로그인을 시도했다"
    assert c._session.headers["Authorization"] == f"Bearer {TOKEN}"


def test_robot_token_is_sent_on_requests(requests_mock):
    requests_mock.get(f"{BASE}/datasets", json=[])

    c = NexusClient(BASE, "", "", robot_token=TOKEN)
    c._get("/datasets")

    sent = requests_mock.request_history[-1]
    assert sent.headers["Authorization"] == f"Bearer {TOKEN}"


def test_robot_token_does_not_relogin_on_401(requests_mock):
    """401 이 그대로 올라와야 한다.

    재로그인하면 두 가지가 나빠진다 — 같은 값을 다시 보내는 헛일이고, 401 의 진짜 이유가
    "재로그인 실패" 로 덮인다. 관리자가 조작해야 풀리는 상태라 클라이언트가 할 일이 없다.
    """
    requests_mock.get(f"{BASE}/datasets", status_code=401, json={"error": "unauthorized"})
    login = requests_mock.post(f"{BASE}/api/v1/auth/login", json={"token": "x"})

    c = NexusClient(BASE, "", "", robot_token=TOKEN)
    with pytest.raises(NexusError) as e:
        c._get("/datasets")

    assert e.value.status_code == 401
    assert not login.called, "로봇 토큰인데 재로그인을 시도했다"


def test_robot_token_does_not_refresh(requests_mock):
    """갱신도 없다. `_token_exp` 가 `None` 이라 `_maybe_refresh` 가 즉시 돌아간다 —
    로봇 토큰은 JWT 가 아니므로 만료를 파싱할 수 없다."""
    requests_mock.get(f"{BASE}/datasets", json=[])
    refresh = requests_mock.post(f"{BASE}/api/v1/auth/refresh", json={"token": "x"})

    c = NexusClient(BASE, "", "", robot_token=TOKEN)
    assert c._token_exp is None
    c._get("/datasets")

    assert not refresh.called, "로봇 토큰인데 갱신을 시도했다"


def test_password_client_still_logs_in(requests_mock):
    """사람 경로가 그대로여야 한다 — 로봇 분기가 넓게 걸리면 기존 사용자가 전부 죽는다."""
    login = requests_mock.post(
        f"{BASE}/api/v1/auth/login",
        json={"token": "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOjEsImV4cCI6OTk5OTk5OTk5OX0.sig"},
    )

    NexusClient(BASE, "u@example.com", "pw")

    assert login.called, "사람 계정인데 로그인을 안 했다"


def test_connect_reads_robot_token_from_env(monkeypatch, requests_mock, tmp_path):
    """`NEXUS_ROBOT_TOKEN` 으로도 받는다 — 워크로드는 보통 sealed-secret 에서 환경변수로 받는다."""
    import nexus

    monkeypatch.setenv("NEXUS_ROBOT_TOKEN", TOKEN)
    monkeypatch.setenv("NEXUS_URL", BASE)
    monkeypatch.setenv("CAS_URL", "http://cas")
    monkeypatch.setenv("CAS_KEY_ID", "CASK-x")
    monkeypatch.setenv("CAS_SECRET", "sk-x")
    monkeypatch.setenv("NEXUS_SETTINGS", str(tmp_path / "settings.json"))

    nx = nexus.connect()

    assert nx._session.headers["Authorization"] == f"Bearer {TOKEN}"
    assert not any(
        h.path == "/api/v1/auth/login" for h in requests_mock.request_history
    ), "환경변수 로봇 토큰인데 로그인을 시도했다"


def test_robot_token_is_never_written_to_settings(monkeypatch, requests_mock, tmp_path):
    """설정 파일에 남기면 sealed-secret 으로 관리하는 의미가 사라진다."""
    import nexus

    settings = tmp_path / "settings.json"
    monkeypatch.setenv("NEXUS_URL", BASE)
    monkeypatch.setenv("CAS_URL", "http://cas")
    monkeypatch.setenv("CAS_KEY_ID", "CASK-x")
    monkeypatch.setenv("CAS_SECRET", "sk-x")
    monkeypatch.setenv("NEXUS_SETTINGS", str(settings))

    nexus.connect(robot_token=TOKEN)

    if settings.exists():
        assert TOKEN not in settings.read_text(encoding="utf-8"), "설정 파일에 로봇 토큰이 남았다"
