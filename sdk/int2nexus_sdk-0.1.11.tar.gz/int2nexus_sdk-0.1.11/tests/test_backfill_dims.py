import sys
from unittest.mock import MagicMock

from nexus.dataset import Dataset
from nexus.sample import CasRef


def _ds(client, cas):
    return Dataset(client, cas, "d1", "kitti", "v1")


def _sample(sid, meta, image_url="http://cas/kitti/images/a.png"):
    d = {"sample_id": sid, "split": None, "tags": []}
    if meta is not None:
        d["meta"] = meta
    if image_url is not None:
        d["image_url"] = image_url
    return d


def _patch_probe(monkeypatch, dims=(1920, 1080)):
    """probe 대역 — 넘어온 ref에 dims를 채워 돌려준다. 호출 인자를 기록한다.

    `nexus/__init__.py`가 `from nexus.probe import probe`로 패키지 최상위에 같은 이름을
    올려두기 때문에(`nx.probe(...)` 편의 진입점), `nexus` 패키지의 `probe` 속성은 서브모듈이
    아니라 그 함수로 덮여 있다. 문자열 경로 `"nexus.probe.probe"`로 monkeypatch하면 pytest의
    dotted-path resolver가 `getattr(nexus, "probe")`로 먼저 그 함수를 찾아버려 서브모듈에
    닿지 못하고, `import nexus.probe as m`도 언어 스펙상 `nexus.probe` 속성 접근으로
    귀결되어 똑같이 함수를 돌려준다. `sys.modules["nexus.probe"]`로 직접 꺼내야만 실제
    서브모듈 객체(`backfill_dims`가 호출 시점에 `from nexus.probe import probe`로 읽는
    바로 그 네임스페이스)에 닿아 patch가 먹는다.
    """
    import nexus.probe  # noqa: F401 — 아래 sys.modules 조회로 서브모듈을 먼저 sys.modules에 올린다
    probe_mod = sys.modules["nexus.probe"]
    calls = []

    def fake_probe(refs, **kw):
        refs = list(refs)
        calls.append(refs)
        return [CasRef(bucket=r.bucket, key=r.key, width=dims[0], height=dims[1]) for r in refs]

    monkeypatch.setattr(probe_mod, "probe", fake_probe)
    return calls


def test_targets_missing_and_zero_dims_only(monkeypatch):
    client = MagicMock()
    client.set_sample_dimensions.return_value = [
        {"sample_id": "s-missing", "ok": True},
        {"sample_id": "s-zero", "ok": True},
    ]
    cas = MagicMock(); cas._base = "http://cas"
    ds = _ds(client, cas)
    monkeypatch.setattr(Dataset, "samples", lambda self, **kw: [
        _sample("s-missing", {"format_version": "1.0.0"}),          # 키 없음
        _sample("s-zero", {"width": 0, "height": 0}),               # 0
        _sample("s-ok", {"width": 640, "height": 480}),             # 정상 → 대상 아님
    ])
    calls = _patch_probe(monkeypatch)

    report = ds.backfill_dims(verbose=False)

    assert report["scanned"] == 3
    assert report["targeted"] == 2
    assert len(calls[0]) == 2                      # 정상 샘플은 probe에 가지 않는다
    sent = client.set_sample_dimensions.call_args[0][0]
    assert {i["sample_id"] for i in sent} == {"s-missing", "s-zero"}
    assert sent[0]["width"] == 1920 and sent[0]["height"] == 1080
    assert report["applied"] == 2


def test_skips_samples_without_image(monkeypatch):
    client = MagicMock()
    client.set_sample_dimensions.return_value = [{"sample_id": "s-img", "ok": True}]
    cas = MagicMock(); cas._base = "http://cas"
    ds = _ds(client, cas)
    monkeypatch.setattr(Dataset, "samples", lambda self, **kw: [
        _sample("s-img", {"width": 0, "height": 0}),
        _sample("s-noimg", {"width": 0, "height": 0}, image_url=None),
    ])
    _patch_probe(monkeypatch)

    report = ds.backfill_dims(verbose=False)

    assert report["targeted"] == 1                 # image asset이 없으면 잴 수가 없다
    sent = client.set_sample_dimensions.call_args[0][0]
    assert [i["sample_id"] for i in sent] == ["s-img"]


def test_dry_run_measures_but_does_not_write(monkeypatch):
    client = MagicMock()
    cas = MagicMock(); cas._base = "http://cas"
    ds = _ds(client, cas)
    monkeypatch.setattr(Dataset, "samples", lambda self, **kw: [
        _sample("s-zero", {"width": 0, "height": 0}),
    ])
    calls = _patch_probe(monkeypatch)

    report = ds.backfill_dims(dry_run=True, verbose=False)

    assert len(calls) == 1                         # 실제로 재본다 — 추정이 아니다
    assert report["measured"] == 1
    assert report["applied"] == 0
    client.set_sample_dimensions.assert_not_called()


def test_unmeasurable_sample_is_skipped_not_sent(monkeypatch):
    client = MagicMock()
    client.set_sample_dimensions.return_value = [{"sample_id": "s-ok", "ok": True}]
    cas = MagicMock(); cas._base = "http://cas"
    ds = _ds(client, cas)
    monkeypatch.setattr(Dataset, "samples", lambda self, **kw: [
        _sample("s-ok", {"width": 0, "height": 0}, "http://cas/kitti/a.png"),
        _sample("s-bad", {"width": 0, "height": 0}, "http://cas/kitti/b.png"),
    ])

    def fake_probe(refs, **kw):
        # b.png는 헤더를 읽지 못한 상황 — dims가 None으로 남는다.
        return [
            CasRef(bucket=r.bucket, key=r.key,
                   width=None if r.key.endswith("b.png") else 1920,
                   height=None if r.key.endswith("b.png") else 1080)
            for r in refs
        ]
    import nexus.probe  # noqa: F401 — sys.modules에 서브모듈을 올린다 (이유는 _patch_probe 참고)
    monkeypatch.setattr(sys.modules["nexus.probe"], "probe", fake_probe)

    report = ds.backfill_dims(verbose=False)

    assert report["targeted"] == 2 and report["measured"] == 1
    sent = client.set_sample_dimensions.call_args[0][0]
    assert [i["sample_id"] for i in sent] == ["s-ok"]


def test_zero_or_negative_measurement_is_not_sent(monkeypatch):
    """probe가 0 이하 값을 재서 돌려주는 항목은 서버로 보내지 않는다(측정 못한 것으로 집계).

    서버는 배치 안에 width/height < 1인 항목이 하나라도 있으면 그 청크 전체를 400으로
    거부한다(F5) — 클라이언트가 미리 걸러야 정상 건까지 같이 막히지 않는다."""
    client = MagicMock()
    client.set_sample_dimensions.return_value = [{"sample_id": "s-ok", "ok": True}]
    cas = MagicMock(); cas._base = "http://cas"
    ds = _ds(client, cas)
    monkeypatch.setattr(Dataset, "samples", lambda self, **kw: [
        _sample("s-ok", {"width": 0, "height": 0}, "http://cas/kitti/ok.png"),
        _sample("s-zero", {"width": 0, "height": 0}, "http://cas/kitti/zero.png"),
        _sample("s-neg", {"width": 0, "height": 0}, "http://cas/kitti/neg.png"),
    ])

    def fake_probe(refs, **kw):
        # zero.png는 0x0으로, neg.png는 음수로 "측정"된 상황(헤더 파싱 이상값).
        out = []
        for r in refs:
            if r.key.endswith("zero.png"):
                out.append(CasRef(bucket=r.bucket, key=r.key, width=0, height=0))
            elif r.key.endswith("neg.png"):
                out.append(CasRef(bucket=r.bucket, key=r.key, width=-1, height=100))
            else:
                out.append(CasRef(bucket=r.bucket, key=r.key, width=1920, height=1080))
        return out
    import nexus.probe  # noqa: F401 — sys.modules에 서브모듈을 올린다 (이유는 _patch_probe 참고)
    monkeypatch.setattr(sys.modules["nexus.probe"], "probe", fake_probe)

    report = ds.backfill_dims(verbose=False)

    assert report["targeted"] == 3
    assert report["measured"] == 1        # 0 이하 두 건은 측정 못한 것으로 집계
    sent = client.set_sample_dimensions.call_args[0][0]
    assert [i["sample_id"] for i in sent] == ["s-ok"]   # 0/음수 건은 아예 전송되지 않는다
    assert report["applied"] == 1
    assert report["rejected"] == []


def test_probe_called_with_dataset_cas(monkeypatch):
    """probe는 전역 nx._cas가 아니라 이 Dataset이 들고 있는 self._cas로 호출되어야 한다(F4).

    다른 모든 Dataset 메서드(self._resolve_asset 등)가 self._cas를 쓰는 것과 일관성을
    맞추지 않으면, 여러 CAS를 오가는 스크립트에서 엉뚱한 CAS로 probe가 나간다."""
    client = MagicMock()
    client.set_sample_dimensions.return_value = [{"sample_id": "s1", "ok": True}]
    my_cas = MagicMock(); my_cas._base = "http://my-cas"
    ds = _ds(client, my_cas)
    monkeypatch.setattr(Dataset, "samples", lambda self, **kw: [
        _sample("s1", {"width": 0, "height": 0}, "http://my-cas/kitti/1.png"),
    ])

    import nexus.probe  # noqa: F401
    probe_mod = sys.modules["nexus.probe"]
    seen_kwargs = {}

    def fake_probe(refs, **kw):
        seen_kwargs.update(kw)
        return [CasRef(bucket=r.bucket, key=r.key, width=1920, height=1080) for r in refs]

    monkeypatch.setattr(probe_mod, "probe", fake_probe)

    ds.backfill_dims(verbose=False)

    assert seen_kwargs.get("cas") is my_cas


def test_rejections_are_collected(monkeypatch):
    client = MagicMock()
    client.set_sample_dimensions.return_value = [
        {"sample_id": "s1", "ok": True},
        {"sample_id": "s2", "ok": False, "error": "이미 크기가 기록되어 있습니다 (640x480)"},
    ]
    cas = MagicMock(); cas._base = "http://cas"
    ds = _ds(client, cas)
    monkeypatch.setattr(Dataset, "samples", lambda self, **kw: [
        _sample("s1", {"width": 0, "height": 0}, "http://cas/kitti/1.png"),
        _sample("s2", {"width": 0, "height": 0}, "http://cas/kitti/2.png"),
    ])
    _patch_probe(monkeypatch)

    report = ds.backfill_dims(verbose=False)

    assert report["applied"] == 1
    assert len(report["rejected"]) == 1
    assert report["rejected"][0]["sample_id"] == "s2"
    assert report["rejected"][0]["error"] == "이미 크기가 기록되어 있습니다 (640x480)"


def test_missing_result_in_response_is_reported_as_rejected(monkeypatch):
    """서버 응답이 보낸 item 수보다 짧으면(프록시가 body를 자르는 등) 빠진 항목이
    조용히 사라지지 않고 rejected에 명시적 사유로 남아야 한다 — 그래야 applied +
    len(rejected)가 measured한 전체 항목 수를 계속 설명한다."""
    client = MagicMock()
    client.set_sample_dimensions.return_value = [
        {"sample_id": "s1", "ok": True},
        # s2에 대한 결과가 응답에서 통째로 빠졌다.
    ]
    cas = MagicMock(); cas._base = "http://cas"
    ds = _ds(client, cas)
    monkeypatch.setattr(Dataset, "samples", lambda self, **kw: [
        _sample("s1", {"width": 0, "height": 0}, "http://cas/kitti/1.png"),
        _sample("s2", {"width": 0, "height": 0}, "http://cas/kitti/2.png"),
    ])
    _patch_probe(monkeypatch)

    report = ds.backfill_dims(verbose=False)

    assert report["applied"] == 1
    assert report["rejected"] == [{"sample_id": "s2", "error": "batch 응답에 해당 item 결과 없음"}]
    assert report["applied"] + len(report["rejected"]) == report["measured"]


def test_sends_in_chunks(monkeypatch):
    client = MagicMock()
    client.set_sample_dimensions.side_effect = lambda items, **kw: [
        {"sample_id": i["sample_id"], "ok": True} for i in items
    ]
    cas = MagicMock(); cas._base = "http://cas"
    ds = _ds(client, cas)
    monkeypatch.setattr(Dataset, "samples", lambda self, **kw: [
        _sample(f"s{n}", {"width": 0, "height": 0}, f"http://cas/kitti/{n}.png")
        for n in range(5)
    ])
    _patch_probe(monkeypatch)

    report = ds.backfill_dims(chunk_size=2, verbose=False)

    assert client.set_sample_dimensions.call_count == 3   # 2 + 2 + 1
    assert report["applied"] == 5


def test_targets_negative_dimensions(monkeypatch):
    """음수 차원도 blank로 취급해 대상에 포함된다.

    Python의 truthiness만으로는 -5가 truthy라서 건너뛰어진다.
    서버는 -5를 blank로 취급하고 덮어쓰므로, SDK도 맞춰야 한다."""
    client = MagicMock()
    client.set_sample_dimensions.return_value = [
        {"sample_id": "s-neg", "ok": True},
    ]
    cas = MagicMock(); cas._base = "http://cas"
    ds = _ds(client, cas)
    monkeypatch.setattr(Dataset, "samples", lambda self, **kw: [
        _sample("s-neg", {"width": -5, "height": 100}, "http://cas/kitti/neg.png"),
    ])
    calls = _patch_probe(monkeypatch)

    report = ds.backfill_dims(verbose=False)

    assert report["targeted"] == 1  # 음수는 blank로 취급한다
    assert len(calls[0]) == 1
    sent = client.set_sample_dimensions.call_args[0][0]
    assert sent[0]["sample_id"] == "s-neg"


def test_skips_non_numeric_string_dimension(monkeypatch):
    """숫자가 아닌 문자열(예: "1920") 차원은 fail-closed로 거부한다.

    서버는 숫자 아닌 값을 recorded로 간주하고 건드리지 않는다."""
    client = MagicMock()
    cas = MagicMock(); cas._base = "http://cas"
    ds = _ds(client, cas)
    monkeypatch.setattr(Dataset, "samples", lambda self, **kw: [
        _sample("s-str", {"width": "1920", "height": "1080"}, "http://cas/kitti/str.png"),
        _sample("s-ok", {"width": 0, "height": 0}, "http://cas/kitti/ok.png"),
    ])
    _patch_probe(monkeypatch)

    report = ds.backfill_dims(verbose=False)

    assert report["targeted"] == 1  # s-ok만 대상
    sent = client.set_sample_dimensions.call_args[0][0]
    assert [i["sample_id"] for i in sent] == ["s-ok"]


def test_skips_float_recorded_dimension(monkeypatch):
    """0보다 큰 float는 recorded로 취급한다."""
    client = MagicMock()
    cas = MagicMock(); cas._base = "http://cas"
    ds = _ds(client, cas)
    monkeypatch.setattr(Dataset, "samples", lambda self, **kw: [
        _sample("s-float", {"width": 1920.0, "height": 1080.0}, "http://cas/kitti/float.png"),
        _sample("s-zero", {"width": 0, "height": 0}, "http://cas/kitti/zero.png"),
    ])
    _patch_probe(monkeypatch)

    report = ds.backfill_dims(verbose=False)

    assert report["targeted"] == 1  # s-zero만 대상
    sent = client.set_sample_dimensions.call_args[0][0]
    assert [i["sample_id"] for i in sent] == ["s-zero"]


def test_skips_bool_dimension(monkeypatch):
    """bool 값(True/False 모두)은 recorded로 취급한다 (fail-closed).

    JSON false/true는 Python bool이고, 절대로 blank가 아니다."""
    client = MagicMock()
    cas = MagicMock(); cas._base = "http://cas"
    ds = _ds(client, cas)
    monkeypatch.setattr(Dataset, "samples", lambda self, **kw: [
        _sample("s-false", {"width": False, "height": False}, "http://cas/kitti/false.png"),
        _sample("s-true", {"width": True, "height": True}, "http://cas/kitti/true.png"),
        _sample("s-zero", {"width": 0, "height": 0}, "http://cas/kitti/zero.png"),
    ])
    _patch_probe(monkeypatch)

    report = ds.backfill_dims(verbose=False)

    assert report["targeted"] == 1  # s-zero만 대상 (bool은 recorded)
    sent = client.set_sample_dimensions.call_args[0][0]
    assert [i["sample_id"] for i in sent] == ["s-zero"]


def test_skips_negative_numeric_string_dimension(monkeypatch):
    """숫자로 보이는 문자열도 recorded로 취급한다 (fail-closed).

    "-5"나 "0"은 문자열이므로 타입 기반으로 recorded이다."""
    client = MagicMock()
    cas = MagicMock(); cas._base = "http://cas"
    ds = _ds(client, cas)
    monkeypatch.setattr(Dataset, "samples", lambda self, **kw: [
        _sample("s-negstr", {"width": "-5", "height": "0"}, "http://cas/kitti/negstr.png"),
        _sample("s-missing", {"format_version": "1.0.0"}, "http://cas/kitti/missing.png"),
    ])
    _patch_probe(monkeypatch)

    report = ds.backfill_dims(verbose=False)

    assert report["targeted"] == 1  # s-missing만 대상 (negstr은 문자열이므로 recorded)
    sent = client.set_sample_dimensions.call_args[0][0]
    assert [i["sample_id"] for i in sent] == ["s-missing"]


# ── overwrite 모드 ────────────────────────────────────────────────────────────


def test_default_mode_sends_overwrite_false(monkeypatch):
    """기본 호출은 overwrite=False로 나간다 — 구버전 동작이 기본값이어야 한다."""
    client = MagicMock()
    client.set_sample_dimensions.return_value = [{"sample_id": "s-zero", "ok": True}]
    cas = MagicMock(); cas._base = "http://cas"
    ds = _ds(client, cas)
    monkeypatch.setattr(Dataset, "samples", lambda self, **kw: [
        _sample("s-zero", {"width": 0, "height": 0}),
    ])
    _patch_probe(monkeypatch)

    report = ds.backfill_dims(verbose=False)

    assert client.set_sample_dimensions.call_args.kwargs["overwrite"] is False
    assert report["corrected"] == 0     # 채우기 모드는 기록된 축을 바꾸지 못한다


def test_overwrite_targets_recorded_samples(monkeypatch):
    """overwrite=True면 이미 기록된 값(잘못된 선언값)도 대상이 된다.

    채우기 모드에서는 이런 샘플이 애초에 probe에도 가지 않으므로, 이 스킵이 빠지는 것이
    overwrite 모드의 전부다."""
    client = MagicMock()
    client.set_sample_dimensions.return_value = [{"sample_id": "s-wrong", "ok": True}]
    cas = MagicMock(); cas._base = "http://cas"
    ds = _ds(client, cas)
    monkeypatch.setattr(Dataset, "samples", lambda self, **kw: [
        _sample("s-wrong", {"width": 1280, "height": 720}),   # ann.json의 잘못된 선언값
    ])
    calls = _patch_probe(monkeypatch, dims=(1920, 1080))

    report = ds.backfill_dims(overwrite=True, verbose=False)

    assert report["targeted"] == 1 and len(calls[0]) == 1
    assert client.set_sample_dimensions.call_args.kwargs["overwrite"] is True
    sent = client.set_sample_dimensions.call_args[0][0]
    assert sent == [{"sample_id": "s-wrong", "width": 1920, "height": 1080}]
    assert report["applied"] == 1 and report["corrected"] == 1


def test_overwrite_does_not_rewrite_matching_values(monkeypatch):
    """쟀더니 기록값과 같으면 보내지 않는다.

    overwrite 모드는 전량을 재므로 대부분이 여기 걸린다 — 거르지 않으면 멀쩡한 샘플
    수만 건에 의미 없는 UPDATE를 날린다."""
    client = MagicMock()
    client.set_sample_dimensions.return_value = [{"sample_id": "s-wrong", "ok": True}]
    cas = MagicMock(); cas._base = "http://cas"
    ds = _ds(client, cas)
    monkeypatch.setattr(Dataset, "samples", lambda self, **kw: [
        _sample("s-right", {"width": 1920, "height": 1080}, "http://cas/kitti/1.png"),
        _sample("s-float", {"width": 1920.0, "height": 1080.0}, "http://cas/kitti/2.png"),
        _sample("s-wrong", {"width": 1280, "height": 720}, "http://cas/kitti/3.png"),
    ])
    _patch_probe(monkeypatch, dims=(1920, 1080))

    report = ds.backfill_dims(overwrite=True, verbose=False)

    assert report["targeted"] == 3 and report["measured"] == 3
    assert report["unchanged"] == 2        # 1920.0 == 1920 — 표현 차이는 잘못된 값이 아니다
    sent = client.set_sample_dimensions.call_args[0][0]
    assert [i["sample_id"] for i in sent] == ["s-wrong"]


def test_overwrite_treats_bool_dimension_as_wrong(monkeypatch):
    """`meta.width`가 `true`인 샘플은 폭 1px 이미지와 같은 값으로 판정되면 안 된다.

    Python에서 `True == 1`이라 순진하게 비교하면 이 샘플이 영영 보정 대상에서 빠진다."""
    client = MagicMock()
    client.set_sample_dimensions.return_value = [{"sample_id": "s-bool", "ok": True}]
    cas = MagicMock(); cas._base = "http://cas"
    ds = _ds(client, cas)
    monkeypatch.setattr(Dataset, "samples", lambda self, **kw: [
        _sample("s-bool", {"width": True, "height": True}),
    ])
    _patch_probe(monkeypatch, dims=(1, 1))

    report = ds.backfill_dims(overwrite=True, verbose=False)

    assert report["unchanged"] == 0
    sent = client.set_sample_dimensions.call_args[0][0]
    assert sent == [{"sample_id": "s-bool", "width": 1, "height": 1}]


def test_overwrite_separates_corrections_from_fills(monkeypatch):
    """corrected는 '기존 값을 덮은' 건만 센다 — 빈칸을 채운 건은 빠진다."""
    client = MagicMock()
    client.set_sample_dimensions.side_effect = lambda items, **kw: [
        {"sample_id": i["sample_id"], "ok": True} for i in items
    ]
    cas = MagicMock(); cas._base = "http://cas"
    ds = _ds(client, cas)
    monkeypatch.setattr(Dataset, "samples", lambda self, **kw: [
        _sample("s-wrong", {"width": 1280, "height": 720}, "http://cas/kitti/1.png"),
        _sample("s-blank", {"format_version": "1.0.0"}, "http://cas/kitti/2.png"),
        _sample("s-half", {"width": 1280, "height": 0}, "http://cas/kitti/3.png"),
    ])
    _patch_probe(monkeypatch, dims=(1920, 1080))

    report = ds.backfill_dims(overwrite=True, verbose=False)

    assert report["applied"] == 3
    # s-half는 한쪽 축만 기록되어 있어도 그 축(1280)이 덮이므로 correction이다.
    assert report["corrected"] == 2
    by_id = {c["sample_id"]: c for c in report["changes"]}
    assert by_id["s-wrong"]["from"] == [1280, 720]
    assert by_id["s-blank"]["from"] is None
    assert by_id["s-half"]["from"] == [1280, 0]
    assert by_id["s-wrong"]["to"] == [1920, 1080]


def test_overwrite_dry_run_lists_changes_without_writing(monkeypatch):
    """dry-run이 개수만이 아니라 변경 목록을 준다.

    overwrite 모드에는 sealed 게이트가 없다 — 쓰기 전에 사람이 보는 이 목록이
    'probe가 엉뚱한 객체를 재고 있다'를 잡는 유일한 자리다."""
    client = MagicMock()
    cas = MagicMock(); cas._base = "http://cas"
    ds = _ds(client, cas)
    monkeypatch.setattr(Dataset, "samples", lambda self, **kw: [
        _sample("s-wrong", {"width": 1280, "height": 720}),
    ])
    _patch_probe(monkeypatch, dims=(1920, 1080))

    report = ds.backfill_dims(overwrite=True, dry_run=True, verbose=False)

    client.set_sample_dimensions.assert_not_called()
    assert report["applied"] == 0 and report["corrected"] == 0
    assert report["changes"] == [
        {"sample_id": "s-wrong", "from": [1280, 720], "to": [1920, 1080]}
    ]


def test_overwrite_still_skips_unmeasurable_samples(monkeypatch):
    """헤더를 못 읽은 샘플은 overwrite 모드에서도 보내지 않는다.

    여기서 흘려보내면 멀쩡히 기록된 값을 측정 실패값으로 덮게 된다 — 채우기 모드의
    같은 실수보다 훨씬 나쁘다."""
    client = MagicMock()
    cas = MagicMock(); cas._base = "http://cas"
    ds = _ds(client, cas)
    monkeypatch.setattr(Dataset, "samples", lambda self, **kw: [
        _sample("s-bad", {"width": 1280, "height": 720}, "http://cas/kitti/bad.png"),
    ])

    def fake_probe(refs, **kw):
        return [CasRef(bucket=r.bucket, key=r.key, width=None, height=None) for r in refs]
    import nexus.probe  # noqa: F401 — sys.modules에 서브모듈을 올린다 (이유는 _patch_probe 참고)
    monkeypatch.setattr(sys.modules["nexus.probe"], "probe", fake_probe)

    report = ds.backfill_dims(overwrite=True, verbose=False)

    assert report["targeted"] == 1 and report["measured"] == 0
    client.set_sample_dimensions.assert_not_called()
