import json
import os
import stat
import pytest
from nexus import settings
from nexus._types import NexusCasError, NexusError


def test_env_credentials_win_and_no_issue_call(monkeypatch, tmp_path):
    """환경변수가 있으면 nexus에 요청하지 않는다 — CI·자동화의 탈출구다."""
    monkeypatch.setenv("CAS_KEY_ID", "CASK-env")
    monkeypatch.setenv("CAS_SECRET", "sk-env")
    monkeypatch.setenv("NEXUS_SETTINGS", str(tmp_path / "s.json"))
    resolved = settings.resolve(nexus_url="http://x", email="e", password="p", cas_url="http://c")
    assert resolved["cas_key_id"] == "CASK-env"
    assert resolved["cas_secret"] == "sk-env"


def test_save_cas_credentials_creates_file_and_tightens_mode(tmp_path):
    p = tmp_path / "settings.json"
    settings.save_cas_credentials(p, "CASK-1", "sk-1")
    data = json.loads(p.read_text(encoding="utf-8"))
    assert data["cas_key_id"] == "CASK-1"
    assert data["cas_secret"] == "sk-1"
    if os.name == "posix":
        assert stat.S_IMODE(p.stat().st_mode) == 0o600


def test_save_cas_credentials_preserves_other_keys(tmp_path):
    """기존 설정을 날리지 않는다 — 같은 파일에 nexus_url·email·password가 들어 있다."""
    p = tmp_path / "settings.json"
    p.write_text(json.dumps({"nexus_url": "http://n", "email": "e"}), encoding="utf-8")
    settings.save_cas_credentials(p, "CASK-2", "sk-2")
    data = json.loads(p.read_text(encoding="utf-8"))
    assert data["nexus_url"] == "http://n"
    assert data["email"] == "e"
    assert data["cas_key_id"] == "CASK-2"


def test_cas_region_is_a_known_key_and_does_not_warn(tmp_path, recwarn):
    p = tmp_path / "settings.json"
    p.write_text(json.dumps({"nexus_url": "http://n", "cas_region": "eu-1"}), encoding="utf-8")
    settings.load_file(p)
    assert not any("모르는 키" in str(w.message) for w in recwarn.list)


def test_save_cas_credentials_persists_region(tmp_path):
    p = tmp_path / "settings.json"
    settings.save_cas_credentials(p, "CASK-3", "sk-3", region="eu-1")
    data = json.loads(p.read_text(encoding="utf-8"))
    assert data["cas_region"] == "eu-1"


def test_save_cas_credentials_no_temp_file_left_behind(tmp_path):
    """원자적 쓰기(mkstemp + os.replace)가 임시 파일을 지우지 않고 남기지 않는다."""
    p = tmp_path / "settings.json"
    settings.save_cas_credentials(p, "CASK-4", "sk-4")
    assert [f.name for f in tmp_path.iterdir()] == ["settings.json"]


def test_save_cas_credentials_leaves_original_intact_on_replace_failure(tmp_path, monkeypatch):
    """쓰다가 죽으면(여기서는 os.replace 실패로 흉내) 원본이 절반짜리로 남으면 안 된다 —
    이 파일에는 CAS 자격증명 말고도 nexus_url/email/password가 들어 있다."""
    p = tmp_path / "settings.json"
    p.write_text(json.dumps({"nexus_url": "http://n", "email": "e"}), encoding="utf-8")

    def boom(*a, **k):
        raise OSError("disk full")

    monkeypatch.setattr(settings.os, "replace", boom)

    with pytest.raises(OSError):
        settings.save_cas_credentials(p, "CASK-x", "sk-x")

    data = json.loads(p.read_text(encoding="utf-8"))
    assert data == {"nexus_url": "http://n", "email": "e"}
    # 임시 파일도 안 남는다 — 실패 시 정리한다.
    assert [f.name for f in tmp_path.iterdir()] == ["settings.json"]


# ── NexusClient.issue_cas_credentials ────────────────────────────────────────

def test_issue_cas_credentials_posts_hostname_label_by_default(requests_mock):
    import socket
    from nexus.client import NexusClient

    requests_mock.post("http://nexus-test/api/v1/auth/login", json={"token": "tok"})
    client = NexusClient("http://nexus-test", "u@x.com", "pass")
    requests_mock.post(
        "http://nexus-test/api/v1/auth/cas-credentials",
        status_code=201,
        json={
            "cas_key_id": "CASK-new", "secret_key": "sk-new",
            "cas_url": "http://cas", "region": "cas-default",
        },
    )
    out = client.issue_cas_credentials()
    assert out["cas_key_id"] == "CASK-new"
    assert requests_mock.last_request.json() == {"label": socket.gethostname()}


def test_issue_cas_credentials_explicit_label(requests_mock):
    from nexus.client import NexusClient

    requests_mock.post("http://nexus-test/api/v1/auth/login", json={"token": "tok"})
    client = NexusClient("http://nexus-test", "u@x.com", "pass")
    requests_mock.post(
        "http://nexus-test/api/v1/auth/cas-credentials",
        status_code=201,
        json={"cas_key_id": "k", "secret_key": "s", "cas_url": "http://cas", "region": "r"},
    )
    client.issue_cas_credentials(label="my-laptop")
    assert requests_mock.last_request.json() == {"label": "my-laptop"}


def test_issue_cas_credentials_unconfigured_raises_503(requests_mock):
    from nexus.client import NexusClient

    requests_mock.post("http://nexus-test/api/v1/auth/login", json={"token": "tok"})
    client = NexusClient("http://nexus-test", "u@x.com", "pass")
    requests_mock.post(
        "http://nexus-test/api/v1/auth/cas-credentials",
        status_code=503,
        json={"error": "CAS 관리 자격증명이 구성되지 않았습니다"},
    )
    with pytest.raises(NexusError) as exc:
        client.issue_cas_credentials()
    assert exc.value.status_code == 503


# ── nx.connect()가 비어 있을 때만 자동 발급한다 ───────────────────────────────

def test_connect_auto_issues_when_credentials_missing(monkeypatch, tmp_path, requests_mock):
    import nexus

    nexus._client = None
    nexus._cas = None
    settings_file = tmp_path / "s.json"
    monkeypatch.setenv("NEXUS_SETTINGS", str(settings_file))
    requests_mock.post("http://n/api/v1/auth/login", json={"token": "t"})
    m = requests_mock.post(
        "http://n/api/v1/auth/cas-credentials",
        status_code=201,
        json={
            "cas_key_id": "CASK-auto", "secret_key": "sk-auto",
            "cas_url": "http://c-auto", "region": "r-auto",
        },
    )

    # cas_url을 명시로 준다 — 서버가 함께 돌려주는 cas_url이 이걸 덮으면 안 된다
    # (인자 > 환경변수 > 설정 파일이라는 이 모듈의 문서화된 우선순위 위반).
    #
    # `save_cas_credentials=True`를 명시하는 이유는 0.1.10에서 기본값이 뒤집혔기 때문이다 —
    # 아래 "파일에도 저장돼야" 단언은 이제 **저장을 켠 경우**의 성질이다.
    nexus.connect(
        nexus_url="http://n", email="e", password="p", cas_url="http://c",
        save_cas_credentials=True,
    )

    assert m.called
    assert nexus._cas._key_id == "CASK-auto"
    assert nexus._cas._secret == "sk-auto"
    assert nexus._cas._base == "http://c"  # 명시 인자가 이겼다 — 서버의 "http://c-auto"가 아니다.
    assert nexus._cas._region == "r-auto"
    # 저장을 켰으면 파일에 남아야 다음 프로세스에서 다시 발급받지 않는다. region도 함께 —
    # 안 그러면 기본 region이 아닌 배포는 다음 프로세스부터 영원히 403이 난다.
    saved = json.loads(settings_file.read_text(encoding="utf-8"))
    assert saved["cas_key_id"] == "CASK-auto"
    assert saved["cas_secret"] == "sk-auto"
    assert saved["cas_region"] == "r-auto"


def test_connect_explicit_cas_url_beats_server_issued_cas_url(monkeypatch, tmp_path, requests_mock):
    """IMPORTANT 3 회귀 고정 — 서버가 돌려주는 cas_url은 resolve()가 못 채웠을 때만 쓴다."""
    import nexus

    nexus._client = None
    nexus._cas = None
    monkeypatch.setenv("NEXUS_SETTINGS", str(tmp_path / "s.json"))
    requests_mock.post("http://n/api/v1/auth/login", json={"token": "t"})
    requests_mock.post(
        "http://n/api/v1/auth/cas-credentials",
        status_code=201,
        json={"cas_key_id": "k", "secret_key": "s", "cas_url": "http://server-says-this", "region": "r"},
    )

    nexus.connect(
        nexus_url="http://n", email="e", password="p", cas_url="http://explicit-wins",
    )

    assert nexus._cas._base == "http://explicit-wins"


def test_connect_reads_persisted_region_on_next_connect(monkeypatch, tmp_path, requests_mock):
    """자동 발급 이후 재시작한 다음 프로세스는 파일에 저장된 region으로 서명해야 한다 —
    안 그러면 기본 region이 아닌 배포에서 "처음 한 번만 되고 그 뒤로는 영원히 403"이 된다
    (자격증명은 이미 파일에서 오므로 그때는 `on_forbidden`도 안 걸려 복구 수단이 없다)."""
    import nexus

    nexus._client = None
    nexus._cas = None
    settings_file = tmp_path / "s.json"
    settings_file.write_text(json.dumps({
        "nexus_url": "http://n", "email": "e", "password": "p", "cas_url": "http://c",
        "cas_key_id": "CASK-saved", "cas_secret": "sk-saved", "cas_region": "eu-1",
    }), encoding="utf-8")
    monkeypatch.setenv("NEXUS_SETTINGS", str(settings_file))
    requests_mock.post("http://n/api/v1/auth/login", json={"token": "t"})
    m = requests_mock.post("http://n/api/v1/auth/cas-credentials", status_code=201, json={})

    nexus.connect()

    assert not m.called  # 자격증명이 이미 있으니 자동 발급을 부르지 않는다
    assert nexus._cas._region == "eu-1"


def test_connect_partial_credentials_warn_before_auto_issuing(monkeypatch, tmp_path, requests_mock):
    """CAS_KEY_ID만 있고 secret이 없으면 조용히 덮어쓰지 않고 먼저 경고한다."""
    import nexus

    nexus._client = None
    nexus._cas = None
    monkeypatch.setenv("NEXUS_SETTINGS", str(tmp_path / "s.json"))
    monkeypatch.setenv("CAS_KEY_ID", "partial-kid")  # secret 없이 key_id만
    requests_mock.post("http://n/api/v1/auth/login", json={"token": "t"})
    m = requests_mock.post(
        "http://n/api/v1/auth/cas-credentials",
        status_code=201,
        json={"cas_key_id": "CASK-full", "secret_key": "sk-full", "cas_url": "http://c", "region": "cas-default"},
    )

    with pytest.warns(UserWarning, match="한쪽만"):
        nexus.connect(nexus_url="http://n", email="e", password="p", cas_url="http://c")

    assert m.called
    assert nexus._cas._key_id == "CASK-full"


def test_connect_save_failure_after_issue_explains_orphaned_credential(monkeypatch, tmp_path, requests_mock):
    """저장이 실패해도 발급 자체는 이미 끝나 있다 — 에러 메시지가 그 사실과 key_id를
    담아야 사용자가 수동으로 조치(재저장 또는 폐기)할 수 있다."""
    import nexus

    nexus._client = None
    nexus._cas = None
    monkeypatch.setenv("NEXUS_SETTINGS", str(tmp_path / "s.json"))
    requests_mock.post("http://n/api/v1/auth/login", json={"token": "t"})
    requests_mock.post(
        "http://n/api/v1/auth/cas-credentials",
        status_code=201,
        json={"cas_key_id": "CASK-orphan", "secret_key": "sk", "cas_url": "http://c", "region": "cas-default"},
    )

    def boom(*a, **k):
        raise OSError("disk full")

    monkeypatch.setattr(nexus._settings, "save_cas_credentials", boom)

    # 저장 실패 경로는 저장을 켰을 때만 탄다(0.1.10부터 기본값이 저장하지 않음).
    with pytest.raises(NexusError, match="CASK-orphan"):
        nexus.connect(
            nexus_url="http://n", email="e", password="p", cas_url="http://c",
            save_cas_credentials=True,
        )


def test_connect_does_not_auto_issue_when_credentials_supplied(monkeypatch, tmp_path, requests_mock):
    """세 경로 중 하나로 자격증명이 있으면 자동 발급 엔드포인트를 아예 두드리지 않는다."""
    import nexus

    nexus._client = None
    nexus._cas = None
    monkeypatch.setenv("NEXUS_SETTINGS", str(tmp_path / "s.json"))
    requests_mock.post("http://n/api/v1/auth/login", json={"token": "t"})
    m = requests_mock.post("http://n/api/v1/auth/cas-credentials", status_code=201, json={})

    nexus.connect(
        nexus_url="http://n", email="e", password="p", cas_url="http://c",
        cas_key_id="kid", cas_secret="sec",
    )

    assert not m.called


def _connect_with_issue(monkeypatch, tmp_path, requests_mock, **kwargs):
    """자동 발급이 일어나는 connect. 설정 파일 경로를 돌려준다."""
    import nexus

    nexus._client = None
    nexus._cas = None
    settings_file = tmp_path / "s.json"
    monkeypatch.setenv("NEXUS_SETTINGS", str(settings_file))
    requests_mock.post("http://n/api/v1/auth/login", json={"token": "t"})
    requests_mock.post(
        "http://n/api/v1/auth/cas-credentials",
        status_code=201,
        json={"cas_key_id": "k", "secret_key": "s", "cas_url": "http://c", "region": "cas-default"},
    )

    nexus.connect(
        nexus_url="http://n", email="e", password="p", cas_url="http://c", **kwargs
    )
    return settings_file


def test_connect_does_not_write_credentials_by_default(monkeypatch, tmp_path, requests_mock):
    """**기본값이 저장하지 않음이다**(0.1.10 에서 뒤집었다).

    발급 자체는 그대로 일어나고 이 프로세스 안에서는 쓰인다 — 파일에 남기지 않을 뿐이다.
    뒤집은 이유는 자동 발급 결과가 파일이면 "사람마다 흩어지지 않게 한다" 는 방침이
    자동 발급에서 무너지기 때문이다. 나중에 뒤집으면 그때는 이미 흩어진 파일을 회수해야
    한다.
    """
    settings_file = _connect_with_issue(monkeypatch, tmp_path, requests_mock)
    assert not settings_file.exists(), "기본값인데 설정 파일에 자격증명을 썼다"


def test_connect_save_cas_credentials_true_writes_file(monkeypatch, tmp_path, requests_mock):
    """옵션은 살아 있어야 한다 — 저장이 맞는 배포도 있다(명시적 요청)."""
    settings_file = _connect_with_issue(
        monkeypatch, tmp_path, requests_mock, save_cas_credentials=True
    )
    assert settings_file.exists(), "True 인데 저장하지 않았다"
    assert "k" in settings_file.read_text(encoding="utf-8")


def test_connect_save_cas_credentials_false_skips_file_write(monkeypatch, tmp_path, requests_mock):
    settings_file = _connect_with_issue(
        monkeypatch, tmp_path, requests_mock, save_cas_credentials=False
    )
    assert not settings_file.exists()


def test_connect_unconfigured_server_falls_back_without_raising(monkeypatch, tmp_path, requests_mock):
    """503은 사용자 잘못이 아니다 — connect()는 그래도 성공해야 한다(자격증명 없이)."""
    import nexus

    nexus._client = None
    nexus._cas = None
    monkeypatch.setenv("NEXUS_SETTINGS", str(tmp_path / "s.json"))
    requests_mock.post("http://n/api/v1/auth/login", json={"token": "t"})
    requests_mock.post(
        "http://n/api/v1/auth/cas-credentials",
        status_code=503,
        json={"error": "CAS 관리 자격증명이 구성되지 않았습니다"},
    )

    with pytest.warns(UserWarning, match="구성되지"):
        client = nexus.connect(nexus_url="http://n", email="e", password="p", cas_url="http://c")

    assert client is not None
    assert nexus._cas._key_id == ""
    assert nexus._cas._secret == ""


# ── cas.py 의 403 재시도 ──────────────────────────────────────────────────────

def test_on_forbidden_retries_once_and_succeeds(requests_mock):
    from nexus.cas import CasClient

    calls = []

    def reissue():
        calls.append(1)
        return "new-kid", "new-secret"

    c = CasClient("http://cas-retry", key_id="old-kid", secret="old-secret", on_forbidden=reissue)
    requests_mock.put("http://cas-retry/b/k", [{"status_code": 403}, {"status_code": 200}])

    c.put("b", "k", b"data", "image/png")

    assert len(calls) == 1
    assert "new-kid" in requests_mock.last_request.headers["Authorization"]


def test_on_forbidden_second_403_propagates_and_callback_called_once(requests_mock):
    from nexus.cas import CasClient

    calls = []

    def reissue():
        calls.append(1)
        return "new-kid", "new-secret"

    c = CasClient("http://cas-retry2", key_id="old-kid", secret="old-secret", on_forbidden=reissue)
    requests_mock.put("http://cas-retry2/b/k", status_code=403)

    with pytest.raises(NexusCasError):
        c.put("b", "k", b"data", "image/png")

    assert len(calls) == 1
    assert requests_mock.call_count == 2  # 최초 1 + 재시도 1, 그 이상은 없다


def test_reissue_budget_spans_the_client_not_the_request(requests_mock):
    """403이 여러 **요청**에 걸쳐 반복돼도 재발급은 한 번뿐이어야 한다.

    이 설계에서 403은 예외가 아니라 정상 응답이다 — `viewer` 자격증명에는 PutObject가
    없고, 모든 역할이 `annotations/`·`manifests/`에 deny를 달고 나온다. 요청마다 재발급하면
    파일 500개를 올리는 `viewer` 하나가 자격증명 1000개를 발급하고 상한 정리로 그만큼
    폐기를 유발한다(발급당 cas 관리 호출 약 15회). 기존 동시성 테스트는 '동시에 맞은
    403'만 고정하고 이 순차 경로는 비어 있었다.

    **막는 장치가 클라이언트당 예산에서 재발급 간격으로 바뀌었다**
    (`cas.py::_REISSUE_MIN_INTERVAL_SECS`) — 자격증명에 만료가 붙으면서 오래 도는
    프로세스는 두 번 이상 갱신해야 하는데 예산은 첫 번째에서 바닥났다. 이 테스트가
    보는 성질(연속된 403이 재발급을 한 번만 낸다)은 둘 다에서 성립하고, 여기 5회는
    간격 안에서 일어난다.
    """
    from nexus.cas import CasClient

    calls = []

    def reissue():
        calls.append(1)
        return "new-kid", "new-secret"

    c = CasClient("http://cas-budget", key_id="old-kid", secret="old-secret", on_forbidden=reissue)
    requests_mock.put("http://cas-budget/b/k", status_code=403)

    for _ in range(5):
        with pytest.raises(NexusCasError):
            c.put("b", "k", b"data", "image/png")

    assert len(calls) == 1, "요청 수가 아니라 클라이언트당 한 번이어야 한다"
    # 첫 요청만 재시도로 2회, 나머지 4요청은 1회씩.
    assert requests_mock.call_count == 6


def test_policy_denied_403_message_says_it_is_policy_not_a_stale_credential(requests_mock):
    """정책이 막은 403은 메시지가 '정책 거부'라고 말해야 한다 — 사용자가 자격증명이
    깨졌다고 오해하고 재접속을 반복하는 것이 이 기능에서 가장 흔한 오진이다.

    **판정 근거가 바뀌었다.** 전에는 "예산을 다 쓰고도 403" 이라는 정황으로 넘겨짚었는데,
    cas 는 그 구분을 S3 에러 코드로 이미 주고 있었다(`AccessDenied`). 그래서 이제는 실제
    cas 가 보내는 본문을 그대로 넣어 시험한다 — 정황이 아니라 응답이 답한다.
    """
    from nexus.cas import CasClient

    c = CasClient(
        "http://cas-hint", key_id="old-kid", secret="old-secret",
        on_forbidden=lambda: ("new-kid", "new-secret"),
    )
    requests_mock.put(
        "http://cas-hint/b/k",
        status_code=403,
        text='<?xml version="1.0"?><Error><Code>AccessDenied</Code>'
             "<Message>denied</Message></Error>",
    )

    with pytest.raises(NexusCasError) as exc:
        c.put("b", "k", b"data", "image/png")

    assert "정책" in str(exc.value)
    assert "viewer" in str(exc.value)


def test_forbidden_hint_without_callback_mentions_both_causes(requests_mock):
    """재발급 경로가 없는 자격증명(수동 지정)은 폐기와 정책 거부를 구별할 수 없다 —
    메시지가 둘 다 짚어줘야 한다."""
    from nexus.cas import CasClient

    c = CasClient("http://cas-hint2", key_id="kid", secret="sec")
    requests_mock.put("http://cas-hint2/b/k", status_code=403)

    with pytest.raises(NexusCasError) as exc:
        c.put("b", "k", b"data", "image/png")

    assert "폐기" in str(exc.value) and "정책" in str(exc.value)


def test_non_403_error_has_no_forbidden_hint(requests_mock):
    """500에 정책 이야기를 붙이면 오히려 오진을 만든다."""
    from nexus.cas import CasClient

    c = CasClient("http://cas-hint3", key_id="kid", secret="sec")
    requests_mock.put("http://cas-hint3/b/k", status_code=400)

    with pytest.raises(NexusCasError) as exc:
        c.put("b", "k", b"data", "image/png")

    assert "정책" not in str(exc.value)


def test_on_forbidden_409_does_not_retry_and_surfaces_server_message(requests_mock):
    from nexus.cas import CasClient

    def reissue():
        raise NexusError(
            "cas에서 폐기된 자격증명이 있습니다. 관리자에게 문의하십시오",
            status_code=409,
            server_message="cas에서 폐기된 자격증명이 있습니다. 관리자에게 문의하십시오",
        )

    c = CasClient("http://cas-retry3", key_id="old-kid", secret="old-secret", on_forbidden=reissue)
    requests_mock.put("http://cas-retry3/b/k", status_code=403)

    with pytest.raises(NexusError) as exc:
        c.put("b", "k", b"data", "image/png")

    assert exc.value.status_code == 409
    assert "관리자에게 문의" in exc.value.server_message
    # cas에는 최초 1회만 나갔다 — 재시도하지 않았다.
    assert requests_mock.call_count == 1


def test_no_on_forbidden_callback_403_raises_immediately(requests_mock):
    """콜백을 안 주면(수동 자격증명 등) 기존과 동일하게 재시도 없이 바로 실패한다."""
    from nexus.cas import CasClient

    c = CasClient("http://cas-retry4", key_id="kid", secret="sec")
    requests_mock.put("http://cas-retry4/b/k", status_code=403)

    with pytest.raises(NexusCasError):
        c.put("b", "k", b"data", "image/png")

    assert requests_mock.call_count == 1


def test_on_forbidden_retry_also_covers_get(requests_mock):
    """put만 도는 게 아니라 공유 재시도 경로(`_retry_with_fresh_credentials`)가 다른
    메서드에도 실제로 걸려 있는지 — head를 put과 다르게(인라인으로) 짜 놓으면 이런
    테스트가 없을 때 조용히 어긋난다."""
    from nexus.cas import CasClient

    calls = []

    def reissue():
        calls.append(1)
        return "new-kid", "new-secret"

    c = CasClient("http://cas-retry5", key_id="old-kid", secret="old-secret", on_forbidden=reissue)
    requests_mock.get(
        "http://cas-retry5/b/k",
        [{"status_code": 403}, {"content": b"hello", "status_code": 200}],
    )

    assert c.get("b", "k") == b"hello"
    assert len(calls) == 1


# ── 재발급 콜백을 어느 출처에 거는가 ──────────────────────────────────────────
#
# 서버가 CAS 자격증명에 만료를 붙이면서(요청자 토큰의 만료를 물려받는다) 출처별로 답이
# 갈렸다. 설정 파일에 저장된 값은 이 SDK가 자동 발급 결과로 스스로 써 넣은 것이라 갱신할
# 주체가 SDK 말고 없고, 인자·환경변수로 준 값은 운영자가 관리하는 영구 자격증명일 수 있어
# 403 한 번에 nexus 자동 발급으로 바꿔치기하면 `connect` docstring이 약속한 탈출구가
# 조용히 무력해진다.

def _write_settings(tmp_path, monkeypatch, **extra):
    """설정 파일에 접속 설정 + CAS 자격증명을 적고 그 경로를 쓰게 한다.

    이 자리에서 환경변수를 반드시 지운다 — 개발자 셸에 `CAS_KEY_ID`가 떠 있으면 "파일에서
    왔다"는 전제가 깨지고, 그러면 이 테스트가 통과해도 아무것도 증명하지 못한다.
    """
    settings_file = tmp_path / "s.json"
    settings_file.write_text(json.dumps({
        "nexus_url": "http://n", "email": "e", "password": "p", "cas_url": "http://c",
        "cas_key_id": "CASK-stale", "cas_secret": "sk-stale", "cas_region": "eu-1",
        **extra,
    }), encoding="utf-8")
    monkeypatch.setenv("NEXUS_SETTINGS", str(settings_file))
    monkeypatch.delenv("CAS_KEY_ID", raising=False)
    monkeypatch.delenv("CAS_SECRET", raising=False)
    return settings_file


def _mock_login_and_issue(requests_mock):
    requests_mock.post("http://n/api/v1/auth/login", json={"token": "t"})
    return requests_mock.post(
        "http://n/api/v1/auth/cas-credentials",
        status_code=201,
        json={
            "cas_key_id": "CASK-fresh", "secret_key": "sk-fresh",
            "cas_url": "http://c", "region": "eu-1",
        },
    )


def test_file_credentials_get_a_reissue_callback(monkeypatch, tmp_path, requests_mock):
    """설정 파일에서 온 자격증명이 403을 받으면 **재발급한다.**

    이 성질이 없으면 만료가 붙은 순간 이렇게 된다: `save_cas_credentials=True`로 한 번
    돌아 파일에 값이 깔리고(그 프로세스는 콜백이 있어 무사), 다음 프로세스는 파일에서
    읽어 콜백 없이 돌다가, 만료 시각 이후 모든 CAS 호출이 403인데 재발급을 시도조차 하지
    않는다. 게다가 그때 나오는 힌트는 "정책이 거부했다"라 엉뚱한 곳을 가리킨다.
    0.1.9 이하는 `save_cas_credentials` 기본값이 `True`였으므로 그런 설치본이 실제로 있다.
    """
    import nexus

    nexus._client = None
    nexus._cas = None
    settings_file = _write_settings(tmp_path, monkeypatch)
    issue = _mock_login_and_issue(requests_mock)

    nexus.connect()

    # 접속만으로 발급하지는 않는다 — 저장된 값이 아직 살아 있을 수 있고, 파드를 띄울
    # 때마다 자격증명이 쌓이면 안 된다. 갱신은 실제로 403을 맞았을 때만이다.
    assert not issue.called
    assert nexus._cas._key_id == "CASK-stale"

    requests_mock.put("http://c/b/k", [{"status_code": 403}, {"status_code": 200}])
    nexus._cas.put("b", "k", b"data", "image/png")

    assert issue.call_count == 1
    assert nexus._cas._key_id == "CASK-fresh"
    assert nexus._cas._secret == "sk-fresh"

    # 파일도 제자리 갱신한다 — 안 그러면 다음 프로세스가 만료된 값을 또 읽고 403을 한 번
    # 더 맞는 왕복이 남는다. 같은 파일의 접속 설정은 그대로여야 한다(통째로 덮으면 로그인
    # 정보가 사라진다).
    saved = json.loads(settings_file.read_text(encoding="utf-8"))
    assert saved["cas_key_id"] == "CASK-fresh"
    assert saved["cas_secret"] == "sk-fresh"
    assert saved["cas_region"] == "eu-1"
    assert saved["nexus_url"] == "http://n" and saved["password"] == "p"


def test_argument_credentials_keep_the_escape_hatch(monkeypatch, tmp_path, requests_mock):
    """인자로 준 자격증명은 재발급하지 않는다.

    운영자가 관리하는 영구 자격증명일 수 있고, 그것을 403 한 번에 nexus 자동 발급으로
    바꿔치기하면 `connect` docstring이 약속한 탈출구가 조용히 무력해진다. 파일에 값이
    있어도(여기서는 있다) 인자가 이기므로 판정은 인자 쪽이다.
    """
    import nexus

    nexus._client = None
    nexus._cas = None
    _write_settings(tmp_path, monkeypatch)
    issue = _mock_login_and_issue(requests_mock)

    nexus.connect(cas_key_id="kid-arg", cas_secret="sec-arg")

    assert nexus._cas._on_forbidden is None
    put = requests_mock.put("http://c/b/k", status_code=403)
    with pytest.raises(NexusCasError):
        nexus._cas.put("b", "k", b"data", "image/png")

    assert not issue.called
    assert put.call_count == 1, "재시도조차 하지 않아야 한다"
    assert nexus._cas._key_id == "kid-arg"


def test_env_credentials_keep_the_escape_hatch(monkeypatch, tmp_path, requests_mock):
    """환경변수로 준 자격증명도 마찬가지다 — CI·학습 파드가 주입하는 경로가 이쪽이다.

    인자와 따로 보는 이유는 판정이 두 갈래라서다(`_cas_credentials_from_user`). 한쪽만
    시험하면 다른 쪽이 파일 취급으로 넘어가도 아무도 모른다.
    """
    import nexus

    nexus._client = None
    nexus._cas = None
    _write_settings(tmp_path, monkeypatch)
    monkeypatch.setenv("CAS_KEY_ID", "kid-env")
    monkeypatch.setenv("CAS_SECRET", "sec-env")
    issue = _mock_login_and_issue(requests_mock)

    nexus.connect()

    assert nexus._cas._key_id == "kid-env"
    assert nexus._cas._on_forbidden is None
    put = requests_mock.put("http://c/b/k", status_code=403)
    with pytest.raises(NexusCasError):
        nexus._cas.put("b", "k", b"data", "image/png")

    assert not issue.called
    assert put.call_count == 1


def test_on_forbidden_called_once_under_concurrent_403(requests_mock):
    """여러 스레드가 같은 CasClient를 공유(`upload.py`의 ThreadPoolExecutor)할 때 동시에
    403을 맞아도 `on_forbidden`은 딱 한 번만 불려야 한다 — 안 그러면 워커 수만큼
    자격증명이 발급되고, 한 스레드가 새 key_id를 읽는 사이 다른 스레드가 secret을
    덮어써 서로 안 맞는 조합을 볼 수도 있다."""
    import threading
    from concurrent.futures import ThreadPoolExecutor
    from nexus.cas import CasClient

    calls = []
    reissue_lock = threading.Lock()

    def reissue():
        with reissue_lock:
            calls.append(1)
        return "new-kid", "new-secret"

    def responder(request, context):
        auth = request.headers.get("Authorization", "")
        context.status_code = 200 if "Credential=new-kid" in auth else 403
        return b""

    requests_mock.put("http://cas-concurrent/b/k", content=responder)
    c = CasClient(
        "http://cas-concurrent", key_id="old-kid", secret="old-secret", on_forbidden=reissue
    )

    n_workers = 8
    barrier = threading.Barrier(n_workers)

    def worker(_):
        barrier.wait()
        c.put("b", "k", b"data", "image/png")

    with ThreadPoolExecutor(max_workers=n_workers) as ex:
        list(ex.map(worker, range(n_workers)))

    assert len(calls) == 1
    assert c._key_id == "new-kid"
    assert c._secret == "new-secret"
