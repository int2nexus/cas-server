"""로컬 설정 파일(`~/.int2nexus/settings.json`) 로딩과 접속 설정 해소.

우선순위는 **명시 인자 > 환경변수 > 설정 파일** — AWS CLI·gcloud와 같은 관례다.
코드에 적은 값이 항상 이기므로 "분명히 인자를 넘겼는데 파일이 이긴다"는 사고가 없고,
CI는 환경변수로 로컬 파일을 덮을 수 있다.

설계: `docs/superpowers/specs/2026-08-05-sdk-settings-and-tls-design.md`
"""
from __future__ import annotations

import json
import os
import tempfile
import warnings
from pathlib import Path

from nexus._types import NexusError

#: 설정 파일 기본 위치. `NEXUS_SETTINGS`로 덮을 수 있다(CI·컨테이너용).
DEFAULT_SETTINGS_PATH = Path.home() / ".int2nexus" / "settings.json"

_PATH_ENV = "NEXUS_SETTINGS"

# 필드 → 환경변수. verify를 뺀 6개는 기존에 쓰던 이름 그대로다(하위호환). cas_region은
# 자동 발급 자격증명과 함께 저장되는 CAS 서명 region — 이게 없으면 "처음 한 번은 되고
# 그다음부터는 영원히 403"이 될 수 있다(기본 region이 아닌 배포에서, `on_forbidden`이
# 자격증명 소스가 파일로 넘어간 뒤에는 없기 때문에 SDK 스스로 복구할 방법이 없다).
_ENV_VARS = {
    "nexus_url": "NEXUS_URL",
    "email": "NEXUS_EMAIL",
    "password": "NEXUS_PASSWORD",
    "cas_url": "CAS_URL",
    "cas_key_id": "CAS_KEY_ID",
    "cas_secret": "CAS_SECRET",
    "cas_region": "CAS_REGION",
    "verify": "NEXUS_VERIFY",
}

_REQUIRED = ("nexus_url", "email", "password", "cas_url")
_KNOWN = tuple(_ENV_VARS)

_TRUE = {"1", "true", "yes", "on"}
_FALSE = {"0", "false", "no", "off"}


def settings_path(explicit: "str | Path | None" = None) -> Path:
    """실제로 읽을 설정 파일 경로. 명시 인자 > `NEXUS_SETTINGS` > 기본 위치."""
    if explicit is not None:
        return Path(explicit).expanduser()
    env = os.environ.get(_PATH_ENV)
    if env:
        return Path(env).expanduser()
    return DEFAULT_SETTINGS_PATH


def parse_verify(raw: "bool | str | None") -> "bool | str | None":
    """`verify` 값을 requests가 받는 형태로 정규화한다.

    `True`/`False`는 그대로, 문자열은 불리언 표기면 불리언으로, 그 외에는 **CA 번들 경로**로
    본다(requests의 `verify`가 경로 문자열을 받는다). 검증을 끄는 것보다 사내 루트 CA를
    지정하는 쪽이 안전하므로 경로를 일급으로 취급한다.
    """
    if raw is None or isinstance(raw, bool):
        return raw
    text = str(raw).strip()
    if not text:
        return None
    lowered = text.lower()
    if lowered in _TRUE:
        return True
    if lowered in _FALSE:
        return False
    return text


def load_file(path: "str | Path | None" = None) -> dict:
    """설정 파일을 읽어 dict로. 파일이 없으면 `{}`.

    JSON이 깨졌거나 최상위가 객체가 아니면 **에러를 낸다** — 조용히 무시하면 오타 하나로
    "설정이 안 먹는다"가 되고 원인을 찾기 어렵다. 모르는 키는 경고만 한다(오타 탐지).
    """
    p = settings_path(path)
    if not p.is_file():
        return {}

    try:
        raw = p.read_text(encoding="utf-8")
    except OSError as e:
        raise NexusError(f"설정 파일을 읽을 수 없습니다: {p} ({e})") from e

    try:
        data = json.loads(raw)
    except json.JSONDecodeError as e:
        raise NexusError(
            f"설정 파일의 JSON 형식이 잘못됐습니다: {p} (line {e.lineno}, column {e.colno}: {e.msg})"
        ) from e

    if not isinstance(data, dict):
        raise NexusError(f"설정 파일의 최상위는 JSON 객체여야 합니다: {p}")

    unknown = sorted(k for k in data if k not in _KNOWN)
    if unknown:
        warnings.warn(
            f"설정 파일 {p}에 모르는 키가 있습니다: {', '.join(unknown)} "
            f"(사용 가능: {', '.join(_KNOWN)}) — 오타인지 확인하세요.",
            stacklevel=2,
        )

    _warn_if_world_readable(p)
    return data


def _warn_if_world_readable(p: Path) -> None:
    """POSIX에서 group/other 비트가 서 있으면 경고.

    Windows에서는 `chmod`가 사실상 무의미해(파일 ACL과 무관하게 항상 0o666처럼 보인다)
    검사하지 않는다 — 거짓 경고만 남기 때문이다. 이 사실은 README에도 적어둔다.
    """
    if os.name != "posix":
        return
    try:
        mode = p.stat().st_mode
    except OSError:
        return
    if mode & 0o077:
        warnings.warn(
            f"설정 파일 {p}의 권한이 느슨합니다(비밀번호·CAS secret이 들어 있습니다). "
            f"`chmod 600 {p}`를 권합니다.",
            stacklevel=3,
        )


def resolve(
    *, path: "str | Path | None" = None, require_login: bool = True, **explicit
) -> dict:
    """접속 설정을 해소한다. 반환 키는 `_ENV_VARS`와 동일.

    `explicit`에서 `None`인 값은 "지정하지 않음"으로 보고 다음 순위로 넘어간다.
    필수 값이 끝까지 비면 **무엇이 빠졌고 어디에 넣으면 되는지**를 담아 에러를 낸다.

    `require_login=False`면 `email`/`password`를 필수에서 뺀다 — 로봇 토큰으로 연결할 때는
    로그인 경로를 아예 타지 않으므로 그 둘을 요구하면 워크로드가 있지도 않은 사람 계정의
    자격증명을 들고 있어야 한다(그것이 고객이 거부한 모양이다).
    """
    file_values = load_file(path)
    resolved: dict = {}

    for field, env_var in _ENV_VARS.items():
        value = explicit.get(field)
        if value is None:
            value = os.environ.get(env_var)
        if value is None or value == "":
            value = file_values.get(field)
        resolved[field] = value

    required = _REQUIRED if require_login else tuple(
        f for f in _REQUIRED if f not in ("email", "password")
    )
    missing = [f for f in required if not resolved.get(f)]
    if missing:
        resolved_path = settings_path(path)
        lines = [
            f"nexus 접속 설정이 부족합니다: {', '.join(missing)}",
            "",
            "다음 중 하나로 지정하세요 (우선순위: 인자 > 환경변수 > 설정 파일).",
            f"  1) nx.connect({', '.join(f'{f}=...' for f in missing)})",
            f"  2) 환경변수 {', '.join(_ENV_VARS[f] for f in missing)}",
            f"  3) 설정 파일 {resolved_path} 에 아래 키를 추가",
            "     " + json.dumps({f: "..." for f in missing}, ensure_ascii=False),
        ]
        raise NexusError("\n".join(lines))

    resolved["verify"] = parse_verify(resolved.get("verify"))
    if resolved["verify"] is None:
        resolved["verify"] = True
    resolved["cas_key_id"] = resolved.get("cas_key_id") or ""
    resolved["cas_secret"] = resolved.get("cas_secret") or ""
    # region은 CasClient 기본값과 같은 문자열로 떨어진다 — 아무도 지정한 적 없으면
    # "설정 안 함"과 "기본값" 사이에 차이가 없어야 하기 때문이다.
    resolved["cas_region"] = resolved.get("cas_region") or "cas-default"
    return resolved


def save_cas_credentials(
    path: "str | Path | None", key_id: str, secret: str, region: "str | None" = None
) -> None:
    """발급받은 CAS 자격증명을 설정 파일에 쓴다. **기존 키는 보존한다.**

    같은 파일에 `nexus_url`·`email`·`password`가 들어 있으므로 통째로 덮으면 접속 설정이
    사라진다. 파일이 없으면 새로 만든다.

    `region`도 함께 저장한다(주면) — 안 그러면 기본 region이 아닌 배포에서 "처음 접속은
    되고 그다음 프로세스부터는 영원히 403"이 된다: 최초 발급 직후에는 그 프로세스가 서버
    응답의 region을 메모리에 들고 있어 동작하지만, 다음 프로세스는 파일에서 자격증명만
    읽고(`cas_key_id`/`cas_secret`가 이미 있으니 `nexus.connect()`가 자동 발급을 다시
    부르지 않는다 — 그게 이 기능의 의도다) region은 `CasClient`의 기본값
    (`"cas-default"`)으로 서명하게 된다. 그 시점엔 `on_forbidden`도 없다(파일에서 온
    자격증명에는 안 건다 — `__init__.py` 참조) 그래서 SDK 스스로 복구할 방법이 없다.

    **파일 쓰기는 원자적이다.** 이 파일에는 CAS 자격증명 말고도 `nexus_url`·`email`·
    `password`가 들어 있으므로, 쓰다가 죽으면(디스크 꽉 참·강제 종료 등) 그 JSON이 깨져
    `load_file`이 이후 영구히 거부한다 — 자격증명 하나가 아니라 접속 설정 전체를 잃는다.
    그래서 같은 디렉터리에 임시 파일을 만들어 다 쓴 뒤 `os.replace`로 덮어씌운다 —
    `os.replace`는 POSIX·Windows 모두에서 원자적이라, 죽어도 옛 파일이나 새 파일 둘 중
    하나만 남고 절반짜리는 남지 않는다.

    임시 파일은 `tempfile.mkstemp`로 만든다 — POSIX에서 처음부터 소유자 전용(0600)
    권한으로 생성되므로(생성과 권한 조이기 사이에 세계에 읽히는 순간이 없다), 만든 뒤에
    `chmod`로 조이는 것보다 이 파일에 담긴 두 벌의 자격증명(nexus 로그인 + CAS)에
    안전하다. Windows에서는 `chmod`가 사실상 무의미해(`_warn_if_world_readable`와 같은
    이유) 건너뛴다.
    """
    p = settings_path(path)
    # load_file은 파일이 없으면 {}, JSON이 깨졌으면 에러를 낸다 — 손상된 파일을 조용히
    # 덮어써서 나머지 설정(비밀번호 등)까지 잃는 것보다는, 여기서도 그대로 실패하는 편이 낫다.
    data = dict(load_file(p))
    data["cas_key_id"] = key_id
    data["cas_secret"] = secret
    if region:
        data["cas_region"] = region
    p.parent.mkdir(parents=True, exist_ok=True)

    fd, tmp_name = tempfile.mkstemp(
        dir=str(p.parent), prefix=f".{p.name}.", suffix=".tmp"
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(json.dumps(data, ensure_ascii=False, indent=2))
        if os.name == "posix":
            # mkstemp가 이미 0600으로 만들지만, 그 사실에 조용히 기대는 대신 명시한다.
            os.chmod(tmp_name, 0o600)
        os.replace(tmp_name, p)
    except BaseException:
        try:
            os.unlink(tmp_name)
        except OSError:
            pass
        raise
