from __future__ import annotations
import os
import warnings

from nexus._types import (
    IngestResult,
    NexusAuthError,
    NexusBatchError,
    NexusCasError,
    NexusError,
    NexusIngestError,
)
from nexus import settings as _settings
from nexus.cas import CasClient
from nexus.client import NexusClient
from nexus.dataset import AnnotationSession, Dataset
from nexus.imageinfo import ImageInfo, image_info
from nexus.probe import probe
from nexus.sample import CasRef, Sample
from nexus.upload import upload

_client: NexusClient | None = None
_cas: CasClient | None = None


def _apply_insecure_tls(verify: "bool | str") -> None:
    """`verify=False`일 때 urllib3의 요청마다 나오는 경고를 억제하고 **한 번만** 우리 경고를 낸다.

    요청마다 나오는 경고는 대량 적재 로그를 뒤덮어 실제 문제를 가린다. 그렇다고 조용히
    넘기면 "이 연결은 중간자 공격을 탐지하지 못한다"는 사실이 어디에도 남지 않으므로,
    접속 시점에 한 번은 반드시 알린다.
    """
    if verify is not False:
        return
    warnings.warn(
        "TLS 인증서 검증이 꺼져 있습니다(verify=False) — 이 연결은 중간자 공격을 탐지하지 "
        "못합니다. 사내 프록시가 원인이라면 검증을 끄는 대신 루트 CA 번들 경로를 주는 쪽을 "
        "권합니다: nx.connect(verify='/path/to/corp-ca.pem') 또는 설정 파일의 \"verify\" 키.",
        stacklevel=3,
    )
    try:  # urllib3 2.x / 1.x 모두 대응
        from urllib3.exceptions import InsecureRequestWarning

        warnings.simplefilter("ignore", InsecureRequestWarning)
    except Exception:  # pragma: no cover - urllib3 내부 구조가 바뀐 경우
        pass


def _save_cas_credentials_or_explain(
    path: "str | None", key_id: str, secret: str, region: "str | None"
) -> None:
    """발급받은 자격증명을 파일에 쓴다. **쓰기가 실패해도 발급 자체는 이미 끝나 있다** —
    여기서 잡지 않고 그냥 올리면 사용자는 "접속이 실패했다"만 보고, nexus에는 이미 만든
    자격증명 하나가 조용히 남는다(다음 재시도마다 또 하나씩 늘어난다). 그래서 무슨 일이
    있었는지(발급은 됐다, key_id가 무엇이다, 수동으로 저장하거나 폐기해야 한다)를 에러
    메시지에 박아 올린다 — 최소한 사용자가 원인을 알고 조치할 수 있게.
    """
    try:
        _settings.save_cas_credentials(
            _settings.settings_path(path), key_id, secret, region
        )
    except Exception as e:
        raise NexusError(
            f"CAS 자격증명 {key_id}을(를) nexus에서 새로 발급받았지만 설정 파일에 저장하지 "
            f"못했습니다({e}). **자격증명 자체는 이미 발급되어 남아 있습니다** — 그대로 두면 "
            f"다음 접속 시도마다 또 하나씩 새로 발급됩니다. 원인(디스크 권한·용량 등)을 고친 "
            f"뒤 `nexus.settings.save_cas_credentials(path, {key_id!r}, secret, region)`으로 "
            f"직접 저장하거나, 더 쓰지 않을 거라면 "
            f"`DELETE /api/v1/auth/cas-credentials/{key_id}`로 폐기하세요."
        ) from e


def _auto_issue_cas_credentials(client: NexusClient) -> "dict | None":
    """자격증명이 비어 있을 때 nexus에서 자동으로 발급받는다.

    **503(서버에 CAS 관리 자격증명이 구성되지 않음)은 사용자 잘못이 아니다** — 그
    배포는 CAS 익명 접근만 허용하도록 운영진이 의도한 것일 수 있다. 여기서는 조용히
    포기하고 이 기능이 없던 시절과 같은 상태(자격증명 없이 접속, 서명 없는 요청은
    `CasClient._signed_headers`가 그대로 통과시킨다)로 되돌아간다.

    그 외 에러(예: 409 — cas 운영자가 이 사용자의 자격증명을 직접 폐기해 되살릴 수
    없음)는 사용자가 알아야 하는 상태이므로 삼키지 않고 그대로 올린다.
    """
    try:
        return client.issue_cas_credentials()
    except NexusError as e:
        if e.status_code == 503:
            warnings.warn(
                "서버에 CAS 관리 자격증명이 구성되지 않아 자동 발급을 건너뜁니다 — "
                "CAS 익명 접근만 가능합니다. 필요하면 CAS_KEY_ID/CAS_SECRET을 직접 "
                "지정하세요.",
                stacklevel=3,
            )
            return None
        raise


def connect(
    nexus_url: str | None = None,
    email: str | None = None,
    password: str | None = None,
    cas_url: str | None = None,
    cas_key_id: str | None = None,
    cas_secret: str | None = None,
    timeout: "float | tuple[float, float]" = (10.0, 120.0),
    verify: "bool | str | None" = None,
    settings_path: "str | None" = None,
    save_cas_credentials: bool = False,
    robot_token: "str | None" = None,
) -> NexusClient:
    """nexus/CAS에 접속한다. 인자를 하나도 안 주면 환경변수와 설정 파일에서 해소한다.

    값의 우선순위는 **인자 > 환경변수 > 설정 파일**(`~/.int2nexus/settings.json`,
    `NEXUS_SETTINGS`로 경로 변경 가능). 설정 파일에 다 적어두면 `nx.connect()` 한 줄이면 된다.

    `verify`는 TLS 인증서 검증 — `True`(기본), `False`(검증 끔), 또는 **CA 번들 경로**.
    사내 TLS 검사 장비 때문에 SSL 에러가 난다면 검증을 끄는 대신 사내 루트 CA 경로를 주는
    쪽을 권한다. nexus와 CAS 양쪽 세션에 같은 값이 적용된다.

    **CAS 자격증명이 갖춰지지 않으면 nexus가 이 계정 앞으로 자동 발급해준다**(서버에 CAS
    관리 자격증명이 구성돼 있어야 함) — 운영자가 손으로 만들어 나눠주던 것을 대체한다.

    **판정은 `cas_key_id`와 `cas_secret`이 둘 다 해소됐는가로 한다.** 둘 다 있으면 이
    단계는 실행되지 않는다 — CI·학습 파드가 환경변수로 주입하는 운영자 관리 영구
    자격증명이 항상 이기고, 그 값이 있는 한 nexus를 두드리지 않는다(그래서 파드를 띄울
    때마다 자격증명이 쌓이지 않는다). **한쪽만 있으면 발급이 일어나고 있던 쪽까지 새 값으로
    덮인다** — 한쪽만으로는 `_signed_headers`가 서명을 만들지 못해 그 값이 아무 일도 하지
    못하기 때문이다. 사용자가 넣은 값을 지우는 동작이라 덮어쓰기 전에 `warnings.warn`으로
    알린다.

    **자동 발급된 자격증명은 기본적으로 설정 파일에 쓰지 않는다**(`save_cas_credentials`,
    0.1.10 에서 `True` → `False` 로 뒤집었다). 발급 자체는 그대로 일어나고 이 프로세스
    안에서는 쓰인다 — 파일에 남기지 않을 뿐이다.

    뒤집은 이유는 **자동 발급의 결과가 파일이면 "자격증명이 사람마다 흩어지지 않게 한다" 는
    방침이 자동 발급에서 무너지기 때문**이다. 나중에 뒤집으면 그때는 이미 흩어진 파일을
    회수해야 한다. 지금은 이 경로를 타는 소비자가 없어 뒤집는 비용이 0 이다 — 웹은 CAS
    자격증명이 필요 없고, 노트북과 적재 잡은 환경변수 주입이며 **환경변수가 이긴다**(위의
    "둘 다 있으면 이 단계는 실행되지 않는다").

    저장이 맞는 배포는 `save_cas_credentials=True` 로 명시한다. 저장하지 않으면 프로세스가
    끝날 때 자격증명이 사라지고 다음 실행에서 새로 발급받으므로, `key_id` 가 쌓이는 것이
    싫으면 환경변수로 영구 자격증명을 주입하는 쪽이 맞다(그러면 발급 자체가 안 일어난다).

    **로봇 토큰**(`robot_token=` 또는 `NEXUS_ROBOT_TOKEN`)을 주면 로그인 경로를 타지 않고
    그 값이 그대로 Bearer 로 실린다. `email`/`password` 는 필요 없다. 관리자가
    `POST /api/v1/admin/robots/{user_id}/tokens` 로 발급한 `nxr_` 로 시작하는 값이고,
    워크로드는 보통 sealed-secret 에서 환경변수로 받는다.

    **로봇 토큰은 설정 파일에 저장하지 않는다.** 그 값은 배포가 주입하는 것이지 이 라이브러리가
    관리할 것이 아니고, 파일에 남기면 sealed-secret 으로 관리하는 의미가 사라진다.

    로봇 토큰에는 갱신도 재로그인도 없다. `401` 은 그대로 올라간다 — 폐기·만료·계정 정지
    중 무엇이든 관리자가 조작해야 풀리고, 재시도해 봐야 같은 값을 다시 보내는 것뿐이다.
    """
    # bucket은 전역 기본값을 두지 않는다 — nx.upload(paths, bucket=...)에서 호출별로 지정.
    # timeout=(connect, read) — read를 넉넉히(배치 적재가 오래 걸릴 수 있음). 없으면 정체가 무한 hang.
    global _client, _cas

    # 인자 > 환경변수. 설정 파일은 보지 않는다 — 로봇 토큰은 배포가 주입하는 값이고,
    # 파일에 남기면 sealed-secret 으로 관리하는 의미가 사라진다.
    resolved_robot_token = robot_token or os.environ.get("NEXUS_ROBOT_TOKEN") or None

    cfg = _settings.resolve(
        path=settings_path,
        require_login=resolved_robot_token is None,
        nexus_url=nexus_url,
        email=email,
        password=password,
        cas_url=cas_url,
        cas_key_id=cas_key_id,
        cas_secret=cas_secret,
        verify=verify,
    )
    _apply_insecure_tls(cfg["verify"])

    client = NexusClient(
        cfg["nexus_url"], cfg["email"] or "", cfg["password"] or "",
        timeout=timeout, verify=cfg["verify"],
        robot_token=resolved_robot_token,
    )
    _client = client

    # settings.resolve()가 file/env에서 region을 읽어와 채워둔 값(둘 다 없으면
    # CasClient 기본값과 같은 "cas-default"). 자동 발급이 성공하면 서버 응답값으로
    # 갈아 끼운다 — 아래 IMPORTANT 4 참조(region을 저장해두지 않으면 기본 region이 아닌
    # 배포에서 다음 프로세스부터 영원히 403이 난다).
    region = cfg["cas_region"]
    on_forbidden = None
    if not cfg["cas_key_id"] or not cfg["cas_secret"]:
        if cfg["cas_key_id"] or cfg["cas_secret"]:
            # 한쪽만 있으면 어차피 서명에 못 쓴다(`_signed_headers`가 둘 다 있어야
            # 서명한다) — 자동 발급이 조용히 그 반쪽짜리를 덮어쓰기 전에 알린다.
            warnings.warn(
                "CAS_KEY_ID/CAS_SECRET 중 한쪽만 설정되어 있어 그것만으로는 서명할 수 "
                "없습니다. nexus에서 새로 발급받아 두 값을 함께 덮어씁니다.",
                stacklevel=3,
            )
        issued = _auto_issue_cas_credentials(client)
        if issued is not None:
            cfg["cas_key_id"] = issued["cas_key_id"]
            cfg["cas_secret"] = issued["secret_key"]
            # 명시 인자로 준 cas_url이 있으면(즉 resolve()가 이미 채워뒀으면) 그게
            # 이긴다 — 이 모듈의 문서화된 우선순위(인자 > 환경변수 > 설정 파일)를
            # nexus의 자동 응답값이 뒤엎으면 안 된다. cas_url이 `_REQUIRED`라 지금은
            # 이 분기가 거의 항상 비어 있지 않은 값을 보지만, 나중에 cas_url이 선택이
            # 되더라도 규칙이 깨지지 않도록 명시적으로 "비어 있을 때만" 채운다.
            if not cfg["cas_url"]:
                cfg["cas_url"] = issued["cas_url"]
            region = issued["region"] or region
            cfg["cas_region"] = region
            if save_cas_credentials:
                _save_cas_credentials_or_explain(
                    settings_path, cfg["cas_key_id"], cfg["cas_secret"], region,
                )

            def on_forbidden() -> "tuple[str, str]":
                """CAS가 403을 주면(발급된 자격증명이 그 사이 폐기됨) 한 번 다시 발급받는다.

                **"한 번"은 이 `CasClient`가 사는 동안 통틀어 한 번이다** — 요청마다가
                아니다(`cas.py::_REISSUE_BUDGET`). 이 기능이 붙이는 정책에서 403은 예외가
                아니라 정상 응답이라(`viewer`의 쓰기, `annotations/`·`manifests/` 접두사)
                요청당 예산이면 그런 호출 하나마다 자격증명이 하나씩 발급되고 상한 정리가
                남의 자격증명을 그만큼 폐기한다.

                **자동 발급된 자격증명에만 건다.** 사용자가 직접(인자·환경변수·설정
                파일로) 넣은 자격증명은 운영자가 관리하는 영구 자격증명일 수 있어,
                그걸 403 한 번에 nexus 자동 발급으로 바꿔치기하면 위 docstring의
                탈출구(escape hatch)가 조용히 무력화된다. 재발급 자체가 409(cas
                운영자가 직접 폐기해 되살릴 수 없음)면 여기서 잡지 않고 그대로
                올린다 — `cas.py::_retry_with_fresh_credentials` 참조.

                호출 횟수 제한도 잠금도 이 함수는 모른다 — 동시 호출 억제
                (`_forbidden_lock`)와 클라이언트당 예산 둘 다 `CasClient`가 한다.
                """
                fresh = client.issue_cas_credentials()
                if save_cas_credentials:
                    _save_cas_credentials_or_explain(
                        settings_path, fresh["cas_key_id"], fresh["secret_key"],
                        fresh.get("region") or region,
                    )
                return fresh["cas_key_id"], fresh["secret_key"]

    _cas = CasClient(
        cfg["cas_url"], cfg["cas_key_id"], cfg["cas_secret"],
        region=region, verify=cfg["verify"], on_forbidden=on_forbidden,
    )
    return client


def _auto_connect() -> NexusClient:
    global _client
    if _client is None:
        connect()
    return _client  # type: ignore[return-value]


def list_datasets(
    *,
    q: str | None = None,
    name: str | None = None,
    description: str | None = None,
    tags: "str | list[str] | None" = None,
    sort: str | None = None,
    order: str | None = None,
    favorite: bool = False,
    mine: bool = False,
    unowned: bool = False,
    limit: int | None = None,
    cursor: str | None = None,
    client: NexusClient | None = None,
) -> list[dict]:
    """등록된 dataset 목록(dict 리스트).

    각 항목: `dataset_id`/`name`/`description`/`tags`/`created_at`와 **`versions`**(버전 문자열
    목록, 예 `['v0','v1']`), **`is_favorite`**(내 즐겨찾기 여부). 옵션 — `name`/`description`: 부분
    검색(ILIKE), `tags`: 하나라도 포함(ANY), `sort`: "name"|"created_at"(기본), `order`: "asc"/"desc"(기본
    desc), `favorite`: True면 내 즐겨찾기만, `mine`: 내가 담당인 것만, `unowned`: 담당자가 없는 것만.

    **`limit`을 안 주면 커서를 자동으로 순회해 전체를 모은다**(서버 0.1.7부터 한 응답에
    기본 100개까지만 실린다). `limit`에 숫자를 주면 그 개수만큼 한 페이지만 반환한다.
    """
    c = client or _auto_connect()
    return c.list_datasets(
        q=q, name=name, description=description, tags=tags, sort=sort, order=order,
        favorite=favorite, mine=mine, unowned=unowned, limit=limit, cursor=cursor,
    )


def annotation_session(
    session_id: str, *, client: NexusClient | None = None
) -> "AnnotationSession":
    """`session_id`로 기존 세션을 다시 잡는다.

    세션은 파이썬 프로세스와 무관하게 서버에 남아 있다 — 스크립트를 껐다 켜도, 다른
    사람이 만든 세션이어도 id만 있으면 이어받을 수 있다. 목록에서 고르려면
    :func:`annotation_sessions` 를 쓴다.
    """
    c = client or _auto_connect()
    return AnnotationSession(c, c.get_annotation_session(session_id))


def annotation_sessions(
    *,
    status: "str | None" = None,
    dataset_id: str | None = None,
    mine: bool = False,
    limit: int | None = None,
    client: NexusClient | None = None,
) -> "list[AnnotationSession]":
    """**전역** CVAT 편집 세션 목록 — dataset·버전을 가로질러 "지금 진행 중인 것"을 모은다.

    기본은 진행 중인 것만(`status="active"` = creating+open)이다. 이력까지 보려면 `"all"`,
    특정 상태만 보려면 `"open"`/`"closed"`/`"failed"`. `mine=True`면 내가 만든 것만.

    각 항목은 `dataset_name`/`version`/`sample_count`를 이미 담고 있어 추가 조회 없이
    목록을 그릴 수 있다. 다만 `has_unimported_changes`는 목록에서 항상 `None`이다
    (세션마다 CVAT 호출이 필요해서) — 필요하면 `.refresh()` 후 읽을 것.
    """
    c = client or _auto_connect()
    rows = c.list_annotation_sessions(
        dataset_id=dataset_id, status=status, mine=mine, limit=limit
    )
    return [AnnotationSession(c, r) for r in rows]


__all__ = [
    "connect",
    "list_datasets",
    "annotation_sessions",
    "annotation_session",
    "Dataset",
    "AnnotationSession",
    "Sample",
    "CasRef",
    "upload",
    "probe",
    "image_info",
    "ImageInfo",
    "IngestResult",
    "NexusError",
    "NexusAuthError",
    "NexusCasError",
    "NexusIngestError",
    "NexusBatchError",
]
