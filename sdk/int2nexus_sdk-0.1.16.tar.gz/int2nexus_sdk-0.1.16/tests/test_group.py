import pytest
from nexus.group import LabelGroup, RawGroup
from nexus.instance import Instance


def test_labelgroup_roundtrip():
    rows = [{"id": "a", "label": "car", "bounding_box": {"type": "bounding_box", "rect": [0, 0, 1, 1]}}]
    g = LabelGroup.from_list(rows)
    assert len(g) == 1
    assert isinstance(g[0], Instance)
    assert g.to_list() == rows


def test_labelgroup_add_remove():
    g = LabelGroup([])
    inst = Instance(id="x", label="a", components={})
    g.add(inst)
    assert len(g) == 1
    g.remove(inst)
    assert len(g) == 0


def test_rawgroup_verbatim_even_when_not_a_list():
    weird = {"unexpected": "shape"}
    rg = RawGroup(weird)
    rg.validate()  # no-op
    assert rg.to_raw() == weird
    rows = [{"anything": 1}]
    assert RawGroup(rows).to_raw() == rows


def _row(t="bounding_box"):
    return {"id": "a", "label": "car", t: {"type": t, "rect": [0, 0, 1, 1]}}


def test_container_roundtrip_and_labels_accessor():
    from nexus.group import LabelContainer
    c = LabelContainer.from_list([_row(), _row()])
    c.validate()
    assert c.element_type == "bounding_box"
    assert len(c.labels) == 2
    assert c.to_list() == [_row(), _row()]


def test_container_rejects_multi_component_row():
    from nexus.group import LabelContainer
    from nexus._types import NexusValidationError
    row = {"id": "a", "label": "car",
           "bounding_box": {"type": "bounding_box", "rect": [0, 0, 1, 1]},
           "extra": {"type": "classification", "label": "x"}}
    with pytest.raises(NexusValidationError):
        LabelContainer.from_list([row]).validate()


def test_container_rejects_mixed_types():
    from nexus.group import LabelContainer
    from nexus._types import NexusValidationError
    with pytest.raises(NexusValidationError):
        LabelContainer.from_list([_row("bounding_box"), _row("classification")]).validate()
