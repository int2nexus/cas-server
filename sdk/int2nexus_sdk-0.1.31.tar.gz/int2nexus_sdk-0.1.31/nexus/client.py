from __future__ import annotations
import base64
import json
import math
import numbers
import random
import threading
import time
import warnings

import requests
from nexus import _retry
from nexus._types import (
    NexusAuthError,
    NexusError,
    NexusIngestError,
    NexusValidationError,
    NexusSchemaJobPending,
    NexusVersionJobPending,
    _raise_for_status,
)
from nexus._version import apply_user_agent
from nexus.oidc import read_token as _read_oidc_token
from urllib.parse import quote

# 만료 이 시간 전부터 미리 갱신한다. 토큰 수명(24시간)에 비하면 짧지만, 요청 하나가
# 이 창을 넘겨 만료되는 일이 없을 만큼은 길다.
_REFRESH_MARGIN_SECS = 300

# 서버가 적재 유입 제어로 429를 낼 때 물러났다 다시 오는 횟수. 8회면 아래 백오프로
# 최대 90초 남짓을 버틴다 — 관측된 포화 구간(수 분)을 전부 덮지는 못하지만, 그보다
# 길어지면 조용히 매달려 있는 것보다 호출부에 알리는 편이 낫다.
_MAX_THROTTLE_RETRIES = 8

# seal 이 파드당 동시 seal 상한(서버 0.1.21~)에 걸려 429 를 받았을 때 기다리는 기본 시간(초).
# 기다리는 대상이 적재 포화가 아니라 **앞 seal 의 길이**(큰 버전은 수 분)라 위의 8 회(약 90~140 초)로는
# 큰 seal 하나를 못 넘긴다. 10 분이면 수십 초짜리 seal 이 여럿 줄 서 있어도 덮는다.
_SEAL_WAIT_SECS = 600.0
# 인자를 안 준 것과 `None`(명시적으로 지움)을 가르는 표지 — 안 주면 seal 은 본문 없이 나간다.
_UNSET = object()
# seal 대기 중 다시 물어보는 간격의 상한(초). 일반 백오프처럼 30 초까지 키우면 앞 seal 이 끝난 뒤에도
# 그만큼 놀게 된다 — seal 은 끝나는 순간 자리가 나므로 짧게 자주 묻는 편이 맞다.
_SEAL_POLL_CAP_SECS = 15.0
# 202(대기 작업) 뒤 `GET /api/v1/version-jobs/{id}` 를 다시 묻는 간격(초).
_VERSION_JOB_POLL_SECS = 2.0
_VERSION_JOB_FAILED_STATES = ("failed", "cancelled")
# 스키마 재계산 작업의 실패 끝 상태 — 서버 표의 CHECK 가 `cancelled` 를 받는다(지금은 취소 경로가 없다).
_SCHEMA_JOB_FAILED_STATES = ("failed", "cancelled")
# 대기 예산에 맞춰 조회 시한을 깎을 때의 하한(초).
_POLL_MIN_TIMEOUT_SECS = 1.0
# 옛 서버라 스키마 작업 경로가 없을 때 `NexusError.code` 에 싣는 SDK 쪽 값(서버가 내는 code 가 아니다).
SCHEMA_JOBS_UNSUPPORTED = "schema_jobs_unsupported"
# 재계산 요청이 2xx 인데 본문에 작업이 없을 때 `NexusError.code` 에 싣는 SDK 쪽 값.
SCHEMA_JOB_MISSING = "schema_job_missing"
# 지정 삭제의 종류 → 경로 조각.
_SCHEMA_DELETE_KINDS = {"labels": "labels", "components": "components", "meta_fields": "meta-fields"}


# 운영자가 draft 대량 읽기를 끈 서버(0.1.29~)가 이 표시가 붙은 draft 읽기를 거절한다. 옛 서버는 헤더를 무시한다.
_BULK_READ_HEADER = {"x-nexus-bulk-read": "1"}
_DRAFT_BULK_READ_DISABLED = "draft_bulk_read_disabled"
_DRAFT_BULK_READ_MESSAGE = "운영자가 draft 대량 읽기를 껐습니다 — sealed 버전을 쓰십시오"
# 인증된 응답에 서버가 싣는 자기 판(nexus-server 0.1.29~). 없으면 그 응답을 준 파드가 0.1.28 이하다.
VERSION_HEADER = "X-Nexus-Version"
# 샘플 태그·크기 보정이 버전 경로(`/datasets/{id}/versions/{v}/...`)로 옮겨 간 서버 판(서버 설계 2026-10-30
# version-scoped-sample-fields 7-1). **실제로 발행하는 서버 판 번호와 같아야 한다** - 발행 판이 정해지면 맞춘다.
# 이 판 미만이거나 `X-Nexus-Version` 이 없는(0.1.28 이하) 파드는 옛 경로(`/samples/tags`·`/samples/dimensions`)를 쓴다.
VERSION_PATHS_MIN_SERVER = (0, 1, 37)


def parse_server_version(value: "str | None") -> "tuple[int, ...] | None":
    """`"0.1.29"` → `(0, 1, 29)`. 없거나 읽을 수 없으면 `None`."""
    if not value:
        return None
    try:
        return tuple(int(p) for p in value.strip().split("-")[0].split("."))
    except ValueError:
        return None


def _draft_bulk_read_error(e: NexusError) -> NexusError:
    """403 `draft_bulk_read_disabled` 를 고정 문구의 `NexusError` 로 바꾼다. 다른 오류는 그대로 돌려준다."""
    if e.status_code == 403 and e.code == _DRAFT_BULK_READ_DISABLED:
        return NexusError(
            _DRAFT_BULK_READ_MESSAGE, status_code=403,
            server_message=e.server_message, code=_DRAFT_BULK_READ_DISABLED,
        )
    return e


def _seg(value: str) -> str:
    """경로 **한 조각**으로 인코딩한다(`/` 까지). 버전 이름은 사용자가 정하는 문자열이라
    `#` `?` `/` 가 들어갈 수 있는데, 그대로 두면 `#` 뒤가 fragment 로 떨어져 요청이 다른 버전으로
    가고 `/` 는 경로를 한 칸 늘린다. 공백·한글은 requests 가 원래 같은 값으로 인코딩했다."""
    return quote(str(value), safe="")


def _throttle_delay(response: "requests.Response", attempt: int, cap: float = 30.0) -> float:
    """429를 받고 다시 오기까지 기다릴 시간(초).

    **`Retry-After`와 지수 백오프 중 큰 쪽**을 쓴다. 헤더는 서버가 정한 하한이라
    그보다 일찍 오면 안 되고, 헤더 값만 따르면(지금 서버는 항상 `1`이다) 8회가 8초
    만에 소진돼 포화가 몇 분 가는 상황에서 아무것도 못 한다.

    거기에 지터를 **위로만** 얹는다. 이 결함이 실제로 터진 상황이 **다섯 클라이언트가
    동시에 재개한 것**이었다 — 전원이 같은 순간 429를 받고 같은 시간을 기다리면 다시
    같은 순간에 몰려 온다. 아래로도 흔들면 `Retry-After`보다 일찍 오게 되므로 위로만
    흔든다(1.0~1.5배).
    """
    floor = 0.0
    raw = response.headers.get("Retry-After")
    if raw:
        try:
            floor = max(0.0, float(raw.strip()))
        except ValueError:
            floor = 0.0
    backoff = min(0.5 * (2 ** attempt), cap)
    return max(floor, backoff) * (1.0 + 0.5 * random.random())


def _jwt_exp(token: str) -> "int | None":
    """JWT payload의 `exp`를 **검증 없이** 읽는다. 못 읽으면 None.

    서명을 확인하지 않는 것이 맞다 — 검증은 서버가 한다. 여기서 필요한 건 "언제쯤
    갱신해야 하나"라는 힌트뿐이고, 값이 틀려도 최악의 경우 갱신 시점이 어긋날 뿐
    (그러면 401 재로그인이 받아준다). 이 값으로 권한 판단을 하지 않는다.
    """
    try:
        payload = token.split(".")[1]
        payload += "=" * (-len(payload) % 4)  # base64url은 패딩이 없다
        exp = json.loads(base64.urlsafe_b64decode(payload))["exp"]
        return int(exp)
    except Exception:
        return None


def _check_wait(wait) -> None:
    # 유한한 0 이상의 숫자만 받는다(`_retry.resolve_timeout` 과 같은 기준). `nan` 은 모든 비교가 거짓이라
    # 대기 상한이 영영 걸리지 않고, bool·None·문자열은 비교에서 TypeError 가 되거나 뜻이 흐려진다.
    if (
        isinstance(wait, bool)
        or not isinstance(wait, numbers.Real)
        or not math.isfinite(wait)
        or wait < 0
    ):
        raise ValueError(f"wait 는 0 이상의 유한한 초여야 합니다: {wait!r}")


class NexusClient:
    def __init__(
        self,
        nexus_url: str,
        email: str,
        password: str,
        timeout: "float | tuple[float, float]" = (10.0, 120.0),
        verify: "bool | str" = True,
        robot_token: "str | None" = None,
        oidc: "OidcAuth | None" = None,
        retry_timeout: "float | None" = None,
    ) -> None:
        self._base = nexus_url.rstrip("/")
        self._session = requests.Session()
        # `User-Agent`에 `int2nexus-sdk/<version>`을 싣는다 — 서버 요청 로그의 `ua`가
        # 지금까지 `python-requests/<version>`만 받아 SDK 버전을 밖에서 알 수 없었다.
        # 세션에 한 번 걸어 모든 요청(로그인·갱신 포함)이 덮이게 한다.
        apply_user_agent(self._session)
        # TLS 검증 설정을 **세션에 한 번** 건다 — `_login`과 `_get`/`_post`/... 전부는 물론
        # 세션을 직접 쓰는 get_dataset/get_version까지 한 번에 덮인다. 메서드마다 인자를
        # 흘리면 나중에 메서드를 추가할 때 빠뜨리기 쉽고, 그 누락은 "어떤 호출만 SSL 에러"라는
        # 재현하기 어려운 증상으로 나타난다.
        # `verify`는 bool 또는 **CA 번들 경로**(사내 루트 CA). 검증을 끄는 것보다 경로 쪽이 안전하다.
        self._session.verify = verify
        # flush가 배치를 병렬 POST하므로 커넥션 풀을 넉넉히 — 기본 pool_maxsize(10)면
        # 동시성 초과 시 커넥션을 버리고 재생성해 오버헤드가 난다.
        adapter = requests.adapters.HTTPAdapter(pool_connections=32, pool_maxsize=32)
        self._session.mount("http://", adapter)
        self._session.mount("https://", adapter)
        # (connect, read) 타임아웃. read는 서버가 응답 바이트를 보내기까지 허용 시간 —
        # 없으면(requests 기본) 일시적 커넥션 정체가 **무한 hang**으로 굳는다. 배치 처리가
        # 오래 걸릴 수 있어 read는 넉넉히. 호출부가 kwargs로 개별 override 가능.
        self._timeout = timeout
        self._token: str | None = None
        self._token_exp: int | None = None
        # 갱신 API가 없는 구버전 서버(< 0.1.1)를 만나면 켜진다 — 매 요청마다 404를
        # 두드리지 않기 위해. SDK가 구서버에서도 그대로 동작해야 한다.
        self._refresh_unsupported = False
        # 가장 최근 응답이 알린 서버 판(`X-Nexus-Version`). 헤더가 없는 응답은 건드리지 않는다.
        self._server_version: "tuple[int, ...] | None" = None
        # 토큰이 만료되면(수명 24시간) 다시 로그인하기 위해 자격증명을 들고 있는다.
        # 없으면 오래 도는 프로세스·노트북이 하루 뒤부터 전부 401로 죽고, 사용자는
        # 스크립트를 재시작하는 것 말고 방법이 없다. 비밀번호가 프로세스 메모리에
        # 남지만, 애초에 설정 파일(~/.int2nexus/settings.json)에 평문으로 있다.
        self._email = email
        self._password = password
        # flush가 배치를 병렬 POST하므로 여러 스레드가 동시에 401을 받을 수 있다.
        # 락이 없으면 그 수만큼 로그인 요청이 몰린다.
        self._auth_lock = threading.Lock()
        # 서버 부재를 기다리는 시간(첫 실패부터, 스펙 §4-1). `None` 이면 NEXUS_RETRY_TIMEOUT, 없으면 120 초.
        self._retry_timeout = _retry.resolve_timeout(retry_timeout)
        # 서버가 멱등 키를 처리한다는 헤더를 본 적이 있는가. 한 번이라도 보면 켠다 — 로그인 응답을 포함한 **모든 응답**이
        # 지나는 세션 훅으로 본다. `get_dataset` 처럼 세션을 직접 쓰는 호출도 덮인다.
        self._ingest_idempotency = False
        self._session.hooks["response"].append(self._observe_response)

        # **로봇 토큰은 로그인 경로를 타지 않는다.** 값이 그대로 Bearer 로 실린다.
        #
        # 갱신도 재로그인도 하지 않는다. `_maybe_refresh`는 `_token_exp`가 `None`이면
        # 즉시 돌아가고(로봇 토큰은 JWT가 아니라 만료를 파싱할 수 없다), `_relogin`은
        # 아래에서 명시적으로 막는다 — 서버가 로봇 토큰의 `refresh`를 403으로 막으므로
        # 시도 자체가 무의미하고, 401을 받은 진짜 이유(폐기·만료·계정 정지)를
        # 재로그인 실패로 덮어써서 가린다.
        self._robot_token = robot_token

        # **OIDC 직접 인증**(`token_file`/`token_provider`). 서버가 OIDC 토큰을 요청마다
        # 직접 Bearer 로 받으므로(교환 없이) 로그인 경로를 타지 않는다. `robot_token` 과
        # 다른 점은 토큰이 **시간이 지나면 바뀐다**는 것이다 — 그래서 헤더에 한 번 박지
        # 않고 `_maybe_refresh`(선제)·`_relogin`(401 시)이 출처에서 다시 가져온다. 회전은
        # 출처(kubelet 파일 교체 / provider)가 지고, 서버는 OIDC 요청의 `refresh` 를
        # 403 으로 막는다. `robot_token` 과는 상호배타다 — 둘 다 로그인을 대체하므로 함께
        # 받으면 어느 쪽이 이기는지가 모호하다(`connect` 가 값 단계에서 막지만, 직접
        # 생성하는 경로도 여기서 막는다).
        self._oidc = oidc
        if oidc is not None and robot_token is not None:
            raise ValueError("robot_token 과 oidc 는 함께 줄 수 없습니다")

        if oidc is not None:
            # 최초 토큰을 지금 가져온다. 출처가 틀렸으면(파일 없음·provider 예외) 여기서
            # `NexusAuthError` 로 실패한다 — 로그인이 최초에 실패하는 것과 같은 자리다.
            self._set_token(_read_oidc_token(oidc))
        elif robot_token is not None:
            # **로봇 토큰은 로그인 경로를 타지 않는다.** 값이 그대로 Bearer 로 실린다.
            #
            # 갱신도 재로그인도 하지 않는다. `_maybe_refresh`는 `_token_exp`가 `None`이면
            # 즉시 돌아가고(로봇 토큰은 JWT가 아니라 만료를 파싱할 수 없다), `_relogin`은
            # 아래에서 명시적으로 막는다 — 서버가 로봇 토큰의 `refresh`를 403으로 막으므로
            # 시도 자체가 무의미하고, 401을 받은 진짜 이유(폐기·만료·계정 정지)를
            # 재로그인 실패로 덮어써서 가린다.
            self._token = robot_token
            self._token_exp = None
            self._session.headers["Authorization"] = f"Bearer {robot_token}"
        else:
            self._login(email, password)

    def _login(self, email: str, password: str) -> None:
        r = self._session.post(
            f"{self._base}/api/v1/auth/login",
            json={"email": email, "password": password},
            timeout=self._timeout,
        )
        if not r.ok:
            raise NexusAuthError(
                f"Login failed ({r.status_code}): {r.text}",
                status_code=r.status_code,
                server_message=r.text or None,
            )
        self._set_token(r.json()["token"])

    def _set_token(self, token: str) -> None:
        self._token = token
        self._token_exp = _jwt_exp(token)
        self._session.headers["Authorization"] = f"Bearer {token}"

    def _observe_response(self, r: requests.Response, *args, **kwargs) -> None:
        if r.headers.get(_retry.IDEMPOTENCY_HEADER) == "1":
            self._ingest_idempotency = True

    def _ingest_is_idempotent(self, path: str, kwargs: dict) -> bool:
        """이 `/ingest` 요청을 다시 보내도 되는가 — 서버가 지원을 알렸고 모든 item 에 키가 있을 때만."""
        if not self._ingest_idempotency:
            return False
        body = kwargs.get("json")
        if path == "/ingest/batch":
            items = body.get("items") if isinstance(body, dict) else None
        elif path == "/ingest":
            items = [body]
        else:
            return False
        return bool(items) and all(isinstance(i, dict) and i.get("idempotency_key") for i in items)

    def _maybe_refresh(self) -> None:
        """만료가 가까우면 **미리** 토큰을 갱신한다.

        만료된 **뒤에는** 갱신할 수 없다(서버가 401). 그래서 이건 401 재로그인을 대체하는
        게 아니라 그 앞을 막는 것이고, 재로그인은 폴백으로 남는다 — 프로세스가 절전되거나
        오래 멈춰 있어 갱신 시점을 놓치는 경우가 있다.

        갱신이 재로그인보다 나은 이유는 비용이다. 로그인은 bcrypt(cost 12) 검증을 하므로
        수백 ms가 걸리는데, 갱신은 DB 조회 한 번이다. 비밀번호를 네트워크로 다시 보내지
        않는 것도 이점이다.

        **실패해도 조용히 넘어간다.** 여기서 예외를 올리면 갱신이라는 부수적인 일 때문에
        정작 사용자의 요청이 죽는다. 실패하면 원래 토큰으로 진행하고, 만료됐으면 401
        재로그인이 받아준다.
        """
        # OIDC 는 `refresh` 엔드포인트가 아니라 **출처에서 다시 가져오는 것**이 갱신이다
        # (서버가 OIDC 요청의 `refresh` 를 403 으로 막는다). 파일이면 다시 읽고 provider 면
        # 다시 부른다 — 그 사이 kubelet/코드가 새 토큰을 준비해 둔다.
        if self._oidc is not None:
            self._oidc_maybe_refetch()
            return
        if self._refresh_unsupported or self._token_exp is None:
            return
        if self._token_exp - time.time() > _REFRESH_MARGIN_SECS:
            return
        with self._auth_lock:
            # 병렬 flush에서 여러 스레드가 동시에 도달한다. 락 안에서 다시 확인해
            # 갱신이 한 번만 일어나게 한다.
            if self._token_exp is None or self._token_exp - time.time() > _REFRESH_MARGIN_SECS:
                return
            try:
                r = self._session.post(
                    f"{self._base}/api/v1/auth/refresh", timeout=self._timeout
                )
            except requests.RequestException:
                return
            if r.status_code == 404:
                # 갱신 API가 없는 구버전 서버(< 0.1.1). 매 요청마다 두드리지 않도록 꺼둔다.
                self._refresh_unsupported = True
                return
            if not r.ok:
                return
            try:
                self._set_token(r.json()["token"])
            except (ValueError, KeyError):
                return

    def _oidc_maybe_refetch(self) -> None:
        """OIDC 토큰의 만료가 가까우면 출처에서 다시 가져온다(선제).

        `exp` 를 못 읽으면(비 JWT 등) 조용히 둔다 — 언제 갱신할지 알 수 없고, 매 요청
        provider 를 부르면 네트워크 왕복이 요청마다 붙는다. 만료되면 401 재취득이 받는다.
        **실패해도 조용히 넘어간다** — `_maybe_refresh` 와 같은 이유다(부수적인 일).
        """
        if self._token_exp is None:
            return
        if self._token_exp - time.time() > _REFRESH_MARGIN_SECS:
            return
        with self._auth_lock:
            # 병렬 flush 에서 여러 스레드가 동시에 도달한다. 락 안에서 다시 확인해 재취득이
            # 한 번만 일어나게 한다(password 경로의 락 재확인과 같다).
            if self._token_exp is None or self._token_exp - time.time() > _REFRESH_MARGIN_SECS:
                return
            try:
                self._set_token(_read_oidc_token(self._oidc))
            except NexusAuthError:
                # `_relogin` 과 같은 예외만 잡는다 — `_read_oidc_token` 은 provider 예외까지
                # `NexusAuthError` 로 감싸므로 이걸로 충분하고, 여기서 `except Exception` 을
                # 쓰면 예상 못 한 버그(예: `_set_token` 내부)까지 삼켜 갱신이 조용히 멈춘다.
                return

    # _get/_post/_put/_delete raise NexusError(status_code=, server_message=) on non-2xx —
    # server_message는 서버 응답 바디의 {"error": "..."} 텍스트(str(requests.HTTPError)와 달리
    # 안 사라짐). 대부분의 호출부(list_datasets, create_dataset, create_version, delete_version 등)는
    # 이 NexusError를 그대로 전파한다; ingest()/get_manifest()/get_sample() 등 일부만 잡아서
    # 더 구체적인 타입(NexusIngestError)이나 상태코드별 메시지로 재포장한다.
    # 모든 호출에 기본 timeout을 건다(호출부가 timeout= 로 덮어쓸 수 있음).
    def _send(
        self, method: str, path: str, *, throttle_wait: "float | None" = None,
        resend: bool = True, throttle_waited: "list[float] | None" = None,
        retry_until: "float | None" = None, **kwargs
    ) -> requests.Response:
        """모든 API 호출이 지나는 곳.

        - **401이면 한 번 다시 로그인하고 재시도한다**(`_send_once`). 서버가 401을 내는 지점은 요청 본문을 보기도 전인
          인증 추출기라 부작용이 없다. 자격증명 자체가 틀렸으면 재로그인이 실패하고 원래의 401이 올라간다.
          (본문은 전부 `json=`이라 재직렬화된다 — 스트림·파일 업로드가 있었다면 재시도가 성립하지 않는다.)
        - **429도 물러났다 다시 온다**(`_send_once`, 서버 0.1.9부터 `/ingest/batch`가 유입 제어로 낸다). 자리를 얻지 못해
          거부한 것이라 부작용이 없다. 소진되면 429가 그대로 올라간다. `throttle_wait` 를 주면 횟수(8 회) 대신 그
          초만큼 기다린다 — seal 처럼 앞 요청이 끝나야 자리가 나는 429 용이다(`seal`).
        - **서버 부재(연결 실패·502·503·504)는 `retry_timeout` 까지 다시 보낸다**(0.1.19, 스펙 §4-2). 요청이 서버에 닿지
          않은 실패는 무엇이든, 처리됐을지 모르는 실패는 다시 보내도 결과가 같은 요청만(`_retry.is_safe`). `/ingest` 는
          서버가 `X-Nexus-Idempotency` 를 알렸고 모든 item 에 `idempotency_key` 가 있을 때만 — 그 밖의 재전송은 중복이다.
          nexus 가 스스로 낸 503·504(`X-Request-Id` 있음)는 기다려도 풀리지 않아 다시 보내지 않는다.
        - `resend=False` 면 **서버에 닿지 않은 실패(연결 거부·연결 타임아웃)만** 다시 보낸다. 다시 보내도 결과는 같지만
          서버에서 아직 돌고 있을 수 있는 무거운 요청(전수 모드 facet 개수)에 쓴다 — 읽기 타임아웃·프록시 504 뒤에
          다시 보내면 같은 집계가 DB 커넥션을 하나 더 쥔다.
        - **무거운 읽기는 예외다**(`_retry.is_heavy_read` — explorer·explorer/count POST, `GET /subsets/{id}/samples`):
          연결을 맺은 뒤 응답 헤더를 기다리다 난 읽기 시한 초과와 nexus 가 내지 않은 504 는 다시 보내지 않고 올린다(시한
          초과에는 `_retry.HEAVY_READ_HINT` 를 붙인다). 서버에서 같은 전체 탐색이 아직 돌고 있을 수 있어 다시 보내면 부하가
          두 배다. 연결 단계 실패·502·503·본문을 받던 도중의 시한 초과(헤더가 왔으니 서버 일은 끝났다)는 위 규칙 그대로이고,
          401 재로그인 요청 자체의 시한 초과도 종전처럼 다시 보낸다.
        - `retry_until`(단조 시계 절대 시각)을 주면 그때를 넘겨 다시 보내지 않는다 — 작업 대기처럼 호출부에 `wait`
          예산이 있는 조회용이다(`retry_timeout` 이 남아 있어도 끊는다).
        """
        self._maybe_refresh()
        kwargs.setdefault("timeout", self._timeout)
        url = f"{self._base}{path}"
        deadline = _retry.Deadline(self._retry_timeout, until=retry_until)
        # 429 로 기다린 합(`throttle_wait` 용). **부재 재시도를 건너 이어 센다** — `_send_once` 안에서만 세면
        # seal 폴링 도중 파드 교체로 연결이 끊길 때마다 0 부터 다시 세어 `wait` 를 넘긴다.
        if throttle_waited is None:
            throttle_waited = [0.0]
        while True:
            try:
                r = self._send_once(
                    method, url, deadline, throttle_wait=throttle_wait,
                    throttle_waited=throttle_waited, **kwargs,
                )
            except requests.RequestException as e:
                # 401 재로그인(`_login`) 도중의 연결 실패도 여기로 온다. 그 실패는 무거운 읽기 자체의 시한이 아니므로
                # 무거운 읽기 규칙을 쓰지 않는다(`heavy_read=False`).
                relogin_failure = getattr(e, _retry.RELOGIN_FAILURE_ATTR, False)
                if not resend:
                    if not _retry.is_connect_phase(e):
                        raise
                elif not _retry.should_retry(
                    method, path, exc=e, ingest_idempotent=self._ingest_is_idempotent(path, kwargs),
                    heavy_read=False if relogin_failure else None,
                ):
                    # 무거운 읽기의 시한 초과는 다시 보내지 않고 올린다 — 예외 타입은 그대로, 이유만 붙인다.
                    if (
                        not relogin_failure
                        and _retry.is_heavy_read(method, path)
                        and _retry.is_post_connect_timeout(e)
                        and hasattr(e, "add_note")
                    ):
                        e.add_note(_retry.HEAVY_READ_HINT)
                    raise
                delay = deadline.next_delay()
                if delay is None:
                    raise
                time.sleep(delay)
                continue
            self._note_server_version(r)
            if resend and _retry.should_retry(
                method,
                path,
                status=r.status_code,
                from_nexus=_retry.REQUEST_ID_HEADER in r.headers,
                ingest_idempotent=self._ingest_is_idempotent(path, kwargs),
            ):
                delay = deadline.next_delay()
                if delay is not None:
                    time.sleep(delay)
                    continue
            return r

    def _send_once(
        self,
        method: str,
        url: str,
        deadline: "_retry.Deadline",
        *,
        throttle_wait: "float | None" = None,
        throttle_waited: "list[float] | None" = None,
        **kwargs,
    ) -> requests.Response:
        """401 재로그인과 429 물러남을 처리하는 한 번의 전송(부재 재시도는 `_send`).

        429 로 물러난 시간은 그 자리에서 `deadline` 에 돌려준다 — 뒤이어 예외가 나도 이미 반영돼 있다.
        `throttle_wait` 가 None 이면 429 를 `_MAX_THROTTLE_RETRIES` 회까지, 값이 있으면 기다린 시간의 합이 그
        초를 넘기 직전까지 다시 보낸다(다음 대기가 남은 시간보다 길면 거기서 429 를 돌려준다). 그 합은
        `throttle_waited[0]` 에 쌓는다 — `_send` 가 부재 재시도를 건너 같은 칸을 넘겨 합이 이어진다.
        """
        waited = throttle_waited if throttle_waited is not None else [0.0]
        attempt = 0
        while True:
            token_used = self._token
            r = self._session.request(method, url, **kwargs)
            if r.status_code == 401:
                try:
                    relogged = self._relogin(token_used)
                except requests.RequestException as e:
                    # 재로그인 요청의 실패다 — 원래 요청은 401 로 끝났으므로 `_send` 가 무거운 읽기의 시한 규칙을
                    # 쓰지 않고 종전처럼 다시 보내게 표시한다.
                    setattr(e, _retry.RELOGIN_FAILURE_ATTR, True)
                    raise
                if relogged:
                    r = self._session.request(method, url, **kwargs)
            if r.status_code != 429:
                return r
            if throttle_wait is None:
                if attempt == _MAX_THROTTLE_RETRIES:
                    return r
                wait = _throttle_delay(r, attempt)
            else:
                wait = _throttle_delay(r, attempt, cap=_SEAL_POLL_CAP_SECS)
                if waited[0] + wait > throttle_wait:
                    return r
            time.sleep(wait)
            deadline.credit(wait)
            waited[0] += wait
            attempt += 1

    def _relogin(self, token_used: "str | None") -> bool:
        """만료된 토큰을 갱신한다. 갱신됐으면 True(= 재시도할 가치가 있다)."""
        # 로봇 토큰에는 갱신이 없다. 폐기·만료·계정 정지 중 무엇이든 401은 그대로
        # 올라가야 한다 — 재시도해 봐야 같은 값을 다시 보내는 것뿐이다.
        if self._robot_token is not None:
            return False
        # OIDC 는 출처에서 다시 가져와 재시도한다 — 프로세스가 선제 재취득 시점을 놓쳐
        # 만료 토큰으로 401 을 받은 경우다(절전 등). 출처가 새 토큰을 못 주면(파일 없음·
        # provider 예외) 원래의 401 을 그대로 올린다.
        if self._oidc is not None:
            with self._auth_lock:
                if self._token != token_used:
                    return True  # 다른 스레드가 이미 재취득했다.
                try:
                    fresh = _read_oidc_token(self._oidc)
                except NexusAuthError:
                    return False
                # **방금 401 난 토큰과 같으면 재시도하지 않는다.** 만료가 아니라 매핑 삭제·
                # aud/iss 불일치로 401 이면 출처(아직 유효한 파일·provider)가 같은 토큰을
                # 돌려준다. 그걸 다시 보내면 확실히 또 401 이라 왕복만 낭비된다 — robot_token
                # 이 그 자리에서 False 를 내는 것과 같은 이유다.
                if fresh == token_used:
                    return False
                self._set_token(fresh)
                return True
        with self._auth_lock:
            # 다른 스레드가 이미 갱신했으면 그대로 쓴다 — flush가 병렬로 POST하기 때문에
            # 이 검사가 없으면 401을 받은 수만큼 로그인이 몰린다.
            if self._token != token_used:
                return True
            try:
                self._login(self._email, self._password)
                return True
            except NexusAuthError:
                # 재로그인이 안 되면 원래의 401을 그대로 올린다. 여기서 예외를 바꿔치기하면
                # 호출부가 기대하는 status_code가 달라진다.
                return False

    def _note_server_version(self, r: "requests.Response") -> None:
        v = parse_server_version(r.headers.get(VERSION_HEADER))
        if v is not None:
            self._server_version = v

    def _version_paths_supported(self) -> bool:
        """지금까지 본 응답으로 서버가 샘플 태그·크기 보정의 버전 경로를 받는 판인가. 아직 못 봤으면 False(옛 경로)."""
        v = self._server_version
        return v is not None and v >= VERSION_PATHS_MIN_SERVER

    def _versioned_write(
        self, method: str, old_path: str, new_path: "str | None", **kwargs
    ) -> requests.Response:
        """버전 경로가 있는 서버면 `new_path`, 아니면 `old_path` 로 보낸다. `new_path` 가 None 이면(dataset/version 을
        못 받은 옛 호출 모양) 늘 옛 경로다.

        판을 아직 못 봐서 옛 경로로 보냈는데 410 이 오면 새 서버다 - 그 응답의 헤더로 판을 기억했으므로 새 경로로 한 번
        다시 보낸다(옛 경로는 410 이면 아무것도 쓰지 않는다)."""
        if new_path is not None and self._version_paths_supported():
            return self._request_checked(method, new_path, **kwargs)
        try:
            return self._request_checked(method, old_path, **kwargs)
        except NexusError as e:
            if e.status_code != 410 or new_path is None:
                raise
            if self._server_version is None:
                self._server_version = VERSION_PATHS_MIN_SERVER
            return self._request_checked(method, new_path, **kwargs)

    def _request_checked(self, method: str, path: str, **kwargs) -> requests.Response:
        r = self._send(method, path, **kwargs)
        _raise_for_status(r)
        return r

    def _get(self, path: str, **kwargs) -> requests.Response:
        r = self._send("GET", path, **kwargs)
        _raise_for_status(r)
        return r

    def _post(self, path: str, **kwargs) -> requests.Response:
        r = self._send("POST", path, **kwargs)
        _raise_for_status(r)
        return r

    def _put(self, path: str, **kwargs) -> requests.Response:
        r = self._send("PUT", path, **kwargs)
        _raise_for_status(r)
        return r

    def _delete(self, path: str, **kwargs) -> requests.Response:
        r = self._send("DELETE", path, **kwargs)
        _raise_for_status(r)
        return r

    def _patch(self, path: str, **kwargs) -> requests.Response:
        r = self._send("PATCH", path, **kwargs)
        _raise_for_status(r)
        return r

    # ── 계정 관리 ────────────────────────────────────────────────────────────
    def change_password(self, current_password: str, new_password: str) -> None:
        """로그인한 계정의 비밀번호를 바꾼다. 현재 비밀번호를 재확인한다.

        **이미 발급된 토큰은 무효화되지 않는다**(만료까지 최대 24시간). 변경은 새 로그인부터
        적용되므로, 이 클라이언트 인스턴스는 계속 그대로 쓸 수 있다.

        `~/.int2nexus/settings.json`에 비밀번호를 적어두었다면 **그 파일도 함께 고쳐야 한다** —
        안 그러면 다음 `nx.connect()`가 실패한다.

        현재 비밀번호가 틀리면 `NexusError(status_code=403)`. 403은 세션 만료가 아니라
        확인 실패라는 뜻이므로 재로그인해도 해결되지 않는다.
        """
        self._post(
            "/api/v1/auth/password",
            json={"current_password": current_password, "new_password": new_password},
        )
        # 보관 중인 자격증명도 갱신한다. 안 하면 토큰이 만료되는 시점(최대 24시간 뒤)에
        # 재로그인이 **옛 비밀번호**로 시도돼 실패한다 — 바꾼 지 한참 뒤에야 터지는
        # 종류의 버그라 원인을 찾기 어렵다.
        with self._auth_lock:
            self._password = new_password

    def delete_account(self, password: str) -> dict:
        """로그인한 계정을 **완전히 삭제**한다(비활성화가 아니다). 되돌릴 수 없다.

        **서버 `0.1.7` 부터는 담당하던 dataset 이 남아 있어도 삭제된다** — `0.1.6` 이
        넣었던 409 거부는 철회됐다. 그 dataset 들은 지워지지 않고 **담당자만 해제**되며,
        그 수가 반환의 `released_datasets` 다(0 이 아닐 수 있다).

        **담당자가 해제돼도 그 dataset 을 지울 수 있는 사람이 늘지는 않는다** — 서버
        `0.1.9` 부터 담당자는 인가에 관여하지 않고(08-27 리포트 7-1 의 철회를 반영했다),
        지우는 것도 고치는 것도 사람 `editor` 이상이면 담당자와 무관하게 된다. 담당자가
        비었다는 것은 「인수 대기」라는 관리 상태일 뿐이고 `list_datasets(unowned=True)` 가
        그것을 일감으로 보여준다. (이 문단은 한동안 「**`admin` 만** 지울 수 있게 된다」로
        적혀 있었다 — 없는 보호를 근거로 이관을 권하고 있었다.)

        반환: `{"deleted_user_id", "released_datasets", "warning"}`.

        삭제 후 이 클라이언트는 그냥 버린다. 서버가 요청마다 계정 행을 확인하므로
        (`auth.revocationCacheTtlSecs`, 기본 5초) 곧 **조회를 포함한 모든 요청이 401** 이
        된다 — 응답의 `warning` 문구는 그보다 오래된 것이다.
        """
        return self._delete(
            "/api/v1/auth/account", json={"password": password}
        ).json()

    def transfer_dataset_owner(self, dataset_id: str, email: str) -> dict:
        """이 dataset 의 소유권을 다른 계정으로 넘긴다. **현재 소유자만** 부를 수 있다.

        **넘겨도 이 계정의 권한은 그대로다**(서버 `0.1.9` 부터). 수정·적재·삭제 전부 역할이
        가르므로 `editor` 이상이면 계속 된다 — 옮겨 가는 것은 「다시 넘길 자격」 하나다.
        되돌리려면 새 소유자가 다시 넘겨주거나 superuser 가 지정해야 한다.

        주인이 없는(`owner_user_id` 가 NULL) dataset 에는 쓸 수 없다 — 403 이다.
        그건 superuser 의 관리 조작이다.

        거부되는 경우:

        - 현재 소유자가 아니거나 dataset 에 소유자가 없음 — `NexusError(status_code=403)`
        - **자기 자신에게 이관** — `NexusError(status_code=400)`. 아무 일도 일어나지 않은
          것을 "넘겼다"로 읽지 않도록 서버가 거부한다.
        - dataset 이 없거나 `email` 로 가입된 계정이 없음 — `NexusError(status_code=404)`

        반환은 갱신된 dataset dict 다(`owner_user_id` 가 새 소유자로 바뀌어 있다).

        서버 `0.1.6` 부터.
        """
        return self._put(
            f"/api/v1/datasets/{dataset_id}/owner", json={"email": email}
        ).json()

    def delete_version(
        self, dataset_id: str, version: str, confirm: str, delete_cas: bool = False,
        *, confirm_dataset_name: "str | None" = None,
    ) -> dict:
        """version hard-delete(dataset 유지). confirm=<버전 문자열> 필요.
        기본은 샘플 에셋 보존이고, True 를 명시해야 미참조 에셋이 삭제된다(seal 스냅샷은 서버 0.1.31~ 값과 무관하게 지운다).

        **sealed 버전**: 비-admin 은 `NexusError(status_code=409)`(dataset 의 마지막 버전이라 함께
        지워지는 경우 포함). `role=admin` 은 `confirm_dataset_name=<데이터셋 이름>` 을 정확히 주면
        삭제된다(틀리거나 빠지면 400). draft 버전에는 이 인자가 필요 없다."""
        params = {"confirm": confirm, "delete_cas": str(bool(delete_cas)).lower()}
        if confirm_dataset_name is not None:
            params["confirm_dataset_name"] = confirm_dataset_name
        try:
            return self._delete(
                f"/datasets/{dataset_id}/versions/{_seg(version)}", params=params,
            ).json()
        except NexusError as e:
            if e.status_code == 403:
                raise NexusError(
                    f"cannot delete a version of dataset '{dataset_id}' — deleting needs "
                    f"role 'editor' or higher; being the dataset owner is not required "
                    f"({e.server_message or str(e)})",
                    status_code=e.status_code,
                    server_message=e.server_message,
                ) from e
            raise

    def delete_dataset(
        self, dataset_id: str, *, confirm_dataset_name: str, delete_cas: bool = False,
    ) -> dict:
        """dataset 통째 삭제(nexus-server 0.1.26 부터). 버전마다 `delete_version` 과 같은 규칙으로 지운다.
        `confirm_dataset_name` 은 dataset 의 현재 이름이고 **늘 필수**다(틀리거나 비면 400).

        - sealed 버전이 있으면 `role=admin` 만 지운다 — 아니면 `NexusError(status_code=409)` 이고 아무것도
          지우지 않는다. `viewer`·로봇은 403.
        - **dataset 전체로는 원자적이지 않다**(버전 하나가 트랜잭션 하나). 도중에 실패했거나 응답을 못
          받았으면 다시 부르면 된다 — 남은 버전부터 지우고, 이미 다 지워졌으면 404 다. 이 요청은 SDK 가
          자동으로 다시 보내지 않는다.
        - 반환: `{dataset_id, versions_deleted, samples_deleted, cas_objects_deleted}`."""
        params = {
            "confirm_dataset_name": confirm_dataset_name,
            "delete_cas": str(bool(delete_cas)).lower(),
        }
        return self._delete(f"/datasets/{dataset_id}", params=params).json()

    def _paged(
        self, path: str, id_field: str, limit: "int | None", cursor: "str | None",
        base_params: "dict | None" = None, *, value_field: str, cursor_value: "str | None" = None,
    ) -> list[dict]:
        """키셋 커서를 자동으로 순회해 전체를 모은다.

        다음 페이지를 물을 때 마지막 행의 `id_field` 를 `cursor` 로, 정렬 값(`value_field` — 목록의 정렬 기준 열)을
        `cursor_value` 로 함께 보낸다. 서버가 커서 행을 다시 읽지 않고 그 값에서 이으므로 그 사이 커서 행이 지워지거나
        정렬 값이 바뀌어도 건너뛰지 않는다(follow-ups 35 절 — 전에는 지워진 커서 행이 빈 페이지를 돌려 뒤가 조용히
        빠졌다). 행에 그 값이 없으면 `cursor` 만 보낸다. 모르는 파라미터를 무시하는 옛 서버에는 종전과 같다.

        `limit`을 주면 순회하지 않고 한 페이지만 돌려준다 — 호출부가 페이지 크기를 직접
        정하고 싶을 때를 위한 것이고, `ds.samples()`가 쓰는 규칙과 같다.

        서버가 목록을 기본 100개로 자르므로(0.1.7+) 순회가 없으면 조용히 일부만 돌아온다.

        **`limit`을 준 호출이 정확히 그 수만큼 받으면 경고를 한 번 낸다.** 그 응답은
        "전부가 이만큼"과 "여기서 잘렸다"를 구분해 주지 않는데, 말없이 잘린 목록으로 도는
        배치는 **틀린 답을 성공으로 보고한다**. 도입처가 이 종류의 결함을 조용한 위험으로
        지목했고(2026-08-27 리포트 7-4), 실제로 dataset 수가 기본 상한을 넘어가는 중이었다.
        """
        base = dict(base_params or {})
        if limit is not None:
            params = dict(base, limit=limit)
            if cursor:
                params["cursor"] = cursor
                if cursor_value:
                    params["cursor_value"] = cursor_value
            page = self._get(path, params=params).json()
            if len(page) == limit:
                warnings.warn(
                    f"{path} 가 limit({limit})만큼 돌아왔습니다 — 뒤가 더 있을 수 있습니다. "
                    f"전량이 필요하면 limit 을 빼거나(자동 순회) "
                    f"cursor={page[-1].get(id_field)!r}, cursor_value={page[-1].get(value_field)!r} 로 이어 받으십시오.",
                    RuntimeWarning,
                    stacklevel=3,
                )
            return page

        page_size = 1000  # 서버 상한
        out: list[dict] = []
        cur, cur_value = cursor, cursor_value
        while True:
            params = dict(base, limit=page_size)
            if cur:
                params["cursor"] = cur
                if cur_value:
                    params["cursor_value"] = cur_value
            page = self._get(path, params=params).json()
            out.extend(page)
            if len(page) < page_size:
                break
            cur, cur_value = page[-1][id_field], page[-1].get(value_field)
        return out

    def list_datasets(
        self,
        *,
        q: str | None = None,
        name: str | None = None,
        description: str | None = None,
        tags: "str | list[str] | None" = None,
        sort: str | None = None,
        order: str | None = None,
        favorite: bool = False,
        mine: bool = False,
        unowned: bool = False,
        limit: int | None = None,
        cursor: str | None = None,
        name_exact: str | None = None,
        cursor_value: str | None = None,
    ) -> list[dict]:
        """dataset 목록. 옵션: q(통합 검색 — name/description/tags 중 하나라도 부분일치, UI 단일 검색창용),
        name/description(개별 ILIKE), name_exact(이름 정확히 일치, 대소문자 구분 — nexus-server
        `0.1.26` 부터이고 그 이하 서버는 이 인자를 무시해 걸러지지 않은 목록을 준다), tags(ANY),
        sort(name|created_at), order(asc|desc),
        favorite(True면 내 즐겨찾기만), mine(내가 담당인 것만), unowned(담당자가 없는 것만).
        각 항목에 is_favorite 과 `created_by_kind`(`"human"` | `"robot"` | `None` — 만든
        계정의 종) 포함. 뒤엣것은 `0.1.10` 다음 서버부터이고, 그 이전 서버는 키 자체가
        없으므로 `.get("created_by_kind")` 로 읽을 것.

        **`limit`을 안 주면 커서를 자동으로 순회해 전체를 모은다.** 서버 0.1.7부터 이 목록은
        한 응답에 기본 100개까지만 실리므로, 순회하지 않으면 dataset이 그보다 많은 배포에서
        조용히 일부만 돌아온다. `limit`에 숫자를 주면 그 개수만큼 한 페이지만 반환한다
        (`ds.samples()`와 같은 규칙).

        `mine`과 `unowned`를 함께 주면 서버가 400을 낸다 — 항상 빈 결과라 필터 오류와
        구분되지 않기 때문이다.

        `cursor` 로 직접 이어 받을 때는 그 행의 정렬 값(`sort="name"` 이면 `name`, 아니면 `created_at`)을
        `cursor_value` 로 함께 준다 — 커서 행이 그 사이 지워졌으면 서버(nexus-server `0.1.40` 부터)가 값 없이는 400
        `cursor_not_found` 를 낸다. 자동 순회는 이 값을 알아서 보낸다."""
        params: dict = {}
        if q:
            params["q"] = q
        if name:
            params["name"] = name
        if name_exact is not None:
            params["name_exact"] = name_exact
        if description:
            params["description"] = description
        if tags:
            params["tags"] = tags if isinstance(tags, str) else ",".join(tags)
        if sort:
            params["sort"] = sort
        if order:
            params["order"] = order
        if favorite:
            params["favorite"] = "true"
        if mine:
            params["mine"] = "true"
        if unowned:
            params["unowned"] = "true"

        return self._paged(
            "/datasets", "dataset_id", limit, cursor, params,
            value_field="name" if sort == "name" else "created_at", cursor_value=cursor_value,
        )

    def sample_history(self, dataset_id: str, sample_id: str) -> dict:
        """한 샘플의 버전별 annotation 이력(든 버전만, created_at 오름차순)."""
        return self._get(f"/datasets/{dataset_id}/samples/{sample_id}/history").json()

    def version_diff(
        self, dataset_id: str, version: str, *, against: str | None = None
    ) -> dict:
        """버전 diff — target(version) vs base(against, 없으면 parent_version)."""
        params = {"against": against} if against else {}
        return self._get(
            f"/datasets/{dataset_id}/versions/{_seg(version)}/diff", params=params
        ).json()

    # ── Annotation sessions (CVAT) ─────────────────────────────────────────
    def create_annotation_session(
        self,
        dataset_id: str,
        version: str,
        sample_ids: list[str],
        *,
        groups: "list[str] | None" = None,
        extra_labels: "list[dict] | None" = None,
    ) -> dict:
        """CVAT 편집 세션 생성. **201을 즉시 받고 준비는 서버가 백그라운드로 한다** —
        반환된 세션의 status는 `creating`이고 `cvat_url`은 아직 없다.
        `AnnotationSession.wait_open()`으로 기다릴 것.

        sealed 버전이거나 다른 활성 세션과 샘플이 겹치면 `NexusError(status_code=409)`,
        서버에 `[cvat]` 설정이 없으면 503."""
        body: dict = {"sample_ids": list(sample_ids)}
        if groups is not None:
            body["groups"] = groups
        if extra_labels is not None:
            body["extra_labels"] = extra_labels
        return self._post(
            f"/datasets/{dataset_id}/versions/{_seg(version)}/annotation-sessions", json=body
        ).json()

    def list_annotation_sessions(
        self,
        *,
        dataset_id: "str | None" = None,
        version: "str | None" = None,
        status: "str | None" = None,
        mine: bool = False,
        limit: "int | None" = None,
        cursor: "str | None" = None,
    ) -> list[dict]:
        """세션 목록. `dataset_id`+`version`을 주면 그 버전만, 아니면 **전역**이다.

        `status` 기본은 서버 쪽 `active`(creating+open) — 이력까지 보려면 `"all"`.
        `mine=True`는 로그인 계정이 만든 것만(SDK는 항상 토큰을 싣는다)."""
        params: dict = {}
        if status is not None:
            params["status"] = status
        if mine:
            params["mine"] = "true"
        if limit is not None:
            params["limit"] = limit
        if cursor is not None:
            params["cursor"] = cursor
        if dataset_id and version:
            path = f"/datasets/{dataset_id}/versions/{_seg(version)}/annotation-sessions"
        else:
            path = "/annotation-sessions"
            if dataset_id:
                params["dataset_id"] = dataset_id
        return self._get(path, params=params).json()

    def get_annotation_session(self, session_id: str) -> dict:
        """세션 단건. 목록과 달리 `sample_ids`와 `has_unimported_changes`가 채워진다
        (후자는 CVAT을 한 번 호출하므로 폴링에는 목록을 쓸 것)."""
        return self._get(f"/annotation-sessions/{session_id}").json()

    def import_annotation_session(self, session_id: str) -> dict:
        """CVAT 결과를 draft에 반영하고 요약을 반환. **반복 호출이 멱등**이다."""
        return self._post(f"/annotation-sessions/{session_id}/import").json()

    def close_annotation_session(self, session_id: str, *, force: bool = False) -> dict:
        """작업 종료 — 샘플 잠금만 풀고 CVAT project는 남긴다.
        미반영 변경이 있으면 `NexusError(status_code=409)`이며 `force=True`로 넘긴다."""
        params = {"force": "true"} if force else {}
        return self._post(
            f"/annotation-sessions/{session_id}/close", params=params
        ).json()

    def delete_annotation_session(self, session_id: str) -> None:
        """세션과 **CVAT project를 완전히 삭제**한다 — 이미지 사본과 미반영 편집도 사라진다.
        **사람** `editor` 이상이면 가능하다(담당자가 아니어도 된다). `viewer` 와 **로봇 계정**은
        `NexusError(status_code=403)` — 로봇이 막히는 것은 사라지는 것에 아직 nexus로 들어오지
        않은 작업자 편집이 섞여 있고 seal이 그것을 지켜 주지 않기 때문이다. 로봇도 잠금은
        풀 수 있다(:meth:`close_annotation_session`)."""
        self._delete(f"/annotation-sessions/{session_id}")

    # ── Subsets (저장된 explorer 필터) ──────────────────────────────────────
    def create_subset(self, dataset_id: str, version: str, name: str, filter: dict) -> dict:
        """서브셋 생성. filter = SampleExplorerRequest 형태.

        `editor` 이상이면 가능하다(담당자가 아니어도 된다) — `viewer` 는
        `NexusError(status_code=403)`."""
        return self._post(
            f"/datasets/{dataset_id}/versions/{_seg(version)}/subsets",
            json={"name": name, "filter": filter},
        ).json()

    def list_subsets(
        self, dataset_id: str, version: str, *,
        limit: int | None = None, cursor: str | None = None, cursor_value: str | None = None,
    ) -> list[dict]:
        """서브셋 목록. `list_versions`와 같은 페이지네이션 규칙이다(`cursor_value` 는 그 행의 `updated_at`)."""
        return self._paged(
            f"/datasets/{dataset_id}/versions/{_seg(version)}/subsets", "subset_id", limit, cursor,
            value_field="updated_at", cursor_value=cursor_value,
        )

    def get_subset(self, subset_id: str) -> dict:
        return self._get(f"/subsets/{subset_id}").json()

    def update_subset(
        self, subset_id: str, *, name: str | None = None, filter: dict | None = None
    ) -> dict:
        body: dict = {}
        if name is not None:
            body["name"] = name
        if filter is not None:
            body["filter"] = filter
        return self._put(f"/subsets/{subset_id}", json=body).json()

    def delete_subset(self, subset_id: str) -> None:
        self._delete(f"/subsets/{subset_id}")

    def subset_samples(
        self, subset_id: str, *, cursor: str | None = None,
        limit: int | None = None, include_annotations: bool | None = None,
    ) -> list[dict]:
        """서브셋 필터 resolve → 샘플 한 페이지(explorer와 동일 형식)."""
        params: dict = {}
        if cursor is not None:
            params["cursor"] = cursor
        if limit is not None:
            params["limit"] = limit
        if include_annotations is not None:
            params["include_annotations"] = str(include_annotations).lower()
        return self._get(f"/subsets/{subset_id}/samples", params=params).json()

    def materialize_subset(self, subset_id: str, version: str) -> dict:
        """서브셋을 **새 버전**으로 물질화(필터링된 fork). 필터를 resolve한 샘플만 담고
        라벨은 서브셋의 version에서 복제. 0개 resolve면 400. 생성된 DatasetVersion 반환.

        `editor` 이상이면 가능하다(담당자가 아니어도 된다) — `viewer` 는
        `NexusError(status_code=403)`."""
        return self._post(
            f"/subsets/{subset_id}/version", json={"version": version}
        ).json()

    def add_favorite(self, dataset_id: str) -> None:
        """dataset을 내 즐겨찾기에 추가(멱등). PUT /datasets/{id}/favorite."""
        self._put(f"/datasets/{dataset_id}/favorite")

    def remove_favorite(self, dataset_id: str) -> None:
        """dataset을 내 즐겨찾기에서 해제(멱등). DELETE /datasets/{id}/favorite."""
        self._delete(f"/datasets/{dataset_id}/favorite")

    def get_favorite_layout(self) -> dict:
        """내 즐겨찾기 그룹 구성을 서버 응답 그대로 돌려준다. GET /api/v1/datasets/favorites/groups.

        `{"groups": [{"group_id", "name", "position", "dataset_ids"}], "unassigned": [dataset_id]}`
        — 배열 순서가 곧 그룹 순서·그룹 안 순서이고, `unassigned` 는 어느 그룹에도 없는 즐겨찾기다.
        dataset 이름은 없다(이름까지 필요하면 `nx.favorite_groups()`)."""
        return self._get("/api/v1/datasets/favorites/groups").json()

    def create_dataset(
        self,
        name: str,
        tags: list[str] | None = None,
        description: str | None = None,
    ) -> dict:
        body: dict = {"name": name}
        if tags:
            # 문자열 하나를 넘기면 단일 원소 리스트로 자동 변환 (서버는 배열을 기대).
            body["tags"] = [tags] if isinstance(tags, str) else list(tags)
        if description:
            body["description"] = description
        return self._post("/datasets", json=body).json()

    def update_dataset(
        self, dataset_id: str, *, name: str | None = None, description: str | None = None,
    ) -> dict:
        """dataset의 name/description을 제공된 것만 갱신(둘 다 None이면 no-op). name이 이미
        다른 dataset에 쓰이고 있으면 서버가 409. `editor` 이상이면 담당자가 아니어도
        가능하다 — `viewer` 는 `NexusError(status_code=403)`."""
        body: dict = {}
        if name is not None:
            body["name"] = name
        if description is not None:
            body["description"] = description
        return self._patch(f"/datasets/{dataset_id}", json=body).json()

    def get_dataset(self, dataset_id: str) -> dict | None:
        """dataset 단건 조회(name/tags/description/owner_user_id 등). 없으면 None."""
        r = self._send("GET", f"/datasets/{dataset_id}")
        if r.status_code == 404:
            return None
        _raise_for_status(r)
        return r.json()

    def list_versions(
        self, dataset_id: str, *, limit: int | None = None, cursor: str | None = None,
        cursor_value: str | None = None,
    ) -> list[dict]:
        """dataset의 version 목록.

        서버 0.1.7부터 한 응답에 기본 100개까지만 실린다. `limit`을 안 주면 커서를 자동으로
        순회해 전체를 모은다(`list_datasets`와 같은 규칙, `cursor_value` 는 그 행의 `created_at`)."""
        return self._paged(
            f"/datasets/{dataset_id}/versions", "dataset_version_id", limit, cursor,
            value_field="created_at", cursor_value=cursor_value,
        )

    def get_version(self, dataset_id: str, version: str) -> dict | None:
        r = self._send("GET", f"/datasets/{dataset_id}/versions/{_seg(version)}")
        if r.status_code == 404:
            return None
        _raise_for_status(r)
        return r.json()

    def create_version(
        self,
        dataset_id: str,
        version: str,
        fork_from: str | None = None,
        sample_ids: list[str] | None = None,
        *,
        wait: float = _SEAL_WAIT_SECS,
        block: bool = True,
    ) -> dict:
        """새 버전 생성. `fork_from`만 주면 그 버전 전량 fork(멤버 승계).
        `fork_from`+`sample_ids`면 **필터링된 fork** — 그 버전 멤버 중 지정 샘플만 담음
        (서버가 비멤버 sample_id는 400). `sample_ids`만 주면(무 fork_from) 400.
        둘 다 없으면 빈 draft 버전. 스키마(관측된 label/component)는 nexus-server 0.1.37 부터 버전마다 따로 쌓이고
        fork 는 부모의 관측을 물려받는다(부분·필터 fork 도 부모 관측 그대로라 고르지 않은 샘플에만 있던 항목이 남고, 판 올림
        전부터 있던 legacy 부모면 dataset 전체 관측을 받아 다른 버전에만 있는 그룹도 보인다 — 걷어 내려면 `recompute_schema`).

        서버(0.1.33~)가 fork 를 작업 줄에 올리면(202) `block=True` 일 때 그 작업이 끝날 때까지 최대 `wait` 초(기본 600)
        기다렸다가 draft 버전을 다시 읽어 돌려준다. 넘기면 `NexusVersionJobPending`(작업은 서버에서 계속 돈다),
        작업이 실패·취소되면 `NexusError(status_code=409)`. `block=False` 면 202 본문(`{"job", "version"}`)을 그대로
        돌려준다. 그 밖의 응답(201)과 옛 서버는 종전과 같다."""
        _check_wait(wait)
        started = time.monotonic()
        body: dict = {"version": version}
        if fork_from is not None:
            body["fork_from"] = fork_from
        if sample_ids is not None:
            body["sample_ids"] = sample_ids
        r = self._post(f"/datasets/{dataset_id}/versions", json=body)
        if r.status_code == 202:
            return self._after_accepted(
                r.json(), dataset_id, version, "draft", float(wait), block, started
            )
        return r.json()

    def get_version_job(self, job_id: str) -> dict:
        """버전 작업(seal·fork) 하나를 조회한다(서버 0.1.33~). 없거나 7 일이 지나 지워졌으면 `NexusError(status_code=404)`."""
        return self._get(f"/api/v1/version-jobs/{_seg(job_id)}").json()

    def wait_existing_version(
        self, dataset_id: str, version_row: dict, *, wait: float = _SEAL_WAIT_SECS
    ) -> dict:
        """이미 있는 버전이 `preparing` 이거나 `failed` 일 때 — 앞선 `create_version` 이 `NexusVersionJobPending` 으로 끝났거나
        `block=False` 였던 버전을 다시 열 때 — 그 작업이 끝나기를 `wait` 초까지 기다려 draft 버전을 돌려준다.
        `failed` 는 409 `NexusError`. 서버(0.1.33~)가 버전 응답에 싣는 `job` 요약으로 작업을 찾는다."""
        _check_wait(wait)
        started = time.monotonic()
        version = version_row.get("version")
        if version_row.get("status") == "failed":
            msg = (version_row.get("job") or {}).get("error")
            raise NexusError(
                f"버전 '{version}' 은 만들기에 실패한 상태입니다 — 지우고 다시 만드십시오",
                status_code=409,
                server_message=msg,
            )
        j = version_row.get("job")
        if not j or not j.get("job_id"):
            raise NexusError(
                f"버전 '{version}' 은 준비 중인데 기다릴 작업을 찾을 수 없습니다",
                status_code=409,
                server_message="version is preparing without a job",
            )
        return self._after_accepted(
            {"job": j, "version": version_row}, dataset_id, version, "draft", float(wait), True, started
        )

    def _after_accepted(
        self, body: dict, dataset_id: str, version: str, want_status: str,
        wait: float, block: bool, started: float, slept: float = 0.0,
    ) -> dict:
        """seal·fork 가 202 로 받아들여진 뒤. `block=False` 면 본문 그대로, 아니면 작업이 끝날 때까지 2 초 간격으로 묻는다.

        시간은 요청을 시작한 때부터 `wait` 초이고 429 로 기다린 시간과 같은 예산이다. `done` 이면 버전을 다시 읽어
        돌려주고 `failed`·`cancelled` 면 409, 넘기면 `NexusVersionJobPending`. 작업 조회가 404(지워짐)면 버전을 다시
        읽어 `want_status` 이면 끝난 것으로 본다."""
        if not block:
            return body
        job = body["job"]
        job_id = job["job_id"]
        while True:
            try:
                job = self.get_version_job(job_id)
            except NexusError as e:
                if e.status_code != 404:
                    raise
                current = self.get_version(dataset_id, version)
                if current and current.get("status") == want_status:
                    return current
                raise NexusError(
                    f"버전 작업 {job_id} 의 기록이 없고 버전 '{version}' 도 {want_status} 가 아닙니다",
                    status_code=409,
                    server_message="version job record is gone",
                ) from e
            state = job.get("state")
            if state == "done":
                current = self.get_version(dataset_id, version)
                if current is None:
                    raise NexusError(
                        f"버전 작업 {job_id} 가 끝났지만 버전 '{version}' 을 찾을 수 없습니다",
                        status_code=404,
                    )
                return current
            if state in _VERSION_JOB_FAILED_STATES:
                msg = job.get("error")
                raise NexusError(
                    f"버전 작업 {job_id} {state}: {msg}", status_code=409, server_message=msg
                )
            left = wait - max(slept, time.monotonic() - started)
            if left <= 0:
                raise NexusVersionJobPending(job)
            step = min(_VERSION_JOB_POLL_SECS, left)
            time.sleep(step)
            slept += step

    def create_clone_job(
        self, dataset_id: str, version: str, target_name: str, target_version: str
    ) -> dict:
        """`(dataset_id, version)`을 새 dataset `target_name`(버전 `target_version`)으로 전량
        복제하는 비동기 job을 만든다. 복사는 서버 백그라운드에서 진행되고, 즉시 생성된 job(dict)을
        반환한다 — 진행 상태는 `get_clone_job`으로 폴링한다.

        **엔드포인트가 없는 구서버는 `NexusError(status_code=404)`** — `Dataset.clone`이 이를
        잡아 클라이언트 반복 복제로 폴백한다. 대상 이름 중복은 409, 소스 없음은 404(이 경우도
        404지만, clone의 소스는 호출자 자신의 현재 dataset이라 실무상 라우트 부재와 구분된다),
        동시 복제 상한 초과는 429."""
        return self._post(
            f"/datasets/{dataset_id}/versions/{_seg(version)}/clone-jobs",
            json={"target_name": target_name, "target_version": target_version},
        ).json()

    def get_clone_job(self, job_id: str) -> dict:
        """clone job 하나를 조회(폴링용). 없으면 `NexusError(status_code=404)`."""
        return self._get(f"/clone-jobs/{job_id}").json()

    def add_sample_ids(
        self,
        dataset_id: str,
        version: str,
        sample_ids: list[str],
        from_version: "str | None" = None,
    ) -> dict:
        """이미 있는 sample 들을 이 버전에 링크한다. 반환은 `{"linked", "skipped", "had_residue"}`.

        `from_version`(같은 dataset 의 버전 이름)은 대상 말고 다른 버전에 링크된 sample 을 넣을 때 필수다 — 없으면
        `NexusError(status_code=400, code="from_version_required")` 이고 아무것도 링크하지 않는다. 주면 새로 링크된
        sample 이 그 버전에서 보이는 meta·태그·split·annotation 을 가져오며, 보낸 sample 은 모두 그 버전의 멤버여야
        한다(아니면 400). `None` 이면 키를 보내지 않는다.

        호환성: nexus-server 0.1.36 이하는 204 + 빈 본문을 준다(`from_version` 은 무시된다) — 그때는 `{}` 를 반환한다.
        """
        body: dict = {"sample_ids": sample_ids}
        if from_version is not None:
            body["from_version"] = from_version
        r = self._post(f"/datasets/{dataset_id}/versions/{_seg(version)}/samples", json=body)
        if not r.content:
            return {}
        try:
            out = r.json()
        except ValueError:
            return {}
        return out if isinstance(out, dict) else {}

    def remove_sample_ids(self, dataset_id: str, version: str, sample_ids: list[str]) -> dict:
        """여러 sample을 version에서 링크 해제(sample·데이터는 유지). `{"removed": n, "had_residue": m}` 반환
        (`had_residue` 는 nexus-server 0.1.37 부터 — 뺀 샘플 중 그 버전에 기록이 있던 수)."""
        return self._delete(
            f"/datasets/{dataset_id}/versions/{_seg(version)}/samples",
            json={"sample_ids": sample_ids},
        ).json()

    def import_samples(
        self,
        dataset_id: str,
        version: str,
        source_dataset_id: str,
        source_version: str,
        sample_ids: list[str],
    ) -> dict:
        """다른 dataset(source_dataset_id/source_version)의 sample들을 이 dataset(target) 버전으로
        복사(크로스 데이터셋 재사용). asset은 재사용(재업로드 없음)하지만 sample/annotation은
        독립 복제되어 이후 target 쪽 수정이 source에 영향 없음. 반환:
        `{"imported": [{"source_sample_id", "sample_id"}, ...]}`."""
        return self._post(
            f"/datasets/{dataset_id}/versions/{_seg(version)}/samples/import",
            json={
                "source_dataset_id": source_dataset_id,
                "source_version": source_version,
                "sample_ids": sample_ids,
            },
        ).json()

    def add_tags_bulk(
        self, sample_ids: list[str], tags: list[str], *,
        dataset_id: "str | None" = None, version: "str | None" = None,
    ) -> list[dict]:
        """여러 sample에 동일한 tag들을 추가(합집합, 순서 보존).

        `dataset_id`·`version` 을 주고 서버가 버전 경로를 가진 판(`VERSION_PATHS_MIN_SERVER` 이상)이면
        `POST /datasets/{id}/versions/{v}/samples/tags/items` 로 보낸다 - **그 버전에만 반영된다**. 이 버전에 없거나 삭제된
        샘플이 하나라도 있으면 아무것도 쓰지 않고 `NexusError(status_code=400, code="meta_write_rejected")` 이고, sealed
        버전은 409 다. 반환은 요청한 샘플 전부의 그 버전 실효 행이다. 그보다 낮은 판이거나 `dataset_id`/`version` 을 주지
        않으면 옛 `POST /samples/tags` 로 보낸다(없거나 삭제된 id 는 결과에서 조용히 빠지고 버전과 무관하게 공유 값을
        고친다) - 새 서버에서 옛 경로는 410 이다.
        `editor` 이상이면 가능하다(담당자가 아니어도 된다) - `viewer` 는 403 이다."""
        return self._versioned_write(
            "POST", "/samples/tags", self._tags_items_path(dataset_id, version),
            json={"sample_ids": sample_ids, "tags": tags},
        ).json()

    def remove_tags_bulk(
        self, sample_ids: list[str], tags: list[str], *,
        dataset_id: "str | None" = None, version: "str | None" = None,
    ) -> list[dict]:
        """여러 sample에서 동일한 tag들을 제거. 경로 선택과 의미는 `add_tags_bulk` 와 같다."""
        return self._versioned_write(
            "DELETE", "/samples/tags", self._tags_items_path(dataset_id, version),
            json={"sample_ids": sample_ids, "tags": tags},
        ).json()

    @staticmethod
    def _tags_items_path(dataset_id: "str | None", version: "str | None") -> "str | None":
        if not dataset_id or not version:
            return None
        return f"/datasets/{dataset_id}/versions/{_seg(version)}/samples/tags/items"

    def seal(
        self, dataset_id: str, version: str, *, wait: float = _SEAL_WAIT_SECS, description=_UNSET,
        block: bool = True,
    ) -> dict:
        """버전을 seal(불변 스냅샷)한다. 성공 시 sealed DatasetVersion을 반환한다.
        이미 sealed면 서버가 409를 반환하며 NexusError(status_code=409)로 전파된다.

        서버(0.1.33~)는 seal 을 작업 줄에 올리면 202 를 준다. `block=True`(기본)면 그 작업이 끝날 때까지 2 초 간격으로
        묻고 sealed 버전을 돌려준다 — 기다리는 시간은 `wait` 초 안에서 429 대기와 한 예산이다. 넘기면
        `NexusVersionJobPending`(`job_id` 를 싣고 seal 은 서버에서 계속 돈다), 작업이 실패·취소되면
        `NexusError(status_code=409, server_message=작업 오류)`. `block=False` 면 202 본문(`{"job", "version"}`)을
        그대로 돌려준다. 200 은 종전과 같다.

        서버(0.1.21~)는 파드의 동시 seal 상한이 차 있으면 seal 을 **시작하지 않고** 429 를 준다. 그러면
        `Retry-After` 를 지키며 최대 `wait` 초(기본 600)까지 다시 보낸다 — 시작하지 않은 요청이라 다시 보내도
        중복 seal 이 생기지 않는다. 넘기면 NexusError(status_code=429). `wait=0` 이면 기다리지 않는다.
        `wait` 는 기다린 시간만 세고 seal 자체의 소요는 세지 않는다(그쪽은 `timeout` 이다).

        seal 도중 읽기 타임아웃(기본 120 초, 다시 보내지 않는다)이 나도 서버(0.1.21~)의 seal 은 끝까지 계속된다 —
        실패로 보지 말고 `if_sealed="ignore"` 로 다시 호출하거나 버전 상태를 확인한다.

        `description` 을 주면 seal 과 함께 버전 설명을 기록한다(`None` 은 지움). 서버 0.1.21 부터 — 0.1.20 이하
        서버는 본문을 무시해 설명이 저장되지 않는다. 안 주면 본문 없이 보낸다."""
        _check_wait(wait)
        started = time.monotonic()
        kwargs = {} if description is _UNSET else {"json": {"description": description}}
        throttled = [0.0]
        r = self._post(
            f"/datasets/{dataset_id}/versions/{_seg(version)}/seal",
            throttle_wait=float(wait),
            throttle_waited=throttled,
            **kwargs,
        )
        if r.status_code == 202:
            return self._after_accepted(
                r.json(), dataset_id, version, "sealed", float(wait), block, started,
                slept=throttled[0],
            )
        return r.json()

    def update_version(self, dataset_id: str, version: str, *, description: "str | None") -> dict:
        """버전 설명을 바꾼다(draft·sealed 모두, 서버 0.1.21~). `None`·빈 문자열은 지운다. 최대 10,000 자."""
        return self._patch(
            f"/datasets/{dataset_id}/versions/{_seg(version)}", json={"description": description}
        ).json()

    def ensure_bucket(self, bucket: str) -> None:
        self._post("/api/v1/buckets/ensure", json={"bucket": bucket})

    def _ingest(self, payload: dict) -> dict:
        """`/ingest` 로 등록한다(내부 — 공개 쓰기는 `Dataset.add`·`flush`).

        **flush 를 거치지 않고 부르면 멱등 키가 붙지 않는다.** 응답을 못 받은 요청을 다시 보내려면 payload 에
        `idempotency_key`(1~128 자 출력 가능한 ASCII, 예: `str(uuid.uuid4())`)를 직접 넣어야 한다. 넣지 않으면 서버 부재 중
        애매한 실패는 지금처럼 예외로 올라간다 — 중복은 생기지 않는다(스펙 §4-3).
        """
        try:
            return self._post("/ingest", json=payload).json()
        except NexusValidationError:
            # annotation 규칙 위반(400 `annotation_invalid`)은 `errors` 목록을 실은 채 그대로 올린다.
            raise
        except NexusError as e:
            raise NexusIngestError(
                str(e), status_code=e.status_code, server_message=e.server_message
            ) from e

    def _ingest_batch(self, items: list[dict]) -> dict:
        """`/ingest/batch` 로 등록한다(내부 — 공개 쓰기는 `Dataset.add`·`flush`).

        **flush 를 거치지 않고 부르면 멱등 키가 붙지 않는다.** 응답을 못 받은 요청을 다시 보내려면 item 마다
        `idempotency_key`(1~128 자 출력 가능한 ASCII, 예: `str(uuid.uuid4())`)를 직접 넣어야 한다. 넣지 않으면 서버 부재 중
        애매한 실패는 지금처럼 예외로 올라간다 — 중복은 생기지 않는다(스펙 §4-3).
        """
        try:
            return self._post("/ingest/batch", json={"items": items}).json()
        except NexusError as e:
            raise NexusIngestError(
                str(e), status_code=e.status_code, server_message=e.server_message
            ) from e

    def get_manifest(self, dataset_id: str, version: str) -> dict:
        try:
            return self._get(f"/datasets/{dataset_id}/versions/{_seg(version)}/manifest").json()
        except NexusError as e:
            if e.status_code == 409:
                raise NexusError(
                    f"version '{version}' is not sealed — to_df() requires a sealed version",
                    status_code=e.status_code,
                    server_message=e.server_message,
                ) from e
            raise

    def get_manifest_samples(
        self, dataset_id: str, version: str,
        cursor: str | None = None, limit: int = 1000,
    ) -> dict:
        params = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return self._get(
            f"/datasets/{dataset_id}/versions/{_seg(version)}/manifest/samples",
            params=params,
        ).json()

    def _patch_annotations(
        self,
        dataset_id: str,
        version: str,
        sample_id: str,
        annotation_data: dict,
    ) -> dict:
        """그 버전의 샘플 annotation을 통째로 교체하고 **서버 보고서**를 반환한다(내부 — 공개 쓰기는 `AnnotatedSample.save`).

        보고서는 `{"instances": n, "skipped": n,
        "skipped_reasons": {"missing_label", "not_an_object", "group_not_an_array"}}` 형태다.
        교체는 병합이 아니므로 스킵된 원소는 원래 있던 인스턴스가 지워진 것과 같다 —
        `skipped`가 0이 아니면 유실이 일어났다는 뜻이다.

        호환성(중요): 구버전 서버(0.1.3 이하)는 이 경로에서 204 + 빈 본문을 준다.
        본문이 비었거나 JSON이 아니면 예외를 던지지 않고 `{}`를 반환한다 — 신버전 SDK가
        구버전 서버에 붙는 조합에서 저장 자체는 성공했기 때문이다.
        """
        r = self._put(
            f"/datasets/{dataset_id}/versions/{_seg(version)}/samples/{sample_id}/annotations",
            json={"annotation_data": annotation_data},
        )
        if not r.content:
            return {}
        try:
            body = r.json()
        except ValueError:
            return {}
        return body if isinstance(body, dict) else {}

    def get_sample_annotations(self, dataset_id: str, version: str, sample_id: str) -> dict:
        """샘플의 annotation만 조회한다(코어 필드 없음).

        반환은 같은 경로 PUT 의 `annotation_data`와 **같은 형태**라, 고쳐서 그대로
        되돌려 보낼 수 있다. 코어 필드까지 필요하면 `get_sample()`을 쓴다.
        """
        return self._get(
            f"/datasets/{dataset_id}/versions/{_seg(version)}/samples/{sample_id}/annotations"
        ).json()

    def _merge_sample_annotations(
        self,
        dataset_id: str,
        version: str,
        sample_id: str,
        annotation_data: dict,
    ) -> dict:
        """그 버전의 샘플 annotation 을 **부분 저장**하고 서버 보고서를 반환한다(PATCH, 내부 — 공개 쓰기는 `AnnotatedSample.save`).

        보낸 그룹만 통째 교체하고(빈 배열은 비우기) 안 보낸 그룹은 보존한다. `meta` 는
        top-level 병합이다 — 보낸 키는 교체, 값이 `None` 이면 그 키 삭제, 안 보낸 키는 보존.
        nexus-server `0.1.18` 부터. 그 이하는 이 경로에 PATCH 가 없어 405 다.
        """
        return self._patch(
            f"/datasets/{dataset_id}/versions/{_seg(version)}/samples/{sample_id}/annotations",
            json={"annotation_data": annotation_data},
        ).json()

    def set_sample_dimensions(
        self, items: "list[dict]", *, overwrite: bool = False,
        dataset_id: "str | None" = None, version: "str | None" = None,
    ) -> "list[dict]":
        """여러 샘플의 meta.width/height를 채우거나 고친다. `items`는 `{sample_id, width, height}`.

        기본값은 **빈칸 채우기 전용**이다 - 이미 크기가 기록된 샘플은 거부되어 결과에 사유와
        함께 담긴다. `overwrite=True`면 기록된 값도 보낸 값으로 교체한다.

        `overwrite`는 배치 단위다. 서버는 한 요청을 통째로 한 모드로 처리하므로, 채울 것과
        고칠 것을 한 호출에 섞어 보낼 수 없다.

        거부는 에러가 아니므로 서버는 배치 전체를 200으로 답한다. 건별 결과
        (`{sample_id, ok, error?}`) 리스트를 그대로 반환한다.

        `dataset_id`·`version` 을 주고 서버가 버전 경로를 가진 판이면 `PATCH /datasets/{id}/versions/{v}/samples/dimensions`
        로 보낸다 - 그 버전의 실효 meta 를 읽고 그 버전에만 쓰며 **sealed 버전은 409** 다. 이 버전에 없는 샘플은 그 항목만
        거부된다. 그보다 낮은 판이거나 둘을 주지 않으면 옛 `PATCH /samples/dimensions`(sealed 도 통과, 공유 값을 고침)로
        보낸다 - 새 서버에서 옛 경로는 410 이다.
        """
        new_path = (
            f"/datasets/{dataset_id}/versions/{_seg(version)}/samples/dimensions"
            if dataset_id and version else None
        )
        return self._versioned_write(
            "PATCH", "/samples/dimensions", new_path, json={"items": items, "overwrite": overwrite},
        ).json()["results"]

    def count_samples(
        self,
        dataset_id: str,
        version: str,
        filter: "dict | None" = None,
        *,
        exact: bool = False,
    ) -> "tuple[int, bool]":
        """필터에 걸리는 샘플 수. `(개수, 정확한가)`.

        기본은 10,000에서 세기를 멈추고 `(10000, False)`를 준다 — 사람은 "482,193"과
        "10,000+"를 다르게 읽지 않으므로 화면에는 그것으로 충분하고, 그 편이 훨씬 싸다.
        `exact=True`는 상한을 풀어 전수를 센다(비용이 결과 집합에 비례한다).
        """
        r = self._post(
            f"/datasets/{dataset_id}/versions/{_seg(version)}/samples/explorer/count",
            json=filter or {},
            params={"exact": "true"} if exact else {},
        ).json()
        return int(r["count"]), bool(r["exact"])

    # ── 집계·스키마·dataset 태그 (SDK 0.1.21, FiftyOne interop) ─────────────────
    # 서버 경로를 그대로 감싸고 응답 JSON 을 해석 없이 돌려준다. 해석은 `Dataset` 쪽이 한다.

    def version_stats(self, dataset_id: str, version: str) -> dict:
        """`{sample_count, total_size_bytes}`. 에셋 크기 합산을 함께 해서 샘플 수만 필요하면
        `count_samples(exact=True)` 가 싸다(200 만 샘플에서 약 1.5 초 대 0.5 초)."""
        return self._get(f"/datasets/{dataset_id}/versions/{_seg(version)}/stats").json()

    def facet_values(self, dataset_id: str, version: str, field: str) -> dict:
        """facet 값 목록(`kind` 로 갈리는 응답 — `range`·`datetime_range`·`enum` 등)."""
        return self._get(
            f"/datasets/{dataset_id}/versions/{_seg(version)}/facets", params={"field": field},
        ).json()

    def facet_counts(
        self, dataset_id: str, version: str, field: str, filter: "dict | None" = None,
        *, exact: bool = False,
    ) -> dict:
        """facet 값별 **샘플** 수. `{field, computed, truncated, counts: [{value, count}]}`.
        `filter` 는 explorer 본문과 같은 모양이고 그 field 자신의 필터는 서버가 뺀다.
        기본은 값 종류 500 개·3 초에서 멈춘다. `exact=True` 는 100,000 개·50 초까지 센다(nexus-server 0.1.24 부터 —
        그 이하는 인자를 무시하고 기본대로 답한다). 넘으면 `truncated: true`, 못 세면 `computed: false`(`counts` 는 빈 배열).
        `exact=True` 는 응답을 못 받으면(읽기 타임아웃·앞단 프록시 504) 자동으로 다시 보내지 않는다 — 서버에서 아직 세고
        있을 수 있어서다. 요청이 서버에 닿지 않은 실패(연결 거부)만 다시 보낸다."""
        return self._facet_counts(dataset_id, version, field, filter, exact=exact)[0]

    def _facet_counts(
        self, dataset_id: str, version: str, field: str, filter: "dict | None" = None,
        *, exact: bool = False,
    ) -> "tuple[dict, str | None]":
        """`facet_counts` 의 응답과 그 응답을 준 서버의 판(`X-Nexus-Version`, 0.1.28 이하 파드는 `None`)."""
        params = {"field": field}
        if exact:
            params["exact"] = "true"
        res = self._post(
            f"/datasets/{dataset_id}/versions/{_seg(version)}/facets/counts",
            params=params, json=filter or {}, resend=not exact,
        )
        return res.json(), res.headers.get(VERSION_HEADER)

    def histogram(self, dataset_id: str, version: str, field: str) -> dict:
        """`kind` 가 `numeric_histogram`·`datetime_histogram`·`categorical_histogram` 중 하나.
        categorical 의 `buckets[].value` 는 서버가 `meta->>'키'` 로 읽은 **문자열**이다."""
        return self._get(
            f"/datasets/{dataset_id}/versions/{_seg(version)}/histogram", params={"field": field},
        ).json()

    def get_group_kinds(self, dataset_id: str) -> "dict[str, str]":
        """dataset 에 저장된 그룹 종류 `{group_key: "group"|"container"}`. 없는 dataset 은 `NexusError(404)`.
        nexus-server 0.1.29 부터 — 그 이하는 경로가 없어 본문 없는 404 다."""
        return self._get(f"/datasets/{dataset_id}/group-kinds").json().get("kinds") or {}

    def patch_group_kinds(self, dataset_id: str, kinds: "dict[str, str | None]") -> "dict[str, str]":
        """그룹 종류를 누적해 저장한다(값 `None` 은 그 키를 지운다). 저장 뒤의 전체를 돌려준다. `viewer` 는 403.
        nexus-server 0.1.29 부터."""
        return self._patch(f"/datasets/{dataset_id}/group-kinds", json={"kinds": kinds}).json().get("kinds") or {}

    def request_schema_recompute(self, dataset_id: str, version: str) -> dict:
        """그 버전의 스키마 재계산을 줄에 세우고 작업 dict 를 돌려준다(기다리지 않는다, nexus-server 0.1.37~).

        같은 버전에 진행 중인 재계산이 있으면 서버가 그 작업을 준다. 옛 서버(경로 없음)는 판을 밝힌
        `NexusError(status_code=404)`."""
        path = f"/datasets/{dataset_id}/versions/{_seg(version)}/schema/recompute"
        r = self._send("POST", path)
        self._raise_if_schema_jobs_missing(r, "스키마 재계산")
        _raise_for_status(r)
        try:
            job = r.json().get("job")
        except (ValueError, AttributeError):
            job = None
        if not isinstance(job, dict) or not job.get("job_id"):
            # 2xx 인데 작업이 없다(nexus 가 아닌 앞단이 답했거나 본문이 잘렸다) — 작업이 섰는지 알 수 없다.
            raise NexusError(
                f"스키마 재계산: {r.status_code} 응답에 작업(job)이 없습니다 — 작업이 섰는지 알 수 없습니다"
                " (다시 부르면 서버가 같은 버전의 살아 있는 작업을 줍니다)",
                status_code=r.status_code,
                code=SCHEMA_JOB_MISSING,
            )
        return job

    def _raise_if_schema_jobs_missing(self, r: requests.Response, what: str) -> None:
        """스키마 작업 경로의 404 가 「nexus 인데 경로가 없음(옛 서버)」이면 판을 밝힌 404(`code="schema_jobs_unsupported"`)
        로 바꾼다.

        nexus(0.1.20~)는 모든 응답에 `X-Nexus-Idempotency: 1` 을 붙이고(매칭 안 된 404 포함, 프록시가 흉내 내지 않는 nexus
        고유 헤더), 인증을 지난 응답에만 `X-Nexus-Version` 을 붙인다. 이 경로들은 인증 뒤에 dataset·버전을 찾으므로 새 서버의
        404(dataset·버전 없음)에는 판 헤더가 있고 경로가 없는 옛 서버의 404 에는 없다. nexus 고유 헤더도 없는 404(프록시·
        base URL 문제, 0.1.19 이하 서버)는 그대로 둔다. 기억한 판이 아니라 그 응답의 헤더로 가르므로 롤백한 서버도 맞다."""
        if (
            r.status_code != 404
            or r.headers.get(VERSION_HEADER)
            or r.headers.get(_retry.IDEMPOTENCY_HEADER) != "1"
        ):
            return
        try:
            _raise_for_status(r)
        except NexusError as e:
            # 기억한 판은 쓰지 않는다 — 롤백한 서버면 0.1.37 을 기억하고 있어 안내가 앞뒤가 맞지 않는다.
            raise NexusError(
                f"{what}: 이 서버에 경로가 없습니다 — nexus-server 0.1.37 부터 됩니다(서버가 그보다 옛 판입니다)",
                status_code=404,
                server_message=e.server_message,
                code=SCHEMA_JOBS_UNSUPPORTED,
            ) from None

    def get_schema_job(self, job_id: str) -> dict:
        """스키마 재계산 작업 하나(`state` 는 `queued`·`running`·`done`·`failed`, 서버 표는 `cancelled` 도 받는다 — 지금은
        취소 경로가 없다). 끝난 작업의 `result` 는
        `{"conflicts": [...], "replaced": bool, "samples": n}` — `replaced=False` 는 도중에 버전이 sealed 가 되어 seal 의
        값이 남았다는 뜻이다. 없으면 `NexusError(status_code=404)` — 끝난 지 7 일이 지나 정리됐거나, 버전이 지워져 작업도
        함께 지워졌다."""
        return self._get(f"/api/v1/schema-jobs/{_seg(job_id)}").json()

    def _timeout_within(self, left: float) -> "float | tuple[float, float]":
        """남은 대기 예산 `left` 초 안에 끝나게 깎은 요청 시한. 1 초보다 짧게는 깎지 않는다(그보다 짧으면 정상 응답도
        시한에 걸린다)."""
        cap = max(left, _POLL_MIN_TIMEOUT_SECS)

        def one(x):
            return cap if x is None else min(x, cap)  # `None`(시한 없음)도 예산으로 묶는다

        t = self._timeout
        if isinstance(t, tuple):
            return (one(t[0]), one(t[1]))
        return one(t)

    def wait_schema_job(self, job: dict, *, wait: float = _SEAL_WAIT_SECS) -> dict:
        """재계산 작업이 끝나기를 `wait` 초까지 기다려 끝난 작업 dict 를 돌려준다. 아직 안 끝난 `job` 이면 곧바로 한 번
        묻고 그 뒤 2 초 간격으로 묻는다.

        `failed`·`cancelled` 면 `NexusError(status_code=409, server_message=작업 오류)`, 넘기면 `NexusSchemaJobPending`
        (작업은 서버에서 계속 돈다). 기다리는 동안 버전이 지워지면 작업도 함께 지워져 `NexusError(status_code=404)` 다.
        조회 하나의 시한과 부재 재시도도 `wait` 안에서 끊는다(`retry_timeout` 이 더 길어도) — 예산이 다 된 뒤의 조회
        실패는 마지막으로 본 작업을 실은 `NexusSchemaJobPending` 이다."""
        _check_wait(wait)
        started = time.monotonic()
        until = started + float(wait)
        slept = 0.0
        job_id = job["job_id"]
        path = f"/api/v1/schema-jobs/{_seg(job_id)}"
        first = True
        while True:
            state = job.get("state")
            if state == "done":
                return job
            if state in _SCHEMA_JOB_FAILED_STATES:
                msg = job.get("error")
                raise NexusError(
                    f"스키마 재계산 작업 {job_id} {state}: {msg or '사유 없음'}", status_code=409, server_message=msg
                )
            if not first:
                left = float(wait) - max(slept, time.monotonic() - started)
                if left <= 0:
                    raise NexusSchemaJobPending(job)
                step = min(_VERSION_JOB_POLL_SECS, left)
                time.sleep(step)
                slept += step
            first = False
            try:
                job = self._get(
                    path, retry_until=until, timeout=self._timeout_within(until - time.monotonic())
                ).json()
            except requests.RequestException:
                if time.monotonic() < until:
                    raise
                raise NexusSchemaJobPending(job) from None

    def recompute_schema(
        self, dataset_id: str, version: str, *, wait: float = _SEAL_WAIT_SECS, block: bool = True
    ) -> dict:
        """그 버전의 스키마(그룹·라벨·컴포넌트·meta 필드 관측)를 지금 데이터로 다시 만든다(nexus-server 0.1.37~).

        draft 는 지금 데이터를, sealed 는 seal 스냅샷을 읽는다. `block=True`(기본)면 작업이 끝날 때까지 `wait` 초
        (기본 600) 안에서 기다려 끝난 작업 dict(`result` 포함)를 돌려주고, `block=False` 면 줄에 세운 작업 dict 를
        바로 돌려준다. 실패는 `NexusError(409)`, 시간 초과는 `NexusSchemaJobPending`. 준비 중·실패 버전은 409
        (`code="version_preparing"`), viewer 는 403."""
        _check_wait(wait)
        started = time.monotonic()
        job = self.request_schema_recompute(dataset_id, version)
        if not block:
            return job
        # `wait` 는 요청을 보낸 때부터다(seal·fork 와 같다) — 요청의 재전송 대기도 그 안에 든다.
        return self.wait_schema_job(job, wait=max(0.0, float(wait) - (time.monotonic() - started)))

    def delete_schema_items(self, dataset_id: str, version: str, kind: str, items: "list[dict]") -> int:
        """그 버전의 스키마 항목을 지정해 지우고 지운 관측 행 수를 돌려준다(nexus-server 0.1.37~). 데이터는 보지 않는다.

        `kind` 와 `items` 의 모양: `"labels"` → `{"group", "label"}`, `"components"` → `{"group", "name"}`,
        `"meta_fields"` → `{"field", "value_type"?}`(`value_type` 을 빼면 그 필드의 모든 타입 — 실수 필드는 `number`·`float`
        두 행이라 하나만 지우면 남는다). `items` 는 1~1,000 개. draft 만 — sealed 는 409, 준비 중·실패 버전은 409
        `version_preparing`. 데이터가 남아 있으면 그 그룹을 다시 쓰거나 재계산할 때 다시 기록되므로 데이터를 먼저 지운다.
        응답을 받기 전에 끊겨도 다시 보내지 않는다(지웠는지 모르므로 `/schema` 로 확인한 뒤 다시 부른다)."""
        seg = _SCHEMA_DELETE_KINDS.get(kind)
        if seg is None:
            raise ValueError(f"kind 는 labels·components·meta_fields 중 하나여야 합니다: {kind!r}")
        if isinstance(items, (dict, str, bytes)):
            raise TypeError("items 는 항목 dict 의 목록이어야 합니다")
        items = list(items)
        if not items:
            raise ValueError("items 가 비었습니다")
        r = self._send(
            "DELETE", f"/datasets/{dataset_id}/versions/{_seg(version)}/schema/{seg}", json={"items": items}
        )
        self._raise_if_schema_jobs_missing(r, "스키마 지정 삭제")
        _raise_for_status(r)
        return int(r.json().get("deleted", 0))

    def version_schema(self, dataset_id: str, version: str) -> dict:
        """버전 스키마(`meta_schema.fields` 는 관측된 meta 필드만 담는다)."""
        return self._get(f"/datasets/{dataset_id}/versions/{_seg(version)}/schema").json()

    def add_dataset_tags(self, dataset_id: str, tags: "list[str]") -> dict:
        """dataset 태그 추가. 갱신된 dataset 을 돌려준다. `viewer` 는 403."""
        return self._post(f"/datasets/{dataset_id}/tags", json={"tags": list(tags)}).json()

    def remove_dataset_tags(self, dataset_id: str, tags: "list[str]") -> dict:
        """dataset 태그 제거. 갱신된 dataset 을 돌려준다. `viewer` 는 403."""
        return self._delete(f"/datasets/{dataset_id}/tags", json={"tags": list(tags)}).json()

    def patch_meta_items(self, dataset_id: str, version: str, items: "list[dict]") -> dict:
        """여러 샘플의 meta 를 샘플마다 다른 값으로 병합한다(`[{sample_id, meta}]`, 최대 10,000 건, 전부 또는 없음).
        거절이 있으면 `NexusError`(`code == "meta_write_rejected"`, `rejected`). nexus-server 0.1.24 부터."""
        return self._patch(
            f"/datasets/{dataset_id}/versions/{_seg(version)}/samples/meta", json={"items": items},
        ).json()

    def patch_asset_items(
        self, dataset_id: str, version: str, items: "list[dict]", overwrite: bool = False,
    ) -> dict:
        """draft 버전의 샘플에 에셋을 붙인다(`[{sample_id, assets: {role: {bucket, key, ...}}}]`, 최대 10,000 건,
        전부 또는 없음). `{updated, unchanged}`. 거절이 있으면 `NexusError`(`code == "asset_write_rejected"`,
        `rejected: [{sample_id, role, reason}]`). 같은 값은 다시 보내도 `unchanged` 라 응답이 없는 실패를 자동으로
        다시 보낸다. nexus-server 0.1.29 부터."""
        return self._patch(
            f"/datasets/{dataset_id}/versions/{_seg(version)}/samples/assets",
            json={"items": items, "overwrite": bool(overwrite)},
        ).json()

    def patch_meta_by_filter(
        self, dataset_id: str, version: str, filter: "dict | None", meta: dict, confirm: "int | None" = None,
    ) -> dict:
        """필터에 걸린 샘플 전부의 meta 에 같은 패치를 병합한다. `{updated, skipped_non_object_meta}`.
        대상이 10,000 건을 넘으면 `confirm=<건수>` 가 필요하다. nexus-server 0.1.24 부터."""
        params = {} if confirm is None else {"confirm": confirm}
        return self._patch(
            f"/datasets/{dataset_id}/versions/{_seg(version)}/samples/meta/by-filter",
            json={"filter": filter or {}, "meta": meta}, params=params,
        ).json()

    def set_keypoint_info(
        self,
        dataset_id: str,
        version: str,
        keypoint_info: dict,
        *,
        filter: "dict | None" = None,
        confirm: "int | None" = None,
    ) -> dict:
        """필터에 걸리는 샘플들의 `meta.keypoint_info`를 컴포넌트 키 단위로 병합한다.

        `keypoint_info`는 `{"<컴포넌트 키>": {"labels": [...], "edges": [[...]]}}`.
        `filter`를 비우면 그 버전의 **전부**가 대상이다.

        대상이 10,000건을 넘으면 서버가 `confirm=<개수>`를 요구한다(409).
        반환은 `{"updated": n, "skipped_non_object_meta": n}`.
        """
        params = {} if confirm is None else {"confirm": confirm}
        return self._patch(
            f"/datasets/{dataset_id}/versions/{_seg(version)}/samples/keypoint-info",
            json={"filter": filter or {}, "keypoint_info": keypoint_info},
            params=params,
        ).json()

    def get_sample(self, dataset_id: str, version: str, sample_id: str) -> dict:
        """단건 GT 조회. 코어 필드 + group_key 배열이 평탄화된 dict를 반환한다."""
        try:
            return self._get(
                f"/datasets/{dataset_id}/versions/{_seg(version)}/samples/{sample_id}"
            ).json()
        except NexusError as e:
            if e.status_code == 404:
                raise NexusError(
                    f"sample {sample_id} not found in {dataset_id}/{version}",
                    status_code=e.status_code,
                    server_message=e.server_message,
                ) from e
            raise

    def explore_samples(
        self, dataset_id: str, version: str, *,
        cursor: str | None = None, limit: int = 1000,
        split: str | None = None, tags: "list[str] | None" = None,
        exclude_tags: "list[str] | None" = None,
        meta: dict | None = None, annotation: "list[dict] | None" = None,
        include_annotations: bool | None = None,
        sample_ids: "list[str] | None" = None,
        fields: "list[str] | None" = None,
    ) -> list[dict]:
        """버전-스코프 explorer 조회 **한 페이지**(커서 기반, 페이지네이션은 호출부 책임).
        `annotation`은 `[{"group_key":, "label":, "confidence":{"min":,"max":}, "track_id":,
        "id":, "component":{...}}, ...]` 형태 — 리스트 원소끼리는 AND(sample_id 교집합),
        한 원소 안의 조건은 **같은 instance**가 전부 만족해야 함(correlated).
        `sample_ids`는 다른 필터와 AND(교집합) — 명시한 샘플들로만 범위를 좁힌다.
        `exclude_tags`는 여기 적은 태그를 **하나라도** 가진 샘플을 뺀다(`tags`와 AND).

        `fields`(nexus-server 0.1.26 부터): `["meta.<키>", "tags", "split", "sample_id"]` 중 고른 것만
        담은 행(`{"sample_id": .., "<필드>": 값}`)을 받는다. 이때 `limit` 은 10,000 까지이고, 값이 길면
        서버가 페이지를 짧게 자르므로 **빈 페이지가 올 때까지** 커서로 잇는다(마지막 페이지를 알려면
        `explore_samples_page`). 0.1.25 이하 서버는 `fields` 를 무시하고 행 전체를 1,000 개까지 준다."""
        return self.explore_samples_page(
            dataset_id, version, cursor=cursor, limit=limit, split=split, tags=tags,
            exclude_tags=exclude_tags, meta=meta, annotation=annotation,
            include_annotations=include_annotations, sample_ids=sample_ids, fields=fields,
        )[0]

    def explore_samples_page(
        self, dataset_id: str, version: str, *,
        cursor: str | None = None, limit: int = 1000,
        split: str | None = None, tags: "list[str] | None" = None,
        exclude_tags: "list[str] | None" = None,
        meta: dict | None = None, annotation: "list[dict] | None" = None,
        include_annotations: bool | None = None,
        sample_ids: "list[str] | None" = None,
        fields: "list[str] | None" = None,
    ) -> "tuple[list[dict], bool]":
        """`explore_samples` 한 페이지와 「마지막 페이지인가」. 서버(0.1.26~)는 projection(`fields`)의 마지막
        페이지에 `X-Nexus-Page-End: 1` 을 붙인다 — 없으면(옛 서버·행 전체) `False` 라 호출부가 종전 규칙으로 잇는다."""
        body: dict = {"limit": limit}
        if cursor is not None:
            body["cursor"] = cursor
        if split is not None:
            body["split"] = split
        if tags:
            body["tags"] = tags
        if exclude_tags:
            body["exclude_tags"] = exclude_tags
        if meta is not None:
            body["meta"] = meta
        if annotation:
            body["annotation"] = annotation
        if include_annotations is not None:
            body["include_annotations"] = include_annotations
        if sample_ids:
            body["sample_ids"] = sample_ids
        if fields:
            body["fields"] = fields
        # annotation 을 싣는 행 읽기(대량 읽기)에만 표시를 붙인다 — id·projection 은 붙이지 않는다.
        extra = {"headers": dict(_BULK_READ_HEADER)} if include_annotations is True and not fields else {}
        try:
            res = self._post(
                f"/datasets/{dataset_id}/versions/{_seg(version)}/samples/explorer", json=body, **extra,
            )
        except NexusError as e:
            converted = _draft_bulk_read_error(e)
            if converted is e:
                raise
            raise converted from e
        return res.json(), res.headers.get("X-Nexus-Page-End") == "1"

    def list_sample_ids_by_label(
        self, dataset_id: str, version: str, label: str
    ) -> set[str]:
        # 버전-스코프 explorer의 annotation 필터로 조회. 라벨만 필요하므로
        # include_annotations=False(경량)로 sample_id만 페이징한다.
        ids: set[str] = set()
        cursor = None
        limit = 1000
        while True:
            page = self.explore_samples(
                dataset_id, version, cursor=cursor, limit=limit,
                annotation=[{"label": label}], include_annotations=False,
            )
            for s in page:
                ids.add(s["sample_id"])
            if len(page) < limit:
                break
            cursor = page[-1]["sample_id"]  # DESC order → last row is the smallest sample_id
        return ids
