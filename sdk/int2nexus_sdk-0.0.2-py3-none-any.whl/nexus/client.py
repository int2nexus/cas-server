from __future__ import annotations
import requests
from nexus._types import NexusAuthError, NexusIngestError


class NexusClient:
    def __init__(self, nexus_url: str, email: str, password: str) -> None:
        self._base = nexus_url.rstrip("/")
        self._session = requests.Session()
        self._token: str | None = None
        self._login(email, password)

    def _login(self, email: str, password: str) -> None:
        r = self._session.post(
            f"{self._base}/api/v1/auth/login",
            json={"email": email, "password": password},
        )
        if not r.ok:
            raise NexusAuthError(f"Login failed ({r.status_code}): {r.text}")
        self._token = r.json()["token"]
        self._session.headers["Authorization"] = f"Bearer {self._token}"

    # _get and _post raise requests.HTTPError on non-2xx responses.
    # Callers (list_datasets, create_dataset, create_version) let this propagate;
    # ingest() wraps it in NexusIngestError for structured batch error handling.
    def _get(self, path: str, **kwargs) -> requests.Response:
        r = self._session.get(f"{self._base}{path}", **kwargs)
        r.raise_for_status()
        return r

    def _post(self, path: str, **kwargs) -> requests.Response:
        r = self._session.post(f"{self._base}{path}", **kwargs)
        r.raise_for_status()
        return r

    def _put(self, path: str, **kwargs) -> requests.Response:
        r = self._session.put(f"{self._base}{path}", **kwargs)
        r.raise_for_status()
        return r

    def list_datasets(self) -> list[dict]:
        return self._get("/datasets").json()

    def create_dataset(
        self,
        name: str,
        tags: list[str] | None = None,
        description: str | None = None,
    ) -> dict:
        body: dict = {"name": name}
        if tags:
            # 문자열 하나를 넘기면 단일 원소 리스트로 자동 변환 (서버는 배열을 기대).
            body["tags"] = [tags] if isinstance(tags, str) else list(tags)
        if description:
            body["description"] = description
        return self._post("/datasets", json=body).json()

    def get_version(self, dataset_id: str, version: str) -> dict | None:
        r = self._session.get(
            f"{self._base}/datasets/{dataset_id}/versions/{version}"
        )
        if r.status_code == 404:
            return None
        r.raise_for_status()
        return r.json()

    def create_version(
        self,
        dataset_id: str,
        version: str,
        fork_from: str | None = None,
    ) -> dict:
        body: dict = {"version": version}
        if fork_from is not None:
            body["fork_from"] = fork_from
        return self._post(f"/datasets/{dataset_id}/versions", json=body).json()

    def add_sample_ids(self, dataset_id: str, version: str, sample_ids: list[str]) -> None:
        self._post(
            f"/datasets/{dataset_id}/versions/{version}/samples",
            json={"sample_ids": sample_ids},
        )

    def ensure_bucket(self, bucket: str) -> None:
        self._post("/api/v1/buckets/ensure", json={"bucket": bucket})

    def ingest(self, payload: dict) -> dict:
        try:
            return self._post("/ingest", json=payload).json()
        except requests.HTTPError as e:
            raise NexusIngestError(str(e)) from e

    def ingest_batch(self, items: list[dict]) -> dict:
        try:
            return self._post("/ingest/batch", json={"items": items}).json()
        except requests.HTTPError as e:
            raise NexusIngestError(str(e)) from e

    def get_manifest(self, dataset_id: str, version: str) -> dict:
        from nexus._types import NexusError
        try:
            return self._get(f"/datasets/{dataset_id}/versions/{version}/manifest").json()
        except requests.HTTPError as e:
            if e.response is not None and e.response.status_code == 409:
                raise NexusError(
                    f"version '{version}' is not sealed — to_df() requires a sealed version"
                ) from e
            raise

    def get_manifest_samples(
        self, dataset_id: str, version: str,
        cursor: str | None = None, limit: int = 1000,
    ) -> dict:
        params = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        return self._get(
            f"/datasets/{dataset_id}/versions/{version}/manifest/samples",
            params=params,
        ).json()

    def patch_annotations(
        self,
        dataset_id: str,
        version: str,
        sample_id: str,
        annotation_data: dict,
    ) -> None:
        self._put(
            f"/datasets/{dataset_id}/versions/{version}/samples/{sample_id}/annotations",
            json={"annotation_data": annotation_data},
        )

    def get_sample(self, dataset_id: str, version: str, sample_id: str) -> dict:
        from nexus._types import NexusError
        try:
            return self._get(
                f"/datasets/{dataset_id}/versions/{version}/samples/{sample_id}"
            ).json()
        except requests.HTTPError as e:
            if e.response is not None and e.response.status_code == 404:
                raise NexusError(
                    f"sample {sample_id} not found in {dataset_id}/{version}"
                ) from e
            raise

    def list_sample_ids_by_label(
        self, dataset_id: str, version: str, label: str
    ) -> set[str]:
        ids: set[str] = set()
        cursor = None
        limit = 1000
        while True:
            params = {"dataset_id": dataset_id, "version": version,
                      "label": label, "limit": limit}
            if cursor is not None:
                params["cursor"] = cursor
            page = self._get("/samples", params=params).json()
            for s in page:
                ids.add(s["sample_id"])
            if len(page) < limit:
                break
            cursor = page[-1]["sample_id"]  # DESC order → last row is the smallest sample_id
        return ids
