from __future__ import annotations
import os

from nexus._types import (
    IngestResult,
    NexusAuthError,
    NexusBatchError,
    NexusCasError,
    NexusError,
    NexusIngestError,
)
from nexus.cas import CasClient
from nexus.client import NexusClient
from nexus.dataset import Dataset
from nexus.sample import CasRef, Sample
from nexus.upload import upload

_client: NexusClient | None = None
_cas: CasClient | None = None


def connect(
    nexus_url: str | None = None,
    email: str | None = None,
    password: str | None = None,
    cas_url: str | None = None,
    cas_key_id: str | None = None,
    cas_secret: str | None = None,
) -> NexusClient:
    # bucket은 전역 기본값을 두지 않는다 — nx.upload(paths, bucket=...)에서 호출별로 지정.
    global _client, _cas

    _nexus_url = nexus_url or os.environ["NEXUS_URL"]
    _email = email or os.environ["NEXUS_EMAIL"]
    _password = password or os.environ["NEXUS_PASSWORD"]
    _cas_url = cas_url or os.environ["CAS_URL"]
    _cas_key_id = cas_key_id or os.environ.get("CAS_KEY_ID", "")
    _cas_secret = cas_secret or os.environ.get("CAS_SECRET", "")

    _client = NexusClient(_nexus_url, _email, _password)
    _cas = CasClient(_cas_url, _cas_key_id, _cas_secret)
    return _client


def _auto_connect() -> NexusClient:
    global _client
    if _client is None:
        connect()
    return _client  # type: ignore[return-value]


__all__ = [
    "connect",
    "Dataset",
    "Sample",
    "CasRef",
    "upload",
    "IngestResult",
    "NexusError",
    "NexusAuthError",
    "NexusCasError",
    "NexusIngestError",
    "NexusBatchError",
]
