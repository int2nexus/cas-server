import json

import blake3
import pytest
from unittest.mock import MagicMock, create_autospec, patch
from nexus.cas import CasClient
from nexus.client import NexusClient
from nexus.dataset import Dataset
from nexus.sample import Sample, CasRef
from nexus._types import NexusBatchError, NexusError


def _ds(mock_client, mock_cas):
    return Dataset(mock_client, mock_cas, "d1", "kitti", "v1")


def _rich_sample(split=None):
    """리치 CasRef + meta 포함 annotation → flush 시 HEAD/dims fetch 불필요."""
    ref = CasRef("kitti", "images/a.png", hash_hex="h", size=10, content_type="image/png")
    ann = {"meta": {"format_version": "1.0.0", "filename": "http://cas/kitti/images/a.png",
                    "width": 4, "height": 4}}
    return Sample(image=ref, annotation=ann, split=split)


def _samples_page():
    # samples now come from the paginated /manifest/samples endpoint.
    return {
        "samples": [
            {
                "sample_id": "s1",
                "split": "train",
                "assets": {
                    "image": {"cas_url": "http://cas/img1", "hash_hex": "h1", "size": 10},
                },
            },
        ],
        "next_cursor": None,
    }


def _batch_ok(n=1):
    return {"results": [{"index": i, "sample_id": f"s{i}", "dataset_id": "d1"} for i in range(n)]}


# ── properties ────────────────────────────────────────────────────────────────

def test_dataset_id_and_version_properties():
    ds = _ds(MagicMock(), MagicMock())
    assert ds.dataset_id == "d1"
    assert ds.version == "v1"


# ── queueing ────────────────────────────────────────────────────────────────

def test_add_queues_sample():
    ds = _ds(MagicMock(), MagicMock())
    s = _rich_sample()
    ds.add(s)
    assert ds._queue == [s]


def test_list_samples_paginates():
    mock_client = MagicMock()
    mock_client.get_manifest_samples.side_effect = [
        {"samples": [{"sample_id": "s1"}, {"sample_id": "s2"}], "next_cursor": "s2"},
        {"samples": [{"sample_id": "s3"}], "next_cursor": None},
    ]
    ds = _ds(mock_client, MagicMock())
    out = ds.list_samples(page_size=2)
    assert [s["sample_id"] for s in out] == ["s1", "s2", "s3"]
    assert mock_client.get_manifest_samples.call_count == 2


def test_list_samples_split_filter_and_max():
    mock_client = MagicMock()
    mock_client.get_manifest_samples.side_effect = [
        {"samples": [
            {"sample_id": "s1", "split": "train"},
            {"sample_id": "s2", "split": "val"},
            {"sample_id": "s3", "split": "train"},
        ], "next_cursor": None},
    ]
    ds = _ds(mock_client, MagicMock())
    assert [s["sample_id"] for s in ds.list_samples(split="train")] == ["s1", "s3"]
    mock_client.get_manifest_samples.side_effect = [
        {"samples": [{"sample_id": "s1"}, {"sample_id": "s2"}], "next_cursor": "s2"},
    ]
    assert len(ds.list_samples(max_samples=1)) == 1   # 상한에서 즉시 중단


def test_add_accepts_list():
    ds = _ds(MagicMock(), MagicMock())
    samples = [_rich_sample() for _ in range(3)]
    ds.add(samples)                      # 리스트도 add로 처리
    assert len(ds._queue) == 3


def test_add_rejects_non_sample_in_list():
    import pytest
    ds = _ds(MagicMock(), MagicMock())
    with pytest.raises(TypeError, match="Sample"):
        ds.add([_rich_sample(), "not-a-sample"])


# ── Sample ref model ──────────────────────────────────────────────────────────

def test_sample_rejects_local_path_image():
    with pytest.raises(ValueError, match="nx.upload"):
        Sample(image="data/local.png", annotation={"meta": {}})


# ── flush: ref resolution ──────────────────────────────────────────────────────

def test_flush_rich_ref_no_head():
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_client = MagicMock(); mock_client.ingest_batch.return_value = _batch_ok(1)
    ds = _ds(mock_client, mock_cas)
    ref = CasRef("kitti", "images/a.png", hash_hex="h", size=10, content_type="image/png")
    ann = {"meta": {"format_version": "1.0.0", "filename": "http://cas/kitti/images/a.png", "width": 4, "height": 4}}
    ds.add(Sample(image=ref, annotation=ann, split="train"))
    ds.flush(workers=1, verbose=False)
    mock_cas.head.assert_not_called()
    payload = mock_client.ingest_batch.call_args[0][0][0]
    assert payload["image"]["hash_hex"] == "h" and payload["image"]["size"] == 10
    assert payload["image"]["key"] == "images/a.png"


def test_flush_bare_ref_heads():
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_cas.head.return_value = {"hash_hex": "h2", "size": 20, "content_type": "image/png"}
    mock_client = MagicMock(); mock_client.ingest_batch.return_value = _batch_ok(1)
    ds = _ds(mock_client, mock_cas)
    ann = {"meta": {"format_version": "1.0.0", "filename": "x", "width": 1, "height": 1}}
    ds.add(Sample(image="s3://kitti/images/b.png", annotation=ann))
    ds.flush(workers=1, verbose=False)
    mock_cas.head.assert_called_once_with("kitti", "images/b.png")
    payload = mock_client.ingest_batch.call_args[0][0][0]
    assert payload["image"]["hash_hex"] == "h2" and payload["image"]["size"] == 20


def test_flush_includes_assets_dict():
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_client = MagicMock(); mock_client.ingest_batch.return_value = _batch_ok(1)
    ds = _ds(mock_client, mock_cas)
    ref = CasRef("kitti", "images/a.png", hash_hex="h", size=10, content_type="image/png")
    depth_ref = CasRef("kitti", "depth/a.png", hash_hex="d", size=5, content_type="image/png")
    ann = {"meta": {"format_version": "1.0.0", "filename": "http://cas/kitti/images/a.png", "width": 4, "height": 4}}
    ds.add(Sample(image=ref, annotation=ann, assets={"depth": depth_ref}))
    ds.flush(workers=1, verbose=False)
    payload = mock_client.ingest_batch.call_args[0][0][0]
    assert "depth" not in payload
    assert payload["assets"]["depth"]["key"] == "depth/a.png"
    assert payload["assets"]["depth"]["hash_hex"] == "d"


def test_flush_no_assets_omits_assets_key():
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_client = MagicMock(); mock_client.ingest_batch.return_value = _batch_ok(1)
    ds = _ds(mock_client, mock_cas)
    ref = CasRef("kitti", "images/a.png", hash_hex="h", size=10, content_type="image/png")
    ann = {"meta": {"format_version": "1.0.0", "filename": "http://cas/kitti/images/a.png", "width": 4, "height": 4}}
    ds.add(Sample(image=ref, annotation=ann))
    ds.flush(workers=1, verbose=False)
    payload = mock_client.ingest_batch.call_args[0][0][0]
    assert "assets" not in payload


def test_flush_cas_object_missing_marks_failed():
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_cas.head.return_value = None
    mock_client = MagicMock()
    ds = _ds(mock_client, mock_cas)
    ann = {"meta": {"format_version": "1.0.0", "filename": "x", "width": 1, "height": 1}}
    ds.add(Sample(image="s3://kitti/images/missing.png", annotation=ann))
    results = ds.flush(workers=1, verbose=False)
    assert not results[0].ok
    assert "CAS object 없음" in results[0].error


def test_flush_clears_queue():
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_client = MagicMock(); mock_client.ingest_batch.return_value = _batch_ok(1)
    ds = _ds(mock_client, mock_cas)
    ds.add(_rich_sample())
    ds.flush(workers=1, verbose=False)
    assert ds._queue == []


def test_flush_partial_failure_strict_false():
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_client = MagicMock()
    mock_client.ingest_batch.return_value = {
        "results": [
            {"index": 0, "sample_id": "s0", "dataset_id": "d1"},
            {"index": 1, "error": "server error"},
        ]
    }
    ds = _ds(mock_client, mock_cas)
    ds.add(_rich_sample())
    ds.add(_rich_sample())
    results = ds.flush(workers=1, verbose=False)

    assert len(results) == 2
    assert sum(1 for r in results if r.ok) == 1
    assert sum(1 for r in results if not r.ok) == 1
    assert any("server error" in r.error for r in results if r.error)


def test_flush_strict_true_raises_batch_error():
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_client = MagicMock()
    mock_client.ingest_batch.return_value = {"results": [{"index": 0, "error": "fail"}]}
    ds = _ds(mock_client, mock_cas)
    ds.add(_rich_sample())
    with pytest.raises(NexusBatchError) as exc:
        ds.flush(workers=1, strict=True, verbose=False)
    assert len(exc.value.failures) == 1
    assert not exc.value.failures[0].ok


# ── annotation handling ────────────────────────────────────────────────────────

def test_flush_cas_ref_annotation_fetched_inline(requests_mock):
    mock_cas = MagicMock()
    mock_cas.head.return_value = {"hash_hex": "abc123", "size": 1024, "content_type": "image/png"}
    mock_cas._base = "http://cas"
    mock_client = MagicMock()
    mock_client.ingest_batch.return_value = _batch_ok(1)

    ds = _ds(mock_client, mock_cas)
    ds.add(Sample(image="s3://bucket/img.png", annotation="s3://bucket/ann.json"))

    # annotation은 inline으로 fetch(meta 없음) → 이미지 다운로드 없이 최소 meta 생성
    mock_cas.get.return_value = b'{"objects": []}'
    results = ds.flush(workers=1, verbose=False)

    assert results[0].ok
    mock_cas.get.assert_called_once_with("bucket", "ann.json", timeout=30)
    mock_cas.put.assert_not_called()
    payload = mock_client.ingest_batch.call_args[0][0][0]
    assert payload["image"]["bucket"] == "bucket"
    assert payload["image"]["key"] == "img.png"
    assert payload["image"]["hash_hex"] == "abc123"
    ann_data = payload["annotation"]["annotation_data"]
    assert ann_data["objects"] == []
    assert ann_data["meta"]["format_version"] == "1.0.0"
    assert ann_data["meta"]["filename"] == "http://cas/bucket/img.png"
    assert "width" not in ann_data["meta"]
    assert "height" not in ann_data["meta"]


def test_process_meta_present_is_trusted_unchanged():
    # meta가 있으면 어떤 필드도 수정하지 않고 사용자 입력을 그대로 신뢰한다.
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_client = MagicMock(); mock_client.ingest_batch.return_value = _batch_ok(1)
    ref = CasRef("kitti", "images/a.png", hash_hex="h", size=10, content_type="image/png")
    ann = {
        "meta": {"format_version": "2.0", "filename": "/data/src/custom.png", "width": 999, "height": 777},
        "scene_gt": [{"id": "s1", "label": "highway"}],
    }
    ds = _ds(mock_client, mock_cas)
    ds.add(Sample(image=ref, annotation=ann))
    ds.flush(workers=1, verbose=False)

    meta = mock_client.ingest_batch.call_args[0][0][0]["annotation"]["annotation_data"]["meta"]
    assert meta == {"format_version": "2.0", "filename": "/data/src/custom.png", "width": 999, "height": 777}
    assert "original_filename" not in meta   # filename 덮어쓰기/보존 안 함


def test_process_uses_ref_dims_when_meta_absent_no_download():
    # meta가 없으면 CasRef에 캐시된 dims를 사용한다(이미지 재다운로드 없음).
    # (requests_mock을 안 걸었는데 통과 = 이미지 다운로드가 일어나지 않았다는 뜻.)
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_client = MagicMock(); mock_client.ingest_batch.return_value = _batch_ok(1)
    ref = CasRef("kitti", "images/a.png", hash_hex="h", size=10,
                 content_type="image/png", width=640, height=480)
    ds = _ds(mock_client, mock_cas)
    ds.add(Sample(image=ref, annotation={"scene_gt": [{"id": "s1", "label": "x"}]}))  # meta 없음
    ds.flush(workers=1, verbose=False)

    ann_data = mock_client.ingest_batch.call_args[0][0][0]["annotation"]["annotation_data"]
    assert ann_data["meta"] == {
        "format_version": "1.0.0",
        "filename": "http://cas/kitti/images/a.png",
        "width": 640,
        "height": 480,
    }
    assert "scene_gt" in ann_data  # 기존 내용 보존


def test_process_meta_omits_dims_when_ref_has_no_dims():
    # bare ref(URL 등, dims 없음) → meta에 width/height 키를 아예 넣지 않는다.
    # 0을 적으면 facet range가 min:0으로 오염되고 CVAT 정규화 좌표가 무의미해진다.
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_cas.head.return_value = {"hash_hex": "h", "size": 1, "content_type": "image/png"}
    mock_client = MagicMock(); mock_client.ingest_batch.return_value = _batch_ok(1)
    ds = _ds(mock_client, mock_cas)
    ds.add(Sample(image="s3://kitti/images/a.png", annotation={"scene_gt": []}))  # meta 없음, bare ref
    ds.flush(workers=1, verbose=False)

    meta = mock_client.ingest_batch.call_args[0][0][0]["annotation"]["annotation_data"]["meta"]
    assert "width" not in meta and "height" not in meta
    assert meta["filename"] == "http://cas/kitti/images/a.png"


def test_process_builds_minimal_meta_no_annotation_no_download():
    # annotation=None (bare ref) → HEAD만, 이미지 다운로드 없음, meta에 w/h 없음.
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_cas.head.return_value = {"hash_hex": "h", "size": 1, "content_type": "image/png"}
    mock_client = MagicMock(); mock_client.ingest_batch.return_value = _batch_ok(1)

    ds = _ds(mock_client, mock_cas)
    ds.add(Sample(image="s3://kitti/images/d.png"))  # annotation=None
    ds.flush(workers=1, verbose=False)

    meta = mock_client.ingest_batch.call_args[0][0][0]["annotation"]["annotation_data"]["meta"]
    assert meta == {
        "format_version": "1.0.0",
        "filename": "http://cas/kitti/images/d.png",
    }


def test_flush_annotation_only_derives_image_from_meta(requests_mock):
    """annotation만 있을 때 meta.filename에서 image bucket/key를 파싱해 ingest한다."""
    mock_cas = MagicMock()
    mock_cas._base = "http://cas"
    mock_cas.head.return_value = {"hash_hex": "abc", "size": 1024, "content_type": "image/bmp"}
    mock_client = MagicMock()
    mock_client.ingest_batch.return_value = _batch_ok(1)

    ann = {
        "meta": {
            "format_version": "1.0.0",
            "filename": "http://cas/mybucket/img/foo.bmp",
            "width": 1280,
            "height": 720,
        },
        "objects": [],
    }
    mock_cas.get.return_value = json.dumps(ann).encode()

    ds = _ds(mock_client, mock_cas)
    ds.add(Sample(annotation="http://cas/anns/ann.json"))
    results = ds.flush(workers=1, verbose=False)

    assert results[0].ok
    mock_cas.put.assert_not_called()
    payload = mock_client.ingest_batch.call_args[0][0][0]
    assert payload["image"]["bucket"] == "mybucket"
    assert payload["image"]["key"] == "img/foo.bmp"
    ann_data = payload["annotation"]["annotation_data"]
    assert ann_data["meta"]["width"] == 1280
    assert ann_data["objects"] == []


def test_flush_annotation_only_missing_meta_filename_fails(requests_mock):
    """annotation에 meta.filename이 없으면 에러로 처리된다."""
    mock_cas = MagicMock()
    mock_cas._base = "http://cas"
    mock_client = MagicMock()

    mock_cas.get.return_value = b'{"objects": []}'

    ds = _ds(mock_client, mock_cas)
    ds.add(Sample(annotation="http://cas/anns/ann.json"))
    results = ds.flush(workers=1, verbose=False)

    assert not results[0].ok
    assert "meta.filename" in results[0].error


def test_flush_annotation_only_local_filename_fails(requests_mock):
    """meta.filename이 로컬 경로면 CAS URL 요구 에러."""
    mock_cas = MagicMock()
    mock_cas._base = "http://cas"
    mock_client = MagicMock()
    ann = {"meta": {"format_version": "1.0.0", "filename": "local/foo.png", "width": 1, "height": 1}}
    mock_cas.get.return_value = json.dumps(ann).encode()

    ds = _ds(mock_client, mock_cas)
    ds.add(Sample(annotation="http://cas/anns/ann.json"))
    results = ds.flush(workers=1, verbose=False)

    assert not results[0].ok
    assert "meta.filename" in results[0].error


def test_flush_http_url_parses_bucket_key():
    """HTTP CAS URL은 bucket/key로 파싱되고 업로드 없이 ingest된다."""
    mock_cas = MagicMock()
    mock_cas._base = "http://cas"
    mock_cas.head.return_value = {"hash_hex": "abc123", "size": 2048, "content_type": "image/png"}
    mock_client = MagicMock()
    mock_client.ingest_batch.return_value = _batch_ok(1)

    ds = _ds(mock_client, mock_cas)
    ds.add(Sample(image="http://cas/mybucket/path/to/img.png"))
    results = ds.flush(workers=1, verbose=False)

    assert results[0].ok
    mock_cas.put.assert_not_called()
    payload = mock_client.ingest_batch.call_args[0][0][0]
    assert payload["image"]["bucket"] == "mybucket"
    assert payload["image"]["key"] == "path/to/img.png"
    assert payload["image"]["size"] == 2048
    assert payload["image"]["content_type"] == "image/png"


# ── context manager ────────────────────────────────────────────────────────────

def test_context_manager_flushes_on_exit():
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_client = MagicMock(); mock_client.ingest_batch.return_value = _batch_ok(1)

    with Dataset(mock_client, mock_cas, "d1", "kitti", "v1") as ds:
        ds.add(_rich_sample())

    mock_client.ingest_batch.assert_called_once()


def test_context_manager_skips_flush_on_exception():
    mock_client = MagicMock()
    mock_cas = MagicMock()

    try:
        with Dataset(mock_client, mock_cas, "d1", "kitti", "v1") as ds:
            ds.add(_rich_sample())
            raise ValueError("oops")
    except ValueError:
        pass
    mock_client.ingest_batch.assert_not_called()


# ── client / load_or_create ─────────────────────────────────────────────────────

def test_client_ensure_bucket_posts(requests_mock):
    requests_mock.post("http://nexus/api/v1/auth/login",
                       json={"token": "tok", "user_id": 1, "email": "u@x.com"})
    requests_mock.post("http://nexus/api/v1/buckets/ensure", status_code=200)

    from nexus.client import NexusClient
    client = NexusClient("http://nexus", "u@x.com", "pass")
    client.ensure_bucket("kitti")

    assert requests_mock.last_request.method == "POST"
    assert requests_mock.last_request.json() == {"bucket": "kitti"}


def test_load_or_create_finds_existing_dataset_and_version(requests_mock):
    requests_mock.post("http://nexus/api/v1/auth/login",
                       json={"token": "tok", "user_id": 1, "email": "u@x.com"})
    requests_mock.get("http://nexus/datasets",
                      json=[{"dataset_id": "d1", "name": "kitti"}])
    requests_mock.get("http://nexus/datasets/d1/versions/v1",
                      json={"dataset_version_id": "dv1", "version": "v1"})

    from nexus.client import NexusClient
    from nexus.cas import CasClient
    client = NexusClient("http://nexus", "u@x.com", "pass")
    cas = CasClient("http://cas")
    ds = Dataset.load_or_create("kitti", "v1", client=client, cas=cas)
    assert ds._dataset_id == "d1"
    assert ds._version == "v1"


def test_load_or_create_creates_missing_dataset_and_version(requests_mock):
    requests_mock.post("http://nexus/api/v1/auth/login",
                       json={"token": "tok", "user_id": 1, "email": "u@x.com"})
    requests_mock.get("http://nexus/datasets", json=[])
    requests_mock.post("http://nexus/datasets",
                       json={"dataset_id": "d2", "name": "new-ds"}, status_code=201)
    requests_mock.get("http://nexus/datasets/d2/versions/v1", status_code=404)
    requests_mock.post("http://nexus/datasets/d2/versions",
                       json={"dataset_version_id": "dv1", "version": "v1"}, status_code=201)

    from nexus.client import NexusClient
    from nexus.cas import CasClient
    client = NexusClient("http://nexus", "u@x.com", "pass")
    cas = CasClient("http://cas")
    ds = Dataset.load_or_create("new-ds", "v1", client=client, cas=cas)
    assert ds._dataset_id == "d2"
    assert ds._name == "new-ds"


# ── clone (서버 job + 구버전 폴백) ────────────────────────────────────────────

def test_clone_uses_server_job_and_returns_target(monkeypatch):
    """신서버: create_clone_job → 폴링 → succeeded 면 target_dataset_id 로 Dataset 반환.
    클라이언트 import 반복은 일어나지 않는다."""
    mock_client = MagicMock()
    ds = _ds(mock_client, MagicMock())
    mock_client.create_clone_job.return_value = {
        "job_id": "j1", "status": "running", "target_dataset_id": None,
        "target_name": "copy", "target_version": "v2", "copied_count": 0, "total_count": None,
    }
    mock_client.get_clone_job.side_effect = [
        {"job_id": "j1", "status": "running", "copied_count": 1, "total_count": 2,
         "target_dataset_id": "d2", "target_name": "copy", "target_version": "v2"},
        {"job_id": "j1", "status": "succeeded", "copied_count": 2, "total_count": 2,
         "target_dataset_id": "d2", "target_name": "copy", "target_version": "v2"},
    ]
    monkeypatch.setattr("nexus.dataset.time.sleep", lambda _s: None)

    out = ds.clone("copy", "v2", verbose=False)

    assert isinstance(out, Dataset)
    assert (out._dataset_id, out._name, out._version) == ("d2", "copy", "v2")
    mock_client.create_clone_job.assert_called_once_with("d1", "v1", "copy", "v2")
    mock_client.import_samples.assert_not_called()  # 서버가 복사 — 클라 반복 없음


def test_clone_falls_back_to_client_side_on_404(monkeypatch):
    """구서버(엔드포인트 없음): create_clone_job 이 404 → 클라이언트 반복으로 폴백."""
    mock_client = MagicMock()
    ds = _ds(mock_client, MagicMock())
    mock_client.create_clone_job.side_effect = NexusError("not found", status_code=404)
    mock_client.get_dataset.return_value = {"tags": ["t"], "description": "d"}
    new_ds = MagicMock()
    monkeypatch.setattr(Dataset, "load_or_create", classmethod(lambda cls, *a, **k: new_ds))
    monkeypatch.setattr(Dataset, "list_samples",
                        lambda self, **k: [{"sample_id": "s1"}, {"sample_id": "s2"}])

    out = ds.clone("copy", "v9", batch_size=1, verbose=False)

    assert out is new_ds
    mock_client.create_clone_job.assert_called_once()
    assert new_ds.import_samples.call_count == 2  # 2 샘플, batch_size=1


def test_clone_non_404_error_propagates_without_fallback():
    """404 가 아닌 에러(예: 409 이름 중복)는 폴백하지 않고 그대로 올린다."""
    mock_client = MagicMock()
    ds = _ds(mock_client, MagicMock())
    mock_client.create_clone_job.side_effect = NexusError("conflict", status_code=409)

    with pytest.raises(NexusError) as ei:
        ds.clone("copy", "v2", verbose=False)

    assert ei.value.status_code == 409
    mock_client.get_dataset.assert_not_called()  # 폴백 경로 진입 안 함


def test_clone_raises_on_failed_job(monkeypatch):
    mock_client = MagicMock()
    ds = _ds(mock_client, MagicMock())
    mock_client.create_clone_job.return_value = {
        "job_id": "j1", "status": "running", "copied_count": 0, "total_count": None}
    mock_client.get_clone_job.return_value = {
        "job_id": "j1", "status": "failed", "error": "boom", "copied_count": 0, "total_count": 0}
    monkeypatch.setattr("nexus.dataset.time.sleep", lambda _s: None)

    with pytest.raises(NexusError) as ei:
        ds.clone("copy", "v2", verbose=False)
    assert "boom" in str(ei.value)


def test_clone_raises_on_cancelled_job(monkeypatch):
    mock_client = MagicMock()
    ds = _ds(mock_client, MagicMock())
    mock_client.create_clone_job.return_value = {
        "job_id": "j1", "status": "running", "copied_count": 0, "total_count": None}
    mock_client.get_clone_job.return_value = {
        "job_id": "j1", "status": "cancelled", "copied_count": 0, "total_count": 1}
    monkeypatch.setattr("nexus.dataset.time.sleep", lambda _s: None)

    with pytest.raises(NexusError):
        ds.clone("copy", "v2", verbose=False)


def test_clone_timeout_stops_waiting_on_a_job_that_never_finishes(monkeypatch):
    """끝나지 않는 job 은 timeout 이 지나면 job id 를 담은 에러로 멈춘다(무한 폴링 방지)."""
    mock_client = MagicMock()
    ds = _ds(mock_client, MagicMock())
    mock_client.create_clone_job.return_value = {
        "job_id": "j9", "status": "running", "copied_count": 0, "total_count": None}
    mock_client.get_clone_job.return_value = {
        "job_id": "j9", "status": "running", "copied_count": 0, "total_count": None}
    clock = {"t": 0.0}
    monkeypatch.setattr("nexus.dataset.time.monotonic", lambda: clock["t"])
    monkeypatch.setattr("nexus.dataset.time.sleep", lambda s: clock.__setitem__("t", clock["t"] + s))

    with pytest.raises(NexusError) as ei:
        ds.clone("copy", "v2", verbose=False, timeout=5)
    assert "j9" in str(ei.value)
    mock_client.cancel_clone_job.assert_not_called()  # 기다리기만 멈추고 취소하지 않는다


def test_create_clone_job_posts(requests_mock):
    requests_mock.post("http://nexus/api/v1/auth/login",
                       json={"token": "tok", "user_id": 1, "email": "u@x.com"})
    requests_mock.post("http://nexus/datasets/d1/versions/v1/clone-jobs",
                       json={"job_id": "j1", "status": "running"}, status_code=201)
    client = NexusClient("http://nexus", "u@x.com", "pass")
    job = client.create_clone_job("d1", "v1", "copy", "v2")
    assert job["job_id"] == "j1"
    assert requests_mock.last_request.json() == {"target_name": "copy", "target_version": "v2"}


def test_get_clone_job_gets(requests_mock):
    requests_mock.post("http://nexus/api/v1/auth/login",
                       json={"token": "tok", "user_id": 1, "email": "u@x.com"})
    requests_mock.get("http://nexus/clone-jobs/j1", json={"job_id": "j1", "status": "succeeded"})
    client = NexusClient("http://nexus", "u@x.com", "pass")
    assert client.get_clone_job("j1")["status"] == "succeeded"


# ── patch_annotations ───────────────────────────────────────────────────────────

def test_patch_annotations_single_delegates_to_client():
    mock_client = MagicMock()
    ds = _ds(mock_client, MagicMock())
    ann = {"meta": {"filename": "img.bmp"}, "scene_gt": [{"id": "a", "label": "car"}]}

    out = ds.patch_annotations("sample-uuid-123", ann)

    assert out is None
    mock_client.patch_annotations.assert_called_once_with("d1", "v1", "sample-uuid-123", ann)


def test_patch_annotations_batch_dict_parallel():
    mock_client = MagicMock()
    ds = _ds(mock_client, MagicMock())
    patches = {"s1": {"meta": {}, "objects": []}, "s2": {"scene_gt": []}}

    results = ds.patch_annotations(patches, workers=2, verbose=False)

    assert {r.sample_id for r in results} == {"s1", "s2"}
    assert all(r.ok for r in results)
    assert mock_client.patch_annotations.call_count == 2
    mock_client.patch_annotations.assert_any_call("d1", "v1", "s1", {"meta": {}, "objects": []})
    mock_client.patch_annotations.assert_any_call("d1", "v1", "s2", {"scene_gt": []})


def test_patch_annotations_batch_isolates_failure():
    mock_client = MagicMock()

    def put(dsid, ver, sid, ann):
        if sid == "bad":
            raise RuntimeError("boom")
    mock_client.patch_annotations.side_effect = put
    ds = _ds(mock_client, MagicMock())

    results = ds.patch_annotations(
        {"ok1": {"objects": []}, "bad": {"objects": []}}, workers=1, verbose=False
    )
    by_id = {r.sample_id: r for r in results}
    assert by_id["ok1"].ok is True
    assert by_id["bad"].ok is False and "boom" in by_id["bad"].error


def test_patch_annotations_warns_on_skip_but_keeps_return_contract():
    # 벌크 API의 반환 계약은 그대로다(단일 None / 배치 list) — 경고만 추가된다.
    import pytest
    skipped = {
        "instances": 0,
        "skipped": 1,
        "skipped_reasons": {"missing_label": 1, "not_an_object": 0, "group_not_an_array": 0},
    }
    mock_client = MagicMock()
    mock_client.patch_annotations.return_value = skipped
    ds = _ds(mock_client, MagicMock())

    with pytest.warns(RuntimeWarning, match="missing_label=1"):
        assert ds.patch_annotations("s1", {"objects": []}) is None

    with pytest.warns(RuntimeWarning, match="missing_label=1"):
        results = ds.patch_annotations({"s1": {"objects": []}}, workers=1, verbose=False)
    assert [r.ok for r in results] == [True]


def test_patch_annotations_batch_strict_raises():
    from nexus._types import NexusBatchError
    import pytest
    mock_client = MagicMock()
    mock_client.patch_annotations.side_effect = RuntimeError("boom")
    ds = _ds(mock_client, MagicMock())
    with pytest.raises(NexusBatchError):
        ds.patch_annotations({"s1": {"objects": []}}, strict=True, verbose=False)


def test_client_patch_annotations_sends_put(requests_mock):
    requests_mock.post("http://nexus/api/v1/auth/login",
                       json={"token": "tok", "user_id": 1, "email": "u@x.com"})
    requests_mock.put(
        "http://nexus/datasets/d1/versions/v1/samples/s1/annotations",
        status_code=204,
    )

    from nexus.client import NexusClient
    client = NexusClient("http://nexus", "u@x.com", "pass")
    ann = {"meta": {"filename": "img.bmp"}, "scene_gt": [{"id": "a", "label": "car"}]}
    out = client.patch_annotations("d1", "v1", "s1", ann)

    assert requests_mock.last_request.method == "PUT"
    assert requests_mock.last_request.json() == {"annotation_data": ann}
    # 구버전 서버(204 + 빈 본문) 호환: 예외 없이 빈 보고서.
    assert out == {}


def test_client_patch_annotations_returns_server_report(requests_mock):
    requests_mock.post("http://nexus/api/v1/auth/login",
                       json={"token": "tok", "user_id": 1, "email": "u@x.com"})
    report = {
        "instances": 12,
        "skipped": 3,
        "skipped_reasons": {"missing_label": 2, "not_an_object": 1, "group_not_an_array": 0},
    }
    requests_mock.put(
        "http://nexus/datasets/d1/versions/v1/samples/s1/annotations",
        status_code=200, json=report,
    )

    from nexus.client import NexusClient
    client = NexusClient("http://nexus", "u@x.com", "pass")
    assert client.patch_annotations("d1", "v1", "s1", {"objects": []}) == report


def test_client_patch_annotations_tolerates_non_json_body(requests_mock):
    # 본문이 있는데 JSON이 아닌 경우에도 저장은 성공한 것이므로 예외를 던지지 않는다.
    requests_mock.post("http://nexus/api/v1/auth/login",
                       json={"token": "tok", "user_id": 1, "email": "u@x.com"})
    requests_mock.put(
        "http://nexus/datasets/d1/versions/v1/samples/s1/annotations",
        status_code=200, text="ok",
    )

    from nexus.client import NexusClient
    client = NexusClient("http://nexus", "u@x.com", "pass")
    assert client.patch_annotations("d1", "v1", "s1", {"objects": []}) == {}


# ── to_df ─────────────────────────────────────────────────────────────────────

_MANIFEST_KEY = "nexus-manifests/annotations/d1/v1.manifest.json"
_KID, _SECRET = "kid", "sec"


def _snapshot(host="http://cas", shard_hash=None, manifest_hash=None):
    """(get_manifest 응답, {SDK가 요청할 CAS 경로: 바이트}).

    해시는 seal과 같은 BLAKE3이고 URL은 서버 `object_url`의 모양(`{base}/{bucket}/{key}`)이다.
    `host`는 서버가 URL에 박는 CAS 주소 — SDK가 접속한 주소(`http://cas`)와 다를 수 있다.
    """
    shard = _ndjson_lines().encode()
    real_shard_hash = blake3.blake3(shard).hexdigest()
    shard_key = f"nexus-manifests/annotations/shards/{real_shard_hash}.ndjson"
    shard_manifest = json.dumps({
        "format": "sharded_ndjson", "shard_size": 10000, "total_samples": 2,
        "shards": [{
            "url": f"{host}/{shard_key}",
            "hash_hex": real_shard_hash if shard_hash is None else shard_hash,
            "count": 2,
        }],
    }).encode()
    manifest = {
        "annotation_snapshot": {
            "cas_url": f"{host}/{_MANIFEST_KEY}",
            "hash_hex": blake3.blake3(shard_manifest).hexdigest() if manifest_hash is None else manifest_hash,
        },
    }
    return manifest, {_MANIFEST_KEY: shard_manifest, shard_key: shard}


def _require_signature(body):
    """서명 없는 GET에는 cas처럼 403을 내는 응답 콜백 — 이 CAS는 익명 읽기를 받지 않는다."""
    def _cb(request, context):
        if not request.headers.get("Authorization", "").startswith("AWS4-HMAC-SHA256"):
            context.status_code = 403
            return b"<Error><Code>AccessDenied</Code></Error>"
        return body
    return _cb


def _register_snapshot(requests_mock, **kw):
    manifest, objects = _snapshot(**kw)
    for key, body in objects.items():
        requests_mock.get(f"http://cas/{key}", content=_require_signature(body))
    mock_client = MagicMock()
    mock_client.get_manifest.return_value = manifest
    return mock_client, objects


def _signed_cas():
    return CasClient("http://cas", key_id=_KID, secret=_SECRET)


def _ndjson_lines():
    return "\n".join([
        json.dumps({
            "sample_id": "s1",
            "meta": {"filename": "http://cas/img1.png", "width": 640},
            "road_obj_ma": [{"id": "i1", "label": "car", "confidence": 0.9}],
            "seatbelt": [{"id": "b1", "label": "on"}],
        }),
        json.dumps({
            "sample_id": "s2",
            "meta": {"filename": "http://cas/img2.png", "width": 800},
            "road_obj_ma": [{"id": "i2", "label": "truck"}],
            "seatbelt": [{"id": "b2", "label": "off"}],
        }),
    ]) + "\n"


def test_seal_propagates_nexus_error_when_already_sealed():
    mock_client = MagicMock()
    mock_client.seal.side_effect = NexusError(
        "409 Conflict — version already sealed",
        status_code=409, server_message="version already sealed",
    )
    ds = _ds(mock_client, MagicMock())
    with pytest.raises(NexusError, match="already sealed"):
        ds.seal()


def test_seal_if_sealed_ignore_returns_current_version():
    mock_client = MagicMock()
    mock_client.seal.side_effect = NexusError(
        "409 Conflict — version already sealed",
        status_code=409, server_message="version already sealed",
    )
    mock_client.get_version.return_value = {"version": "v1", "status": "sealed"}
    ds = _ds(mock_client, MagicMock())
    result = ds.seal(if_sealed="ignore")
    assert result == {"version": "v1", "status": "sealed"}
    mock_client.get_version.assert_called_once_with("d1", "v1")


def test_to_df_loads_ndjson_snapshot(requests_mock):
    """to_df()는 sealed 스냅샷 NDJSON을 그대로 DataFrame으로 싣는다 (manifest/samples 미사용)."""
    mock_client, _ = _register_snapshot(requests_mock)

    ds = _ds(mock_client, _signed_cas())
    df = ds.to_df()

    assert list(df["sample_id"]) == ["s1", "s2"]
    # NDJSON 원형 — meta + 모든 group_key가 컬럼
    assert {"sample_id", "meta", "road_obj_ma", "seatbelt"}.issubset(set(df.columns))
    assert df.loc[0, "meta"]["filename"] == "http://cas/img1.png"
    assert df.loc[0, "road_obj_ma"][0]["label"] == "car"
    assert df.loc[1, "seatbelt"][0]["label"] == "off"
    # 파일 refs 조인은 더 이상 하지 않는다
    mock_client.get_manifest_samples.assert_not_called()


def test_to_df_groups_filter(requests_mock):
    """groups=[...] 지정 시 그 group_key만(+ sample_id, meta) 싣는다."""
    mock_client, _ = _register_snapshot(requests_mock)

    ds = _ds(mock_client, _signed_cas())
    df = ds.to_df(groups=["seatbelt"])

    assert set(df.columns) == {"sample_id", "meta", "seatbelt"}
    assert "road_obj_ma" not in df.columns
    assert df.loc[0, "seatbelt"][0]["label"] == "on"


def test_to_df_raises_when_not_sealed():
    """annotation 스냅샷이 없으면(=draft) NexusError."""
    mock_client = MagicMock()
    mock_client.get_manifest.return_value = {"annotation_snapshot": None}

    ds = _ds(mock_client, MagicMock())
    with pytest.raises(NexusError, match="sealed"):
        ds.to_df()


def _sealed_ds(requests_mock):
    mock_client, _ = _register_snapshot(requests_mock)
    return _ds(mock_client, _signed_cas())


def test_to_df_saves_jsonl(requests_mock, tmp_path):
    ds = _sealed_ds(requests_mock)
    p = tmp_path / "gt.jsonl"
    df = ds.to_df(path=str(p))                       # 확장자로 jsonl 추론
    assert p.exists() and len(df) == 2
    lines = p.read_text(encoding="utf-8").strip().splitlines()
    assert len(lines) == 2
    assert json.loads(lines[0])["sample_id"] == "s1"


def test_to_df_saves_csv_serializes_nested(requests_mock, tmp_path):
    ds = _sealed_ds(requests_mock)
    p = tmp_path / "gt.csv"
    ds.to_df(groups=["seatbelt"], path=str(p))
    text = p.read_text(encoding="utf-8")
    assert "sample_id" in text and "seatbelt" in text
    # 중첩(list) 셀은 유효 JSON 문자열로 저장
    assert '[{""id"": ""b1""' in text or '[{"id": "b1"' in text


def test_to_df_save_unknown_extension_raises(requests_mock, tmp_path):
    ds = _sealed_ds(requests_mock)
    with pytest.raises(ValueError, match="format"):
        ds.to_df(path=str(tmp_path / "gt.xyz"))


def test_to_df_chunksize_streams_dataframes(requests_mock):
    """chunksize=N → ≤N행 DataFrame 이터레이터(전체를 한 번에 안 올림)."""
    ds = _sealed_ds(requests_mock)   # NDJSON 2행
    chunks = list(ds.to_df(chunksize=1))
    assert len(chunks) == 2
    assert all(len(c) == 1 for c in chunks)
    assert chunks[0].iloc[0]["sample_id"] == "s1"
    assert chunks[1].iloc[0]["sample_id"] == "s2"


def test_to_df_chunksize_with_path_raises(requests_mock, tmp_path):
    ds = _sealed_ds(requests_mock)
    with pytest.raises(ValueError, match="chunksize"):
        ds.to_df(chunksize=10, path=str(tmp_path / "gt.jsonl"))


def test_to_df_signs_snapshot_requests(requests_mock):
    """스냅샷 manifest와 샤드를 SDK의 CAS 자격증명으로 서명해 받는다.

    회귀: 예전에는 익명 GET이라 서명을 요구하는 CAS에서 seal은 되는데 to_df만 403이었다.
    `_register_snapshot`의 응답은 서명이 없으면 403이다.
    """
    ds = _sealed_ds(requests_mock)
    df = ds.to_df()

    assert len(df) == 2
    cas_requests = [r for r in requests_mock.request_history if r.hostname == "cas"]
    assert len(cas_requests) == 2
    for r in cas_requests:
        assert f"Credential={_KID}/" in r.headers["Authorization"]


def test_to_df_ignores_server_cas_host(requests_mock):
    """서버가 URL에 박은 CAS 호스트(클러스터 내부 주소 등)가 아니라 SDK가 접속한 cas_url로 받는다."""
    mock_client, _ = _register_snapshot(requests_mock, host="http://cas.internal.svc:8080")

    df = _ds(mock_client, _signed_cas()).to_df()

    assert list(df["sample_id"]) == ["s1", "s2"]
    assert all(r.hostname == "cas" for r in requests_mock.request_history)


def test_to_df_rejects_manifest_hash_mismatch(requests_mock):
    mock_client, _ = _register_snapshot(requests_mock, manifest_hash="0" * 64)

    with pytest.raises(NexusError, match="해시가 seal 때 기록된 값과 다릅니다"):
        _ds(mock_client, _signed_cas()).to_df()


def test_to_df_rejects_shard_hash_mismatch(requests_mock):
    mock_client, _ = _register_snapshot(requests_mock, shard_hash="0" * 64)

    with pytest.raises(NexusError, match="샤드의 해시가"):
        _ds(mock_client, _signed_cas()).to_df()


def test_to_df_skips_hash_check_when_hash_empty(requests_mock):
    """해시 없이 기록된 옛 버전(서버가 빈 문자열을 준다)은 대조 없이 읽는다."""
    mock_client, _ = _register_snapshot(requests_mock, manifest_hash="", shard_hash="")

    assert len(_ds(mock_client, _signed_cas()).to_df()) == 2


def test_to_df_404_explains_missing_object(requests_mock):
    manifest, _ = _snapshot()
    requests_mock.get(f"http://cas/{_MANIFEST_KEY}", status_code=404)
    mock_client = MagicMock()
    mock_client.get_manifest.return_value = manifest

    with pytest.raises(NexusError, match="객체가 CAS에 없습니다") as ei:
        _ds(mock_client, _signed_cas()).to_df()
    assert ei.value.status_code == 404


def test_to_df_403_reports_cas_reason_not_anonymous_read(requests_mock):
    """403이면 CAS의 거부 사유를 전하고, '익명 읽기 전제'로 안내하지 않는다."""
    manifest, _ = _snapshot()
    requests_mock.get(
        f"http://cas/{_MANIFEST_KEY}", status_code=403,
        content=b"<Error><Code>AccessDenied</Code></Error>",
    )
    mock_client = MagicMock()
    mock_client.get_manifest.return_value = manifest

    with pytest.raises(NexusError) as ei:
        _ds(mock_client, _signed_cas()).to_df()
    assert ei.value.status_code == 403
    assert "AccessDenied" in str(ei.value)
    assert "익명" not in str(ei.value)


def test_resolve_annotation_cas_ref_is_signed(requests_mock):
    """annotation을 CAS ref로 넘기는 경로도 서명해서 받는다."""
    requests_mock.get(
        "http://cas/bucket/anns/ann.json", content=_require_signature(b'{"objects": []}')
    )
    ds = _ds(MagicMock(), _signed_cas())

    assert ds._resolve_annotation(CasRef("bucket", "anns/ann.json")) == {
        "annotation_data": {"objects": []}
    }


def test_to_df_without_cas_client_explains_instead_of_attribute_error():
    """CAS 클라이언트 없이 만든 Dataset(`cas=None`)은 AttributeError 가 아니라 안내로 실패한다.

    0.1.12 까지 to_df 는 CAS 클라이언트를 쓰지 않아 이렇게 만든 핸들로도 동작했다.
    """
    manifest, _ = _snapshot()
    mock_client = MagicMock()
    mock_client.get_manifest.return_value = manifest

    with pytest.raises(NexusError, match="CAS 클라이언트가 없어"):
        _ds(mock_client, None).to_df()


def test_resolve_annotation_without_cas_client_explains():
    with pytest.raises(NexusError, match="CAS 클라이언트가 없어"):
        _ds(MagicMock(), None)._resolve_annotation(CasRef("bucket", "anns/ann.json"))


def test_snapshot_coords_strips_sdk_base_with_path_prefix():
    from nexus.dataset import _snapshot_coords

    assert _snapshot_coords("http://gw/cas/b/annotations/x.json", "http://gw/cas") == (
        "b", "annotations/x.json",
    )
    assert _snapshot_coords("http://other:9000/b/k/v.json", "http://gw/cas") == ("b", "k/v.json")
    with pytest.raises(NexusError):
        _snapshot_coords("http://other:9000/only-bucket", "http://gw/cas")


def test_client_get_manifest_samples_sends_get(requests_mock):
    requests_mock.post("http://nexus/api/v1/auth/login",
                       json={"token": "tok", "user_id": 1, "email": "u@x.com"})
    page = {"samples": [{"sample_id": "s1"}], "next_cursor": "cur2"}
    requests_mock.get("http://nexus/datasets/d1/versions/v1/manifest/samples", json=page)

    from nexus.client import NexusClient
    client = NexusClient("http://nexus", "u@x.com", "pass")
    out = client.get_manifest_samples("d1", "v1", cursor="cur1", limit=500)

    assert out == page
    assert requests_mock.last_request.method == "GET"
    assert requests_mock.last_request.qs["cursor"] == ["cur1"]
    assert requests_mock.last_request.qs["limit"] == ["500"]


# ── batch ingest endpoint ──────────────────────────────────────────────────────

def test_flush_uses_batch_endpoint():
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_client = MagicMock(); mock_client.ingest_batch.return_value = _batch_ok(3)

    ds = _ds(mock_client, mock_cas)
    for i in range(3):
        ref = CasRef("kitti", f"images/{i}.png", hash_hex="h", size=10, content_type="image/png")
        ann = {"meta": {"format_version": "1.0.0", "filename": f"http://cas/kitti/images/{i}.png",
                        "width": 4, "height": 4}}
        ds.add(Sample(image=ref, annotation=ann))

    results = ds.flush(workers=1, verbose=False)

    assert mock_client.ingest_batch.call_count == 1
    assert len(mock_client.ingest_batch.call_args[0][0]) == 3
    assert len(results) == 3
    assert all(r.ok for r in results)
    mock_cas.head.assert_not_called()


def test_flush_chunks_by_batch_size():
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_client = MagicMock()
    mock_client.ingest_batch.side_effect = [_batch_ok(2), _batch_ok(1)]

    ds = _ds(mock_client, mock_cas)
    for i in range(3):
        ref = CasRef("kitti", f"images/{i}.png", hash_hex="h", size=10, content_type="image/png")
        ann = {"meta": {"format_version": "1.0.0", "filename": f"http://cas/kitti/images/{i}.png",
                        "width": 4, "height": 4}}
        ds.add(Sample(image=ref, annotation=ann))

    results = ds.flush(workers=1, batch_size=2, verbose=False)

    assert mock_client.ingest_batch.call_count == 2
    assert len(results) == 3
    assert all(r.ok for r in results)


def test_flush_maps_results_by_index_out_of_order():
    """서버가 결과를 뒤바뀐 순서로 줘도 index로 올바른 sample에 매핑한다."""
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_client = MagicMock()
    mock_client.ingest_batch.return_value = {"results": [
        {"index": 1, "sample_id": "sid-1"},
        {"index": 0, "sample_id": "sid-0"},
    ]}

    ds = _ds(mock_client, mock_cas)
    for i in range(2):
        ref = CasRef("kitti", f"images/{i}.png", hash_hex="h", size=10, content_type="image/png")
        ann = {"meta": {"format_version": "1.0.0", "filename": f"http://cas/kitti/images/{i}.png",
                        "width": 4, "height": 4}}
        ds.add(Sample(image=ref, annotation=ann))

    results = ds.flush(workers=1, verbose=False)

    assert len(results) == 2
    assert results[0].ok and results[0].sample_id == "sid-0"  # chunk pos 0
    assert results[1].ok and results[1].sample_id == "sid-1"  # chunk pos 1


def test_flush_missing_index_in_response_marks_item_failed():
    """서버 응답에 빠진 index가 있으면 해당 sample은 실패로 기록(드롭 금지)."""
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_client = MagicMock()
    mock_client.ingest_batch.return_value = {"results": [{"index": 0, "sample_id": "sid-0"}]}

    ds = _ds(mock_client, mock_cas)
    for i in range(2):
        ref = CasRef("kitti", f"images/{i}.png", hash_hex="h", size=10, content_type="image/png")
        ann = {"meta": {"format_version": "1.0.0", "filename": f"http://cas/kitti/images/{i}.png",
                        "width": 4, "height": 4}}
        ds.add(Sample(image=ref, annotation=ann))

    results = ds.flush(workers=1, verbose=False)

    assert len(results) == 2  # 누락돼도 drop되지 않음
    assert results[0].ok and results[0].sample_id == "sid-0"
    assert not results[1].ok and results[1].error


def test_client_ingest_batch_posts(requests_mock):
    requests_mock.post("http://nexus/api/v1/auth/login",
                       json={"token": "tok", "user_id": 1, "email": "u@x.com"})
    results = {"results": [{"index": 0, "sample_id": "s0", "dataset_id": "d1"}]}
    requests_mock.post("http://nexus/ingest/batch", json=results)

    from nexus.client import NexusClient
    client = NexusClient("http://nexus", "u@x.com", "pass")
    items = [{"dataset": "kitti", "version": "v1", "image": {}, "annotation": {}}]
    out = client.ingest_batch(items)

    assert requests_mock.last_request.method == "POST"
    assert requests_mock.last_request.json() == {"items": items}
    assert out == results


def test_get_sample_delegates_to_client():
    client = MagicMock()
    client.get_sample.return_value = {"sample_id": "s1", "meta": {}}
    ds = Dataset(client, MagicMock(), "d1", "kitti", "v1")
    out = ds.get_sample("s1")
    client.get_sample.assert_called_once_with("d1", "v1", "s1")
    assert out["meta"] == {}
    assert "annotation" not in out


def test_get_annotation_gets_correct_path_and_returns_body_as_is():
    # 코어 필드가 섞이지 않고 서버 응답을 그대로 반환해야 save_annotation의 입력이 된다.
    client = MagicMock()
    body = {"meta": {"scene": "night"}, "objects": [{"id": "o1", "label": "car"}]}
    client.get_sample_annotations.return_value = body
    ds = _ds(client, MagicMock())
    out = ds.get_annotation("s1")
    client.get_sample_annotations.assert_called_once_with("d1", "v1", "s1")
    assert out is body


def _clean_report(instances: int = 1) -> dict:
    return {
        "instances": instances,
        "skipped": 0,
        "skipped_reasons": {"missing_label": 0, "not_an_object": 0, "group_not_an_array": 0},
    }


def test_save_annotation_sends_dict_unchanged_via_low_level_client():
    # Dataset.patch_annotations(오버로드된 벌크용)이 아니라 저수준 client.patch_annotations를
    # 직접 호출해야 한다 — 단일 샘플 경로가 애매해지면 안 된다.
    client = MagicMock()
    client.patch_annotations.return_value = _clean_report()
    ds = _ds(client, MagicMock())
    ann = {"meta": {"scene": "night"}, "objects": [{"id": "o1", "label": "car"}]}
    out = ds.save_annotation("s1", ann)
    client.patch_annotations.assert_called_once_with("d1", "v1", "s1", ann)
    assert out == _clean_report()


def test_save_annotation_returns_server_report():
    client = MagicMock()
    report = {
        "instances": 12,
        "skipped": 3,
        "skipped_reasons": {"missing_label": 2, "not_an_object": 1, "group_not_an_array": 0},
    }
    client.patch_annotations.return_value = report
    ds = _ds(client, MagicMock())
    import warnings as _w
    with _w.catch_warnings():
        _w.simplefilter("ignore")
        out = ds.save_annotation("s1", {"objects": []})
    assert out == report


def test_save_annotation_warns_when_something_was_skipped():
    # 스킵은 "안 들어감"이 아니라 "원래 있던 것이 지워짐"이다 — 반환값만으로는 부족하다.
    import pytest
    client = MagicMock()
    client.patch_annotations.return_value = {
        "instances": 1,
        "skipped": 2,
        "skipped_reasons": {"missing_label": 2, "not_an_object": 0, "group_not_an_array": 0},
    }
    ds = _ds(client, MagicMock())
    with pytest.warns(RuntimeWarning, match="missing_label=2"):
        ds.save_annotation("s1", {"objects": []})


def test_save_annotation_does_not_warn_when_nothing_skipped():
    import warnings as _w
    client = MagicMock()
    client.patch_annotations.return_value = _clean_report(3)
    ds = _ds(client, MagicMock())
    with _w.catch_warnings(record=True) as caught:
        _w.simplefilter("always")
        ds.save_annotation("s1", {"objects": []})
    assert [w for w in caught if issubclass(w.category, RuntimeWarning)] == []


def test_save_annotation_does_not_warn_on_legacy_empty_report():
    # 구버전 서버(204 + 빈 본문)에서는 보고서가 {} 다 — 유실을 주장할 근거가 없다.
    import warnings as _w
    client = MagicMock()
    client.patch_annotations.return_value = {}
    ds = _ds(client, MagicMock())
    with _w.catch_warnings(record=True) as caught:
        _w.simplefilter("always")
        out = ds.save_annotation("s1", {"objects": []})
    assert out == {}
    assert [w for w in caught if issubclass(w.category, RuntimeWarning)] == []


def test_save_annotation_warns_when_no_group_keys():
    # 서버 0.1.18부터 그룹 키 없는 저장은 인스턴스를 건드리지 않는다 — 모르고 있으면
    # "지웠는데 왜 그대로냐"로 놀랄 수 있어 경고한다.
    import pytest
    client = MagicMock()
    client.patch_annotations.return_value = _clean_report(0)
    ds = _ds(client, MagicMock())
    with pytest.warns(RuntimeWarning, match="그룹 키 없이"):
        ds.save_annotation("s1", {"meta": {"scene": "night"}})
    with pytest.warns(RuntimeWarning, match="그룹 키 없이"):
        ds.save_annotation("s1", {})


def test_save_annotation_does_not_warn_when_a_group_key_is_present():
    import warnings as _w
    client = MagicMock()
    client.patch_annotations.return_value = _clean_report(1)
    ds = _ds(client, MagicMock())
    with _w.catch_warnings(record=True) as caught:
        _w.simplefilter("always")
        ds.save_annotation("s1", {"objects": [], "meta": {}})
    assert [w for w in caught if issubclass(w.category, RuntimeWarning)] == []


def test_patch_annotations_single_warns_when_no_group_keys():
    import pytest
    client = MagicMock()
    client.patch_annotations.return_value = _clean_report(0)
    ds = _ds(client, MagicMock())
    with pytest.warns(RuntimeWarning, match="그룹 키 없이"):
        ds.patch_annotations("s1", {"meta": {"w": 1}})


def test_patch_annotations_batch_warns_per_groupless_sample():
    import pytest
    client = MagicMock()
    client.patch_annotations.return_value = _clean_report(0)
    ds = _ds(client, MagicMock())
    with pytest.warns(RuntimeWarning, match="그룹 키 없이") as record:
        results = ds.patch_annotations(
            {"s1": {"meta": {}}, "s2": {"objects": []}}, workers=1, verbose=False
        )
    assert all(r.ok for r in results)
    # s1만 그룹 키가 없다 — 경고는 s1에 대해서만 났어야 한다.
    msgs = [str(w.message) for w in record.list if issubclass(w.category, RuntimeWarning)]
    assert any("sample s1" in m for m in msgs)
    assert not any("sample s2" in m for m in msgs)


def test_get_annotation_then_save_annotation_roundtrip_carries_the_edit():
    client = MagicMock()
    client.get_sample_annotations.return_value = {
        "meta": {"scene": "night"},
        "objects": [{"id": "o1", "label": "car"}],
    }
    ds = _ds(client, MagicMock())

    ann = ds.get_annotation("s1")
    ann["objects"].append({"id": "o2", "label": "person"})
    ds.save_annotation("s1", ann)

    sent = client.patch_annotations.call_args[0][3]
    assert len(sent["objects"]) == 2
    assert sent["objects"][1]["label"] == "person"
    assert sent["meta"] == {"scene": "night"}  # meta는 왕복에서도 그대로 함께 실린다


def test_transfer_owner_delegates_to_low_level_client():
    # 편의 메서드는 dataset_id 를 채워 저수준 client 를 부르기만 한다 — version 은 걸리지
    # 않는다(소유권은 dataset 단위다).
    mock_client = MagicMock()
    updated = {"dataset_id": "d1", "name": "kitti", "owner_user_id": 9}
    mock_client.transfer_dataset_owner.return_value = updated
    ds = _ds(mock_client, MagicMock())

    out = ds.transfer_owner("new-owner@int2.us")

    mock_client.transfer_dataset_owner.assert_called_once_with("d1", "new-owner@int2.us")
    assert out == updated


def test_unlink_samples_calls_client():
    mock_client = MagicMock()
    mock_client.remove_sample_ids.return_value = {"removed": 3}
    ds = _ds(mock_client, MagicMock())
    out = ds.unlink_samples(["a", "b", "c"])
    mock_client.remove_sample_ids.assert_called_once_with("d1", "v1", ["a", "b", "c"])
    assert out["removed"] == 3


def test_samples_builds_single_annotation_filter():
    mock_client = MagicMock()
    mock_client.explore_samples.return_value = [{"sample_id": "s1"}]
    ds = _ds(mock_client, MagicMock())

    out = ds.samples(group_key="det", label="car", confidence_min=0.5, track_id=3)

    mock_client.explore_samples.assert_called_once_with(
        "d1", "v1", cursor=None, limit=1000,
        split=None, tags=None, exclude_tags=None, meta=None,
        annotation=[{"group_key": "det", "label": "car",
                     "confidence": {"min": 0.5, "max": None}, "track_id": 3}],
        include_annotations=True, sample_ids=None,
    )
    assert out == [{"sample_id": "s1"}]


def test_samples_no_filters_passes_none():
    mock_client = MagicMock()
    mock_client.explore_samples.return_value = []
    ds = _ds(mock_client, MagicMock())

    ds.samples(split="train", tags=["night"], meta={"width": {"type": "range", "min": 1}})

    mock_client.explore_samples.assert_called_once_with(
        "d1", "v1", cursor=None, limit=1000,
        split="train", tags=["night"], exclude_tags=None,
        meta={"width": {"type": "range", "min": 1}},
        annotation=None, include_annotations=True, sample_ids=None,
    )


def test_samples_filters_by_sample_ids():
    mock_client = MagicMock()
    mock_client.explore_samples.return_value = [{"sample_id": "s1"}]
    ds = _ds(mock_client, MagicMock())

    out = ds.samples(sample_ids=["s1", "s2"])

    mock_client.explore_samples.assert_called_once_with(
        "d1", "v1", cursor=None, limit=1000,
        split=None, tags=None, exclude_tags=None, meta=None,
        annotation=None, include_annotations=True, sample_ids=["s1", "s2"],
    )
    assert out == [{"sample_id": "s1"}]


def test_samples_limit_and_after_map_to_client_params_single_page():
    mock_client = MagicMock()
    mock_client.explore_samples.return_value = [{"sample_id": f"s{i}"} for i in range(3)]
    ds = _ds(mock_client, MagicMock())

    out = ds.samples(label="car", limit=3, after="s98")

    assert len(out) == 3
    mock_client.explore_samples.assert_called_once_with(
        "d1", "v1", cursor="s98", limit=3,
        split=None, tags=None, exclude_tags=None, meta=None,
        annotation=[{"label": "car"}], include_annotations=True, sample_ids=None,
    )


def test_samples_no_limit_auto_paginates_across_pages():
    mock_client = MagicMock()
    page1 = [{"sample_id": f"s{i}"} for i in range(1000)]  # 가득 찬 페이지 → 계속
    page2 = [{"sample_id": "s-last"}]  # 미만 → 종료
    mock_client.explore_samples.side_effect = [page1, page2]
    ds = _ds(mock_client, MagicMock())

    out = ds.samples(label="car")

    assert out == page1 + page2
    calls = mock_client.explore_samples.call_args_list
    assert len(calls) == 2
    assert calls[0].kwargs["cursor"] is None
    assert calls[0].kwargs["limit"] == 1000
    assert calls[1].kwargs["cursor"] == "s999"  # page1의 마지막 sample_id


def test_samples_no_limit_starts_pagination_from_after_cursor():
    mock_client = MagicMock()
    mock_client.explore_samples.return_value = [{"sample_id": "s1"}]
    ds = _ds(mock_client, MagicMock())

    ds.samples(after="s50")

    mock_client.explore_samples.assert_called_once_with(
        "d1", "v1", cursor="s50", limit=1000,
        split=None, tags=None, exclude_tags=None, meta=None,
        annotation=None, include_annotations=True, sample_ids=None,
    )


def test_import_samples_calls_client():
    mock_client = MagicMock()
    mock_client.import_samples.return_value = {
        "imported": [{"source_sample_id": "s1", "sample_id": "s1-copy"}]
    }
    ds = _ds(mock_client, MagicMock())
    out = ds.import_samples("d-source", "v0", ["s1"])
    mock_client.import_samples.assert_called_once_with("d1", "v1", "d-source", "v0", ["s1"])
    assert out["imported"][0]["sample_id"] == "s1-copy"


def test_update_renames_dataset_and_updates_local_handle():
    mock_client = MagicMock()
    mock_client.update_dataset.return_value = {"dataset_id": "d1", "name": "kitti-renamed"}
    ds = _ds(mock_client, MagicMock())

    ds.update(name="kitti-renamed")

    mock_client.update_dataset.assert_called_once_with("d1", name="kitti-renamed", description=None)
    assert ds._name == "kitti-renamed"


def test_update_description_only_does_not_touch_local_name():
    mock_client = MagicMock()
    mock_client.update_dataset.return_value = {"dataset_id": "d1", "name": "kitti", "description": "new desc"}
    ds = _ds(mock_client, MagicMock())

    ds.update(description="new desc")

    mock_client.update_dataset.assert_called_once_with("d1", name=None, description="new desc")
    assert ds._name == "kitti"  # name= 안 줬으니 로컬 핸들은 그대로


def _clone_mock_client(tags=None, description=None):
    """구서버(clone-job 없음) 폴백 경로용 mock. `create_clone_job` 을 404 로 둬야 한다 —
    그대로 두면 MagicMock 이 job 을 돌려주고, 끝나지 않는 job 을 폴링하느라 테스트가 멈춘다."""
    mock_client = MagicMock()
    mock_client.create_clone_job.side_effect = NexusError("not found", status_code=404)
    mock_client.get_dataset.return_value = {"tags": tags, "description": description}
    mock_client.list_datasets.return_value = []  # 새 dataset 이름은 아직 없음
    mock_client.create_dataset.return_value = {"dataset_id": "d2"}
    mock_client.get_version.return_value = None  # 새 버전도 아직 없음
    mock_client.create_version.return_value = {"dataset_version_id": "dv2", "version": "v0"}
    mock_client.import_samples.return_value = {"imported": []}
    return mock_client


def _fork_mock_client():
    mock_client = MagicMock()
    mock_client.list_datasets.return_value = [{"dataset_id": "d1", "name": "kitti"}]
    mock_client.get_version.return_value = None  # 새 버전은 아직 없음
    mock_client.create_version.return_value = {"dataset_version_id": "dv2", "version": "v2"}
    return mock_client


def test_fork_no_filter_forks_whole_version():
    mock_client = _fork_mock_client()
    ds = _ds(mock_client, MagicMock())

    new_ds = ds.fork("v2")

    mock_client.explore_samples.assert_not_called()
    mock_client.create_version.assert_called_once_with(
        "d1", "v2", fork_from="v1", sample_ids=None
    )
    assert new_ds._dataset_id == "d1"
    assert new_ds._version == "v2"


def test_fork_with_filter_collects_all_matching_ids_across_pages():
    mock_client = _fork_mock_client()
    page1 = [{"sample_id": f"s{i}"} for i in range(1000)]  # samples()의 내부 page_size(1000)만큼 가득
    page2 = [{"sample_id": "s-last"}]
    mock_client.explore_samples.side_effect = [page1, page2]
    ds = _ds(mock_client, MagicMock())

    ds.fork("v2", label="car")

    calls = mock_client.explore_samples.call_args_list
    assert calls[0].kwargs["cursor"] is None
    assert calls[1].kwargs["cursor"] == "s999"  # page1의 마지막 sample_id
    mock_client.create_version.assert_called_once_with(
        "d1", "v2", fork_from="v1",
        sample_ids=[f"s{i}" for i in range(1000)] + ["s-last"],
    )


def test_fork_raises_when_filter_matches_nothing():
    mock_client = _fork_mock_client()
    mock_client.explore_samples.return_value = []
    ds = _ds(mock_client, MagicMock())

    with pytest.raises(ValueError):
        ds.fork("v2", label="nonexistent")

    mock_client.create_version.assert_not_called()


def test_fork_sample_ids_filter_passed_through():
    mock_client = _fork_mock_client()
    mock_client.explore_samples.return_value = [{"sample_id": "s1"}, {"sample_id": "s2"}]
    ds = _ds(mock_client, MagicMock())

    ds.fork("v2", sample_ids=["s1", "s2"])

    mock_client.explore_samples.assert_called_once_with(
        "d1", "v1", cursor=None, limit=1000,
        split=None, tags=None, exclude_tags=None, meta=None,
        annotation=None, include_annotations=False, sample_ids=["s1", "s2"],
    )
    mock_client.create_version.assert_called_once_with(
        "d1", "v2", fork_from="v1", sample_ids=["s1", "s2"]
    )


def test_clone_copies_tags_description_and_creates_new_dataset():
    mock_client = _clone_mock_client(tags=["a", "b"], description="orig")
    mock_client.get_manifest_samples.return_value = {
        "samples": [{"sample_id": "s1"}, {"sample_id": "s2"}], "next_cursor": None,
    }
    ds = _ds(mock_client, MagicMock())

    new_ds = ds.clone("kitti-copy", "v0", verbose=False)

    mock_client.create_dataset.assert_called_once_with("kitti-copy", tags=["a", "b"], description="orig")
    mock_client.import_samples.assert_called_once_with("d2", "v0", "d1", "v1", ["s1", "s2"])
    assert new_ds._dataset_id == "d2"
    assert new_ds._version == "v0"


def test_clone_chunks_large_sample_list_by_batch_size():
    mock_client = _clone_mock_client()
    sample_ids = [f"s{i}" for i in range(5)]
    mock_client.get_manifest_samples.return_value = {
        "samples": [{"sample_id": sid} for sid in sample_ids], "next_cursor": None,
    }
    ds = _ds(mock_client, MagicMock())

    ds.clone("kitti-copy", "v0", batch_size=2, verbose=False)

    calls = mock_client.import_samples.call_args_list
    assert [c.args[4] for c in calls] == [["s0", "s1"], ["s2", "s3"], ["s4"]]


def test_clone_empty_source_creates_dataset_without_importing():
    mock_client = _clone_mock_client()
    mock_client.get_manifest_samples.return_value = {"samples": [], "next_cursor": None}
    ds = _ds(mock_client, MagicMock())

    ds.clone("kitti-copy", "v0", verbose=False)

    mock_client.import_samples.assert_not_called()


def test_resolve_delete_cas_explicit_and_nontty():
    from nexus.dataset import _resolve_delete_cas
    assert _resolve_delete_cas(True, "x") is True
    assert _resolve_delete_cas(False, "x") is False
    # None + 비대화형(pytest stdin은 tty 아님) → False(보존)
    assert _resolve_delete_cas(None, "x") is False


def test_delete_confirm_true_calls_delete_version():
    mock_client = MagicMock()
    mock_client.delete_version.return_value = {"version": "v1", "samples_deleted": 1, "dataset_deleted": False}
    ds = _ds(mock_client, MagicMock())
    ds.delete(confirm=True, delete_cas=False)
    mock_client.delete_version.assert_called_once_with("d1", "v1", "v1", delete_cas=False)


def test_delete_confirm_string_passthrough():
    mock_client = MagicMock()
    ds = _ds(mock_client, MagicMock())
    ds.delete(confirm="v1", delete_cas=True)
    mock_client.delete_version.assert_called_once_with("d1", "v1", "v1", delete_cas=True)


def test_delete_confirm_none_nontty_raises():
    ds = _ds(MagicMock(), MagicMock())
    with pytest.raises(ValueError):
        ds.delete()             # confirm=None + 비대화형 → 에러
    with pytest.raises(ValueError):
        ds.delete(confirm=False)


def test_delete_confirm_none_prompt_yes(monkeypatch):
    # Jupyter처럼 input()이 되는 환경: _prompt가 "y" 반환 → 진행
    import nexus.dataset as nd
    monkeypatch.setattr(nd, "_prompt", lambda q: "y")
    mock_client = MagicMock()
    mock_client.delete_version.return_value = {"dataset_deleted": False}
    ds = _ds(mock_client, MagicMock())
    ds.delete(delete_cas=False)
    mock_client.delete_version.assert_called_once_with("d1", "v1", "v1", delete_cas=False)


def test_delete_confirm_none_prompt_no_cancels(monkeypatch):
    import nexus.dataset as nd
    monkeypatch.setattr(nd, "_prompt", lambda q: "n")
    mock_client = MagicMock()
    ds = _ds(mock_client, MagicMock())
    out = ds.delete(delete_cas=False)
    assert out == {"cancelled": True}
    mock_client.delete_version.assert_not_called()


def test_favorite_unfavorite_call_client():
    mock_client = MagicMock()
    ds = _ds(mock_client, MagicMock())
    ds.favorite()
    mock_client.add_favorite.assert_called_once_with("d1")
    ds.unfavorite()
    mock_client.remove_favorite.assert_called_once_with("d1")


def test_create_subset_returns_subset():
    from nexus.dataset import Subset
    mock_client = MagicMock()
    mock_client.create_subset.return_value = {
        "subset_id": "s1", "name": "a", "version": "v1", "filter_json": {}}
    ds = _ds(mock_client, MagicMock())
    sub = ds.create_subset("a", {"meta": {}})
    assert isinstance(sub, Subset) and sub.subset_id == "s1"
    mock_client.create_subset.assert_called_once_with("d1", "v1", "a", {"meta": {}})


def test_subset_samples_paginates():
    from nexus.dataset import Subset
    mock_client = MagicMock()
    mock_client.subset_samples.side_effect = [
        [{"sample_id": str(i)} for i in range(1000)],
        [{"sample_id": "x"}, {"sample_id": "y"}, {"sample_id": "z"}],
    ]
    ds = _ds(mock_client, MagicMock())
    sub = Subset(ds, {"subset_id": "s1", "name": "a", "version": "v1", "filter_json": {}})
    got = sub.samples()
    assert len(got) == 1003
    assert mock_client.subset_samples.call_count == 2


def test_subset_update_delete():
    from nexus.dataset import Subset
    mock_client = MagicMock()
    mock_client.update_subset.return_value = {
        "subset_id": "s1", "name": "b", "version": "v1", "filter_json": {"x": 1}}
    ds = _ds(mock_client, MagicMock())
    sub = Subset(ds, {"subset_id": "s1", "name": "a", "version": "v1", "filter_json": {}})
    sub.update(name="b")
    assert sub.name == "b"
    sub.delete()
    mock_client.delete_subset.assert_called_once_with("s1")


def test_diff_calls_client():
    mock_client = MagicMock()
    mock_client.version_diff.return_value = {"base": "v0", "target": "v1"}
    ds = _ds(mock_client, MagicMock())
    ds.diff()
    mock_client.version_diff.assert_called_once_with("d1", "v1", against=None)


# ── flush: 권한 실패는 삼키지 않는다 ────────────────────────────────────────────

def _denied_batch(n: int, code: int = 403, msg: str = "forbidden"):
    return {"results": [{"index": i, "error": msg, "status": code} for i in range(n)]}


def _one_sample():
    ref = CasRef("kitti", "images/a.png", hash_hex="h", size=10, content_type="image/png")
    ann = {"meta": {"format_version": "1.0.0", "filename": "http://cas/kitti/images/a.png",
                    "width": 4, "height": 4}}
    return Sample(image=ref, annotation=ann)


def test_flush_raises_on_403_even_when_not_strict():
    """기본값(strict=False)에서 조용히 넘어가면 CI가 아무것도 적재하지 않고 성공한 것처럼 보인다."""
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_client = MagicMock(); mock_client.ingest_batch.return_value = _denied_batch(2)
    ds = _ds(mock_client, mock_cas)
    ds.add([_one_sample(), _one_sample()])
    with pytest.raises(NexusError) as exc:
        ds.flush(workers=1, verbose=False)          # strict 기본값 False
    assert exc.value.status_code == 403
    # 무엇을 해야 하는지 알려줘야 한다 — "forbidden" 한 단어로는 원인을 못 짚는다.
    assert "editor" in str(exc.value)


def test_flush_raises_on_401_with_reconnect_hint():
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_client = MagicMock()
    mock_client.ingest_batch.return_value = _denied_batch(1, code=401, msg="unauthorized")
    ds = _ds(mock_client, mock_cas)
    ds.add(_one_sample())
    with pytest.raises(NexusError) as exc:
        ds.flush(workers=1, verbose=False)
    assert exc.value.status_code == 401
    assert "connect()" in str(exc.value)


def test_flush_still_tolerates_per_item_data_errors():
    """400(데이터 문제)은 종전대로 건별 결과로만 남는다 — 부분 성공을 유지해야 한다."""
    mock_cas = MagicMock(); mock_cas._base = "http://cas"
    mock_client = MagicMock()
    mock_client.ingest_batch.return_value = {
        "results": [
            {"index": 0, "sample_id": "s1"},
            {"index": 1, "error": "annotation_data must be object", "status": 400},
        ]
    }
    ds = _ds(mock_client, mock_cas)
    ds.add([_one_sample(), _one_sample()])
    results = ds.flush(workers=1, verbose=False)     # 예외 없이 반환
    assert [r.ok for r in results].count(True) == 1
    assert [r.ok for r in results].count(False) == 1
    assert results[1].status_code == 400 or results[0].status_code == 400


def test_samples_forwards_exclude_tags():
    mock_client = MagicMock()
    mock_client.explore_samples.return_value = []
    ds = _ds(mock_client, MagicMock())

    ds.samples(tags=["train"], exclude_tags=["blurry"])

    kwargs = mock_client.explore_samples.call_args.kwargs
    assert kwargs["tags"] == ["train"]
    assert kwargs["exclude_tags"] == ["blurry"]


def test_fork_treats_exclude_tags_alone_as_a_filter():
    """exclude_tags만 준 fork가 전체를 복사하면 안 된다.

    `has_filter` 판정에서 이 인자를 빠뜨리면 필터가 조용히 무시되고 fork가 원본 전체를
    담는다 — 사용자는 제외된 줄 알고 쓰게 된다.
    """
    mock_client = MagicMock()
    mock_client.explore_samples.return_value = [{"sample_id": "s1"}]
    ds = _ds(mock_client, MagicMock())

    with patch.object(Dataset, "load_or_create") as load_or_create:
        ds.fork("v2", exclude_tags=["blurry"])

    mock_client.explore_samples.assert_called()
    assert mock_client.explore_samples.call_args.kwargs["exclude_tags"] == ["blurry"]
    assert load_or_create.call_args.kwargs["sample_ids"] == ["s1"]


# ── dataset.py ↔ client.py 시그니처 정합 ─────────────────────────────
#
# 이 파일의 다른 테스트는 `MagicMock()`을 쓰는데, 그것은 **어떤 kwargs든 받아준다** —
# `dataset.py`가 `client.py`에 없는 인자를 넘겨도 통과한다. 실제로 `exclude_tags`가
# `explore_samples`의 시그니처에서 빠진 채 발행돼(0.1.7) `ds.samples()` 호출이 전부
# TypeError였는데, mock 기반 테스트 전부가 초록이었다. `create_autospec`은 시그니처를
# 검사하므로 같은 어긋남을 잡는다.


def _autospec_client():
    client = create_autospec(NexusClient, instance=True)
    client.explore_samples.return_value = []
    return client


def test_samples_kwargs_are_accepted_by_the_real_client_signature():
    ds = _ds(_autospec_client(), MagicMock())
    # 필터를 하나도 안 줘도 dataset.py는 모든 kwarg를 명시적으로 넘긴다 —
    # 하나라도 실제 시그니처에 없으면 여기서 TypeError가 난다.
    ds.samples()
    ds.samples(
        sample_ids=["s1"], group_key="det", label="car",
        confidence_min=0.1, confidence_max=0.9, track_id=3,
        split="train", tags=["train"], exclude_tags=["blurry"],
        meta={"width": {"type": "range", "min": 100}},
        include_annotations=False, limit=10, after="s0",
    )


def test_fork_kwargs_are_accepted_by_the_real_client_signature():
    client = _autospec_client()
    client.explore_samples.return_value = [{"sample_id": "s1"}]
    ds = _ds(client, MagicMock())
    with patch.object(Dataset, "load_or_create"):
        ds.fork("v2", tags=["train"], exclude_tags=["blurry"], split="train")


# ---------------------------------------------------------------------------
# 그룹 종류 선언이 파생 핸들(fork·clone·to_version)로 이어진다
# ---------------------------------------------------------------------------

KINDS = {"dets": "container", "merged": "group"}


def _declared(ds):
    ds.declare_group_kinds(KINDS)
    return ds


def test_fork_carries_group_kinds_as_a_copy():
    ds = _declared(_ds(_fork_mock_client(), MagicMock()))
    new_ds = ds.fork("v2")
    assert new_ds._group_kinds == KINDS
    new_ds.declare_group_kinds({"extra": "group"})
    assert "extra" not in ds._group_kinds  # 공유가 아니라 복사


def test_clone_server_job_carries_group_kinds(monkeypatch):
    mock_client = MagicMock()
    ds = _declared(_ds(mock_client, MagicMock()))
    done = {"job_id": "j1", "status": "succeeded", "copied_count": 1, "total_count": 1,
            "target_dataset_id": "d2", "target_name": "copy", "target_version": "v2"}
    mock_client.create_clone_job.return_value = done
    monkeypatch.setattr("nexus.dataset.time.sleep", lambda _s: None)
    out = ds.clone("copy", "v2", verbose=False)
    assert out._group_kinds == KINDS


def test_clone_fallback_carries_group_kinds():
    ds = _declared(_ds(_clone_mock_client(), MagicMock()))
    with patch.object(Dataset, "list_samples", lambda self, **k: []):
        out = ds.clone("copy", "v0", verbose=False)
    assert out._group_kinds == KINDS


def test_subset_to_version_carries_group_kinds():
    from nexus.dataset import Subset
    mock_client = MagicMock()
    mock_client.materialize_subset.return_value = {"version": "v3"}
    ds = _declared(_ds(mock_client, MagicMock()))
    sub = Subset(ds, {"subset_id": "s1", "name": "a", "version": "v1", "filter_json": {}})
    out = sub.to_version("v3")
    assert out._group_kinds == KINDS



# ---------------------------------------------------------------------------
# 릴리스 리뷰 권고 항목
# ---------------------------------------------------------------------------

def test_clone_does_not_fall_back_when_server_says_source_missing():
    """0.1.18+ 서버가 JSON 으로 404(원본 없음)를 주면 폴백하지 않는다 — 폴백하면 빈 대상
    dataset 만 만들고 실패해 고아가 남는다."""
    mock_client = MagicMock()
    ds = _ds(mock_client, MagicMock())
    mock_client.create_clone_job.side_effect = NexusError(
        "not found", status_code=404, server_message="dataset version not found")
    with pytest.raises(NexusError) as ei:
        ds.clone("copy", "v2", verbose=False)
    assert ei.value.status_code == 404
    mock_client.create_dataset.assert_not_called()


def test_clone_falls_back_on_html_404_from_a_proxy(monkeypatch):
    mock_client = MagicMock()
    ds = _ds(mock_client, MagicMock())
    mock_client.create_clone_job.side_effect = NexusError(
        "not found", status_code=404, server_message="<html><body>404 Not Found</body></html>")
    new_ds = MagicMock()
    monkeypatch.setattr(Dataset, "load_or_create", classmethod(lambda cls, *a, **k: new_ds))
    monkeypatch.setattr(Dataset, "list_samples", lambda self, **k: [])
    assert ds.clone("copy", "v2", verbose=False) is new_ds


def test_clone_poll_error_carries_job_id(monkeypatch):
    mock_client = MagicMock()
    ds = _ds(mock_client, MagicMock())
    mock_client.create_clone_job.return_value = {"job_id": "j-42", "status": "running"}
    mock_client.get_clone_job.side_effect = NexusError("bad gateway", status_code=502)
    monkeypatch.setattr("nexus.dataset.time.sleep", lambda _s: None)
    with pytest.raises(NexusError) as ei:
        ds.clone("copy", "v2", verbose=False)
    assert "j-42" in str(ei.value) and ei.value.status_code == 502


def test_load_or_create_rejects_bad_group_kinds_before_creating_anything():
    mock_client = MagicMock()
    with pytest.raises(ValueError):
        Dataset.load_or_create("x", "v0", group_kinds={"dets": "bad"},
                               client=mock_client, cas=MagicMock())
    mock_client.list_datasets.assert_not_called()
    mock_client.create_dataset.assert_not_called()
    mock_client.create_version.assert_not_called()
