import pytest
from pathlib import Path
from nexus.sample import CasRef, Sample, _parse_ref


def test_parse_local_path_string():
    ref = _parse_ref("data/img.png")
    assert isinstance(ref, Path)
    assert ref == Path("data/img.png")


def test_parse_local_path_object():
    ref = _parse_ref(Path("data/img.png"))
    assert isinstance(ref, Path)


def test_parse_s3_url():
    ref = _parse_ref("s3://my-bucket/images/img.png")
    assert isinstance(ref, CasRef)
    assert ref.bucket == "my-bucket"
    assert ref.key == "images/img.png"


def test_parse_s3_nested_key():
    ref = _parse_ref("s3://bucket/a/b/c/file.json")
    assert ref.bucket == "bucket"
    assert ref.key == "a/b/c/file.json"


def test_sample_rejects_local_path_image():
    with pytest.raises(ValueError, match="nx.upload"):
        Sample(image="img.png", annotation="ann.json")


def test_sample_rejects_local_path_in_assets():
    with pytest.raises(ValueError, match="nx.upload"):
        Sample(image="s3://b/img.png", assets={"depth": "depth.png"})


def test_sample_annotation_path_still_allowed():
    # annotation은 로컬 JSON 경로/URL 허용 (이미지/asset만 CAS ref 전용)
    s = Sample(image="s3://b/img.png", annotation="ann.json")
    assert isinstance(s._image_ref, CasRef)
    assert isinstance(s._annotation_ref, Path)
    assert s._asset_refs == {}


def test_sample_s3_refs():
    s = Sample(image="s3://b/img.png", annotation="s3://b/ann.json")
    assert isinstance(s._image_ref, CasRef)
    assert isinstance(s._annotation_ref, CasRef)


def test_sample_assets_multiple_roles():
    s = Sample(
        image="s3://b/img.png", annotation="ann.json",
        assets={"depth": "s3://b/depth.png", "thermal": "s3://b/th.png"},
    )
    assert set(s._asset_refs.keys()) == {"depth", "thermal"}
    assert s._asset_refs["depth"].bucket == "b"
    assert s._asset_refs["depth"].key == "depth.png"
    assert s._asset_refs["thermal"].key == "th.png"


def test_sample_assets_reserved_image_key_raises():
    with pytest.raises(ValueError, match="'image'"):
        Sample(image="s3://b/img.png", assets={"image": "s3://b/other.png"})


def test_sample_split_and_tags():
    s = Sample(image="s3://b/img.png", annotation="ann.json", split="train", tags=["highway", "night"])
    assert s.split == "train"
    assert s.tags == ["highway", "night"]


def test_sample_coerces_str_tag_to_list():
    # tags="x" 문자열을 넘기면 ["x"]로 자동 변환.
    s = Sample(image="s3://b/img.png", tags="rainy")
    assert s.tags == ["rainy"]


def test_parse_http_url():
    ref = _parse_ref("http://192.168.50.78:8080/lg-incabin/img/file.bmp")
    assert isinstance(ref, CasRef)
    assert ref.bucket == "lg-incabin"
    assert ref.key == "img/file.bmp"


def test_parse_https_url():
    ref = _parse_ref("https://cas.example.com/mybucket/path/to/img.png")
    assert isinstance(ref, CasRef)
    assert ref.bucket == "mybucket"
    assert ref.key == "path/to/img.png"


def test_sample_http_url_sets_cas_ref():
    s = Sample(image="http://192.168.50.78:8080/lg-incabin/img/file.bmp")
    assert isinstance(s._image_ref, CasRef)
    assert s._image_ref.bucket == "lg-incabin"
    assert s._image_ref.key == "img/file.bmp"


def test_sample_annotation_only_sets_none_image_ref():
    s = Sample(annotation="http://cas/anns/ann.json")
    assert s._image_ref is None
    assert isinstance(s._annotation_ref, CasRef)


def test_sample_no_image_no_annotation_raises():
    with pytest.raises(ValueError, match="image.*annotation"):
        Sample()


def test_parse_http_url_decodes_percent_encoding():
    # 브라우저에서 복사한 URL 처럼 key 가 인코딩돼 있으면 풀어서 원래 key 로 쓴다 — 안 풀면
    # CAS 서명이 한 번 더 인코딩해(%20 → %2520) 엉뚱한 객체를 찾는다. 서버가 key 에 '%' 를
    # 금지하므로 경로의 %XX 는 항상 인코딩이라 풀어도 모호하지 않다.
    ref = _parse_ref("http://cas:8080/b/space%20dir/%ED%95%9C%EA%B8%80%20a%2Bb.png")
    assert (ref.bucket, ref.key) == ("b", "space dir/한글 a+b.png")


def test_parse_http_url_raw_key_unchanged():
    ref = _parse_ref("http://cas:8080/b/space dir/한글 a+b.png")
    assert (ref.bucket, ref.key) == ("b", "space dir/한글 a+b.png")


def test_parse_s3_url_decodes_percent_encoding():
    ref = _parse_ref("s3://b/a%20b.png")
    assert (ref.bucket, ref.key) == ("b", "a b.png")
