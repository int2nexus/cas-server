"""Test that annotation object layer symbols are exposed at package top level."""
import nexus as nx


def test_public_symbols_exposed():
    """Verify that all annotation object layer symbols are exported from nexus package."""
    for name in [
        "AnnotatedSample",
        "LabelGroup",
        "LabelContainer",
        "RawGroup",
        "Instance",
        "Meta",
        "Label",
        "Detection",
        "Keypoint2D",
        "Keypoint3D",
        "Classification",
        "ScalarValue",
        "VectorValue",
        "Cuboid3D",
        "Polygon",
        "Polyline",
        "NexusValidationError",
    ]:
        assert hasattr(nx, name), f"nexus.{name} not exported"
