"""샘플 태그·크기 보정의 버전 경로 선택(서버 설계 2026-10-30-version-scoped-sample-fields 7-1).

서버 `VERSION_PATHS_MIN_SERVER` 이상이면 `/datasets/{id}/versions/{v}/...` 경로를, 그 미만이거나 `X-Nexus-Version` 이
없는 옛 파드면 옛 경로(`/samples/tags`·`/samples/dimensions`)를 쓴다. 옛 경로가 410 을 주면(새 서버인데 판을 아직
못 본 경우) 그 자리에서 새 경로로 바꾸고 판을 기억한다.
"""
from unittest.mock import MagicMock

import pytest

from nexus._types import NexusError
from nexus.annotated import AnnotatedSample
from nexus.cas import CasClient
from nexus.client import VERSION_PATHS_MIN_SERVER, NexusClient
from nexus.dataset import Dataset

BASE = "http://nexus"
VER = f"{BASE}/datasets/d1/versions/v1"
NEW = "0.1.37"
OLD = "0.1.36"


@pytest.fixture
def client(requests_mock):
    requests_mock.post(f"{BASE}/api/v1/auth/login", json={"token": "tok", "user_id": 1, "email": "u@x.com"})
    return NexusClient(BASE, "u@x.com", "pass")


def _see_server(client, requests_mock, version):
    """인증된 응답 하나를 받아 서버 판을 기억시킨다."""
    headers = {"X-Nexus-Version": version} if version else {}
    requests_mock.get(f"{BASE}/datasets/d1/versions/v1", json={"version": "v1", "status": "draft"}, headers=headers)
    client.get_version("d1", "v1")


def test_min_server_constant_is_a_release_triple():
    assert VERSION_PATHS_MIN_SERVER == (0, 1, 37)


def test_new_server_uses_version_tag_paths(client, requests_mock):
    _see_server(client, requests_mock, NEW)
    add = requests_mock.post(f"{VER}/samples/tags/items", json=[{"sample_id": "s1", "tags": ["a"]}])
    rm = requests_mock.delete(f"{VER}/samples/tags/items", json=[{"sample_id": "s1", "tags": []}])
    client.add_tags_bulk(["s1"], ["a"], dataset_id="d1", version="v1")
    client.remove_tags_bulk(["s1"], ["a"], dataset_id="d1", version="v1")
    assert add.last_request.json() == {"sample_ids": ["s1"], "tags": ["a"]}
    assert rm.last_request.json() == {"sample_ids": ["s1"], "tags": ["a"]}


def test_new_server_uses_version_dimensions_path(client, requests_mock):
    _see_server(client, requests_mock, NEW)
    dims = requests_mock.patch(f"{VER}/samples/dimensions", json={"results": [{"sample_id": "s1", "ok": True}]})
    out = client.set_sample_dimensions(
        [{"sample_id": "s1", "width": 8, "height": 6}], overwrite=True, dataset_id="d1", version="v1",
    )
    assert out == [{"sample_id": "s1", "ok": True}]
    assert dims.last_request.json() == {"items": [{"sample_id": "s1", "width": 8, "height": 6}], "overwrite": True}


@pytest.mark.parametrize("version", [None, OLD])
def test_old_or_unversioned_server_uses_old_paths(client, requests_mock, version):
    _see_server(client, requests_mock, version)
    add = requests_mock.post(f"{BASE}/samples/tags", json=[{"sample_id": "s1"}])
    dims = requests_mock.patch(f"{BASE}/samples/dimensions", json={"results": []})
    client.add_tags_bulk(["s1"], ["a"], dataset_id="d1", version="v1")
    client.set_sample_dimensions([{"sample_id": "s1", "width": 8, "height": 6}], dataset_id="d1", version="v1")
    assert add.called and dims.called


def test_without_dataset_and_version_keeps_old_path(client, requests_mock):
    """옛 호출 모양(`add_tags_bulk(ids, tags)`)은 그대로 옛 경로로 간다."""
    _see_server(client, requests_mock, NEW)
    add = requests_mock.post(f"{BASE}/samples/tags", json=[{"sample_id": "s1"}])
    client.add_tags_bulk(["s1"], ["a"])
    assert add.called


def test_gone_from_old_path_switches_to_version_path_and_remembers(client, requests_mock):
    """판을 보기 전에 새 서버의 옛 경로를 불러 410 을 받으면 새 경로로 다시 보내고 판을 기억한다."""
    old = requests_mock.post(
        f"{BASE}/samples/tags", status_code=410,
        json={"error": "버전 경로를 쓰십시오: /datasets/{dataset_id}/versions/{version}/samples/tags/items"},
        headers={"X-Nexus-Version": NEW},
    )
    new = requests_mock.post(f"{VER}/samples/tags/items", json=[{"sample_id": "s1"}])
    client.add_tags_bulk(["s1"], ["a"], dataset_id="d1", version="v1")
    assert old.call_count == 1 and new.call_count == 1
    # 410 응답의 헤더로 판을 알았으므로 다음 호출은 처음부터 새 경로다.
    client.add_tags_bulk(["s1"], ["b"], dataset_id="d1", version="v1")
    assert old.call_count == 1 and new.call_count == 2


def test_gone_without_dataset_and_version_is_raised(client, requests_mock):
    requests_mock.post(f"{BASE}/samples/tags", status_code=410, json={"error": "버전 경로를 쓰십시오: x"})
    with pytest.raises(NexusError) as ei:
        client.add_tags_bulk(["s1"], ["a"])
    assert ei.value.status_code == 410


def test_annotated_sample_save_sends_tags_to_version_path_on_new_server(client, requests_mock):
    _see_server(client, requests_mock, NEW)
    add = requests_mock.post(f"{VER}/samples/tags/items", json=[{"sample_id": "s1", "tags": ["a", "c"]}])
    ds = Dataset(client, CasClient("http://cas"), "d1", "kitti", "v1")
    s = AnnotatedSample.from_row(
        {"sample_id": "s1", "tags": ["a"], "split": None, "meta": {}}, {}, dataset=ds,
    )
    s.tags.append("c")
    s.save()
    assert add.last_request.json() == {"sample_ids": ["s1"], "tags": ["c"]}
    assert s.tags == ["a", "c"]


def test_backfill_dims_passes_dataset_and_version(monkeypatch):
    import sys
    import nexus.probe  # noqa: F401 - 서브모듈을 sys.modules 에 올린다(패키지 속성 `probe` 는 함수로 덮여 있다)
    from nexus.sample import CasRef

    client = MagicMock()
    client.set_sample_dimensions.return_value = [{"sample_id": "s1", "ok": True}]
    cas = MagicMock()
    cas._base = "http://cas"
    ds = Dataset(client, cas, "d1", "kitti", "v1")
    monkeypatch.setattr(
        sys.modules["nexus.probe"], "probe",
        lambda refs, **kw: [CasRef(bucket=r.bucket, key=r.key, width=8, height=6) for r in refs],
    )
    monkeypatch.setattr(Dataset, "samples", lambda self, **kw: [
        {"sample_id": "s1", "split": None, "tags": [], "meta": {}, "image_url": "http://cas/kitti/a.png"}
    ])
    ds.backfill_dims(verbose=False)
    kw = client.set_sample_dimensions.call_args.kwargs
    assert kw["dataset_id"] == "d1" and kw["version"] == "v1"
