"""통째 교체 저장의 안전장치(SDK 0.1.25, follow-ups 24 절 3·8번).

- `save_annotation()` 은 기본으로 `meta` 를 보내지 않는다 — 받은 meta 를 그대로 돌려보내면 그 사이 다른 곳에서 바꾼 값을 되돌린다.
- 행 모양(`sample_id` 등 코어 키가 배열이 아닌 값)의 dict 는 통째 교체에 넣지 않는다.
- `samples(include_annotations=False)` 의 행은 읽기 전용 `SampleSummary` 이고 저장 메서드가 받지 않는다.
"""
import warnings

import pytest

import nexus as nx
from nexus import AnnotatedSample, NexusValidationError, SampleSummary
from nexus.cas import CasClient
from nexus.client import NexusClient
from nexus.dataset import Dataset

BASE = "http://nexus"
VER = f"{BASE}/datasets/d1/versions/v1"
ANN = f"{VER}/samples/s1/annotations"
REPORT = {"instances": 1, "skipped": 0,
          "skipped_reasons": {"missing_label": 0, "not_an_object": 0, "group_not_an_array": 0}}
DET = [{"id": "a", "label": "car", "bounding_box": {"type": "bounding_box", "rect": [0, 0, 1, 1]}}]


@pytest.fixture
def ds(requests_mock):
    requests_mock.post(f"{BASE}/api/v1/auth/login",
                       json={"token": "tok", "user_id": 1, "email": "u@x.com"})
    return Dataset(NexusClient(BASE, "u@x.com", "pass"), CasClient("http://cas"), "d1", "kitti", "v1")


# ── 3. meta 는 replace_meta=True 일 때만 ─────────────────────────────────────────

def test_save_annotation_drops_meta_by_default_and_warns_once(ds, requests_mock):
    m = requests_mock.put(ANN, json=REPORT)
    with pytest.warns(RuntimeWarning, match="replace_meta=True") as rec:
        ds.save_annotation("s1", {"meta": {"w": 1}, "det": DET})
        ds.save_annotation("s1", {"meta": {"w": 2}, "det": DET})
    assert len([w for w in rec if "replace_meta" in str(w.message)]) == 1
    assert m.request_history[0].json() == {"annotation_data": {"det": DET}}
    assert m.request_history[1].json() == {"annotation_data": {"det": DET}}


def test_save_annotation_does_not_mutate_callers_dict(ds, requests_mock):
    requests_mock.put(ANN, json=REPORT)
    ann = {"meta": {"w": 1}, "det": DET}
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        ds.save_annotation("s1", ann)
    assert ann == {"meta": {"w": 1}, "det": DET}


def test_save_annotation_replace_meta_sends_meta(ds, requests_mock):
    m = requests_mock.put(ANN, json=REPORT)
    with warnings.catch_warnings():
        warnings.simplefilter("error")
        ds.save_annotation("s1", {"meta": {"w": 1}, "det": DET}, replace_meta=True)
    assert m.last_request.json() == {"annotation_data": {"meta": {"w": 1}, "det": DET}}


def test_save_annotation_without_meta_does_not_warn(ds, requests_mock):
    requests_mock.put(ANN, json=REPORT)
    with warnings.catch_warnings():
        warnings.simplefilter("error")
        ds.save_annotation("s1", {"det": DET})


def test_annotated_sample_put_fallback_sends_meta_only_when_changed(ds, requests_mock):
    # 부분 저장이 없는 옛 서버(405)의 통째 PUT 폴백 — meta 를 고쳤을 때만 싣는다.
    requests_mock.get(ANN, json={"meta": {"w": 1}, "det": DET})
    requests_mock.patch(ANN, status_code=405, json={"error": "method not allowed"})
    put = requests_mock.put(ANN, json=REPORT)
    s = AnnotatedSample.from_dict({"meta": {"w": 1}, "det": DET}, {"det": "group"}, sample_id="s1", dataset=ds)
    s.get_group("det")[0].label = "bus"
    with pytest.warns(RuntimeWarning, match="통째 교체"):
        s.save()
    assert "meta" not in put.last_request.json()["annotation_data"]
    s.meta["w"] = 5
    s.save()
    assert put.last_request.json()["annotation_data"]["meta"] == {"w": 5}


# ── 8. 행 모양 dict·SampleSummary 거부 ───────────────────────────────────────────

@pytest.mark.parametrize("method", ["save_annotation", "patch_annotations"])
def test_put_paths_reject_row_shaped_dict(ds, requests_mock, method):
    m = requests_mock.put(ANN, json=REPORT)
    row = {"sample_id": "s1", "split": None, "tags": [], "meta": {}, "det": DET}
    with pytest.raises(NexusValidationError, match="sample_id"):
        getattr(ds, method)("s1", row)
    assert not m.called


def test_merge_annotation_rejects_row_shaped_dict(ds, requests_mock):
    m = requests_mock.patch(ANN, json=REPORT)
    with pytest.raises(NexusValidationError, match="sample_id"):
        ds.merge_annotation("s1", {"sample_id": "s1", "det": DET})
    assert not m.called


def test_group_named_like_a_core_key_still_round_trips(ds, requests_mock):
    # 그룹 이름에 예약어 제한이 없다 — `tags` 라는 그룹은 배열이라 통과해야 한다.
    m = requests_mock.put(ANN, json=REPORT)
    ds.save_annotation("s1", {"tags": DET, "det": DET})
    assert m.last_request.json() == {"annotation_data": {"tags": DET, "det": DET}}


def test_patch_annotations_batch_reports_row_shaped_item_as_failure(ds, requests_mock):
    requests_mock.put(ANN, json=REPORT)
    with pytest.warns(RuntimeWarning, match="1건 중 1건"):
        out = ds.patch_annotations({"s1": {"sample_id": "s1", "det": DET}}, verbose=False)
    assert not out[0].ok and "sample_id" in out[0].error


def test_lightweight_rows_are_read_only_sample_summaries(ds, requests_mock):
    requests_mock.post(f"{VER}/samples/explorer", json=[{"sample_id": "s1", "split": None, "tags": ["a"]}])
    (row,) = ds.samples(include_annotations=False)
    assert isinstance(row, SampleSummary) and isinstance(row, dict)
    assert row["tags"] == ["a"] and dict(row) == {"sample_id": "s1", "split": None, "tags": ["a"]}
    for mutate in (lambda r: r.__setitem__("det", DET), lambda r: r.update(det=DET),
                   lambda r: r.pop("tags"), lambda r: r.setdefault("det", DET), lambda r: r.clear(),
                   lambda r: r.__delitem__("tags"), lambda r: r.popitem()):
        with pytest.raises(TypeError, match="읽기 전용"):
            mutate(row)
    assert dict(row) == {"sample_id": "s1", "split": None, "tags": ["a"]}


def test_full_rows_stay_plain_dicts(ds, requests_mock):
    requests_mock.post(f"{VER}/samples/explorer", json=[{"sample_id": "s1", "det": DET}])
    (row,) = ds.samples()
    assert type(row) is dict


@pytest.mark.parametrize("method", ["save_annotation", "patch_annotations", "merge_annotation"])
def test_save_methods_reject_sample_summary(ds, requests_mock, method):
    put = requests_mock.put(ANN, json=REPORT)
    patch = requests_mock.patch(ANN, json=REPORT)
    with pytest.raises(TypeError, match="include_annotations=False"):
        getattr(ds, method)("s1", SampleSummary({"sample_id": "s1"}))
    assert not put.called and not patch.called


def test_from_row_rejects_sample_summary():
    with pytest.raises(TypeError, match="include_annotations=False"):
        AnnotatedSample.from_row(SampleSummary({"sample_id": "s1", "tags": []}), {})


def test_sample_summary_is_public():
    assert "SampleSummary" in nx.__all__


def test_sample_summary_survives_copy_and_pickle():
    import copy
    import pickle
    r = SampleSummary({"sample_id": "s1", "tags": ["a"]})
    for c in (copy.copy(r), copy.deepcopy(r), pickle.loads(pickle.dumps(r))):
        assert isinstance(c, SampleSummary) and c == r


def test_sample_summary_read_only_is_top_level_only():
    # 안쪽 값은 일반 dict·list 로 둔다 — isinstance·json 직렬화를 깨지 않는다. 읽기 전용은 최상위 키뿐이다.
    import copy
    import json
    r = SampleSummary({"sample_id": "s1", "tags": ["a"], "meta": {"w": 1}})
    assert type(r["meta"]) is dict and type(r["tags"]) is list
    assert json.loads(json.dumps(r)) == {"sample_id": "s1", "tags": ["a"], "meta": {"w": 1}}
    deep = copy.deepcopy(dict(r))
    deep["meta"]["w"] = 2
    assert r["meta"] == {"w": 1}


# ── 서버 0.1.30 의 형식 거절(400) ─────────────────────────────────────────────

BAD_GROUP = {"error": "group 'det'[0] must have a string 'label'"}


@pytest.mark.parametrize("method,verb", [
    ("save_annotation", "put"), ("patch_annotations", "put"), ("merge_annotation", "patch"),
])
def test_server_400_on_annotation_write_is_validation_error(ds, requests_mock, method, verb):
    getattr(requests_mock, verb)(ANN, status_code=400, json=BAD_GROUP)
    with pytest.raises(NexusValidationError) as ei:
        getattr(ds, method)("s1", {"det": [{"id": "a"}]})
    e = ei.value
    # NexusError 의 하위라 status_code 로 가르던 코드는 그대로 동작한다.
    assert isinstance(e, nx.NexusError)
    assert e.status_code == 400
    assert e.server_message == BAD_GROUP["error"]
    assert isinstance(e.__cause__, nx.NexusError)


@pytest.mark.parametrize("status", [404, 409, 422])
def test_other_server_errors_on_annotation_write_stay_nexus_error(ds, requests_mock, status):
    requests_mock.put(ANN, status_code=status, json={"error": "x"})
    with pytest.raises(nx.NexusError) as ei:
        ds.save_annotation("s1", {"det": DET})
    assert not isinstance(ei.value, NexusValidationError)
    assert ei.value.status_code == status


def test_old_server_skip_still_warns(ds, requests_mock):
    # 0.1.29 이하 서버는 버리고 skipped 로 센다 — 옛 서버 호환으로 경고를 남긴다.
    requests_mock.put(ANN, json={"instances": 0, "skipped": 1,
                                 "skipped_reasons": {"missing_label": 1}})
    with pytest.warns(RuntimeWarning, match="저장되지 않았습니다"):
        ds.save_annotation("s1", {"det": [{"id": "a"}]})


def test_patch_annotations_batch_warns_once_on_failures(ds, requests_mock):
    requests_mock.put(ANN, json=REPORT)
    requests_mock.put(f"{VER}/samples/s2/annotations", status_code=400, json=BAD_GROUP)
    requests_mock.put(f"{VER}/samples/s3/annotations", status_code=400, json=BAD_GROUP)
    with pytest.warns(RuntimeWarning, match="patch_annotations") as rec:
        results = ds.patch_annotations({"s1": {"det": DET}, "s2": {"det": [{}]}, "s3": {"det": [{}]}},
                                       verbose=False)
    msgs = [str(w.message) for w in rec if "patch_annotations" in str(w.message)]
    assert len(msgs) == 1
    assert "3건 중 2건" in msgs[0] and "s2, s3" in msgs[0] and "must have a string 'label'" in msgs[0]
    assert [r.ok for r in results] == [True, False, False]
    assert [r.status_code for r in results] == [None, 400, 400]


def test_patch_annotations_batch_without_failures_does_not_warn(ds, requests_mock):
    requests_mock.put(ANN, json=REPORT)
    with warnings.catch_warnings():
        warnings.simplefilter("error")
        results = ds.patch_annotations({"s1": {"det": DET}}, verbose=False)
    assert results[0].ok


def test_patch_annotations_batch_strict_raises_without_warning(ds, requests_mock):
    requests_mock.put(ANN, status_code=400, json=BAD_GROUP)
    with warnings.catch_warnings():
        warnings.simplefilter("error")
        with pytest.raises(nx.NexusBatchError) as ei:
            ds.patch_annotations({"s1": {"det": [{}]}}, strict=True, verbose=False)
    assert ei.value.failures[0].status_code == 400


def test_patch_annotations_batch_warning_lists_at_most_five_ids(ds, requests_mock):
    ids = [f"s{i}" for i in range(1, 8)]
    for sid in ids:
        requests_mock.put(f"{VER}/samples/{sid}/annotations", status_code=400, json=BAD_GROUP)
    with pytest.warns(RuntimeWarning, match="외 2건"):
        ds.patch_annotations({sid: {"det": [{}]} for sid in ids}, verbose=False)
